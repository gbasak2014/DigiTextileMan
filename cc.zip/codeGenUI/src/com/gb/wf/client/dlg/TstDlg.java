package com.gb.wf.client.dlg;

import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextArea;

public class TstDlg extends SdpDialogBox {
	TextArea ta = new TextArea();

	Label lbl = new Label("Hello...");

	public TstDlg(String str) {
		super(false, false);
		DockLayoutPanel dp = new DockLayoutPanel(Unit.EM);
		
		setText("Test Dialog");
		setSize("500px", "500px");
		dp.setSize("500px", "500px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		
		ta.setVisibleLines(20);
		ta.setWidth("400px");		
		ta.setText(str);
		
		dp.add(ta);
		Button btn = new Button("Click", new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				hideMe();
			}
		});
		
		dp.addSouth(btn, 30);
		
	
		add(dp);
	}

	void hideMe() {
		this.hide();
	}
}
