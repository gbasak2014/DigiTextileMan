package com.gb.wf.client.dlg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.gb.wf.client.ControllerService;
import com.gb.wf.client.ControllerServiceAsync;
import com.gb.wf.client.component.DFConstants;
import com.gb.wf.client.component.WFDesignerPage;
import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.widget.CustomAction;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.TextAlign;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class ServiceAddDlg extends SdpDialogBox {
	public static String SERVICE = "service";
	public static String UDF = "udf";

	TextBox txtName = new TextBox();
	TextArea taDesc = new TextArea();

	TextArea taConde = new TextArea();
	Map<TextBox, ListBox> inParams = new HashMap<TextBox, ListBox>();
	List<ColumnDto> retType = new ArrayList<ColumnDto>();

	VerticalPanel pnlInputParams = new VerticalPanel();

	CustomAction widget;
	List<String> lstDataType = new ArrayList<String>();

	private final ControllerServiceAsync service = GWT.create(ControllerService.class);
	WFDesignerPage designerPage;

	String type;
	List<TextBox> paramList = new ArrayList<TextBox>();
	long projectId;

	ListBox lstParamsAvail = new ListBox();
	
	public ServiceAddDlg(CustomAction widget, WFDesignerPage designerPage, String type, long projectId) {
		super(false, false);
		this.widget = widget;
		this.designerPage = designerPage;
		this.type = type;
		this.projectId = projectId;

		int w = Window.getClientWidth() - 50;
		int h = Window.getClientHeight() - 50;

		String wpx = w + "px";
		String hpx = h + "px";
		this.setSize(wpx, hpx);
		this.setStyleName("gwt-DialogBox");
		this.setText("Common Sefvice");
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize(wpx, hpx);
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		HorizontalPanel hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		Label lbl = new Label("Name:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtName.setStyleName("textBox");
		this.txtName.setWidth("300px");

		Button btnSave = new Button("Save");
		Button btnClose = new Button("Close");
		Button btnImport = new Button("Import Packages");
		Button btnRet = new Button("Define Return Schema");
		lbl.getElement().getStyle().setFloat(Float.RIGHT);
		btnSave.getElement().getStyle().setFloat(Float.RIGHT);
		btnClose.getElement().getStyle().setFloat(Float.RIGHT);
		btnImport.getElement().getStyle().setFloat(Float.RIGHT);
		btnRet.getElement().getStyle().setFloat(Float.RIGHT);

		hp.add(lbl);
		hp.add(this.txtName);
		hp.add(btnImport);
		hp.add(btnRet);
		hp.add(btnSave);
		hp.add(btnClose);
		dp.addNorth(hp, 35);

		hp = new HorizontalPanel();
		hp.add(new Label("Description"));
		this.taDesc.setWidth((w - 100) + "px");
		hp.add(this.taDesc);
		dp.addNorth(hp, 50);

		this.lstParamsAvail.addItem("Implicite Variables");
		this.lstParamsAvail.addItem("sparkContext: SparkContext");
		this.lstParamsAvail.addItem("hiveContext: HiveContext");

		Button btnAddInput = new Button("Add Input Parameters");
		pnlInputParams.add(this.lstParamsAvail);
		pnlInputParams.add(btnAddInput);
		dp.addWest(pnlInputParams, 200);

		this.taConde.setWidth((w - 200) + "px");
		this.taConde.setHeight((h - 50) + "px");
		dp.add(this.taConde);
		this.taConde.setText("//TODO - Write process code (Scala/Java)\n");
		btnAddInput.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				addInputParams();
			}
		});

		btnSave.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processSave();
			}
		});

		btnClose.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processClose();
			}
		});
		btnImport.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				addImport();
			}
		});
		btnRet.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				viewRetSchemaDlg();
			}
		});

		this.add(dp);
		this.initComponens();
	}

	void initComponens() {
		populateDataTypes();
	}

	void populateDataTypes() {
		service.getSourceConfig(new AsyncCallback<String>() {
			@Override
			public void onSuccess(String data) {
				addDataTypes(data);
			}

			@Override
			public void onFailure(Throwable arg0) {
				Window.alert("Server ERROR!!!");
			}
		});
	}

	void addImport() {
		ImportDlg dlg = new ImportDlg(this.widget);

		dlg.setTitle("Import Packages");
		dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
		dlg.center();
		dlg.show();
	}

	void viewRetSchemaDlg() {
		SchemaDlg dlg = new SchemaDlg(this.widget, this.lstDataType, "service".equalsIgnoreCase(this.type));

		dlg.setTitle("Define Return Schema");
		dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
		dlg.center();
		dlg.show();
	}

	void addDataTypes(String data) {
		JSONObject json = JSONParser.parseStrict(data).isObject();

		JSONArray arr = json.get("dataTypes").isArray();
		for (int i = 0; i < arr.size(); i++) {
			this.lstDataType.add(arr.get(i).isString().stringValue());
		}
	}

	void addInputParams() {
		ListBox lstDt = new ListBox();
		for (String dt : this.lstDataType) {
			lstDt.addItem(dt);
		}
		TextBox txt = new TextBox();
		txt.setWidth("100px");
		HorizontalPanel hp = new HorizontalPanel();
		hp.add(txt);
		hp.add(lstDt);

		this.inParams.put(txt, lstDt);
		this.pnlInputParams.add(hp);
		this.paramList.add(txt);
	}

	void processSave() {
		JSONObject req = new JSONObject();
		req.put("name", new JSONString(this.txtName.getText()));
		req.put("description", new JSONString(this.taDesc.getText()));
		req.put("type", new JSONString(this.type));
		req.put("code", new JSONString(this.taConde.getText()));
		req.put("returnCategory", new JSONString(this.widget.getRetCategory()));
		req.put("returnType", this.widget.getFieldsJSON());
		req.put("projectId", new JSONNumber(this.projectId));

		JSONArray arr = new JSONArray();
		int i = 0;
		for (Entry<TextBox, ListBox> kv : this.inParams.entrySet()) {
			String pType = kv.getValue().getItemText(kv.getValue().getSelectedIndex());
			String pName = kv.getKey().getText();
			JSONObject rt = new JSONObject();
			rt.put("type", new JSONString(pType));
			rt.put("name", new JSONString(pName));
			rt.put("pos", new JSONNumber(i));
			arr.set(i, rt);
			i++;
		}
		req.put("params", arr);
		List<String> list = this.widget.getImports();
		if (list.size() <= 0) {
			list.add("java.text.SimpleDateFormat");
			list.add("java.util._");
			list.add("org.apache.spark.sql._");
			list.add("org.apache.spark.sql.types._");
			list.add("org.apache.spark.sql.hive._");
			list.add("org.apache.spark.sql.functions._");
		}
		StringBuffer sb = new StringBuffer();
		for (String imp : list) {
			if (sb.length() > 0) {
				sb.append(",");
			}
			sb.append(imp);
		}
		req.put("imports", new JSONString(sb.toString()));
		this.designerPage.showProgress("Adding service...");
		this.service.saveService(req.toString(), new AsyncCallback<String>() {

			@Override
			public void onSuccess(String res) {
				designerPage.stopProgress();
				JSONObject jo = JSONParser.parseStrict(res).isObject();
				Window.alert(jo.get("data").isString().stringValue());
				processClose();
			}

			@Override
			public void onFailure(Throwable arg0) {
				designerPage.stopProgress();
				Window.alert("ERROR adding service!!");
				processClose();
			}
		});
	}

	void processClose() {
		this.hide();
	}
}
