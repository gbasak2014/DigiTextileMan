package com.gb.wf.client.dlg;

import java.util.List;

import com.gb.wf.client.component.SourceColumnTable;
import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.widget.DataFrame;
import com.gb.wf.client.widget.SDPWidget;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextBox;

public class DataFramePropDlg extends SdpDialogBox {
	TextBox txtName = new TextBox();
	DataFrame widget;

	SourceColumnTable columnTable;

	public DataFramePropDlg(SDPWidget widget) {
		super(false, false);
		this.widget = (DataFrame) widget;

		this.setSize("750px", "400px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Filter Properties for " + widget.getName());
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("750px", "400px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		FlowPanel fp = new FlowPanel();
		Label lbl = new Label("Name");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.txtName.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(lbl);
		fp.add(this.txtName);
		dp.addNorth(fp, 30);

		this.columnTable = new SourceColumnTable(this.widget.getDataTypeList());
		dp.add(this.columnTable);

		fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.add(dp);
		this.initComponens();
	}

	void initComponens() {
		this.txtName.setText(this.widget.getName());
		List<ColumnDto> list = this.widget.getFields();
		for (ColumnDto dto : list) {
			this.columnTable.insertRow(dto.getName(), dto.getDataType(), dto.getSensitiveFlag());
		}
	}

	void processOk() {
		this.widget.setName(this.txtName.getText());
		List<ColumnDto> list = this.widget.getFields();
		list.clear();
		
		int pos=0;
		for (ColumnDto cd : this.columnTable.getColumnList())
		{
			ColumnDto c = new ColumnDto();
			c.setDataType(cd.getDataType());
			c.setId(-1);
			c.setName(cd.getName());
			c.setSensitiveFlag(cd.getSensitiveFlag());
			c.setPos(pos);
			list.add(c);
			pos++;
		}

		this.hide();
	}

	void processCancel() {
		this.hide();
	}
}
