package com.gb.wf.client.dlg;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.SourceHBase;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.TextAlign;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;

public class SourceHBasePropDlg extends SdpDialogBox {
	TextBox txtName = new TextBox();
	TextBox txtTable = new TextBox();

	TextArea taFields = new TextArea();
	ListBox lstFields = new ListBox();

	SDPWidget widget;

	public SourceHBasePropDlg(SDPWidget widget) {
		super(false, false);
		this.widget = widget;

		this.setSize("600px", "500px");
		this.setStyleName("gwt-DialogBox");
		this.setText("HBase Source Properties for " + widget.getName());
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("600px", "500px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		HorizontalPanel hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		Label lbl = new Label("Name:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtName.setStyleName("textBox");
		this.txtName.setWidth("200px");
		hp.add(lbl);
		hp.add(this.txtName);
		lbl = new Label("Table:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtTable.setStyleName("textBox");
		this.txtTable.setWidth("200px");
		hp.add(lbl);
		hp.add(this.txtTable);
		dp.addNorth(hp, 30);
		
		lbl = new Label("Comma (,) separated fields name (e.g. <Column family#Column>,<Column family#Column>)");
		this.taFields.setSize("580px", "50px");
		dp.addNorth(lbl, 25);
		dp.addNorth(this.taFields, 75);

		Button btn = new Button("Add Fields to List");
		btn.setSize("200px", "25px");
		btn.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				processFields();
			}
		});

		dp.addNorth(btn, 25);

		dp.addNorth(new Label("Fields in Source"), 20);
		this.lstFields.setSize("100px", "200px");
		this.lstFields.setVisibleItemCount(20);
		dp.addNorth(this.lstFields, 200);

		FlowPanel fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.add(dp);

		this.initComponens();
	}

	void initComponens() {
		SourceHBase sh = (SourceHBase) this.widget;
		this.txtName.setText(sh.getName());
		this.txtTable.setText(sh.getTableName());

		StringBuffer buff = new StringBuffer();
		if (sh.getFields() != null && sh.getFields().size() > 0) {
			for (int i = 0; i < sh.getFields().size(); i++) {
				this.lstFields.addItem(sh.getFields().get(i).getName());
				if (i > 0) {
					buff.append(",");
				}
				buff.append(sh.getFields().get(i));
			}
		}

		this.taFields.setText(buff.toString());
	}

	void processOk() {
		SourceHBase sh = (SourceHBase) this.widget;
		sh.setName(this.txtName.getText());
		sh.setTable(txtTable.getText());

		List<ColumnDto> lst = new ArrayList<ColumnDto>();
		for (int i = 0; i < this.lstFields.getItemCount(); i++) {
			ColumnDto dto = new ColumnDto();
			dto.setName(this.lstFields.getItemText(i));
			lst.add(dto);
		}

		sh.setFields(lst);

		this.hide();
	}

	void processCancel() {
		this.hide();
	}

	void processFields() {
		String[] fields = this.taFields.getText().split(",");
		this.lstFields.clear();

		for (String field : fields) {
			this.lstFields.addItem(field);
		}
	}
}
