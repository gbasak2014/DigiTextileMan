package com.gb.wf.client.dlg;

import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.TargetHDFS;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.TextAlign;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextBox;

public class TargetFilePropDlg extends SdpDialogBox {
	TextBox txtName = new TextBox();
	TextBox txtPath = new TextBox();
	ListBox lstPathPattern = new ListBox();

	TargetHDFS widget;

	public TargetFilePropDlg(SDPWidget widget) {
		super(false, false);
		this.widget = (TargetHDFS) widget;

		this.setSize("600px", "300px");
		this.setStyleName("gwt-DialogBox");
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("650px", "300px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		HorizontalPanel hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		Label lbl = new Label("Name:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtName.setStyleName("textBox");
		this.txtName.setWidth("200px");
		hp.add(lbl);
		hp.add(this.txtName);
		dp.addNorth(hp, 35);

		hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		lbl = new Label("Target Path:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtPath.setWidth("450px");
		this.txtPath.setStyleName("textBox");
		hp.add(lbl);
		hp.add(this.txtPath);
		hp.add(this.lstPathPattern);
		this.lstPathPattern.addItem("Select pattern");
		this.lstPathPattern.addItem("Match All");
		this.lstPathPattern.addItem("Year (YYYY)");
		this.lstPathPattern.addItem("Month (MM)");
		this.lstPathPattern.addItem("Day (DD)");
		this.lstPathPattern.addItem("Hour (HH)");

		this.lstPathPattern.addChangeHandler(new ChangeHandler() {
			@Override
			public void onChange(ChangeEvent event) {
				addPathPattern();
			}
		});

		dp.addNorth(hp, 30);

		FlowPanel fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.add(dp);
		this.initComponens();

	}

	void initComponens() {
		this.txtName.setText(this.widget.getName());
		this.txtPath.setText(this.widget.getPath());
	}

	void processOk() {
		this.widget.setName(this.txtName.getText());
		this.widget.setPath(this.widget.getPath());

		this.hide();
	}

	void processCancel() {
		this.hide();
	}

	void addPathPattern() {
		String pattern = null;
		switch (this.lstPathPattern.getSelectedIndex()) {
		case 1:
			pattern = "*";
			break;
		case 2:
			pattern = "$YYYY";
			break;
		case 3:
			pattern = "$MM";
			break;
		case 4:
			pattern = "$DD";
			break;
		case 5:
			pattern = "$HH";
		}

		if (pattern != null) {
			this.txtPath.setText(this.txtPath.getText() + pattern);
		}
	}
}
