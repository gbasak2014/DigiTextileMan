package com.gb.wf.client.dlg;

import java.util.List;

import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.util.ComponentTypes;
import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.TargetDelim;
import com.gb.wf.client.widget.TargetJSON;
import com.gb.wf.client.widget.TargetXML;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class JsonPropDlg extends SdpDialogBox {
	TextBox txtName = new TextBox();
	TextBox txtDelim = new TextBox();
	TextBox txtPath = new TextBox();

	ListBox lstFields = new ListBox(true);

	SDPWidget widget;

	TextArea taSample = new TextArea();

	public JsonPropDlg(SDPWidget widget) {
		super(false, false);
		this.widget = widget;

		this.setSize("750px", "500px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Formatter: " + widget.getName());
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("750px", "500px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		this.lstFields.setVisibleItemCount(20);
		this.lstFields.setWidth("150px");

		VerticalPanel vpn = new VerticalPanel();
		FlowPanel fp = new FlowPanel();
		Label lbl = new Label("Name:");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(lbl);
		txtName.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(txtName);

		lbl = new Label();
		txtDelim.setWidth("150px");
		txtDelim.setHeight("20px");
		txtDelim.getElement().getStyle().setFloat(Float.LEFT);
		if (this.widget.getType() == ComponentTypes.TARGET_XML) {
			lbl.setText("Root Element:");
			lbl.getElement().getStyle().setFloat(Float.LEFT);
			fp.add(lbl);
			fp.add(txtDelim);
		}
		if (this.widget.getType() == ComponentTypes.TARGET_DELIM) {
			lbl.setText("Field Separator:");
			lbl.getElement().getStyle().setFloat(Float.LEFT);
			fp.add(lbl);
			fp.add(txtDelim);
		}
		vpn.add(fp);

		fp = new FlowPanel();
		lbl = new Label("Path:");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		txtPath.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(lbl);
		fp.add(txtPath);
		vpn.add(fp);

		dp.addNorth(vpn, 60);

		HorizontalPanel hp = new HorizontalPanel();
		VerticalPanel vp = new VerticalPanel();

		hp.add(lstFields);
		taSample.setVisibleLines(15);
		taSample.setWidth("400px");
		vp.add(taSample);
		Button btn = new Button("Show Sample");
		btn.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent ce) {
				showSample();
			}
		});
		vp.add(btn);
		hp.add(vp);
		dp.add(hp);

		fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.add(dp);
		this.initComponens();
	}

	void initComponens() {
		this.txtName.setText(this.widget.getName());
		if (this.widget.getType() == ComponentTypes.TARGET_XML) {
			this.txtDelim.setText(((TargetXML) this.widget).getRootElement());
			this.txtPath.setText(((TargetXML) this.widget).getPath());
		} else if (this.widget.getType() == ComponentTypes.TARGET_DELIM) {
			this.txtDelim.setText(((TargetDelim) this.widget).getDelim());
			this.txtPath.setText(((TargetDelim) this.widget).getPath());
		} else if (this.widget.getType() == ComponentTypes.TARGET_JSON) {
			this.txtPath.setText(((TargetJSON) this.widget).getPath());
		}

		List<ColumnDto> flds = this.widget.getPredecessors().get(0).getFields();
		this.widget.getFields().clear();
		for (ColumnDto f : flds) {
			this.lstFields.addItem(f.getName());
			this.widget.getFields().add(f);
		}
	}

	void processOk() {
		this.widget.setName(this.txtName.getText());
		if (this.widget.getType() == ComponentTypes.TARGET_XML) {
			((TargetXML) this.widget).setRootElement(this.txtDelim.getText());
			((TargetXML) this.widget).setPath(this.txtPath.getText());
		} else if (this.widget.getType() == ComponentTypes.TARGET_DELIM) {
			((TargetDelim) this.widget).setDelim(this.txtDelim.getText());
			((TargetDelim) this.widget).setPath(this.txtPath.getText());
		} else if (this.widget.getType() == ComponentTypes.TARGET_JSON) {
			((TargetJSON) this.widget).setPath(this.txtPath.getText());
		}

		this.hide();
	}

	void showSample() {
		String sample = "";
		switch (this.widget.getType()) {
		case ComponentTypes.TARGET_DELIM:
			sample = prepareDelim();
			break;
		case ComponentTypes.TARGET_XML:
			sample = prepareXml();
			break;
		case ComponentTypes.TARGET_JSON:
			sample = prepareJson();
			break;
		}

		this.taSample.setText(sample);
	}

	String prepareJson() {
		JSONObject json = new JSONObject();
		for (ColumnDto f : this.widget.getFields()) {
			json.put(f.getName(), new JSONString("Value of " + f.getName()));
		}

		return json.toString();
	}

	String prepareXml() {
		StringBuffer xml = new StringBuffer();
		String re = this.txtDelim.getText();
		xml.append("<").append(re).append(">");
		for (ColumnDto f : this.widget.getFields()) {
			String e = "<" + f.getName() + ">Value of " + f.getName() + "</" + f.getName() + ">";
			xml.append(e);
		}
		xml.append("</").append(re).append(">");

		return xml.toString();
	}

	String prepareDelim() {
		String sample = "";
		String delim = this.txtDelim.getText();

		for (ColumnDto f : this.widget.getFields()) {
			if (sample.length() > 0) {
				sample = sample + delim;
			}

			sample = sample + f.getName();
		}

		return sample;
	}

	void processCancel() {
		this.hide();
	}
}
