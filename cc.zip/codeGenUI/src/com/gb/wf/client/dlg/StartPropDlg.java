package com.gb.wf.client.dlg;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.component.ParamRow;
import com.gb.wf.client.dto.ParamDto;
import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.Start;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class StartPropDlg extends SdpDialogBox {
	TextBox txtName = new TextBox();
	TextBox txtDesc = new TextBox();
	Start widget;
	
	List<ParamRow> params = new ArrayList<ParamRow>();
	VerticalPanel table = new VerticalPanel();
	
	ParamRow param;
	
	public StartPropDlg(SDPWidget widget) {
		super(false, false);
		this.widget = (Start)widget;
		
		this.setSize("600px", "300px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Job Properties: " + widget.getName());
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("600px", "300px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		FlowPanel fp = new FlowPanel();
		Label lbl = new Label("Name:");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(lbl);
		txtName.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(txtName);
		
		lbl = new Label("Description:");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(lbl);
		txtDesc.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(txtDesc);
		
		dp.addNorth(fp, 30);

		fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});
		
		DockLayoutPanel dpParam = new DockLayoutPanel(Unit.PX);
		dpParam.setSize("600px", "200px");
		Button btn = new Button("Add Param");
		btn.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				addParam();
			}
		});
		
		dpParam.addNorth(btn, 25);
		this.table.setWidth("600px");
		dpParam.add(this.table);
		dp.add(dpParam);
		this.add(dp);
		
		this.initComponens();
	}

	void initComponens() {
		this.txtName.setText(this.widget.getJobName());
		this.txtDesc.setText(this.widget.getDesc());
		for (ParamDto p : this.widget.getParams())
		{
			ParamRow r = new ParamRow(p.getId(), p.getParam(), p.getType(), this);
			this.params.add(r);
			this.table.add(r);
		}
	}

	void processOk() {
		this.widget.setJobName(this.txtName.getText());
		this.widget.setDesc(this.txtDesc.getText());
		this.widget.addParams(this.params);
		this.hide();
	}

	void processCancel() {
		this.hide();
	}
	
	public void deleteParam(ParamRow row)
	{
		this.table.remove(row);
		this.params.remove(row);
	}
	
	public void addParam()
	{
		ParamRow row = new ParamRow(-1, "", "", this);
		this.table.add(row);
		this.params.add(row);
	}
}
