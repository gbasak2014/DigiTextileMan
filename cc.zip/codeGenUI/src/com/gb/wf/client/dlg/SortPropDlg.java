package com.gb.wf.client.dlg;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.component.SDPButtonActions;
import com.gb.wf.client.component.TransformationHeader;
import com.gb.wf.client.component.TransformationRow;
import com.gb.wf.client.component.TransformationTable;
import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.dto.OrderDto;
import com.gb.wf.client.handler.TransRowSelectionHandler;
import com.gb.wf.client.widget.ImageButton;
import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.Sort;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class SortPropDlg extends SdpDialogBox implements ClickHandler, TransRowSelectionHandler {
	TextBox txtName = new TextBox();
	ListBox lstFields = new ListBox(true);

	TransformationTable transformationTable;
	TransformationRow selectedRow;

	Sort widget;

	public SortPropDlg(SDPWidget widget) {
		super(false, false);
		this.transformationTable = new TransformationTable(this, new TransformationHeader("SL.No", "Column Name", "Order"));
		this.widget = (Sort) widget;

		this.setSize("750px", "500px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Sort Properties for " + widget.getName());
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("750px", "500px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		this.lstFields.setVisibleItemCount(20);
		this.lstFields.setWidth("150px");

		VerticalPanel vpn = new VerticalPanel();
		FlowPanel fp = new FlowPanel();
		Label lbl = new Label("Name:");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		txtName.getElement().getStyle().setFloat(Float.LEFT);
		fp.add(lbl);
		fp.add(txtName);
		vpn.add(fp);
		dp.addNorth(vpn, 30);

		HorizontalPanel vp = new HorizontalPanel();
		VerticalPanel vp1 = new VerticalPanel();
		vp1.add(new ImageButton("images/btn-add.jpg", SDPButtonActions.ADD_COLUMN, "Add selected column", this, 20, 20));
		vp1.add(new ImageButton("images/btn-add-all.jpg", SDPButtonActions.ADD_ALL_COLUMNS, "Add all column", this, 20, 20));

		vp.add(lstFields);
		vp.add(vp1);

		vp.add(this.transformationTable);

		vp1 = new VerticalPanel();
		vp1.add(new ImageButton("images/btn-add-row.jpg", SDPButtonActions.INSERT_COLUMN, "Insert column", this, 20, 20));
		vp1.add(new ImageButton("images/btn-delete-row.jpg", SDPButtonActions.DELETE_ROW, "Delete selected column", this, 20, 20));
		vp1.add(new ImageButton("images/btn-move-up.jpg", SDPButtonActions.MOVE_UP, "Move selected row up", this, 20, 20));
		vp1.add(new ImageButton("images/btn-move-down.jpg", SDPButtonActions.MOVE_DOWN, "Move selected row down", this, 20, 20));

		vp.add(vp1);
		dp.add(vp);

		fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.add(dp);
		this.initComponens();
	}

	void initComponens() {
		this.txtName.setText(this.widget.getName());

		List<ColumnDto> flds = this.widget.getPredecessors().get(0).getFields();
		for (ColumnDto f : flds) {
			this.lstFields.addItem(f.getName());
		}

		int idx = 0;
		for (OrderDto odto : this.widget.getOrderByColumns()) {
			this.transformationTable.insertRow(odto.getField(), odto.getOrder(), idx);
			idx++;
		}
	}

	void processOk() {
		this.widget.setName(this.txtName.getText());
		List<ColumnDto> fields = new ArrayList<ColumnDto>();

		this.widget.clearAllOrder();
		for (TransformationRow tr : this.transformationTable.getModel()) {
			this.widget.addOrderBy(new OrderDto(tr.getTransformation(), tr.getFieldName()));
		}

		int cnt = this.lstFields.getItemCount();
		for (int i = 0; i < cnt; i++) {
			ColumnDto dto = new ColumnDto();
			dto.setName(this.lstFields.getItemText(i));
			dto.setPos(i);
			dto.setSensitiveFlag(false);
			dto.setDataType("NA");
			dto.setId(-1);
			fields.add(dto);
		}

		this.widget.setFields(fields);
		this.hide();
	}

	void processCancel() {
		this.hide();
	}

	@Override
	public void onClick(ClickEvent event) {
		int cmd = ((ImageButton) event.getSource()).getCommand();
		int idx;
		switch (cmd) {
		case SDPButtonActions.ADD_COLUMN:
			for (idx = 0; idx < this.lstFields.getItemCount(); idx++) {
				if (this.lstFields.isItemSelected(idx)) {
					String field = this.lstFields.getItemText(idx);
					this.transformationTable.insertRow(field, "ASC");
				}
			}

			break;
		case SDPButtonActions.ADD_ALL_COLUMNS:
			for (idx = 0; idx < this.lstFields.getItemCount(); idx++) {
				String field = this.lstFields.getItemText(idx);
				this.transformationTable.insertRow(field, "ASC");
			}
			break;
		case SDPButtonActions.INSERT_COLUMN:
			this.transformationTable.insertRow("", "");
			break;
		case SDPButtonActions.DELETE_ROW:
			if (this.selectedRow != null) {
				this.transformationTable.removeRow(this.selectedRow);
				this.selectedRow = null;
			}
		}
	}

	@Override
	public void rowSelected(TransformationRow row) {
		if (this.selectedRow != null) {
			this.selectedRow.deselectRow();
		}
		this.selectedRow = row;
		this.selectedRow.selectRow();
	}
}
