package com.gb.wf.client.dlg;

import java.util.List;

import com.gb.wf.client.widget.CustomAction;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.TextArea;

public class ImportDlg extends SdpDialogBox {

	CustomAction widget;

	TextArea taImport = new TextArea();

	public ImportDlg(CustomAction widget) {
		super(false, false);
		this.widget = widget;

		this.setSize("700px", "500px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Import List: " + widget.getName());
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("700px", "500px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		this.taImport.setSize("700px", "400px");
		dp.add(this.taImport);

		FlowPanel fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.add(dp);
		this.initComponens();
	}

	void initComponens() {
		String imprts = "";
		if (this.widget.getImports() == null || this.widget.getImports().size() <=0 ) {
			imprts = "java.text.SimpleDateFormat\n";
			imprts = imprts + "java.util._\n";
			imprts = imprts + "org.apache.spark.sql._\n";
			imprts = imprts + "org.apache.spark.sql.types._\n";
			imprts = imprts + "org.apache.spark.sql.hive._\n";
			imprts = imprts + "org.apache.spark.sql.functions._\n";
		} else {
			for (String imp : this.widget.getImports()) {
				imprts = imprts + imp + "\n"; 
			}
		}

		this.taImport.setText(imprts);
	}

	void processOk() {
		List<String> imp = this.widget.getImports();
		String ii = this.taImport.getText();
		if (ii != null && ii.trim().length() > 0) {
			imp.clear();
			for (String im : ii.split("\n")) {
				imp.add(im);
			}
		}
		this.hide();
	}

	void processCancel() {
		this.hide();
	}
}
