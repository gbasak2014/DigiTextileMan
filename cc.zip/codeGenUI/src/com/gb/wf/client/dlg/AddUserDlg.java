package com.gb.wf.client.dlg;

import com.gb.wf.client.ControllerService;
import com.gb.wf.client.ControllerServiceAsync;
import com.gb.wf.client.dto.ProjectDto;
import com.gb.wf.client.dto.UserDto;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.PasswordTextBox;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class AddUserDlg extends SdpDialogBox {
	private final ControllerServiceAsync service = GWT.create(ControllerService.class);

	TextBox txtLoginid = new TextBox();
	TextBox txtName = new TextBox();
	TextBox txtEmail = new TextBox();
	ListBox lstProject = new ListBox();
	TextBox txtQuestion1 = new TextBox();
	TextBox txtQuestion2 = new TextBox();
	TextBox txtAnswer1 = new TextBox();
	TextBox txtAnswer2 = new TextBox();

	PasswordTextBox ptxt1 = new PasswordTextBox();
	PasswordTextBox ptxt2 = new PasswordTextBox();

	Label lblMsg = new Label();
	UserDto admin;

	public AddUserDlg(UserDto admin) {
		super(false, false);
		this.admin = admin;

		this.setSize("500px", "450px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Create User");
		
		VerticalPanel vp = new VerticalPanel();
		vp.setSize("500px", "450px");
		lblMsg.getElement().getStyle().setBackgroundColor("#ff0000");
		vp.add(lblMsg);

		Label lbl = new Label("User Registration");
		lbl.setStyleName("titleText");
		vp.add(lbl);

		HorizontalPanel hp = new HorizontalPanel();
		lbl = new Label("Login Id:");
		lbl.setWidth("150px");
		this.txtLoginid.setWidth("200px");
		hp.add(lbl);
		hp.add(txtLoginid);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Project:");
		lbl.setWidth("150px");
		this.lstProject.setWidth("200px");
		this.lstProject.addItem("Select Project");
		for (ProjectDto p : this.admin.getProjects()) {
			this.lstProject.addItem(p.getId() + "-" + p.getName());
		}

		hp.add(lbl);
		hp.add(this.lstProject);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Name:");
		lbl.setWidth("150px");
		this.txtName.setWidth("200px");
		hp.add(lbl);
		hp.add(txtName);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Email:");
		lbl.setWidth("150px");
		this.txtEmail.setWidth("200px");
		hp.add(lbl);
		hp.add(txtEmail);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Security Question one:");
		lbl.setWidth("150px");
		this.txtQuestion1.setWidth("200px");
		hp.add(lbl);
		hp.add(txtQuestion1);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Answer:");
		lbl.setWidth("150px");
		this.txtAnswer1.setWidth("200px");
		hp.add(lbl);
		hp.add(txtAnswer1);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Security Question two:");
		lbl.setWidth("150px");
		this.txtQuestion2.setWidth("200px");
		hp.add(lbl);
		hp.add(txtQuestion2);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Answer:");
		lbl.setWidth("150px");
		this.txtAnswer2.setWidth("200px");
		hp.add(lbl);
		hp.add(txtAnswer2);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Password:");
		lbl.setWidth("150px");
		this.ptxt1.setWidth("200px");
		hp.add(lbl);
		hp.add(ptxt1);
		vp.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("Retype Password:");
		lbl.setWidth("150px");
		this.ptxt2.setWidth("200px");
		hp.add(lbl);
		hp.add(ptxt2);
		vp.add(hp);

		FlowPanel fp = new FlowPanel();
		Button btn = new Button("Add", new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btn.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btn);

		btn = new Button("Cancel", new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});
		btn.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btn);
		vp.add(fp);

		this.add(vp);
	}

	void processOk() {
		try {
			int idx = this.lstProject.getSelectedIndex();
			if (idx <= 0) {
				Window.alert("Please select Project...");
			} else {
				JSONObject json = new JSONObject();
				json.put("userId", new JSONString(txtLoginid.getText()));
				json.put("name", new JSONString(txtName.getText()));
				json.put("email", new JSONString(txtEmail.getText()));
				String prg = this.lstProject.getItemText(idx);
				String prgId = prg.split("-")[0];
				json.put("projectId", new JSONString(prgId));
				json.put("question1", new JSONString(txtQuestion1.getText()));
				json.put("question2", new JSONString(txtQuestion2.getText()));
				json.put("answer1", new JSONString(txtAnswer1.getText()));
				json.put("answer2", new JSONString(txtAnswer2.getText()));
				json.put("ptxt1", new JSONString(ptxt1.getText()));
				json.put("ptxt2", new JSONString(ptxt2.getText()));

				this.service.addUser(json.toString(), new AsyncCallback<String>() {
					@Override
					public void onSuccess(String res) {
						processAdd(res);
					}

					@Override
					public void onFailure(Throwable arg0) {
						Window.alert("Server ERROR");
					}
				});
			}
		} catch (Exception e) {
		}
	}

	void processCancel() {
		this.hide();
	}

	void processAdd(String res) {
		if ("ERROR".equals(res)) {
			lblMsg.setText("Error adding user!!!");
		} else {
			JSONObject json = (JSONObject) JSONParser.parseStrict(res);
			String status = json.get("status").isString().stringValue();
			if ("EXIST".equals(status)) {
				lblMsg.setText("User exist with the Id.");
			} else if ("FAIL".equals(status)) {
				lblMsg.setText("Fail to add user!!");
			} else if ("SUCCESS".equals(status)) {
				Window.alert("User added successfully...");
				this.hide();
			}
		}
	}
}
