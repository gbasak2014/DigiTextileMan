package com.gb.wf.client.dlg;

import com.google.gwt.user.client.ui.DialogBox;

public class SdpDialogBox extends DialogBox {
	public SdpDialogBox() {
		super();
	}

	public SdpDialogBox(boolean autoHive) {
		super(autoHive);
	}

	public SdpDialogBox(boolean autoHive, boolean modal) {
		super(autoHive, modal);
	}

	public void postProcess() {
	}
}
