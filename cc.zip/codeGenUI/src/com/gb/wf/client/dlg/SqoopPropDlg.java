package com.gb.wf.client.dlg;

import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import com.gb.wf.client.ControllerService;
import com.gb.wf.client.ControllerServiceAsync;
import com.gb.wf.client.component.DFConstants;
import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.dto.ProjectDto;
import com.gb.wf.client.dto.SourceMetaDto;
import com.gb.wf.client.handler.WFActionHandler;
import com.gb.wf.client.util.SdfUtils;
import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.Sqoop;
import com.gb.wf.client.widget.Start;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.TextAlign;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class SqoopPropDlg extends SdpDialogBox {
	TextBox txtName = new TextBox();
	TextBox txtSchema = new TextBox();
	TextBox txtTable = new TextBox();

	TextBox txtUrl = new TextBox();
	TextBox txtUser = new TextBox();
	TextBox txtPassword = new TextBox();

	ListBox lstSrc = new ListBox();
	ListBox lstFields = new ListBox();

	ListBox lstImportType = new ListBox();
	ListBox lstIncremental = new ListBox();

	TextBox txtChkCol = new TextBox();
	TextBox txtLstval = new TextBox();
	TextBox txtOutDir = new TextBox();
	TextBox txtTarget = new TextBox();
	TextBox txtSep = new TextBox();
	ListBox lstDtTmBehav = new ListBox();

	Sqoop widget;

	long projectId;
	SourceMetaDto sourceMeta;

	WFActionHandler actionHandler;
	
	private final ControllerServiceAsync service = GWT.create(ControllerService.class);

	public SqoopPropDlg(SDPWidget widget, long projectId, WFActionHandler actionHandler) {
		super(false, false);
		this.widget = (Sqoop) widget;
		this.projectId = projectId;
		this.actionHandler = actionHandler;
		
		this.setSize("800px", "500px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Sqoop Import Properties for " + widget.getName());
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("800px", "600px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		HorizontalPanel hp = new HorizontalPanel();

		hp.getElement().getStyle().setMargin(2, Unit.PX);
		Label lbl = new Label("Name:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtName.setStyleName("textBox");
		this.txtName.setWidth("200px");

		hp.add(lbl);
		hp.add(this.txtName);
		hp.add(this.lstSrc);
		dp.addNorth(hp, 35);

		VerticalPanel vpSrc = new VerticalPanel();
		vpSrc.setBorderWidth(1);
		vpSrc.getElement().getStyle().setBorderColor("#AAAAAA");
		hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		lbl = new Label("JDBC Url:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtUrl.setStyleName("textBox");
		this.txtUrl.setWidth("400px");
		hp.add(lbl);
		hp.add(txtUrl);
		vpSrc.add(hp);

		hp = new HorizontalPanel();
		lbl = new Label("User:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtUser.setStyleName("textBox");
		this.txtUser.setWidth("200px");
		hp.add(lbl);
		hp.add(txtUser);
		lbl = new Label("Password:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtPassword.setStyleName("textBox");
		this.txtPassword.setWidth("200px");
		hp.add(lbl);
		hp.add(txtPassword);
		vpSrc.add(hp);

		hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		lbl = new Label("Schema:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtSchema.setWidth("200px");
		this.txtSchema.setStyleName("textBox");
		hp.add(lbl);
		hp.add(this.txtSchema);
		lbl = new Label("Table:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtTable.setWidth("200px");
		this.txtTable.setStyleName("textBox");
		hp.add(lbl);
		hp.add(this.txtTable);
		vpSrc.add(hp);
		dp.addNorth(vpSrc, 90);

		VerticalPanel vp = new VerticalPanel();

		vp.add(new Label("Fields"));
		this.lstFields.setSize("100px", "200px");
		this.lstFields.setVisibleItemCount(20);
		vp.add(this.lstFields);
		this.lstFields.setWidth("250px");
		dp.addWest(vp, 250);

		vp = new VerticalPanel();
		hp = new HorizontalPanel();
		hp.add(new Label("Import Type"));
		hp.add(this.lstImportType);
		hp.add(new Label("Incremental"));
		hp.add(this.lstIncremental);
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new Label("Check Column"));
		hp.add(this.txtChkCol);
		hp.add(new Label("Last value"));
		hp.add(this.txtLstval);		
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new Label("Output Directory"));
		this.txtOutDir.setWidth("400px");
		hp.add(this.txtOutDir);
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new Label("Target Directory"));
		this.txtTarget.setWidth("400px");
		hp.add(this.txtTarget);
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new Label("Field Separator"));
		hp.add(this.txtSep);
		hp.add(new Label("zeroDateTimeBehavior "));
		hp.add(this.lstDtTmBehav);
		vp.add(hp);
		vp.add(new Button("Save and Create Sqoop Job", new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				createSqoopJob();
			}
		}));

		dp.add(vp);

		FlowPanel fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.add(dp);
		getSourceList();
		this.initComponens();

		this.lstImportType.addChangeHandler(new ChangeHandler() {
			@Override
			public void onChange(ChangeEvent arg0) {
				impTypeChanged();
			}
		});

		this.lstSrc.addChangeHandler(new ChangeHandler() {
			@Override
			public void onChange(ChangeEvent arg0) {
				sourceChanged();
			}
		});

	}

	void impTypeChanged() {
		if (this.lstImportType.getSelectedIndex() == 1) {
			this.lstIncremental.setEnabled(true);
		} else {
			this.lstIncremental.setEnabled(false);
		}
	}

	void sourceChanged() {
		int idx = this.lstSrc.getSelectedIndex();
		if (idx > 0) {
			String[] src = this.lstSrc.getItemText(idx).split("-");
			long id = Long.parseLong(src[0]);

			if (this.sourceMeta == null || this.sourceMeta.getId() != id) {
				this.service.getProjectSources(id, new AsyncCallback<String>() {
					@Override
					public void onSuccess(String res) {
						populateSourceMeta(res);
					}

					@Override
					public void onFailure(Throwable arg0) {
						Window.alert("Error to get Source detail!!");
					}
				});
			}
		}
	}

	void populateSourceMeta(String res) {
		try {
			if (this.sourceMeta == null) {
				this.sourceMeta = new SourceMetaDto();
			}

			SdfUtils.getSourceMeta(res, this.sourceMeta);

			String dbTbl = this.sourceMeta.getDelimiter();
			if (dbTbl != null && dbTbl.length() > 0) {
				this.txtSchema.setText(dbTbl.split(":")[0]);
				this.txtTable.setText(dbTbl.split(":")[1]);
			}
			this.txtUrl.setText(this.sourceMeta.getSource());

			this.txtUser.setText(this.sourceMeta.getUser());
			this.txtPassword.setText(this.sourceMeta.getPassword());

			Map<Integer, ColumnDto> m = new TreeMap<Integer, ColumnDto>();
			for (ColumnDto c : this.sourceMeta.getColumns()) {
				m.put(c.getPos(), c);
			}

			for (Entry<Integer, ColumnDto> cd : m.entrySet()) {
				ColumnDto dto = cd.getValue();
				this.lstFields.addItem(dto.getPos() + "> " + dto.getName() + ": " + dto.getDataType() + (dto.getSensitiveFlag() ? " -> Sensitive" : ""));
			}

		} catch (Exception e) {
			Window.alert("ERROR" + e.getMessage());
		}

	}

	private void getSourceList() {
		this.service.getDBSourceList(this.projectId, new AsyncCallback<String>() {
			@Override
			public void onSuccess(String res) {
				fillSourceList(res);
			}

			@Override
			public void onFailure(Throwable arg0) {
				Window.alert("Server ERROR!!");
			}
		});
	}

	void fillSourceList(String src) {
		this.lstSrc.addItem("Select source");
		for (String s : src.split(",")) {
			this.lstSrc.addItem(s);
		}

		int s = this.lstSrc.getItemCount();

		for (int i = 1; this.widget.getMetaId() > 0 && i < s; i++) {
			if (this.widget.getMetaId() == Long.parseLong(this.lstSrc.getItemText(i).split("-")[0].trim())) {
				this.lstSrc.setSelectedIndex(i);
				break;
			}
		}
		
		sourceChanged();
	}

	void initComponens() {
		this.lstImportType.addItem("FULL");
		this.lstImportType.addItem("INCREMENTAL");

		this.lstIncremental.addItem("append");
		this.lstIncremental.addItem("lastmodified");

		this.lstDtTmBehav.addItem("convertToNull");
		this.lstDtTmBehav.addItem("round");
		this.lstDtTmBehav.addItem("exception");

		this.txtName.setText(this.widget.getName());
		this.txtChkCol.setText(this.widget.getCheckColumn());
		this.txtOutDir.setText(this.widget.getOutDir());
		this.txtTarget.setText(this.widget.getText());
		this.txtSep.setText(this.widget.getDelimiter());
		this.txtTarget.setText(this.widget.getTargetDir());
		this.txtLstval.setText(this.widget.getLastValue());
		
		String impType = this.widget.getImportType();
		if (impType != null && impType.equals("INCREMENTAL")) {
			this.lstImportType.setSelectedIndex(1);
			this.lstIncremental.setEnabled(true);
			String incr = this.widget.getIncremental();
			if (incr != null && incr.equals("lastmodified")) {
				this.lstIncremental.setSelectedIndex(1);
			} else {
				this.lstIncremental.setSelectedIndex(0);
			}
		} else {
			this.lstImportType.setSelectedIndex(0);
			this.lstIncremental.setEnabled(false);
		}

		int s = this.lstDtTmBehav.getItemCount();
		for (int i = 0; i < s; i++) {
			String str = this.lstDtTmBehav.getItemText(i);
			if (str.equals(this.widget.getDateTmBehav())) {
				this.lstDtTmBehav.setSelectedIndex(i);
				break;
			}
		}

	}

	void processOk() {
		setProps();
		this.hide();
	}

	void processCancel() {
		this.hide();
	}

	void createSqoopJob() {
		setProps();
		openExecuteWorkflow();		
	}

	void openExecuteWorkflow() {
		try {
			ProjectDto p = this.actionHandler.getDesignerPage().getToolBar().getSelectedProject();
			Start start = this.actionHandler.getDesignerPage().getDrawingController().getStartNode();
			if (start != null) {
				ExecuteWfDlg dlg = new ExecuteWfDlg(this.actionHandler, p, start, this.widget, ExecuteWfDlg.CREATE_SQOOP_JOB);
				dlg.setModal(false);
				dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
				dlg.setGlassEnabled(true);
				dlg.setAnimationEnabled(true);
				dlg.center();
				dlg.show();
			} else {
				Window.alert("Please add start node!!");
			}
		} catch (Exception e) {
			Window.alert("Error!!!" + e.getMessage());
		}
	}
	
	void setProps() {
		this.widget.setMetaId(this.sourceMeta.getId());
		this.widget.setName(this.txtName.getText());
		this.widget.setMetaId(this.sourceMeta.getId());
		this.widget.setSchema(this.txtSchema.getText());
		this.widget.setTable(this.txtTable.getText());
		this.widget.setUrl(this.txtUrl.getText());
		this.widget.setUser(this.txtUser.getText());
		this.widget.setPwd(this.txtPassword.getText());
		this.widget.setImportType(this.lstImportType.getItemText(this.lstImportType.getSelectedIndex()));
		this.widget.setCheckColumn(this.txtChkCol.getText());
		this.widget.setTargetDir(this.txtTarget.getText());
		this.widget.setOutDir(this.txtOutDir.getText());
		this.widget.setIncremental(this.lstIncremental.getItemText(this.lstIncremental.getSelectedIndex()));
		this.widget.setDelimiter(this.txtSep.getText());
		this.widget.setDateTmBehav(this.lstDtTmBehav.getItemText(this.lstDtTmBehav.getSelectedIndex()));
		this.widget.setFields(this.sourceMeta.getColumns());
		this.widget.setLastValue(this.txtLstval.getText());
	}
}
