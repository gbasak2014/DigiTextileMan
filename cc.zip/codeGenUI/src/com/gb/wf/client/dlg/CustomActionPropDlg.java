package com.gb.wf.client.dlg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.gb.wf.client.ControllerService;
import com.gb.wf.client.ControllerServiceAsync;
import com.gb.wf.client.component.DFConstants;
import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.widget.CustomAction;
import com.gb.wf.client.widget.SDPWidget;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.BorderStyle;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.TextAlign;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class CustomActionPropDlg extends SdpDialogBox {
	TextBox txtName = new TextBox();
	TextArea taFields = new TextArea();

	TextArea taConde = new TextArea();

	CustomAction widget;

	Map<String, TextBox> inParams = new HashMap<String, TextBox>();

	ListBox lstvar = new ListBox();
	List<String> lstDataType = new ArrayList<String>();

	private final ControllerServiceAsync service = GWT.create(ControllerService.class);

	public CustomActionPropDlg(SDPWidget widget) {
		super(false, false);
		this.widget = (CustomAction) widget;

		int w = Window.getClientWidth() - 50;
		int h = Window.getClientHeight() - 50;

		String wpx = w + "px";
		String hpx = h + "px";
		this.setSize(wpx, hpx);
		this.setStyleName("gwt-DialogBox");
		this.setText("Custom action - " + widget.getName());
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize(wpx, hpx);
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		HorizontalPanel hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		Label lbl = new Label("Name:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtName.setStyleName("textBox");
		this.txtName.setWidth("300px");

		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		Button btnImport = new Button("Import Packages");
		Button btnRet = new Button("Define Return Schema");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		btnImport.getElement().getStyle().setFloat(Float.RIGHT);
		btnRet.getElement().getStyle().setFloat(Float.RIGHT);

		hp.add(lbl);
		hp.add(this.txtName);
		hp.add(this.lstvar);
		hp.add(btnCancel);
		hp.add(btnOk);
		hp.add(btnImport);
		hp.add(btnRet);
		dp.addNorth(hp, 35);

		VerticalPanel vp = new VerticalPanel();
		vp.add(new Label("Input DataFrames"));
		Map<String, String> map = this.widget.getParams();

		for (SDPWidget sw : this.widget.getPredecessors()) {
			FlowPanel fpnl = new FlowPanel();
			Label ptype = new Label(sw.getName());
			ptype.getElement().getStyle().setBorderColor("#aaaaaa");
			ptype.getElement().getStyle().setBorderStyle(BorderStyle.SOLID);
			ptype.getElement().getStyle().setFloat(Float.LEFT);

			TextBox txtVal = new TextBox();
			String val = map.get(sw.getName());
			txtVal.setText(val != null ? val : sw.getName());
			txtVal.getElement().getStyle().setFloat(Float.LEFT);
			txtVal.setWidth("100px");
			txtVal.setHeight("20px");
			fpnl.add(ptype);
			fpnl.add(txtVal);
			vp.add(fpnl);

			this.inParams.put(sw.getName(), txtVal);

			ptype.addClickHandler(new ClickHandler() {
				@Override
				public void onClick(ClickEvent ce) {
					String src = ((Label) ce.getSource()).getText();
					refreshDfFields(src);
				}
			});
		}

		vp.add(new Label("DataFrame Columns:"));
		this.taFields.setWidth("200px");
		this.taFields.setHeight("350px");
		vp.add(this.taFields);
		dp.addWest(vp, 200);

		this.taConde.setWidth((w - 200) + "px");
		this.taConde.setHeight((h - 50) + "px");
		dp.add(this.taConde);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});
		btnImport.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				vieImports();
			}
		});
		btnRet.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				viewRetSchemaDlg();
			}
		});

		this.add(dp);
		this.initComponens();
	}

	void initComponens() {
		this.txtName.setText(this.widget.getActionName());
		this.taConde.setText(this.widget.getCode());
		populateDataTypes();
		this.lstvar.addItem("Available variables");
		this.lstvar.addItem("sqlContext: HiveContext");
		this.lstvar.addItem("inParams: Map<String,String>");
	}

	void populateDataTypes() {
		service.getSourceConfig(new AsyncCallback<String>() {
			@Override
			public void onSuccess(String data) {
				addDataTypes(data);
			}

			@Override
			public void onFailure(Throwable arg0) {
				Window.alert("Server ERROR!!!");
			}
		});
	}

	void vieImports() {
		ImportDlg dlg = new ImportDlg(this.widget);

		dlg.setTitle("Import Packages");
		dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
		dlg.center();
		dlg.show();
	}

	void viewRetSchemaDlg() {
		SchemaDlg dlg = new SchemaDlg(this.widget, this.lstDataType, true);
		dlg.setTitle("Define Return Schema");
		dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
		dlg.center();
		dlg.show();
	}

	void addDataTypes(String data) {
		JSONObject json = JSONParser.parseStrict(data).isObject();

		JSONArray arr = json.get("dataTypes").isArray();
		for (int i = 0; i < arr.size(); i++) {
			this.lstDataType.add(arr.get(i).isString().stringValue());
		}
	}

	void refreshDfFields(String name) {
		for (SDPWidget w : this.widget.getPredecessors()) {
			if (name.equals(w.getName())) {
				this.taFields.setText("");
				String flds = "";
				for (ColumnDto cd : w.getFields()) {
					if (flds.length() > 0) {
						flds = flds + "\n";
					}
					flds = flds + cd.getName() + ": " + cd.getDataType();
				}
				this.taFields.setText(flds);
				break;
			}
		}
	}

	void processOk() {
		this.widget.setName(this.txtName.getText());
		this.widget.setActionName(this.txtName.getText());
		this.widget.setCode(this.taConde.getText());
		Map<String, String> map = this.widget.getParams();
		map.clear();
		for (Entry<String, TextBox> kv : this.inParams.entrySet()) {
			map.put(kv.getKey(), kv.getValue().getText());
		}

		List<String> list = this.widget.getImports();
		if (list.size() <= 0) {
			list.add("java.text.SimpleDateFormat");
			list.add("java.util._");
			list.add("org.apache.spark.sql._");
			list.add("org.apache.spark.sql.types._");
			list.add("org.apache.spark.sql.hive._");
			list.add("org.apache.spark.sql.functions._");
		}
		this.hide();
	}

	void processCancel() {
		this.hide();
	}
}
