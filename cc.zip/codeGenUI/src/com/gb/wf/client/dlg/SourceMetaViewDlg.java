package com.gb.wf.client.dlg;

import java.util.List;

import com.gb.wf.client.dto.SourceMetaDto;
import com.gb.wf.client.widget.ImageButton;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.cellview.client.CellTable;
import com.google.gwt.user.cellview.client.TextColumn;
import com.google.gwt.user.client.ui.DockLayoutPanel;

public class SourceMetaViewDlg extends SdpDialogBox implements ClickHandler {

	CellTable<SourceMetaDto> table = new CellTable<SourceMetaDto>();
	TextColumn<SourceMetaDto> id;
	TextColumn<SourceMetaDto> metaName;
	TextColumn<SourceMetaDto> source;
	TextColumn<SourceMetaDto> description;
	TextColumn<SourceMetaDto> user;
	TextColumn<SourceMetaDto> password;
	TextColumn<SourceMetaDto> delimiter;
	TextColumn<SourceMetaDto> sourceType;
	TextColumn<SourceMetaDto> recordType;
	List<SourceMetaDto> srcList;
	
	public SourceMetaViewDlg(List<SourceMetaDto> srcList, String projectName) {
		super(false, false);
		this.srcList = srcList;
		this.setSize("750px", "500px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Source Meta data for: " + projectName);
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("750px", "500px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		this.initComponens();
	}

	void initComponens() {
		initTable();
		this.table.setRowCount(this.srcList.size());
		this.table.setRowData(this.srcList);
	}

	void initTable() {
		this.id = new TextColumn<SourceMetaDto>() {
			@Override
			public String getValue(SourceMetaDto smd) {
				return "" + smd.getId();
			}
		};

		metaName = new TextColumn<SourceMetaDto>() {
			@Override
			public String getValue(SourceMetaDto smd) {
				return smd.getMetaName();
			}
		};
		source = new TextColumn<SourceMetaDto>() {
			@Override
			public String getValue(SourceMetaDto smd) {
				return smd.getSource();
			}
		};
		description = new TextColumn<SourceMetaDto>() {
			@Override
			public String getValue(SourceMetaDto smd) {
				return smd.getDescription();
			}
		};
		user = new TextColumn<SourceMetaDto>() {
			@Override
			public String getValue(SourceMetaDto smd) {
				return smd.getUser();
			}
		};
		password = new TextColumn<SourceMetaDto>() {
			@Override
			public String getValue(SourceMetaDto smd) {
				return smd.getPassword();
			}
		};
		delimiter = new TextColumn<SourceMetaDto>() {
			@Override
			public String getValue(SourceMetaDto smd) {
				return smd.getDelimiter();
			}
		};
		sourceType = new TextColumn<SourceMetaDto>() {
			@Override
			public String getValue(SourceMetaDto smd) {
				return smd.getSourceType();
			}
		};
		recordType = new TextColumn<SourceMetaDto>() {
			@Override
			public String getValue(SourceMetaDto smd) {
				return smd.getRecordType();
			}
		};

		this.table.addColumn(this.id, "Id");
		this.table.addColumn(this.metaName, "Name");
		this.table.addColumn(this.source, "Source");
		this.table.addColumn(this.description, "Description");
		this.table.addColumn(this.delimiter, "Delimiter");
		this.table.addColumn(this.sourceType, "Source Type");
		this.table.addColumn(this.recordType, "Record Type");
		this.table.addColumn(this.user, "User");
		this.table.addColumn(this.password, "Password");
	}

	void processOk() {
		this.hide();
	}

	void processCancel() {
		this.hide();
	}

	@Override
	public void onClick(ClickEvent event) {
		int cmd = ((ImageButton) event.getSource()).getCommand();
		int idx;
	}
}
