package com.gb.wf.client.dlg;

import java.util.HashMap;
import java.util.Map;

import com.gb.wf.client.widget.ResponseJSON;
import com.gb.wf.client.widget.SDPWidget;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class ResponsePropDlg extends SdpDialogBox {
	TextBox txtName = new TextBox();
	TextBox txtTargetUrl = new TextBox();
	TextBox txtTargetTable = new TextBox();
	TextBox txtTargetKeyColumn = new TextBox();
	TextBox txtTargetValColumn = new TextBox();
	TextBox txtTargetKey = new TextBox();
	TextBox txtTargetUser = new TextBox();
	TextBox txtTargetPwd = new TextBox();
	
	
	TextBox txtResponseRoot = new TextBox();
	Map<String, TextBox> map = new HashMap<String, TextBox>();
	
	ResponseJSON widget;

	public ResponsePropDlg(SDPWidget widget) {
		super(false, false);
		this.widget = (ResponseJSON) widget;
		initMap();
		
		this.setSize("750px", "600px");
		this.setStyleName("gwt-DialogBox");
		this.setText("Sort Properties for " + widget.getName());
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("750px", "500px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		VerticalPanel vpn = new VerticalPanel();

		FlowPanel fp = new FlowPanel();
		Label lbl = new Label("Name:");
		lbl.setWidth("150px");
		lbl.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.txtName.getElement().getStyle().setFloat(Float.LEFT);
		this.txtName.setWidth("400px");
		fp.add(lbl);
		fp.add(this.txtName);
		vpn.add(fp);
		
		fp = new FlowPanel();
		lbl = new Label("DB Url:");
		lbl.setWidth("150px");
		lbl.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.txtTargetUrl.getElement().getStyle().setFloat(Float.LEFT);
		this.txtTargetUrl.setWidth("400px");
		fp.add(lbl);
		fp.add(this.txtTargetUrl);
		vpn.add(fp);

		fp = new FlowPanel();
		lbl = new Label("Table:");
		lbl.setWidth("150px");
		lbl.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.txtTargetTable.getElement().getStyle().setFloat(Float.LEFT);
		this.txtTargetTable.setWidth("400px");
		fp.add(lbl);
		fp.add(this.txtTargetTable);
		vpn.add(fp);

		fp = new FlowPanel();
		lbl = new Label("DB User:");
		lbl.setWidth("150px");
		lbl.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.txtTargetUser.getElement().getStyle().setFloat(Float.LEFT);
		this.txtTargetUser.setWidth("400px");
		fp.add(lbl);
		fp.add(this.txtTargetUser);
		vpn.add(fp);
		
		fp = new FlowPanel();
		lbl = new Label("DB Password:");
		lbl.setWidth("150px");
		lbl.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.txtTargetPwd.getElement().getStyle().setFloat(Float.LEFT);
		this.txtTargetPwd.setWidth("400px");
		fp.add(lbl);
		fp.add(this.txtTargetPwd);
		vpn.add(fp);
		
		
		fp = new FlowPanel();
		lbl = new Label("Key Column:");
		lbl.setWidth("150px");
		lbl.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.txtTargetKeyColumn.getElement().getStyle().setFloat(Float.LEFT);
		this.txtTargetKeyColumn.setWidth("400px");
		fp.add(lbl);
		fp.add(this.txtTargetKeyColumn);
		vpn.add(fp);
		
		fp = new FlowPanel();
		lbl = new Label("Key:");
		lbl.setWidth("150px");
		lbl.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.txtTargetKey.getElement().getStyle().setFloat(Float.LEFT);
		this.txtTargetKey.setWidth("400px");
		fp.add(lbl);
		fp.add(this.txtTargetKey);
		vpn.add(fp);
		
		fp = new FlowPanel();
		lbl = new Label("Value Column:");
		lbl.setWidth("150px");
		lbl.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.txtTargetValColumn.getElement().getStyle().setFloat(Float.LEFT);
		this.txtTargetValColumn.setWidth("400px");
		fp.add(lbl);
		fp.add(this.txtTargetValColumn);
		vpn.add(fp);
		
		vpn.add(new Label("---------------------- Configure Response ----------------------"));

		fp = new FlowPanel();
		lbl = new Label("Response JSON Root Element Name:");
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.txtResponseRoot.getElement().getStyle().setFloat(Float.LEFT);
		this.txtResponseRoot.setWidth("300px");
		fp.add(lbl);
		fp.add(this.txtResponseRoot);
		vpn.add(fp);
		vpn.add(new Label("---------------------- Configure Dataframe Elements ----------------------"));
		for (String k : this.map.keySet())
		{
			TextBox t = this.map.get(k);
			fp = new FlowPanel();
			lbl = new Label(k + ":");
			lbl.getElement().getStyle().setFloat(Float.LEFT);
			lbl.setWidth("300px");
			lbl.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_RIGHT);
			t.getElement().getStyle().setFloat(Float.LEFT);
			t.setWidth("300px");
			fp.add(lbl);
			fp.add(t);
			vpn.add(fp);
		}
		
		dp.add(vpn);
		
		fp = new FlowPanel();
		Button btnOk = new Button("OK");

		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.add(dp);
		this.initComponens();
	}

	void initMap(){
		Map<String, String> m = this.widget.getDfResponseMap();
		this.map.clear();
		for (String k : m.keySet())
		{
			TextBox t = new TextBox();
			t.setText(m.get(k));
			this.map.put(k, t);
		}
		
		for (SDPWidget w: this.widget.getPredecessors())
		{
			if (!map.containsKey(w.getName()))
			{
				map.put(w.getName(), new TextBox());
			}
		}
	}
	
	void initComponens() {
		this.txtName.setText(this.widget.getName());
		this.txtTargetUrl.setText(this.widget.getTargetUrl());
		this.txtTargetTable.setText(this.widget.getTargetTable());
		this.txtTargetKeyColumn.setText(this.widget.getTargetKeyColumn());
		this.txtTargetValColumn.setText(this.widget.getTargetValColumn());
		this.txtTargetKey.setText(this.widget.getTargetKey());
		this.txtResponseRoot.setText(this.widget.getResponseRoot());
		this.txtResponseRoot.setText(this.widget.getResponseRoot());
		this.txtTargetUser.setText(this.widget.getTargetUser());
		this.txtTargetPwd.setText(this.widget.getTargetPwd());
	}

	void processOk() {
		this.widget.setName(this.txtName.getText());
		this.widget.setTargetUrl(this.txtTargetUrl.getText());
		this.widget.setTargetTable(this.txtTargetTable.getText());
		this.widget.setTargetKeyColumn(this.txtTargetKeyColumn.getText());
		this.widget.setTargetValColumn(this.txtTargetValColumn.getText());
		this.widget.setTargetKey(this.txtTargetKey.getText());
		this.widget.setTargetUser(this.txtTargetUser.getText());
		this.widget.setTargetPwd(this.txtTargetPwd.getText());
		this.widget.setResponseRoot(this.txtResponseRoot.getText());

		Map<String, String> m = this.widget.getDfResponseMap();
		m.clear();
		for (String k : this.map.keySet())
		{
			m.put(k, this.map.get(k).getText());
		}
		
		this.hide();
	}

	void processCancel() {
		this.hide();
	}

}
