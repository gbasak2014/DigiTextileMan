package com.gb.wf.client.dlg;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.SourceRDBMS;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.TextAlign;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;

public class SourceRDBMSPropDlg extends SdpDialogBox {
	TextBox txtName = new TextBox();
	TextBox txtSchema = new TextBox();
	TextBox txtTable = new TextBox();

	TextBox txtUrl = new TextBox();
	TextBox txtUser = new TextBox();
	TextBox txtPassword = new TextBox();

	TextArea taFields = new TextArea();
	ListBox lstFields = new ListBox();

	SDPWidget widget;

	public SourceRDBMSPropDlg(SDPWidget widget) {
		super(false, false);
		this.widget = widget;

		this.setSize("600px", "500px");
		this.setStyleName("gwt-DialogBox");
		this.setText("RDBMS Source Properties for " + widget.getName());
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("600px", "500px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");

		HorizontalPanel hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		Label lbl = new Label("Name:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtName.setStyleName("textBox");
		this.txtName.setWidth("200px");

		hp.add(lbl);
		hp.add(this.txtName);
		dp.addNorth(hp, 35);

		hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		lbl = new Label("JDBC Url:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtUrl.setStyleName("textBox");
		this.txtUrl.setWidth("200px");
		hp.add(lbl);
		hp.add(txtUrl);
		lbl = new Label("User:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtUser.setStyleName("textBox");
		this.txtUser.setWidth("100px");
		hp.add(lbl);
		hp.add(txtUser);
		lbl = new Label("Password:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtPassword.setStyleName("textBox");
		this.txtPassword.setWidth("100px");
		hp.add(lbl);
		hp.add(txtPassword);
		dp.addNorth(hp, 35);

		hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(2, Unit.PX);
		lbl = new Label("Schema:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtSchema.setWidth("100px");
		this.txtSchema.setStyleName("textBox");
		hp.add(lbl);
		hp.add(this.txtSchema);
		lbl = new Label("Table:");
		lbl.getElement().getStyle().setTextAlign(TextAlign.RIGHT);
		this.txtTable.setWidth("100px");
		this.txtTable.setStyleName("textBox");
		hp.add(lbl);
		hp.add(this.txtTable);
		dp.addNorth(hp, 30);

		lbl = new Label("Comma (,) separated fields name");
		this.taFields.setSize("580px", "50px");
		dp.addNorth(lbl, 25);
		dp.addNorth(this.taFields, 75);

		Button btn = new Button("Add Fields to List");
		btn.setSize("200px", "25px");
		btn.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				processFields();
			}
		});

		dp.addNorth(btn, 25);

		dp.addNorth(new Label("Fields in Source"), 20);
		this.lstFields.setSize("100px", "200px");
		this.lstFields.setVisibleItemCount(20);
		dp.addNorth(this.lstFields, 200);

		FlowPanel fp = new FlowPanel();
		Button btnOk = new Button("OK");
		Button btnCancel = new Button("Cancel");
		btnOk.getElement().getStyle().setFloat(Float.RIGHT);
		btnCancel.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btnOk);
		fp.add(btnCancel);
		dp.addSouth(fp, 30);

		btnOk.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});

		btnCancel.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});

		this.add(dp);
		this.initComponens();
	}

	void initComponens() {
		SourceRDBMS sr = (SourceRDBMS) this.widget;
		this.txtName.setText(sr.getName());
		this.txtSchema.setText(sr.getSchema());
		this.txtTable.setText(sr.getTableName());
		this.txtUrl.setText(sr.getJdbcUrl());
		this.txtUser.setText(sr.getUser());
		this.txtPassword.setText(sr.getPassword());

		StringBuffer buff = new StringBuffer();
		if (sr.getFields() != null && sr.getFields().size() > 0) {
			for (int i = 0; i < sr.getFields().size(); i++) {
				this.lstFields.addItem(sr.getFields().get(i).getName());
				if (i > 0) {
					buff.append(",");
				}
				buff.append(sr.getFields().get(i));
			}
		}

		this.taFields.setText(buff.toString());
	}

	void processOk() {
		SourceRDBMS sr = (SourceRDBMS) this.widget;
		sr.setName(this.txtName.getText());
		sr.setSchema(txtSchema.getText());
		sr.setTable(txtTable.getText());
		sr.setJdbcUrl(txtUrl.getText());
		sr.setUser(txtUrl.getText());
		sr.setPassword(txtPassword.getText());

		List<ColumnDto> lst = new ArrayList<ColumnDto>();
		for (int i = 0; i < this.lstFields.getItemCount(); i++) {
			ColumnDto dto = new ColumnDto();
			dto.setName(this.lstFields.getItemText(i));
			lst.add(dto);
		}

		sr.setFields(lst);

		this.hide();
	}

	void processCancel() {
		this.hide();
	}

	void processFields() {
		String[] fields = this.taFields.getText().split(",");
		this.lstFields.clear();

		for (String field : fields) {
			this.lstFields.addItem(field);
		}
	}
}
