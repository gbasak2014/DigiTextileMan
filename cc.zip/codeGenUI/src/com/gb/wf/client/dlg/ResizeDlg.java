package com.gb.wf.client.dlg;

import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class ResizeDlg extends SdpDialogBox {
	TextBox txtOldW = new TextBox();
	TextBox txtOldH = new TextBox();
	TextBox txtNewW = new TextBox();
	TextBox txtNewH = new TextBox();

	int w;
	int h;

	public ResizeDlg(String title, int oldWidth, int oldHeight) {
		super(false, true);
		this.setText(title);
		this.txtOldW.setText(String.valueOf(oldWidth));
		this.txtOldH.setText(String.valueOf(oldHeight));

		VerticalPanel vp = new VerticalPanel();

		HorizontalPanel hp = new HorizontalPanel();
		hp.add(new Label("Old Width:"));
		hp.add(this.txtOldW);
		hp.add(new Label("Old Height:"));
		hp.add(this.txtOldH);
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new Label("New Width:"));
		hp.add(this.txtNewW);
		hp.add(new Label("New Height:"));
		hp.add(this.txtNewH);
		vp.add(hp);

		FlowPanel fp = new FlowPanel();
		Button btn = new Button("OK", new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});
		btn.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btn);

		btn = new Button("Cancel", new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});
		btn.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btn);
		vp.add(fp);
		this.add(vp);
	}

	void processOk() {
		try {
			w = Integer.parseInt(this.txtNewW.getText());
			h = Integer.parseInt(this.txtNewH.getText());
			this.hide();
		} catch (Exception e) {

		}
	}

	void processCancel() {
		w = h = -1;
		this.hide();
	}

	void closeMe() {
		this.hide();
	}

	public int getNewWidth() {
		return this.w;
	}

	public int getNewHeight() {
		return this.h;
	}
}
