package com.gb.wf.client.dlg;

import com.gb.wf.client.ControllerService;
import com.gb.wf.client.ControllerServiceAsync;
import com.gb.wf.client.handler.WFActionHandler;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class OpenWfDlg extends SdpDialogBox {
	ListBox lstFields = new ListBox(false);
	WFActionHandler handler;
	long projectId;

	boolean isJob;
	private final ControllerServiceAsync service = GWT.create(ControllerService.class);

	public OpenWfDlg(WFActionHandler handler, long projectId, String msg, boolean isJob) {
		super(false, true);
		this.handler = handler;
		this.projectId = projectId;
		this.isJob = isJob;
		
		this.setSize("400px", "300px");
		this.setStyleName("gwt-DialogBox");
		DockLayoutPanel dp = new DockLayoutPanel(Unit.PX);
		dp.setSize("450px", "350px");
		dp.getElement().getStyle().setMargin(5, Unit.PX);
		dp.setStyleName("gwt-DialogBox");
		this.setText("Input Box");

		VerticalPanel vp = new VerticalPanel();

		HorizontalPanel hp = new HorizontalPanel();
		hp.add(new Label(msg));
		vp.add(hp);

		hp = new HorizontalPanel();
		hp.add(new Label("Value:"));
		lstFields.setVisibleItemCount(1);
		lstFields.setWidth("200px");
		hp.add(this.lstFields);
		vp.add(hp);

		FlowPanel fp = new FlowPanel();
		Button btn = new Button("OK", new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processOk();
			}
		});
		btn.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btn);

		btn = new Button("Cancel", new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				processCancel();
			}
		});
		btn.getElement().getStyle().setFloat(Float.RIGHT);
		fp.add(btn);
		vp.add(fp);
		this.add(vp);
		this.setModal(true);
		addJobList();
	}

	void addJobList() {
		
		this.service.getJobs(this.isJob, this.projectId, new AsyncCallback<String>() {

			@Override
			public void onSuccess(String jobs) {
				if ("ERROR".equals(jobs)) {
					Window.alert(jobs);
				} else {
					JSONArray json = JSONParser.parseStrict(jobs).isArray();
					int sz = json.size();
					lstFields.addItem("Select Workflow");
					for (int i = 0; i < sz; i++) {
						JSONObject row = json.get(i).isObject();
						lstFields.addItem(row.get("id").toString() + " - " + row.get("name").toString());
						// row.get("desc").toString()
					}
				}
			}
			@Override
			public void onFailure(Throwable t) {
				Window.alert("ERROR getting job details> " + t.getMessage());
			}
		});
	}

	void processOk() {
		this.hide();
		int idx = lstFields.getSelectedIndex();

		if (idx > 0) {
			String wf = lstFields.getItemText(idx);
			this.handler.openWorkflow(Long.parseLong(wf.split("-")[0].trim()));
		} else {
			Window.alert("Please Select job!!");
		}
	}

	void processCancel() {
		this.hide();
	}
}
