package com.gb.wf.client.component;

public interface SDPButtonActions {

	int WF_NEW = 1;
	int WF_SAVE = 2;
	int WF_SAVE_AS = 3;
	int WF_VIEW = 4;
	int WF_COMPILE = 5;
	int WF_OPEN = 6;

	int ADD_COLUMN = 7;
	int ADD_ALL_COLUMNS = 8;
	int REMOVE_COLUMN = 9;
	int INSERT_COLUMN = 10;
	int MOVE_UP = 11;
	int MOVE_DOWN = 12;
	int DELETE_ROW = 13;

	int ADD_JOIN = 14;
	int DELETE_JOIN = 15;
}
