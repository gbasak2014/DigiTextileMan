package com.gb.wf.client.component;

import com.google.gwt.dom.client.Style.BorderStyle;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.TextAlign;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextBox;

public class TransformationHeader extends FlowPanel {
	TextBox txtSlNo = new TextBox();
	TextBox txtTransformation = new TextBox();
	TextBox txtFieldName = new TextBox();

	public TransformationHeader() {
		this("Sl.No", "Transformation", "Column Name");
	}

	public TransformationHeader(String col1, String col2, String col3) {
		Label lblSlNo = new Label(col1);
		Label lblTrans = new Label(col2);
		Label lblField = new Label(col3);

		lblSlNo.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lblTrans.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lblField.getElement().getStyle().setTextAlign(TextAlign.CENTER);

		lblSlNo.getElement().getStyle().setBorderStyle(BorderStyle.SOLID);
		lblTrans.getElement().getStyle().setBorderStyle(BorderStyle.SOLID);
		lblField.getElement().getStyle().setBorderStyle(BorderStyle.SOLID);

		lblSlNo.setWidth("40px");
		lblTrans.setWidth("310px");
		lblField.setWidth("100px");

		lblSlNo.getElement().getStyle().setFloat(Float.LEFT);
		lblTrans.getElement().getStyle().setFloat(Float.LEFT);
		lblField.getElement().getStyle().setFloat(Float.LEFT);

		this.add(lblSlNo);
		this.add(lblTrans);
		this.add(lblField);
	}
}
