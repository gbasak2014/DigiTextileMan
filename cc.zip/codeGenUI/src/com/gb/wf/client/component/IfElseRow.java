package com.gb.wf.client.component;

import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextBox;

public class IfElseRow extends FlowPanel {
	ListBox lstFunction = new ListBox();
	TextBox txtSrc = new TextBox();
	TextBox txtTrg = new TextBox();
	String column;

	public IfElseRow(String col) {
		this(col, "=", "", "");
	}

	public IfElseRow(String col, String function, String src, String trg) {
		Label lbl = new Label(col);

		lbl.getElement().getStyle().setWidth(60, Unit.PX);
		lbl.getElement().getStyle().setHeight(20, Unit.PX);
		this.lstFunction.getElement().getStyle().setWidth(60, Unit.PX);
		this.lstFunction.getElement().getStyle().setHeight(20, Unit.PX);
		this.txtSrc.getElement().getStyle().setWidth(200, Unit.PX);
		this.txtSrc.getElement().getStyle().setHeight(20, Unit.PX);
		this.txtTrg.getElement().getStyle().setWidth(200, Unit.PX);
		this.txtTrg.getElement().getStyle().setHeight(20, Unit.PX);

		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.lstFunction.getElement().getStyle().setFloat(Float.LEFT);
		this.txtSrc.getElement().getStyle().setFloat(Float.LEFT);
		this.txtSrc.getElement().getStyle().setFloat(Float.LEFT);

		this.add(lbl);
		this.add(this.lstFunction);
		this.add(this.txtSrc);
		this.add(this.txtTrg);

		this.lstFunction.addItem("=");
		this.lstFunction.addItem(">=");
		this.lstFunction.addItem("<=");
		this.lstFunction.addItem(">");
		this.lstFunction.addItem("<");
		this.lstFunction.addItem("IN");
		this.lstFunction.addItem("StartWith");
		this.lstFunction.addItem("EndWith");
		this.lstFunction.addItem("Default");

		this.txtSrc.setText(src);
		this.txtTrg.setText(trg);
		int cnt = this.lstFunction.getItemCount();
		for (int i = 0; i < cnt; i++) {
			if (this.lstFunction.getItemText(i).equals(function)) {
				this.lstFunction.setSelectedIndex(i);
			}
		}
	}

	public JSONObject getJson() {
		JSONObject jo = new JSONObject();
		jo.put("operation", new JSONString(this.lstFunction.getItemText(this.lstFunction.getSelectedIndex())));
		jo.put("source", new JSONString(this.txtSrc.getText()));
		jo.put("target", new JSONString(this.txtTrg.getText()));

		return jo;
	}

	public String getString() {
		return getJson().toString();
	}

}
