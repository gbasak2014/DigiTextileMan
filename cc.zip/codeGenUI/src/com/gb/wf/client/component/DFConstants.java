package com.gb.wf.client.component;

public interface DFConstants {
	int Z_INDEX_DRAWING_SCROLLPANE = 1;
	int Z_INDEX_DRAWING_VIEW = 2;
	int Z_INDEX_PROPERTY_PANE = 3;
	int Z_INDEX_MENU = 4;
	int Z_INDEX_MENU_ITEM = 5;
	int Z_INDEX_DIALOGBOX = 6;
	int Z_INDEX_POPUP = 10;

	int WF_NEW = 19;
	int WF_SAVE = 20;
	int WF_SAVE_AS = 21;
	int WF_VIEW = 22;
	int WF_COMPILE = 23;
	int WF_OPEN = 24;
	int WF_REFESH = 25;
	int WF_RESIZE = 26;
	int WF_GRID = 27;
	int WF_RUN = 28;
	
	int ADD_USER = 101;
	int ADD_PROJECT = 102;
	int ADD_META = 103;
	int ADD_COMMON_SERVICES = 104;
	int ADD_UDF = 105;
	
	int PREVIOUS = 201;
}
