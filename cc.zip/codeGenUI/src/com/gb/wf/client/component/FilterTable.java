package com.gb.wf.client.component;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.dto.ConditionDto;
import com.gb.wf.client.handler.RowDeleteHandler;
import com.google.gwt.dom.client.Style.BorderStyle;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.ScrollPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;

public class FilterTable extends DockLayoutPanel implements RowDeleteHandler {
	VerticalPanel table = new VerticalPanel();
	List<FilterConditionRow> model = new ArrayList<FilterConditionRow>();

	List<ColumnDto> fields;

	public FilterTable(List<ColumnDto> fields) {
		super(Unit.PX);
		this.fields = fields;
		this.setSize("500px", "210px");
		ScrollPanel sp = new ScrollPanel();
		sp.getElement().getStyle().setBackgroundColor("#ffffff");
		sp.setSize("480px", "200px");
		table.setWidth("500px");
		sp.add(table);

		this.addNorth(new FilterConditionHeader(), 25);
		this.add(sp);
		this.getElement().getStyle().setBorderColor("#0");
		this.getElement().getStyle().setBorderStyle(BorderStyle.SOLID);

	}

	public void insertRow(String type) {
		FilterConditionRow row = new FilterConditionRow(this.fields, this, type);
		this.model.add(row);
		this.table.add(row);
	}

	public void insertRow(ConditionDto dto) {
		FilterConditionRow row = new FilterConditionRow(this.fields, this, dto.getType(), dto);
		this.model.add(row);
		this.table.add(row);
	}

	public void removeRow(JoinConditionRow row) {
		this.model.remove(row);
		this.table.remove(row);
	}

	public List<FilterConditionRow> getModel() {
		return this.model;
	}

	public JSONArray getJSON() {
		JSONArray jsonArr = new JSONArray();

		for (int i = 0; i < this.model.size(); i++) {
			FilterConditionRow row = this.model.get(i);
			jsonArr.set(i, row.getJSON());
		}

		return jsonArr;
	}

	public String getJSONString() {
		return getJSON().toString();
	}

	public int getRowCount() {
		return this.model.size();
	}

	@Override
	public void deleteRow(Widget widget) {
		this.model.remove(widget);
		this.table.remove(widget);
	}
}
