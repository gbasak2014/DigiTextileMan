package com.gb.wf.client.component;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.dto.ProjectDto;
import com.gb.wf.client.widget.ImageButton;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.ListBox;

public class SPDFToolBar extends FlowPanel {

	ListBox lstProject = new ListBox();
	List<ProjectDto> projects = new ArrayList<ProjectDto>();

	public SPDFToolBar(ClickHandler handler, List<ProjectDto> projectList) {

		this.setStyleName("toolbar");
		HorizontalPanel hp = new HorizontalPanel();
		hp.getElement().getStyle().setMargin(0, Unit.PX);
		hp.add(new Image("images/space.jpg"));
		hp.add(new ImageButton("images/new-wf.jpg", DFConstants.WF_NEW, "Create New Workflow", handler, 20, 20));
		hp.add(new ImageButton("images/open-wf.jpg", DFConstants.WF_OPEN, "Open Workflow", handler, 20, 20));
		hp.add(new ImageButton("images/save-wf.jpg", DFConstants.WF_SAVE, "Save Workflow", handler, 20, 20));
		hp.add(new ImageButton("images/saveas-wf.jpg", DFConstants.WF_SAVE_AS, "Save As Workflow", handler, 20, 20));
		hp.add(new ImageButton("images/view-wf.jpg", DFConstants.WF_VIEW, "View Workflow", handler, 20, 20));
		hp.add(new ImageButton("images/compile-wf.jpg", DFConstants.WF_COMPILE, "Compile Workflow to generate code",
				handler, 20, 20));
		hp.add(new ImageButton("images/run-wf.jpg", DFConstants.WF_RUN, "Execute Workflow", handler, 20, 20));

		hp.add(new ImageButton("images/btn-resize.jpg", DFConstants.WF_RESIZE, "Resize Design", handler, 20, 20));
		hp.add(new ImageButton("images/btn-grid.jpg", DFConstants.WF_GRID, "Show / Hide Grid", handler, 20, 20));

		this.lstProject.addItem("Select project");
		for (ProjectDto project : projectList) {
			this.lstProject.addItem(project.getId() + " - " + project.getName());
			this.projects.add(project);
		}
		this.lstProject.setSelectedIndex(0);

		hp.add(this.lstProject);

		hp.add(new ImageButton("images/btn-add-user.jpg", DFConstants.ADD_USER, "Add user", handler, 20, 20));
		hp.add(new ImageButton("images/btn-add-prg.jpg", DFConstants.ADD_PROJECT, "Add Project", handler, 20, 20));
		hp.add(new ImageButton("images/btn-add-src.jpg", DFConstants.ADD_META, "Create Source", handler, 20, 20));
		hp.add(new ImageButton("images/btn-common-service.jpg", DFConstants.ADD_COMMON_SERVICES, "Create Common services", handler, 20, 20));
		hp.add(new ImageButton("images/btn-udf.jpg", DFConstants.ADD_UDF, "Create UDF", handler, 20, 20));
		hp.add(new ImageButton("images/prev.jpg", DFConstants.PREVIOUS, "Previous Job/Process", handler, 20, 20));
		this.add(hp);
	}

	public void refeshProjectList(List<ProjectDto> projectList) {
		this.lstProject.clear();
		this.projects.clear();
		this.lstProject.addItem("Select project");
		for (ProjectDto project : projectList) {
			this.lstProject.addItem(project.getId() + " - " + project.getName());
			this.projects.add(project);
		}
	}

	public boolean isProjectSelected() {
		return this.lstProject.getSelectedIndex() > 0;
	}

	public long getSelectedProjectId() throws Exception {
		int idx = this.lstProject.getSelectedIndex();
		if (idx <= 0) {
			throw new Exception("Project not selected!!");
		}

		return Long.parseLong(this.lstProject.getItemText(idx).split("-")[0].trim());
	}

	public String getSelectedProjectName() throws Exception {
		int idx = this.lstProject.getSelectedIndex();
		if (idx <= 0) {
			throw new Exception("Project not selected!!");
		}

		return this.lstProject.getItemText(idx).split("-")[1].trim();
	}

	public ProjectDto getSelectedProject() throws Exception {
		long pid = this.getSelectedProjectId();
		for (ProjectDto pd : this.projects) {
			if (pd != null && pd.getId() != null && pd.getId().longValue() == pid) {
				return pd;
			}
		}

		return null;
	}
}
