package com.gb.wf.client.component;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.handler.TransRowSelectionHandler;
import com.google.gwt.dom.client.Style.BorderStyle;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.ScrollPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

public class TransformationTable extends DockLayoutPanel {
	VerticalPanel table = new VerticalPanel();
	List<TransformationRow> model = new ArrayList<TransformationRow>();
	TransRowSelectionHandler handler;

	public TransformationTable(TransRowSelectionHandler handler) {

		this(handler, 510, 410);
	}

	public TransformationTable(TransRowSelectionHandler handler, int width, int height) {
		super(Unit.PX);
		this.handler = handler;
		this.setSize(width + "px", height + "px");
		ScrollPanel sp = new ScrollPanel();
		sp.getElement().getStyle().setBackgroundColor("#ffffff");
		sp.getElement().getStyle().setBorderColor("#0");
		sp.getElement().getStyle().setBorderStyle(BorderStyle.SOLID);
		sp.setSize((width - 10) + "px", (height - 25) + "px");
		table.setWidth("500px");
		sp.add(table);

		this.addNorth(new TransformationHeader(), 25);
		this.add(sp);

	}

	public TransformationTable(TransRowSelectionHandler handler, TransformationHeader header) {
		super(Unit.PX);
		this.handler = handler;
		this.setSize("510px", "410px");
		ScrollPanel sp = new ScrollPanel();
		sp.getElement().getStyle().setBackgroundColor("#ffffff");
		sp.getElement().getStyle().setBorderColor("#0");
		sp.getElement().getStyle().setBorderStyle(BorderStyle.SOLID);
		sp.setSize("500px", "375px");
		table.setWidth("500px");
		sp.add(table);

		this.addNorth(header, 25);
		this.add(sp);
	}

	public TransformationTable(TransRowSelectionHandler handler, TransformationHeader header, int w, int h) {
		super(Unit.PX);
		this.handler = handler;
		this.setSize(w + "px", h + "px");
		ScrollPanel sp = new ScrollPanel();
		sp.getElement().getStyle().setBackgroundColor("#ffffff");
		sp.getElement().getStyle().setBorderColor("#0");
		sp.getElement().getStyle().setBorderStyle(BorderStyle.SOLID);
		sp.setSize((w - 10) + "px", (h - 25) + "px");
		table.setWidth((w - 10) + "px");
		sp.add(table);

		this.addNorth(header, 25);
		this.add(sp);
	}

	public void insertRow(String transformation, String field) {
		insertRow(transformation, field, this.getRowCount(), false);
	}

	public void insertRow(String transformation, String field, boolean isFunction) {
		insertRow(transformation, field, this.getRowCount(), isFunction);
	}

	public void insertRow(String transformation, String field, int index) {
		insertRow(transformation, field, index, false);
	}

	public void insertRow(String transformation, String field, int index, boolean isFunction) {
		TransformationRow row = new TransformationRow(this.handler, isFunction);
		
		if (isFunction && transformation.startsWith("If-Else-If"))
		{
			String[] arr = transformation.split("#");
			row.setTransformation(arr[0]);
			if (arr.length > 1)
			{
				String func = arr[1];
				if (arr.length > 2)
				{
					func = func + "#" + arr[2];
				}
				row.setFunction(func);
			}
		}
		else
		{
			row.setTransformation(transformation);
		}
		
		row.setFieldName(field);
		row.setSlNo(index);
		this.model.add(row);
		this.table.add(row);
	}

	public void removeRow(TransformationRow row) {
		this.model.remove(row);
		this.table.remove(row);
	}

	public List<TransformationRow> getModel() {
		return this.model;
	}

	public JSONArray getJSON() {
		JSONArray jsonArr = new JSONArray();

		for (int i = 0; i < this.model.size(); i++) {
			TransformationRow row = this.model.get(i);
			jsonArr.set(i, row.getJSON());
		}

		return jsonArr;
	}

	public String getJSONString() {
		return getJSON().toString();
	}

	public int getRowCount() {
		return this.model.size();
	}
}
