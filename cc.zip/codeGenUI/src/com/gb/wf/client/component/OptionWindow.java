package com.gb.wf.client.component;

import com.gb.wf.client.handler.WFActionHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Grid;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.PopupPanel;
import com.google.gwt.user.client.ui.RadioButton;

public class OptionWindow extends PopupPanel {
	public static final int OPTION_SAVE = 0;
	public static final int OPTION_OPEN = 1;
	RadioButton rbJob = new RadioButton("wf", "Job");
	RadioButton rbProcess = new RadioButton("wf", "Process");

	WFActionHandler actionHandler;
	int option;

	public OptionWindow(int option) {
		this.option = option;

		final Image img = new Image("images/loader.gif");
		img.setWidth("40px");
		img.setHeight("40px");
		HorizontalPanel hp = new HorizontalPanel();
		Grid grid = new Grid(4, 1);
		Label lbl;
		switch (this.option) {
		case OPTION_SAVE:
			lbl = new Label("Save As....");
			break;
		case OPTION_OPEN:
			lbl = new Label("Open As....");
			break;
		default:
			lbl = new Label("Save As....");
			break;
		}

		lbl.getElement().getStyle().setColor("WHITE");
		this.rbJob.getElement().getStyle().setColor("WHITE");
		this.rbProcess.getElement().getStyle().setColor("WHITE");
		grid.setWidget(0, 0, lbl);
		grid.setWidget(1, 0, this.rbJob);
		grid.setWidget(2, 0, this.rbProcess);
		grid.setWidget(3, 0, hp);
		hp.add(new Button("Ok", new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				processOK();
			}
		}));
		hp.add(new Button("Cancel", new ClickHandler() {
			@Override
			public void onClick(ClickEvent arg0) {
				processCancel();
			}
		}));
		this.add(grid);
		this.setWidth("400px");
		this.setHeight("200px");
		this.getElement().getStyle().setBackgroundColor("#1F3D47");
	}

	void processCancel() {
		this.hide();
	}

	void processOK() {
		switch (this.option) {
		case OPTION_SAVE:
			this.actionHandler.saveWorkflow(this.rbProcess.getValue());
			break;
		case OPTION_OPEN:
			this.actionHandler.openWorkflow(this.rbJob.getValue());
			break;
		default:
			this.actionHandler.saveWorkflow(this.rbProcess.getValue());
			break;
		}

		this.hide();
	}

	public void show(WFActionHandler actionHandler) {
		this.actionHandler = actionHandler;
		this.center();
		this.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_POPUP);
		this.show();
	}
}
