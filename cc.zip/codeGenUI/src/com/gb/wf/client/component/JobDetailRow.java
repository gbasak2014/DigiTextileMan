package com.gb.wf.client.component;

import com.gb.wf.client.handler.JobOpenHandler;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.TextAlign;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.Label;

public class JobDetailRow extends FlowPanel {
	String id;
	JobOpenHandler handler;

	public JobDetailRow() {
		this.getElement().getStyle().setBorderWidth(1, Unit.PX);
		this.getElement().getStyle().setBorderColor("gray");
		this.getElement().getStyle().setHeight(20, Unit.PX);
		Label lbl = new Label("Job Id");
		lbl.getElement().getStyle().setWidth(100, Unit.PX);
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);

		lbl = new Label("Name");
		lbl.getElement().getStyle().setWidth(200, Unit.PX);
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);

		lbl = new Label("Description");
		lbl.getElement().getStyle().setWidth(300, Unit.PX);
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);

		lbl = new Label("Action");
		lbl.getElement().getStyle().setWidth(100, Unit.PX);
		lbl.getElement().getStyle().setTextAlign(TextAlign.CENTER);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);
	}

	public JobDetailRow(String id, String name, String desc, JobOpenHandler handler) {
		this.getElement().getStyle().setBorderWidth(1, Unit.PX);
		this.getElement().getStyle().setBorderColor("gray");
		this.id = id;
		this.handler = handler;

		this.getElement().getStyle().setHeight(20, Unit.PX);
		Label lbl = new Label(String.valueOf(id));
		lbl.getElement().getStyle().setWidth(100, Unit.PX);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);

		lbl = new Label(name);
		lbl.getElement().getStyle().setWidth(200, Unit.PX);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);

		lbl = new Label(desc);
		lbl.getElement().getStyle().setWidth(300, Unit.PX);
		lbl.getElement().getStyle().setFloat(Float.LEFT);
		this.add(lbl);

		Button btn = new Button("Open");
		btn.getElement().getStyle().setHeight(20, Unit.PX);
		this.add(btn);
		btn.addClickHandler(new ClickHandler() {
			@Override
			public void onClick(ClickEvent ce) {
				openWf();
			}
		});
		
		this.getElement().getStyle().setBorderWidth(0.25, Unit.PX);
		this.getElement().getStyle().setBorderColor("0");
	}

	void openWf() {
		this.handler.openJob(Long.valueOf(this.id));
	}
}
