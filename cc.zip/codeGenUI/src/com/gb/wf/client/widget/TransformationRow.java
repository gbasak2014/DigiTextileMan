package com.gb.wf.client.widget;

import java.util.List;

import com.google.gwt.dom.client.Style.BorderStyle;
import com.google.gwt.dom.client.Style.Float;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

public class TransformationRow extends FlowPanel {
	VerticalPanel parent;

	TextBox txtIndex;
	ListBox listFunction;
	TextBox txtArgument;
	ListBox listColumns;
	TextBox txtColumnName;
	
	public TransformationRow(VerticalPanel parent, List<String> columns) {
		super();
		this.parent = parent;
		txtIndex = new TextBox();
		txtIndex.setStyleName("textBox");
		txtIndex.getElement().getStyle().setWidth(40, Unit.PX);
		txtIndex.getElement().getStyle().setFloat(Float.LEFT);

		listFunction = new ListBox();
		listFunction.addItem("Identical");
		listFunction.addItem("concat");
		listFunction.addItem("add");
		listFunction.addItem("dateFormat");
		listFunction.getElement().getStyle().setWidth(200, Unit.PX);
		listFunction.setVisibleItemCount(1);
		listFunction.getElement().getStyle().setFloat(Float.LEFT);

		txtArgument = new TextBox();
		txtArgument.setStyleName("textBox");
		txtArgument.getElement().getStyle().setWidth(320, Unit.PX);
		txtArgument.getElement().getStyle().setFloat(Float.LEFT);

		
		this.listColumns = new ListBox();
		this.listColumns.setVisibleItemCount(1);
		this.listColumns.getElement().getStyle().setWidth(100, Unit.PX);
		this.listColumns.getElement().getStyle().setFloat(Float.LEFT);
		
		for (String col : columns)
		{
			this.listColumns.addItem(col);
		}
		
		ImageButton btn = new ImageButton("images/rm.jpg", 1, "Remove row", new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				removeMe();
			}
		}, 20, 20);

		btn.getElement().getStyle().setFloat(Float.LEFT);

		this.txtColumnName = new TextBox();
		this.txtColumnName.setStyleName("textBox");
		this.txtColumnName.getElement().getStyle().setWidth(100, Unit.PX);
		this.txtColumnName.getElement().getStyle().setFloat(Float.LEFT);
		
		
		this.add(txtIndex);
		this.add(listFunction);
		this.add(txtArgument);
		this.add(listColumns);
		this.add(txtColumnName);
		this.add(btn);
		this.getElement().getStyle().setWidth(800, Unit.PX);
		this.getElement().getStyle().setBorderColor("#000");
		this.getElement().getStyle().setBorderStyle(BorderStyle.SOLID);
		this.getElement().getStyle().setBorderWidth(1, Unit.PX);
		
		
		this.listColumns.addChangeHandler(new ChangeHandler() {
			
			@Override
			public void onChange(ChangeEvent event) {
				addTransParams();
			}
		});
	}

	void addTransParams()
	{
		String col = "$" + listColumns.getValue(listColumns.getSelectedIndex());
		String args = txtArgument.getText();
		if (args != null && args.length() > 0)
		{
			args = args + "," + col;
		}
		else
		{
			args = col;
		}
		
		txtArgument.setText(args);
	}
	
	void removeMe() {
		this.parent.remove(this);
	}
	
	
}
