package com.gb.wf.client.widget;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dlg.SourceFilePropDlg;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class SourceHDFS extends SDPWidget {
	long metaId;
	String sourcePath;
	String delimiter;
	boolean deleteOnSuccess;
	boolean renameOnSuccess;
	String movePath;
	String suffix;

	String fileType;

	public SourceHDFS(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/src-hdfs.jpg", "HDFS File Source", ComponentTypes.SOURCE_HDFS, ComponentTypes.SOURCE, popupMenu, clickHandler);
	}

	@Override
	public void setProperties(JSONObject json) {
		super.setProperties(json);

		this.metaId = json.get("metaId") != null ? (long) json.get("metaId").isNumber().doubleValue() : -1;
		this.sourcePath = json.get("sourcePath") != null ? json.get("sourcePath").isString().stringValue() : "";
		this.delimiter = json.get("delimiter") != null ? json.get("delimiter").isString().stringValue() : "";
		this.deleteOnSuccess = json.get("deleteOnSuccess") != null ? json.get("deleteOnSuccess").isBoolean().booleanValue() : false;
		this.renameOnSuccess = json.get("renameOnSuccess") != null ? json.get("renameOnSuccess").isBoolean().booleanValue() : false;
		this.movePath = json.get("movePath") != null ? json.get("movePath").isString().stringValue() : "";
		this.suffix = json.get("suffix") != null ? json.get("suffix").isString().stringValue() : "";
		this.fileType = json.get("fileType") != null ? json.get("fileType").isString().stringValue() : "";
	}

	public String getSourcePath() {
		return sourcePath;
	}

	public void setSourcePath(String path) {
		this.sourcePath = path;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public boolean isDeleteOnSuccess() {
		return deleteOnSuccess;
	}

	public void setDeleteOnSuccess(boolean deleteOnSuccess) {
		this.deleteOnSuccess = deleteOnSuccess;
	}

	public String getMovePath() {
		return movePath;
	}

	public void setMovePath(String movePath) {
		this.movePath = movePath;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String toString() {
		return getJSON().toString();
	}

	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		json.put("metaId", new JSONNumber(this.getMetaId()));
		json.put("sourcePath", new JSONString(this.getSourcePath()));
		json.put("fileType", new JSONString(this.getFileType()));
		json.put("delimiter", new JSONString(this.getDelimiter()));
		json.put("deleteSource", new JSONString(this.deleteOnSuccess ? "true" : "false"));
		json.put("renameSource", new JSONString(this.renameOnSuccess ? "true" : "false"));
		json.put("renameSuffix", new JSONString(this.suffix != null ? this.suffix : ".DONE"));

		return json;
	}

	public boolean isRenameOnSuccess() {
		return renameOnSuccess;
	}

	public void setRenameOnSuccess(boolean renameOnSuccess) {
		this.renameOnSuccess = renameOnSuccess;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		try {
			return new SourceFilePropDlg(this, projectId);
		} catch (Exception e) {
			Window.alert("ERROR:" + e.getMessage());
		}
		return null;

	}

	public long getMetaId() {
		return metaId;
	}

	public void setMetaId(long metaId) {
		this.metaId = metaId;
	}
}