package com.gb.wf.client.widget;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dlg.SourceTCPPropDlg;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class SourceTcp extends SDPWidget {
	long metaId;
	String host;
	int port;
	int interval;
	String recordType;
	String delimiter;

	public SourceTcp(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/src-tcp.jpg", "TCP Socket Streaming source", ComponentTypes.SOURCE_TCP, ComponentTypes.SOURCE, popupMenu,
				clickHandler);
	}

	public int getInterval() {
		return interval;
	}

	public void setInterval(int interval) {
		this.interval = interval;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		return new SourceTCPPropDlg(this);
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}
}
