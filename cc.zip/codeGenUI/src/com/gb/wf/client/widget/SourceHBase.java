package com.gb.wf.client.widget;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dlg.SourceHBasePropDlg;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class SourceHBase extends SDPWidget {
	String table;

	public SourceHBase(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/src-hbase.jpg", "HDFS File Source", ComponentTypes.SOURCE_HBASE, ComponentTypes.SOURCE, popupMenu, clickHandler);
	}

	public String getTableName() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		return new SourceHBasePropDlg(this);
	}
}
