package com.gb.wf.client.widget;

import java.util.List;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.DataFramePropDlg;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONObject;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class DataFrame extends SDPWidget {

	List<String> dataTypes;
	public DataFrame(SDPPopupMenu popupMenu, ClickHandler clickHandler, List<String> dataTypes) {
		super("images/dataframe.jpg", "DataFrame", ComponentTypes.DATAFRAME, ComponentTypes.DATAFRAME, popupMenu, clickHandler);
		this.dataTypes = dataTypes;
	}

	@Override
	public void setProperties(JSONObject json) {
		super.setProperties(json);
	}

	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();

		return json;
	}

	@Override
	public String toString() {
		return getJSON().toString();
	}

	public List<String> getDataTypeList()
	{
		return this.dataTypes;
	}
	
	@Override
	public SdpDialogBox getPropertyEditor(long id) {
		return new DataFramePropDlg(this);
	}
}