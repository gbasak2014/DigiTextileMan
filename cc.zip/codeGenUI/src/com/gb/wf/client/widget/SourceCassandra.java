package com.gb.wf.client.widget;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class SourceCassandra extends SDPWidget {

	public SourceCassandra(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/src-cassandra.jpg", "Cassandra Source", ComponentTypes.SOURCE_CASSANDRA, ComponentTypes.SOURCE, popupMenu,
				clickHandler);
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		// TODO Auto-generated method stub
		return null;
	}
}
