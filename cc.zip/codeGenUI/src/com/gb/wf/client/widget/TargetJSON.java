package com.gb.wf.client.widget;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.JsonPropDlg;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class TargetJSON extends SDPWidget {
	String path;

	public TargetJSON(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/trg-json.jpg", "SourceJSON", ComponentTypes.TARGET_JSON, ComponentTypes.TARGET_JSON, popupMenu, clickHandler);
	}

	@Override
	public void setProperties(JSONObject json) {
		super.setProperties(json);
		this.path = json.get("path") != null ? json.get("path").isString().stringValue() : null;
	}
	
	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		this.addParentFields();
		return new JsonPropDlg(this);
	}

	@Override
	public JSONObject getJSON() {
		this.addParentFields();
		JSONObject json = super.getJSON();
		json.put("path", new JSONString(this.path));

		return json;
	}
}
