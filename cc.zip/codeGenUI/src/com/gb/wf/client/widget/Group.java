package com.gb.wf.client.widget;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.GroupPropDlg;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dto.TransformationDto;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class Group extends SDPWidget {
	List<TransformationDto> transformations = new ArrayList<TransformationDto>();
	String groupByCols="";

	public Group(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/group-wf.jpg", "Group Data", ComponentTypes.GROUP, ComponentTypes.GROUP, popupMenu, clickHandler);
	}

	public List<TransformationDto> getTransformations() {
		return transformations;
	}

	public void setTransformations(List<TransformationDto> transformations) {
		this.transformations = transformations;
	}

	@Override
	public void setProperties(JSONObject json) {
		super.setProperties(json);
		this.groupByCols = json.get("groupByColumns") != null ? json.get("groupByColumns").isString().stringValue() : null;
		JSONArray arr = json.get("transformations") != null ? json.get("transformations").isArray() : null;
		if (arr != null)
		{
			for (int i=0; i<arr.size(); i++)
			{
				JSONObject obj = arr.get(i).isObject();
				int idx = obj.get("index") != null ? (int)obj.get("index").isNumber().doubleValue() : -1;
				String trns = obj.get("transform") != null ? obj.get("transform").isString().stringValue() : null;
				String tf = obj.get("targetField") != null ? obj.get("targetField").isString().stringValue() : null;
				this.transformations.add(new TransformationDto(idx, trns, tf));
			}
		}
	}
	
	
	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		json.put("groupByColumns", new JSONString(this.getGroupByCols()));
		JSONArray arr = new JSONArray();
		int idx = 0;
		for (TransformationDto dto : transformations) {
			JSONObject obj = new JSONObject();
			obj.put("index", new JSONNumber(dto.getIndex()));
			obj.put("transform", new JSONString(dto.getFunction()));
			obj.put("targetField", new JSONString(dto.getFieldName()));
			arr.set(idx, obj);
			idx++;
		}

		json.put("transformations", arr);

		return json;
	}

	public String getGroupByCols() {
		return groupByCols;
	}

	public void setGroupByCols(String groupByCols) {
		this.groupByCols = groupByCols;
	}

	@Override
	public String toString() {
		return getJSON().toString();
	}

	@Override
	public SdpDialogBox getPropertyEditor(long id) {
		GroupPropDlg dlg = new GroupPropDlg(this);
		return dlg;
	}
}
