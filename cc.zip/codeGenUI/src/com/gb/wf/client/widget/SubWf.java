package com.gb.wf.client.widget;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.component.WFDesignerPage;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dlg.SubWfDlg;
import com.gb.wf.client.dto.ParamDto;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;

/**
 * Joining multiple RDD
 * 
 * @author Gouranga Basak
 *
 */
public class SubWf extends SDPWidget {

	WFDesignerPage designerPage;
	long subWfId;
	String description;
	long projectId;
	List<ParamDto> argParamList = new ArrayList<ParamDto>();
	String subWfName;
	
	public SubWf(WFDesignerPage designerPage, SDPPopupMenu popupMenu, ClickHandler clickHandler, long projectId) {
		super("images/subwf.jpg", "SubWorkflow", ComponentTypes.SUB_WF, ComponentTypes.SUB_WF, popupMenu, clickHandler);
		this.designerPage = designerPage;
		this.projectId = projectId;
	}

	@Override
	public void setProperties(JSONObject json) {
		super.setProperties(json);
		this.projectId = json.get("projectId") != null ? (long) json.get("projectId").isNumber().doubleValue() : -1;
		this.subWfId = json.get("subWfId") != null ? (long) json.get("subWfId").isNumber().doubleValue() : -1;
		this.description = json.get("description") != null ? json.get("description").isString().stringValue() : "";
		this.subWfName = json.get("subWfName") != null ? json.get("subWfName").isString().stringValue() : "";
		
		this.argParamList.clear();
		JSONArray arr = json.get("paramArgMap").isArray();
		int s = arr.size();
		for (int i = 0; i < s; i++) {
			JSONObject obj = arr.get(i).isObject();
			String nm = obj.get("name") != null ? obj.get("name").isString().stringValue() : "";
			String tp = obj.get("type") != null ? obj.get("type").isString().stringValue() : "";
			int pos = obj.get("pos") != null ? (int) obj.get("pos").isNumber().doubleValue() : -1;
			ParamDto dto = new ParamDto(-1, nm, tp, pos);
			argParamList.add(dto);
		}
	}

	@Override
	public void addPredecessor(SDPWidget predecessor) {
		this.predecessors.add(predecessor);
	}
	
	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		json.put("projectId", new JSONNumber(this.projectId));
		json.put("subWfId", new JSONNumber(this.subWfId));
		json.put("subWfName", new JSONString(this.subWfName));
		json.put("description", new JSONString(this.description));

		JSONArray arr = new JSONArray();
		int i = 0;
		for (ParamDto pd : this.argParamList) {
			JSONObject obj = new JSONObject();
			obj.put("name", new JSONString(pd.getParam()));
			obj.put("type", new JSONString(pd.getType()));
			obj.put("pos", new JSONNumber(pd.getPos()));
			arr.set(i, obj);
			i++;
		}
		json.put("paramArgMap", arr);

		return json;
	}

	@Override
	public String toString() {
		return this.getJSON().toString();
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		SDPWidget p = this.getPredecessors().get(0);
		while (!"start".equalsIgnoreCase(p.getName())) {
			p = p.getPredecessors().get(0);
		}

		if (!"start".equalsIgnoreCase(p.getName())) {
			Window.alert("Please add start node...");
			return null;
		}

		Start start = (Start) p;

		return new SubWfDlg(this, start.getParams());
	}

	public WFDesignerPage getDesignerPage() {
		return designerPage;
	}

	public void setDesignerPage(WFDesignerPage designerPage) {
		this.designerPage = designerPage;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getReturnType() {
		return returnType;
	}

	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}

	public long getSubWfId() {
		return subWfId;
	}

	public void setSubWfId(long subWfId) {
		this.subWfId = subWfId;
	}

	public long getProjectId() {
		return projectId;
	}

	public void setProjectId(long projectId) {
		this.projectId = projectId;
	}

	public List<ParamDto> getArgParamList() {
		return argParamList;
	}

	public void setArgParamList(List<ParamDto> argParamList) {
		this.argParamList = argParamList;
	}

	public String getSubWfName() {
		return subWfName;
	}

	public void setSubWfName(String subWfName) {
		this.subWfName = subWfName;
	}
}
