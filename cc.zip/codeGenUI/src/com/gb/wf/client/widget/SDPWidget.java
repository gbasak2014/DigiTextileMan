package com.gb.wf.client.widget;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.component.DFConstants;
import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.ContextMenuEvent;
import com.google.gwt.event.dom.client.ContextMenuHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Image;

public abstract class SDPWidget extends Button {
	long id;
	int left;
	int top;
	int group;
	int type;
	String name;
	List<ColumnDto> fields = new ArrayList<ColumnDto>();

	List<SDPWidget> successors = new ArrayList<SDPWidget>();
	List<SDPWidget> predecessors = new ArrayList<SDPWidget>();

	boolean readOnly = false;
	String returnType = "DataFrame";

	public SDPWidget(String imgSrc, String title, int type, int group, final SDPPopupMenu popup, ClickHandler clickHandler) {
		super();
		this.type = type;
		this.group = group;
		this.name = title;
		Image img = new Image(imgSrc);

		this.getElement().appendChild(img.getElement());
		this.setSize("20px", "20px");
		this.setTitle(title);
		this.getElement().getStyle().setPadding(0, Unit.PX);

		this.sinkEvents(Event.ONCONTEXTMENU);
		if (popup != null) {
			this.addHandler(new ContextMenuHandler() {

				@Override
				public void onContextMenu(ContextMenuEvent event) {
					popup.setPopupPosition(event.getNativeEvent().getClientX(), event.getNativeEvent().getClientY());
					showPopup(popup);
				}
			}, ContextMenuEvent.getType());

		}

		if (clickHandler != null) {
			this.addClickHandler(clickHandler);
			img.addClickHandler(clickHandler);
		}
	}

	public void testSDPWidget11111(String title, int type, int group, final SDPPopupMenu popup, ClickHandler clickHandler) {
		this.setStyleName("imgButton");
		this.type = type;
		this.group = group;
		this.name = title;

		this.setSize("20px", "20px");
		this.setTitle(title);
		this.getElement().getStyle().setPadding(0, Unit.PX);

		this.sinkEvents(Event.ONCONTEXTMENU);
		this.addHandler(new ContextMenuHandler() {

			@Override
			public void onContextMenu(ContextMenuEvent event) {
				popup.setPopupPosition(event.getNativeEvent().getClientX(), event.getNativeEvent().getClientY());
				showPopup(popup);
			}
		}, ContextMenuEvent.getType());

		this.addClickHandler(clickHandler);
	}

	public String getTitle() {
		return this.getTitle();
	}

	public void addChild(SDPWidget child) {
		this.successors.add(child);
		child.addPredecessor(this);
		// child.predecessors.add(this);
		// child.getFields().clear();
		// for (int i = 0; i < this.fields.size(); i++) {
		// child.getFields().add(this.fields.get(i));
		// }
	}

	public void addPredecessor(SDPWidget predecessor) {
		this.predecessors.add(predecessor);
		this.fields.clear();
		for (int i = 0; i < predecessor.fields.size(); i++) {
			this.fields.add(predecessor.fields.get(i));
		}
	}

	public void removeChild(SDPWidget child) {
		this.successors.remove(child);
		child.predecessors.remove(this);
	}

	public int getGroup() {
		return group;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
		this.setTitle(name);
	}

	public List<SDPWidget> getSuccessors() {
		return successors;
	}

	public void setSuccessors(List<SDPWidget> successors) {
		this.successors = successors;
	}

	public List<SDPWidget> getPredecessors() {
		return predecessors;
	}

	public void setPredecessors(List<SDPWidget> predecessors) {
		this.predecessors = predecessors;
	}

	public List<ColumnDto> getFields() {
		return fields;
	}

	public void setFields(List<ColumnDto> fields) {
		this.fields = fields;
	}

	public JSONObject getJSON() {
		JSONObject json = new JSONObject();
		json.put("id", new JSONNumber(this.id));
		json.put("name", new JSONString(this.getName()));
		json.put("componentType", new JSONNumber(this.getType()));
		json.put("fields", getFieldsJSON());
		json.put("predecessors", getPredecessorJSON());
		json.put("successors", getSuccessorJSON());
		json.put("absolutePos", new JSONString(this.getAbsoluteLeft() + ":" + this.getAbsoluteTop()));
		json.put("left", new JSONNumber(this.left));
		json.put("top", new JSONNumber(this.top));
		json.put("returnType", new JSONString(this.returnType));
		return json;
	}

	void showPopup(SDPPopupMenu popup) {
		popup.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_POPUP);
		popup.setGlassEnabled(true);
		popup.setSelectedWidget(this);
		if (ComponentTypes.SUB_WF != this.getType())
		{
			popup.showEdit(false);
		}
		else
		{
			popup.showEdit(true);
		}
		popup.show();
	}

	public JSONArray getFieldsJSON() {
		JSONArray fieldsArr = new JSONArray();
		for (int i = 0; i < this.fields.size(); i++) {
			JSONObject col = new JSONObject();
			ColumnDto dto = this.fields.get(i);
			col.put("name", new JSONString(dto.getName()));
			col.put("dataType", new JSONString(dto.getDataType()));
			col.put("sensitiveFlag", new JSONString(dto.getSensitiveFlag().toString()));
			col.put("pos", new JSONNumber(dto.getPos()));
			col.put("id", new JSONNumber(dto.getId()));

			fieldsArr.set(i, col);
		}

		return fieldsArr;
	}

	public JSONArray getPredecessorJSON() {
		JSONArray pArr = new JSONArray();
		for (int i = 0; i < this.predecessors.size(); i++) {
			pArr.set(i, new JSONString(predecessors.get(i).getName()));
		}

		return pArr;
	}

	public JSONArray getSuccessorJSON() {
		JSONArray sArr = new JSONArray();
		for (int i = 0; i < this.successors.size(); i++) {
			sArr.set(i, new JSONString(successors.get(i).getName()));
		}

		return sArr;
	}

	public void setProperties(JSONObject json) {
		this.id = json.get("id") != null ? (long) json.get("id").isNumber().doubleValue() : -1;
		this.name = json.get("name") != null ? json.get("name").isString().stringValue() : "";
		this.returnType = json.get("returnType") != null ? json.get("returnType").isString().stringValue() : "DataFrame";
		this.left = json.get("left") != null ? (int) json.get("left").isNumber().doubleValue() : 0;
		this.top = json.get("top") != null ? (int) json.get("top").isNumber().doubleValue() : 0;
		this.group = json.get("group") != null ? (int) json.get("group").isNumber().doubleValue() : 0;
		this.type = json.get("componentType") != null ? (int) json.get("componentType").isNumber().doubleValue() : 0;

		if (json.get("fields") != null) {
			JSONArray arrFiled = json.get("fields").isArray();
			for (int i = 0; i < arrFiled.size(); i++) {
				JSONObject f = arrFiled.get(i).isObject();
				ColumnDto dto = new ColumnDto();
				dto.setDataType(f.get("dataType") != null ? f.get("dataType").isString().stringValue() : "");
				dto.setId(f.get("id") != null ? (long) f.get("id").isNumber().doubleValue() : -1);
				dto.setName(f.get("name") != null ? f.get("name").isString().stringValue() : "");
				dto.setPos(f.get("pos") != null ? (int) f.get("pos").isNumber().doubleValue() : -1);
				dto.setSensitiveFlag(f.get("sensitiveFlag") != null ? "true".equals(f.get("sensitiveFlag").isString().stringValue()) : false);
				this.fields.add(dto);
			}
		}
	}

	@Override
	public String toString() {
		return this.getJSON().toString();
	}

	public void addParentFields() {
		this.fields.clear();
		for (ColumnDto f : this.predecessors.get(0).getFields()) {
			this.fields.add(f);
		}
	}

	public void postProcess() {
	}

	public void setPosition(int l, int t) {
		this.left = l;
		this.top = t;
	}

	public abstract SdpDialogBox getPropertyEditor(long projectId);

	public int getLeft() {
		return left;
	}

	public void setLeft(int left) {
		this.left = left;
	}

	public int getTop() {
		return top;
	}

	public void setTop(int top) {
		this.top = top;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public boolean isReadOnly() {
		return readOnly;
	}

	public void setReadOnly(boolean readOnly) {
		this.readOnly = readOnly;
	}

	public String getReturnType() {
		return returnType;
	}

	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}

}
