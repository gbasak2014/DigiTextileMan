package com.gb.wf.client.widget;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dlg.TargetFilePropDlg;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/**
 * Target path in hdfs
 * 
 * @author Gouranga Basak
 *
 */
public class TargetHDFS extends SDPWidget {
	String path;

	public TargetHDFS(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/trg-hdfs.jpg", "Target HDFS", ComponentTypes.TARGET_HDFS, ComponentTypes.DESTINATION, popupMenu, clickHandler);
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		json.put("path", new JSONString(this.getPath()));

		return json;
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		return new TargetFilePropDlg(this);
	}
}
