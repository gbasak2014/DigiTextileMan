package com.gb.wf.client.widget;

import java.util.HashMap;
import java.util.Map;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dlg.ServicePropDlg;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class CommonService extends SDPWidget {
	long serviceId;
	String serviceName;
	
	Map<String, String> params = new HashMap<String, String>();
	String returnCategory;

	public CommonService(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/common-service.jpg", "Service", ComponentTypes.CUSTOM_SERVICES, ComponentTypes.CUSTOM_SERVICES, popupMenu, clickHandler);
	}

	@Override
	public void setProperties(JSONObject json) {
		super.setProperties(json);
		this.serviceId = json.get("serviceId") != null ? (long) json.get("serviceId").isNumber().doubleValue() : -1;
		this.returnCategory = json.get("returnCategory") != null ? json.get("returnCategory").isString().stringValue() : "";
		this.serviceName = json.get("serviceName") != null ? json.get("serviceName").isString().stringValue() : "";
		
		JSONArray arr = json.get("params") != null ? json.get("params").isArray() : null;

		if (arr != null) {
			int s = arr.size();
			for (int i = 0; i < s; i++) {
				JSONObject obj = arr.get(i).isObject();
				String name = obj.get("name").isString().stringValue();
				String type = obj.get("type").isString().stringValue();
				this.params.put(name, type);
			}
		}

	}

	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		json.put("serviceId", new JSONNumber(this.serviceId));
		json.put("returnCategory", new JSONString(this.returnCategory));
		json.put("serviceName", new JSONString(this.serviceName));
		
		JSONArray arr = new JSONArray();
		int i = 0;
		for (String pNm : this.params.keySet()) {
			JSONObject prm = new JSONObject();
			String pType = this.params.get(pNm);
			prm.put("name", new JSONString(pNm));
			prm.put("type", new JSONString(pType));
			arr.set(i, prm);
			i++;
		}
		json.put("params", arr);

		return json;
	}

	@Override
	public String toString() {
		return getJSON().toString();
	}

	@Override
	public SdpDialogBox getPropertyEditor(long id) {
		SDPWidget p = this.getPredecessors().get(0);
		while (!"start".equalsIgnoreCase(p.getName())) {
			p = p.getPredecessors().get(0);
		}

		if (!"start".equalsIgnoreCase(p.getName())) {
			Window.alert("Please add start node...");
			return null;
		}

		Start s = (Start) p;

		return new ServicePropDlg(this, s.getProjectId(), s.getParams());
	}

	public long getServiceId() {
		return serviceId;
	}

	public void setServiceId(long serviceId) {
		this.serviceId = serviceId;
	}

	public Map<String, String> getParams() {
		return params;
	}

	public void setParams(Map<String, String> params) {
		this.params = params;
	}

	public String getReturnCategory() {
		return returnCategory;
	}

	public void setReturnCategory(String returnCategory) {
		this.returnCategory = returnCategory;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
}