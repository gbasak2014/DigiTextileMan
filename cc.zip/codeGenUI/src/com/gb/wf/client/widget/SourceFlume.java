package com.gb.wf.client.widget;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dlg.SourceFlumePropDlg;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/**
 * Flume sink for streaming source
 * 
 * @author Gouranga Basak
 *
 */
public class SourceFlume extends SDPWidget {
	String host="";
	int port=9999;
	int interval=1;
	String recordType="delimited";
	String delimiter=",";

	public SourceFlume(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/src-flume.jpg", "Flume Streaming source", ComponentTypes.SOURCE_TCP, ComponentTypes.SOURCE, popupMenu, clickHandler);
	}

	public int getInterval() {
		return interval;
	}

	public void setInterval(int interval) {
		this.interval = interval;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		return new SourceFlumePropDlg(this);
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}
	
	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		
		json.put("host", new JSONString(this.getHost()));
		json.put("port", new JSONNumber(this.getPort()));
		json.put("interval", new JSONNumber(this.getInterval()));
		json.put("recordType", new JSONString(this.getRecordType()));
		json.put("delimiter", new JSONString(this.getDelimiter()));

		return json;
	}
	
}
