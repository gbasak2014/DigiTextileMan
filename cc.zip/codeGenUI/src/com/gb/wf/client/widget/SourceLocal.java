package com.gb.wf.client.widget;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dlg.SourceFilePropDlg;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class SourceLocal extends SDPWidget {
	long metaId;
	String path;
	String delimiter;
	boolean deleteOnSuccess;
	boolean renameOnSuccess;
	String movePath;
	String suffix;

	String fileFormat;
	String targetPath;

	public SourceLocal(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/src-local.jpg", "Local File Source", ComponentTypes.SOURCE_LOCAL, ComponentTypes.SOURCE, popupMenu, clickHandler);
	}

	@Override
	public void setProperties(JSONObject json) {
		super.setProperties(json);
		
		this.metaId = json.get("metaId") != null ? (long)json.get("metaId").isNumber().doubleValue() : -1;
		this.path = json.get("sourcePath") != null ? json.get("sourcePath").isString().stringValue() : null;
		this.delimiter = json.get("delimiter") != null ? json.get("delimiter").isString().stringValue() : null;
		this.deleteOnSuccess = json.get("deleteOnSuccess") != null ? "true".equals(json.get("deleteOnSuccess").isString().stringValue()) : false;
		this.renameOnSuccess = json.get("renameOnSuccess") != null ? "true".equals(json.get("renameOnSuccess").isString().stringValue()) : false;
		this.movePath = json.get("movePath") != null ? json.get("movePath").isString().stringValue() : null;
		this.suffix = json.get("suffix") != null ? json.get("suffix").isString().stringValue() : null;
		this.fileFormat = json.get("fileFormat") != null ? json.get("fileFormat").isString().stringValue() : null;
		this.targetPath = json.get("targetPath") != null ? json.get("targetPath").isString().stringValue() : null;
	}
	
	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public boolean isDeleteOnSuccess() {
		return deleteOnSuccess;
	}

	public void setDeleteOnSuccess(boolean deleteOnSuccess) {
		this.deleteOnSuccess = deleteOnSuccess;
	}

	public String getMovePath() {
		return movePath;
	}

	public void setMovePath(String movePath) {
		this.movePath = movePath;
	}

	@Override
	public String toString() {
		return getJSON().toString();
	}

	public boolean isRenameOnSuccess() {
		return renameOnSuccess;
	}

	public void setRenameOnSuccess(boolean renameOnSuccess) {
		this.renameOnSuccess = renameOnSuccess;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public String getFileFormat() {
		return fileFormat;
	}

	public void setFileFormat(String fileFormat) {
		this.fileFormat = fileFormat;
	}

	public String getTargetPath() {
		return targetPath;
	}

	public void setTargetPath(String targetPath) {
		this.targetPath = targetPath;
	}

	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		json.put("metaId", new JSONNumber(this.getMetaId()));
		json.put("sourcePath", new JSONString(this.getPath()));
		json.put("targetPath", new JSONString(this.getTargetPath()));
		json.put("fileFormat", new JSONString(this.getFileFormat()));
		json.put("delimiter", new JSONString(this.getDelimiter()));
		json.put("deleteSource", new JSONString(this.deleteOnSuccess ? "true" : "false"));
		json.put("renameSource", new JSONString(this.renameOnSuccess ? "true" : "false"));
		json.put("renameSuffix", new JSONString(this.suffix != null ? this.suffix : ".DONE"));

		return json;
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		try{
		return new SourceFilePropDlg(this, projectId);
		}
		catch(Exception e)
		{
			Window.alert("ERROR:" + e.getMessage());
		}
		return null;
	}

	public long getMetaId() {
		return metaId;
	}

	public void setMetaId(long metaId) {
		this.metaId = metaId;
	}
}
