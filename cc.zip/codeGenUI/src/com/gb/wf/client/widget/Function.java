package com.gb.wf.client.widget;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dlg.StartPropDlg;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class Function extends SDPWidget {
	public Function(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/function.jpg", "Function", ComponentTypes.FUNCTION, ComponentTypes.FUNCTION, popupMenu, clickHandler);
	}

	@Override
	public void setProperties(JSONObject json) {
		super.setProperties(json);

	}

	@Override
	public JSONObject getJSON() {
		JSONObject json = new JSONObject();
		json.put("id", new JSONNumber(this.getId()));
		json.put("name", new JSONString(this.getName()));
		json.put("componentType", new JSONNumber(this.getType()));
		json.put("successors", this.getSuccessorJSON());
		json.put("absolutePos", new JSONString(this.getAbsoluteLeft() + ":" + this.getAbsoluteTop()));
		json.put("left", new JSONNumber(this.left));
		json.put("top", new JSONNumber(this.top));

		return json;

	}

	@Override
	public String toString() {
		return getJSON().toString();
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		return new StartPropDlg(this);
	}

}
