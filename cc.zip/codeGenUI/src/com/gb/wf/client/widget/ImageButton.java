package com.gb.wf.client.widget;

import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.PushButton;

public class ImageButton extends PushButton {
	int command;

	public ImageButton() {
		this.command = -1;
		this.setSize("20px", "20px");
		this.getElement().getStyle().setPadding(0, Unit.PX);
	}

	public ImageButton(String srcImage, int command, String title, ClickHandler handler) {
		this.command = command;
		Image img = new Image(srcImage);
		this.getElement().appendChild(img.getElement());
		this.addClickHandler(handler);
		this.setSize("20px", "20px");
		this.setTitle(title);
		this.getElement().getStyle().setPadding(0, Unit.PX);
	}

	public ImageButton(String srcImage, int command, String title, ClickHandler handler, int width, int height) {
		this.command = command;
		Image img = new Image(srcImage);
		this.getElement().appendChild(img.getElement());
		this.addClickHandler(handler);
		this.setSize(width + "px", height + "px");
		this.setTitle(title);
		this.getElement().getStyle().setPadding(0, Unit.PX);
	}

	public int getCommand() {
		return this.command;
	}
}
