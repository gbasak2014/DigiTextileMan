package com.gb.wf.client.widget;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dlg.SourceRDBMSPropDlg;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class SourceRDBMS extends SDPWidget {
	long metaId;
	String jdbcUrl;
	String user;
	String password;
	String table;
	String schema;

	public SourceRDBMS(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/src-db.jpg", "HDFS File Source", ComponentTypes.SOURCE_RDBMS, ComponentTypes.SOURCE, popupMenu, clickHandler);
	}

	public String getJdbcUrl() {
		return jdbcUrl;
	}

	public void setJdbcUrl(String jdbcUrl) {
		this.jdbcUrl = jdbcUrl;
	}

	public String getTableName() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		return new SourceRDBMSPropDlg(this);
	}

	public long getMetaId() {
		return metaId;
	}

	public void setMetaId(long metaId) {
		this.metaId = metaId;
	}

	public String getTable() {
		return table;
	}
}
