package com.gb.wf.client.widget;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.JsonPropDlg;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class TargetXML extends SDPWidget {
	String rootElement;
	String path;

	public TargetXML(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/trg-xml.jpg", "SourceJSON", ComponentTypes.TARGET_XML, ComponentTypes.TARGET_XML, popupMenu, clickHandler);
	}

	@Override
	public void setProperties(JSONObject json) {
		super.setProperties(json);
		this.rootElement = json.get("root") != null ? json.get("root").isString().stringValue() : null;
		this.path = json.get("path") != null ? json.get("path").isString().stringValue() : null;
	}
	
	public String getRootElement() {
		return rootElement;
	}

	public void setRootElement(String rootElement) {
		this.rootElement = rootElement;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		json.put("root", new JSONString(this.getRootElement()));
		json.put("path", new JSONString(this.path));

		return json;
	}

	@Override
	public String toString() {
		return this.getJSON().toString();
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		return new JsonPropDlg(this);
	}

}
