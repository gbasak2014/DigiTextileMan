package com.gb.wf.client.widget;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class TargetCassandra extends SDPWidget {
	String jdbcUrl;
	String table;
	String schema;

	public TargetCassandra(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/trg-cassandra.jpg", "Cassandra Source", ComponentTypes.TARGET_CASSANDRA, ComponentTypes.DESTINATION, popupMenu,
				clickHandler);
	}

	public String getJdbcUrl() {
		return jdbcUrl;
	}

	public void setJdbcUrl(String jdbcUrl) {
		this.jdbcUrl = jdbcUrl;
	}

	public String getTableName() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		// TODO Auto-generated method stub
		return null;
	}
}
