package com.gb.wf.client.widget;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dlg.SqoopPropDlg;
import com.gb.wf.client.handler.WFActionHandler;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/**
 * Represent Sqoop import
 * 
 * @author Gouranga Basak
 *
 */
public class Sqoop extends SDPWidget {
	long metaId;
	String schema;
	String table;
	String url;
	String user;
	String pwd;
	String importType;
	String checkColumn;
	String targetDir;
	String outDir;
	String incremental;
	String lastValue;
	String delimiter;
	String dateTmBehav;
	WFActionHandler wfActionHandler;
	public Sqoop(SDPPopupMenu popupMenu, ClickHandler clickHandler, WFActionHandler wfActionHandler) {
		super("images/sqoop.jpg", "Sqoop Import", ComponentTypes.SQOOP, ComponentTypes.SQOOP, popupMenu, clickHandler);
		this.wfActionHandler = wfActionHandler;
	}

	@Override
	public void setProperties(JSONObject json) {
		super.setProperties(json);
		this.metaId = json.get("metaId") != null ? (long)json.get("metaId").isNumber().doubleValue() : -1L;
		this.schema = json.get("schema") != null ? json.get("schema").isString().stringValue() : "";
		this.table = json.get("table") != null ? json.get("table").isString().stringValue() : "";
		this.url = json.get("url") != null ? json.get("url").isString().stringValue() : "";
		this.user = json.get("user") != null ? json.get("user").isString().stringValue() : "";
		this.pwd = json.get("pwd") != null ? json.get("pwd").isString().stringValue() : "";
		this.importType = json.get("importType") != null ? json.get("importType").isString().stringValue() : "";
		this.checkColumn = json.get("checkColumn") != null ? json.get("checkColumn").isString().stringValue() : "";
		this.targetDir = json.get("targetDir") != null ? json.get("targetDir").isString().stringValue() : "";
		this.outDir = json.get("outDir") != null ? json.get("outDir").isString().stringValue() : "";
		this.incremental = json.get("incremental") != null ? json.get("incremental").isString().stringValue() : "";
		this.lastValue = json.get("lastValue") != null ? json.get("lastValue").isString().stringValue() : "";
		this.delimiter = json.get("delimiter") != null ? json.get("delimiter").isString().stringValue() : "";
		this.dateTmBehav = json.get("dateTmBehav") != null ? json.get("dateTmBehav").isString().stringValue() : "";
	}

	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		json.put("metaId", new JSONNumber(this.metaId));
		json.put("schema", new JSONString(this.schema));
		json.put("table", new JSONString(this.table));
		json.put("url", new JSONString(this.url));
		json.put("user", new JSONString(this.user));
		json.put("pwd", new JSONString(this.pwd));
		json.put("importType", new JSONString(this.importType));
		json.put("checkColumn", new JSONString(this.checkColumn));
		json.put("targetDir", new JSONString(this.targetDir));
		json.put("outDir", new JSONString(this.outDir));
		json.put("incremental", new JSONString(this.incremental));
		json.put("lastValue", new JSONString(this.lastValue));
		json.put("delimiter", new JSONString(this.delimiter));
		json.put("dateTmBehav", new JSONString(this.dateTmBehav));

		return json;
	}

	@Override
	public String toString() {
		return this.getJSON().toString();
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		return new SqoopPropDlg(this, projectId, this.wfActionHandler);
	}

	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}

	public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getImportType() {
		return importType;
	}

	public void setImportType(String importType) {
		this.importType = importType;
	}

	public String getCheckColumn() {
		return checkColumn;
	}

	public void setCheckColumn(String checkColumn) {
		this.checkColumn = checkColumn;
	}

	public String getTargetDir() {
		return targetDir;
	}

	public void setTargetDir(String targetDir) {
		this.targetDir = targetDir;
	}

	public String getOutDir() {
		return outDir;
	}

	public void setOutDir(String outDir) {
		this.outDir = outDir;
	}

	public String getIncremental() {
		return incremental;
	}

	public void setIncremental(String incremental) {
		this.incremental = incremental;
	}

	public String getLastValue() {
		return lastValue;
	}

	public void setLastValue(String lastValue) {
		this.lastValue = lastValue;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public long getMetaId() {
		return metaId;
	}

	public void setMetaId(long metaId) {
		this.metaId = metaId;
	}

	public String getDateTmBehav() {
		return dateTmBehav;
	}

	public void setDateTmBehav(String dateTmBehav) {
		this.dateTmBehav = dateTmBehav;
	}

}
