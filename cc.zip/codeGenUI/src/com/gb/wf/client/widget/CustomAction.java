package com.gb.wf.client.widget;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.CustomActionPropDlg;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.json.client.JSONValue;

/**
 * Represent custom action on dataframes using java/scala code.
 * 
 * @author Gouranga Basak
 *
 */
public class CustomAction extends SDPWidget {
	String actionName;
	String code;
	Map<String, String> params = new HashMap<String, String>();
	List<String> imports = new ArrayList<String>();
	String retCategory;
	
	public CustomAction(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/custom-action.jpg", "CustomAction", ComponentTypes.CUSTOM_ACTION, ComponentTypes.ACTION, popupMenu, clickHandler);
	}

	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		json.put("actionName", new JSONString(this.getActionName()));
		json.put("code", new JSONString(this.getCode()));
		JSONArray arr = new JSONArray();
		int i = 0;
		for (SDPWidget pw : this.getPredecessors()) {
			String pt = pw.getName();
			String prm = this.params.get(pt);
			JSONObject rt = new JSONObject();
			rt.put("type", new JSONString(pt));
			rt.put("value", new JSONString(prm));
			arr.set(i, rt);
			i++;
		}

		json.put("params", arr);
		String str = "";
		for (String imp : this.imports) {
			if (str.length() > 0) {
				str = str + ",";
			}

			str = str + imp;
		}

		json.put("imports", new JSONString(str));
		json.put("returnCategory", new JSONString(this.getRetCategory()));
		
		return json;
	}

	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Map<String, String> getParams() {
		return params;
	}

	public void setParams(Map<String, String> params) {
		this.params = params;
	}

	public List<String> getImports() {
		return this.imports;
	}

	@Override
	public void setProperties(JSONObject json) {
		super.setProperties(json);
		this.actionName = json.get("actionName") != null ? json.get("actionName").isString().stringValue() : "";
		this.code = json.get("code") != null ? json.get("code").isString().stringValue() : "";
		JSONArray arr = json.get("params").isArray();
		int s = arr.size();
		for (int i = 0; i < s; i++) {
			JSONObject o = arr.get(i).isObject();
			this.params.put(o.get("type").isString().stringValue(), o.get("value").isString().stringValue());
		}

		JSONValue ii = json.get("imports");
		if (ii != null) {
			for (String imp : ii.isString().stringValue().split(",")) {
				this.imports.add(imp);
			}
		}

	}

	@Override
	public String toString() {
		return getJSON().toString();
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		return new CustomActionPropDlg(this);
	}

	public String getRetCategory() {
		return retCategory;
	}

	public void setRetCategory(String retCategory) {
		this.retCategory = retCategory;
	}

	public void setImports(List<String> imports) {
		this.imports = imports;
	}

}
