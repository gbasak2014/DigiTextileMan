package com.gb.wf.client.widget;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.dlg.SortPropDlg;
import com.gb.wf.client.dto.OrderDto;
import com.gb.wf.client.util.ComponentTypes;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/**
 * Represent SORT Dataset
 * 
 * @author Gouranga Basak
 *
 */
public class Sort extends SDPWidget {
	List<OrderDto> orderBy = new ArrayList<OrderDto>();

	public Sort(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/sort-wf.jpg", "Split Sources", ComponentTypes.SORT, ComponentTypes.SORT, popupMenu, clickHandler);
	}

	public List<OrderDto> getOrderByColumns() {
		return this.orderBy;
	}

	public void addOrderBy(OrderDto orderCols) {
		this.orderBy.add(orderCols);
	}

	public void clearAllOrder() {
		this.orderBy.clear();
	}

	@Override
	public void setProperties(JSONObject json) {
		super.setProperties(json);
		
		if (json.get("orderBy") != null)
		{
			JSONArray arr = json.get("orderBy").isArray();
			for (int i=0; i<arr.size(); i++)
			{
				JSONObject obj = arr.get(i).isObject();
				String column = obj.get("column") != null ? obj.get("column").isString().stringValue() : null;
				String order = obj.get("order") != null ? obj.get("order").isString().stringValue() : null;
				this.orderBy.add(new OrderDto(column, order));
			}
		}
	}
	
	
	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		JSONArray arr = new JSONArray();
		int idx = 0;
		for (OrderDto dto : this.getOrderByColumns()) {
			JSONObject obj = new JSONObject();
			obj.put("column", new JSONString(dto.getField()));
			obj.put("order", new JSONString(dto.getOrder()));
			arr.set(idx, obj);
			idx++;
		}

		json.put("orderBy", arr);

		return json;
	}

	@Override
	public String toString() {
		return this.getJSON().toString();
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		// TODO Auto-generated method stub
		return new SortPropDlg(this);
	}
}
