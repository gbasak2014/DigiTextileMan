package com.gb.wf.client.dto;

import com.google.gwt.json.client.JSONNumber;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

public class ParamDto {
	long id;
	String param;
	String type;
	int pos;

	public ParamDto(long id, String param, String type, int pos) {
		this.id = id;
		this.param = param;
		this.type = type;
		this.pos = pos;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getParam() {
		return param;
	}

	public void setParam(String param) {
		this.param = param;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getPos() {
		return pos;
	}

	public void setPos(int pos) {
		this.pos = pos;
	}

	public JSONObject getJSON() {
		JSONObject json = new JSONObject();
		json.put("id", new JSONNumber(this.id));
		json.put("param", new JSONString(this.param));
		json.put("type", new JSONString(this.type));
		json.put("pos", new JSONNumber(this.pos));

		return json;
	}

}
