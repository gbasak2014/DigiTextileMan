package com.gb.wf.client.dto;

public class JoinDto {
	String leftSchema;
	String rightSchema;
	String joinType;
	String leftColumn;
	String rightColumn;
	String joinCondition;

	public JoinDto() {
		this.joinCondition = " = ";
	}
	public JoinDto(String leftSchema, String rightSchema, String joinType, String leftColumn, String rightColumn) {
		this(leftSchema, rightSchema, joinType, leftColumn, rightColumn, " = ");
	}

	public JoinDto(String leftSchema, String rightSchema, String joinType, String leftColumn, String rightColumn, String joinCondition) {
		this.leftSchema = leftSchema;
		this.rightSchema = rightSchema;
		this.joinType = joinType;
		this.leftColumn = leftColumn;
		this.rightColumn = rightColumn;
		this.joinCondition = joinCondition;
	}
	
	public String getLeftSchema() {
		return leftSchema;
	}

	public void setLeftSchema(String leftSchema) {
		this.leftSchema = leftSchema;
	}

	public String getRightSchema() {
		return rightSchema;
	}

	public void setRightSchema(String rightSchema) {
		this.rightSchema = rightSchema;
	}

	public String getJoinType() {
		return joinType;
	}

	public void setJoinType(String joinType) {
		this.joinType = joinType;
	}

	public String getLeftColumn() {
		return leftColumn;
	}

	public void setLeftColumn(String leftColumn) {
		this.leftColumn = leftColumn;
	}

	public String getRightColumn() {
		return rightColumn;
	}

	public void setRightColumn(String rightColumn) {
		this.rightColumn = rightColumn;
	}

	public String getJoinCondition() {
		return joinCondition;
	}

	public void setJoinCondition(String joinCondition) {
		this.joinCondition = joinCondition;
	}

	@Override
	public String toString() {
		return leftSchema + " " + joinType + " " + rightSchema + " ON " + leftColumn + joinCondition + rightColumn;
	}
}
