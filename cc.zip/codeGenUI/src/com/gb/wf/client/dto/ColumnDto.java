package com.gb.wf.client.dto;

public class ColumnDto {
	long id = -1;
	String name;
	Boolean sensitiveFlag;
	Integer pos;
	String dataType;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Boolean getSensitiveFlag() {
		return sensitiveFlag;
	}

	public void setSensitiveFlag(Boolean sensitiveFlag) {
		this.sensitiveFlag = sensitiveFlag;
	}

	public Integer getPos() {
		return pos;
	}

	public void setPos(Integer pos) {
		this.pos = pos;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "{id:" + this.id + ",name:" + this.name + ", dataType:" + this.dataType + ", pos:" + this.pos + ", sensitiveFlag:" + this.sensitiveFlag + "}";
	}
}
