package com.gb.wf.client.dto;

import java.util.List;

public class UserDto {
	String status;
	String userName;
	String userId;
	List<String> roles;
	List<ProjectDto> projects;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public List<ProjectDto> getProjects() {
		return projects;
	}

	public void setProjects(List<ProjectDto> projects) {
		this.projects = projects;
	}

	@Override
	public String toString() {
		return this.userId + ", " + this.userName + ", " + this.projects + ", " + this.roles;
	}
}
