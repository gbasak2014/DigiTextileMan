package com.gb.wf.client.handler;

public interface TitleChangeListener {
	void titleChanged(String title);
}
