package com.gb.wf.client.handler;

import java.util.List;

import com.gb.wf.client.ControllerService;
import com.gb.wf.client.ControllerServiceAsync;
import com.gb.wf.client.component.DFConstants;
import com.gb.wf.client.component.OptionWindow;
import com.gb.wf.client.component.WFDesignerPage;
import com.gb.wf.client.dlg.AddProjectDlg;
import com.gb.wf.client.dlg.AddUserDlg;
import com.gb.wf.client.dlg.ExecuteWfDlg;
import com.gb.wf.client.dlg.JobDetailDlg;
import com.gb.wf.client.dlg.OpenWfDlg;
import com.gb.wf.client.dlg.ResizeDlg;
import com.gb.wf.client.dlg.ServiceAddDlg;
import com.gb.wf.client.dlg.SourceMetaDlg;
import com.gb.wf.client.dto.ProjectDto;
import com.gb.wf.client.util.ComponentTypes;
import com.gb.wf.client.widget.CustomAction;
import com.gb.wf.client.widget.ImageButton;
import com.gb.wf.client.widget.SDPWidget;
import com.gb.wf.client.widget.Start;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.json.client.JSONString;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * Handle Menu Item click event
 * 
 * @author Gouranga Basak
 *
 */
public class WFActionHandler implements ClickHandler {
	private final ControllerServiceAsync service = GWT.create(ControllerService.class);

	WFDesignerPage designerPage;

	long jobId;
	long jobName;

	public WFActionHandler(WFDesignerPage designerPage) {
		this.designerPage = designerPage;
	}

	@Override
	public void onClick(ClickEvent event) {
		OptionWindow optionWindow;
		ImageButton btn = (ImageButton) event.getSource();
		switch (btn.getCommand()) {
		case DFConstants.WF_NEW:
			this.newWorkflow();
			break;
		case DFConstants.WF_SAVE:
			if (this.designerPage.isNewJob()) {
				optionWindow = new OptionWindow(OptionWindow.OPTION_SAVE);
				optionWindow.show(this);
			} else {
				boolean subWf = this.designerPage.isSubWorkflow();
				Window.alert("Sub>>" + subWf);
				this.saveWorkflow(subWf);
			}
			break;
		case DFConstants.WF_SAVE_AS:
			this.saveAsWorkflow();
			break;
		case DFConstants.WF_VIEW:
			optionWindow = new OptionWindow(OptionWindow.OPTION_OPEN);
			optionWindow.show(this);
			break;
		case DFConstants.WF_COMPILE:
			this.compileWorkflow();
			break;
		case DFConstants.WF_OPEN:
			optionWindow = new OptionWindow(OptionWindow.OPTION_OPEN);
			optionWindow.show(this);
			break;
		case DFConstants.WF_RESIZE:
			resizeDesign();
			break;
		case DFConstants.WF_GRID:
			showHideGrid();
			break;
		case DFConstants.ADD_PROJECT:
			addProject();
			break;
		case DFConstants.ADD_USER:
			addUser();
			break;
		case DFConstants.ADD_META:
			addMeta();
			break;
		case DFConstants.WF_RUN:
			openExecuteWorkflow();
			break;
		case DFConstants.ADD_COMMON_SERVICES:
			openCommonServiceDlg();
			break;
		case DFConstants.ADD_UDF:
			openUDFDlg();
			break;
		case DFConstants.PREVIOUS:
			long prvId = this.designerPage.getPreviousId();
			if (prvId > 0) {
				this.openWorkflow(prvId);
				this.designerPage.saveCurrentId(prvId);
			}
			break;
		}
	}

	void openCommonServiceDlg() {
		try {
			long projectId = this.designerPage.getSelectedProjectId();
			ServiceAddDlg dlg = new ServiceAddDlg(new CustomAction(null, null), this.designerPage, ServiceAddDlg.SERVICE, projectId);
			dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
			dlg.center();
			dlg.show();
		} catch (Exception e) {
			Window.alert("Please select project!!");
		}
	}

	void openUDFDlg() {
		try {
			long projectId = this.designerPage.getSelectedProjectId();
			ServiceAddDlg dlg = new ServiceAddDlg(new CustomAction(null, null), this.designerPage, ServiceAddDlg.UDF, projectId);
			dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
			dlg.center();
			dlg.show();
		} catch (Exception e) {
			Window.alert("Please select project!!");
		}
	}

	void showHideGrid() {
		designerPage.getDrawingController().getDiagramController().showGrid(!designerPage.getDrawingController().getDiagramController().isShowGrid());
	}

	void resizeDesign() {
		int w = designerPage.getDrawingController().getDiagramController().getCanvasWidth();
		int h = designerPage.getDrawingController().getDiagramController().getCanvasHeight();

		ResizeDlg dlg = new ResizeDlg("Resize Design", w, h);
		dlg.setTitle("Transformation");
		dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
		dlg.center();
		dlg.show();

		w = dlg.getNewWidth();
		h = dlg.getNewHeight();
		if (w > 0) {
			designerPage.getDrawingController().getDiagramController().getDiagramCanvas().setWidth(w);
			designerPage.getDrawingController().getDiagramController().getDiagramCanvas().setHeight(h);
		}
	}

	void newWorkflow() {
		this.designerPage.getDrawingController().removeAll();
	}

	void saveWorkflow() {
		boolean input = Window.confirm("Save as Sub Workflow?");
		this.designerPage.showProgress("Saving Workflow....");
		this.service.saveWorkflow(this.getJobJson(input), new AsyncCallback<String>() {
			@Override
			public void onSuccess(String msg) {
				JSONObject jo = JSONParser.parseStrict(msg).isObject();
				if (!"SUCCESS".equalsIgnoreCase(jo.get("status").isString().stringValue())) {
					Window.alert("Error saving job!!!");
				} else {
					designerPage.processOpenWorkFlow(jo.toString());
				}

				designerPage.stopProgress();
			}

			@Override
			public void onFailure(Throwable arg0) {
				designerPage.stopProgress();
				Window.alert("Error....");
			}
		});
	}

	public void saveWorkflow(boolean isSubWorkflow) {
		this.designerPage.showProgress("Saving Workflow....");
		this.service.saveWorkflow(this.getJobJson(isSubWorkflow), new AsyncCallback<String>() {
			@Override
			public void onSuccess(String msg) {
				JSONObject jo = JSONParser.parseStrict(msg).isObject();
				if (!"SUCCESS".equalsIgnoreCase(jo.get("status").isString().stringValue())) {
					Window.alert("Error saving job!!!");
				} else {
					designerPage.processOpenWorkFlow(jo.toString());
				}

				designerPage.stopProgress();
			}

			@Override
			public void onFailure(Throwable arg0) {
				designerPage.stopProgress();
				Window.alert("Error....");
			}
		});
	}

	void saveAsWorkflow() {
		boolean input = Window.confirm("Save as Sub Workflow?");
		this.service.saveWorkflow(this.getJobJson(input), new AsyncCallback<String>() {
			@Override
			public void onSuccess(String msg) {
				JSONObject jo = JSONParser.parseStrict(msg).isObject();

				Window.alert(jo.get("data").isString().stringValue());
			}

			@Override
			public void onFailure(Throwable arg0) {
				Window.alert("Error....");
			}
		});
	}

	void viewWorkflow(boolean isJob) {
		long prgId = 0;
		try {
			prgId = this.designerPage.getSelectedProjectId();

		} catch (Exception e) {
			Window.alert("Select Project!!");
			return;
		}

		this.service.getJobs(isJob, prgId, new AsyncCallback<String>() {

			@Override
			public void onSuccess(String jobs) {
				
				if ("ERROR".equals(jobs)) {
					Window.alert(jobs);
				} else {
					openJobDtlDlg(jobs);
				}
			}

			@Override
			public void onFailure(Throwable t) {
				Window.alert("ERROR getting job details: " + t.getMessage());
			}
		});
	}

	public void openWorkflow(boolean isJob) {
		try {
			long pId = this.designerPage.getSelectedProjectId();
			String pName = this.designerPage.getSelectedProjectName();

			OpenWfDlg dlg = new OpenWfDlg(this, pId, "Please enter Job Name for Project: " + pId + " - " + pName, isJob);
			dlg.setTitle("Message Box");
			dlg.setModal(true);
			dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
			dlg.center();
			dlg.show();
		} catch (Exception e) {
			Window.alert("ERROR: " + e.getMessage());
		}
	}

	void openJobDtlDlg(String jobs) {
		JobDetailDlg dlg = new JobDetailDlg(this, jobs);
		dlg.setTitle("Job Detils");
		dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
		dlg.center();
		dlg.show();
	}

	void compileWorkflow() {
		this.designerPage.showProgress("Compiling workflow......");
		this.service.compileJob(this.getJobJson(false), new AsyncCallback<String>() {

			@Override
			public void onSuccess(String msg) {
				designerPage.stopProgress();
				Window.alert("Success>>" + msg);
			}

			@Override
			public void onFailure(Throwable arg0) {
				designerPage.stopProgress();
				Window.alert("...Error...");
			}
		});
	}

	public void openWorkflow(long wfId) {
		this.designerPage.showProgress("Opening workflow....");

		this.service.openWorkflow(String.valueOf(wfId), new AsyncCallback<String>() {
			@Override
			public void onSuccess(String json) {
				designerPage.processOpenWorkFlow(json);
				designerPage.stopProgress();
			}

			@Override
			public void onFailure(Throwable err) {
				designerPage.stopProgress();
				Window.alert(err.getMessage());
			}
		});
	}

	public void openWorkflow(long projectId, String wfId) {
		this.service.openWorkflow(wfId, new AsyncCallback<String>() {
			@Override
			public void onSuccess(String json) {
				designerPage.processOpenWorkFlow(json);
			}

			@Override
			public void onFailure(Throwable err) {
				Window.alert(err.getMessage());
			}
		});
	}

	private String getJobJson(boolean subWorkflow) {
		JSONObject jsonRoot = new JSONObject();
		int paneLeft = this.designerPage.getDrawingController().getAbsoluteLeft();
		int paneTop = this.designerPage.getDrawingController().getAbsoluteTop();

		List<SDPWidget> list = this.designerPage.getDrawingController().getWidgets();
		for (SDPWidget w : list) {
			int l = w.getAbsoluteLeft() - paneLeft;
			int t = w.getAbsoluteTop() - paneTop;
			w.setPosition(l, t);

			try {
				if (w.getType() == ComponentTypes.START) {
					jsonRoot.put("start", w.getJSON());
				} else if (w.getType() == ComponentTypes.END) {
					jsonRoot.put("end", w.getJSON());
				} else {
					jsonRoot.put(w.getName(), w.getJSON());
				}
			} catch (Exception e) {
				Window.alert("ERROR for '" + w.getName() + "' - " + e.getMessage());
			}
		}

		if (subWorkflow) {
			jsonRoot.put("type", new JSONString("SUB_WORKFLOW"));
		} else {
			jsonRoot.put("type", new JSONString("JOB"));
		}

		return jsonRoot.toString();
	}

	public String getJobJson(JSONObject cluster, JSONObject param) {
		JSONObject jsonRoot = new JSONObject();
		int paneLeft = this.designerPage.getDrawingController().getAbsoluteLeft();
		int paneTop = this.designerPage.getDrawingController().getAbsoluteTop();

		List<SDPWidget> list = this.designerPage.getDrawingController().getWidgets();
		for (SDPWidget w : list) {
			int l = w.getAbsoluteLeft() - paneLeft;
			int t = w.getAbsoluteTop() - paneTop;
			w.setPosition(l, t);

			try {
				if (w.getType() == ComponentTypes.START) {
					jsonRoot.put("start", w.getJSON());
				} else if (w.getType() == ComponentTypes.END) {
					jsonRoot.put("end", w.getJSON());
				} else {
					jsonRoot.put(w.getName(), w.getJSON());
				}
			} catch (Exception e) {
				Window.alert("ERROR for '" + w.getName() + "' - " + e.getMessage());
			}
		}

		jsonRoot.put("cluster", cluster);

		if (param != null) {
			jsonRoot.put("parameters", param);
		}
		return jsonRoot.toString();
	}

	private void addUser() {
		AddUserDlg dlg = new AddUserDlg(this.designerPage.getUser());
		dlg.setModal(false);
		dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
		dlg.setGlassEnabled(true);
		dlg.setAnimationEnabled(true);
		dlg.center();
		dlg.show();
	}

	private void addProject() {
		AddProjectDlg dlg = new AddProjectDlg(designerPage);
		dlg.setModal(false);
		dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
		dlg.setGlassEnabled(true);
		dlg.setAnimationEnabled(true);
		dlg.center();
		dlg.show();
	}

	private void addMeta() {
		try {
			final long projectId = this.designerPage.getSelectedProjectId();

			if (this.designerPage.getSourceType().size() <= 0 || this.designerPage.getRecordType().size() <= 0 || this.designerPage.getDataType().size() <= 0) {
				this.service.getSourceConfig(new AsyncCallback<String>() {
					@Override
					public void onSuccess(String data) {
						refreshMetaList(data);
						openSourceMetaDlg(projectId);
					}

					@Override
					public void onFailure(Throwable arg0) {
						Window.alert("Server ERROR!!!");
					}
				});
			} else {
				openSourceMetaDlg(projectId);
			}

		} catch (Exception e) {
			Window.alert("ERROR:" + e.getMessage());
			return;
		}
	}

	void refreshMetaList(String data) {
		JSONObject json = JSONParser.parseStrict(data).isObject();

		List<String> srcType = this.designerPage.getSourceType();
		List<String> recType = this.designerPage.getRecordType();
		List<String> dtType = this.designerPage.getDataType();

		srcType.clear();
		recType.clear();
		dtType.clear();

		JSONArray arr = json.get("sourceTypes").isArray();
		for (int i = 0; i < arr.size(); i++) {
			srcType.add(arr.get(i).isString().stringValue());
		}

		arr = json.get("recordTypes").isArray();
		for (int i = 0; i < arr.size(); i++) {
			recType.add(arr.get(i).isString().stringValue());
		}

		arr = json.get("dataTypes").isArray();
		for (int i = 0; i < arr.size(); i++) {
			dtType.add(arr.get(i).isString().stringValue());
		}
	}

	void openSourceMetaDlg(long projectId) {

		SourceMetaDlg dlg = new SourceMetaDlg(projectId, this.designerPage.getSourceType(), this.designerPage.getRecordType(), this.designerPage.getDataType());
		dlg.setModal(false);
		dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
		dlg.setGlassEnabled(true);
		dlg.setAnimationEnabled(true);
		dlg.center();
		dlg.show();
	}

	void openExecuteWorkflow() {
		try {
			ProjectDto p = this.designerPage.getToolBar().getSelectedProject();
			Start start = this.designerPage.getDrawingController().getStartNode();
			if (start != null) {
				ExecuteWfDlg dlg = new ExecuteWfDlg(this, p, start, start, ExecuteWfDlg.EXECUTE_WF);
				dlg.setModal(false);
				dlg.getElement().getStyle().setZIndex(DFConstants.Z_INDEX_DIALOGBOX);
				dlg.setGlassEnabled(true);
				dlg.setAnimationEnabled(true);
				dlg.center();
				dlg.show();
			} else {
				Window.alert("Please add start node!!");
			}
		} catch (Exception e) {
			Window.alert("Error!!!" + e.getMessage());
		}
	}

	public void requestExecuteWorkflow(String json) {
		this.service.executeJob(json, new AsyncCallback<String>() {
			@Override
			public void onSuccess(String msg) {
				JSONObject jo = JSONParser.parseStrict(msg).isObject();

				Window.alert(jo.get("data").isString().stringValue());
			}

			@Override
			public void onFailure(Throwable arg0) {
				Window.alert("Server Communication Error....");
			}
		});

	}

	public WFDesignerPage getDesignerPage() {
		return this.designerPage;
	}
}
