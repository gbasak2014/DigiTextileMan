package com.gb.wf.client.handler;

import com.gb.wf.client.SparkDataWF;
import com.gb.wf.client.component.DFConstants;
import com.gb.wf.client.widget.ImageButton;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;

public class ToolActionHandler11 implements ClickHandler {
	SparkDataWF sparkDataWF;

	public ToolActionHandler11(SparkDataWF sparkDataWF) {
		this.sparkDataWF = sparkDataWF;
	}

	@Override
	public void onClick(ClickEvent event) {
		ImageButton btn = (ImageButton) event.getSource();
		int cmd = btn.getCommand();

		switch (cmd) {
		case DFConstants.WF_NEW:
			break;
		case DFConstants.WF_COMPILE:
			break;
		case DFConstants.WF_OPEN:
			break;
		case DFConstants.WF_SAVE:
			break;
		case DFConstants.WF_SAVE_AS:
			break;
		case DFConstants.WF_VIEW:
			break;
		}
	}
	
	void newWorkFlow()
	{
		Window.alert("newWorkFlow");

	}
	
	void compileWorkflow()
	{
		Window.alert("compileWorkflow");
	}
	
	void opebWorkflow()
	{
		Window.alert("opebWorkflow");
	}
	
	void saveWorkflow()
	{
		Window.alert("saveWorkflow");
	}
	
	void saveAsWorkflow()
	{
		Window.alert("saveAsWorkflow");
	}
	
	void viewWorkflow()
	{
		Window.alert("viewWorkflow");
	}
}
