package com.gb.wf.client.handler;

import com.google.gwt.event.dom.client.MouseDownEvent;
import com.google.gwt.event.dom.client.MouseDownHandler;
import com.google.gwt.event.dom.client.MouseMoveEvent;
import com.google.gwt.event.dom.client.MouseMoveHandler;
import com.google.gwt.event.dom.client.MouseUpEvent;
import com.google.gwt.event.dom.client.MouseUpHandler;
import com.google.gwt.user.client.ui.AbsolutePanel;
import com.google.gwt.user.client.ui.Composite;

public class MouseDragHandler11 implements MouseDownHandler, MouseUpHandler, MouseMoveHandler {
	AbsolutePanel ap;
	boolean isDrag;

	public MouseDragHandler11(AbsolutePanel ap) {
		this.ap = ap;
	}

	@Override
	public void onMouseDown(MouseDownEvent event) {
		this.isDrag = true;
	}

	@Override
	public void onMouseUp(MouseUpEvent event) {
		this.isDrag = true;
	}

	@Override
	public void onMouseMove(MouseMoveEvent event) {
		if (isDrag) {
			Composite c = (Composite) event.getSource();
			int w = c.getOffsetWidth() / 2;
			int h = c.getOffsetHeight() / 2;
			int x = event.getX();
			int y = event.getY();
			ap.remove(c);
			ap.add(c, (x - w), (y - h));
		}
	}

}
