package com.gb.wf.client;

import com.google.gwt.user.client.rpc.AsyncCallback;

/**
 * The async counterpart of <code>GreetingService</code>.
 */
public interface LoginServiceAsync {
	void registerUser(String json, AsyncCallback<String> callback) throws IllegalArgumentException;

	void loginUser(String json, AsyncCallback<String> callback) throws IllegalArgumentException;

}
