package com.gb.wf.client.tmp;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.util.ComponentTypes;
import com.gb.wf.client.widget.SDPWidget;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONString;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class SourceDelim extends SDPWidget {
	String delim;

	public SourceDelim(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/src-delim.jpg", "SourceJSON", ComponentTypes.SOURCE_DELIM, ComponentTypes.SOURCE_DELIM, popupMenu, clickHandler);
	}

	public String getDelim() {
		return delim;
	}

	public void setDelim(String delim) {
		this.delim = delim;
	}

	@Override
	public JSONObject getJSON() {
		JSONObject json = super.getJSON();
		json.put("delim", new JSONString(this.getDelim()));

		return json;
	}

	@Override
	public String toString() {
		return this.getJSON().toString();
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		return null;
	}
}
