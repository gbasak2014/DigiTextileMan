package com.gb.wf.client.tmp;

import com.gb.wf.client.component.SDPPopupMenu;
import com.gb.wf.client.dlg.SdpDialogBox;
import com.gb.wf.client.util.ComponentTypes;
import com.gb.wf.client.widget.SDPWidget;
import com.google.gwt.event.dom.client.ClickHandler;

/**
 * Represent file on edge node.
 * 
 * @author Gouranga Basak
 *
 */
public class SourceJSON extends SDPWidget {

	public SourceJSON(SDPPopupMenu popupMenu, ClickHandler clickHandler) {
		super("images/src-json.jpg", "SourceJSON", ComponentTypes.SOURCE_JSON, ComponentTypes.SOURCE_JSON, popupMenu, clickHandler);
	}

	@Override
	public SdpDialogBox getPropertyEditor(long projectId) {
		return null;
	}
}
