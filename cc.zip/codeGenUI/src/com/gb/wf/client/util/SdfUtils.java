package com.gb.wf.client.util;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.dto.ColumnDto;
import com.gb.wf.client.dto.ProjectDto;
import com.gb.wf.client.dto.SourceMetaDto;
import com.gb.wf.client.dto.UserDto;
import com.google.gwt.json.client.JSONArray;
import com.google.gwt.json.client.JSONObject;
import com.google.gwt.json.client.JSONParser;
import com.google.gwt.user.client.Window;

public class SdfUtils {

	public static UserDto getUserDto(JSONObject json) {
		UserDto dto = new UserDto();
		try {
			dto.setUserId(json.get("userId").isString().stringValue());
			dto.setUserName(json.get("userName").isString().stringValue());

			JSONArray pArr = json.get("projects").isArray();

			List<ProjectDto> pList = new ArrayList<ProjectDto>();
			for (int i = 0; i < pArr.size(); i++) {
				JSONObject p = pArr.get(i).isObject();
				ProjectDto pDto = new ProjectDto();
				pDto.setId((long) p.get("id").isNumber().doubleValue());
				pDto.setName(p.get("name").isString().stringValue());
				pDto.setDescription(JSONUtil.getEmptyIfNull("description", p));
				pDto.setClusterHome(JSONUtil.getEmptyIfNull("clusterHome", p));
				pDto.setClusterHost(JSONUtil.getEmptyIfNull("clusterHost", p));
				pDto.setClusterPort(JSONUtil.getEmptyIfNull("clusterPort", p));
				pDto.setClusterPwd(JSONUtil.getEmptyIfNull("clusterPwd", p));
				pDto.setClusterUser(JSONUtil.getEmptyIfNull("clusterUser", p));
				pList.add(pDto);
			}
			dto.setProjects(pList);
			JSONArray rArr = json.get("roles").isArray();
			List<String> roles = new ArrayList<String>();
			for (int i = 0; i < rArr.size(); i++) {
				roles.add(rArr.get(i).isString().stringValue());
			}
			dto.setRoles(roles);
		} catch (Exception e) {
			Window.alert("ERROR" + e.getMessage());
		}
		return dto;
	}

	public static void getSourceMeta(String json, SourceMetaDto dto) {

		JSONObject obj = (JSONObject) JSONParser.parseStrict(json);
		List<ColumnDto> columnTable = new ArrayList<ColumnDto>();

		try {
			dto.setId((long) obj.get("id").isNumber().doubleValue());
		} catch (Exception e) {
		}

		try {
			dto.setMetaName(obj.get("metaName").isString().stringValue());
		} catch (Exception e) {
		}

		try {
			dto.setSource(obj.get("source").isString().stringValue());
		} catch (Exception e) {
		}
		try {
			dto.setDescription(obj.get("description").isString().stringValue());
		} catch (Exception e) {
		}
		try {
			dto.setUser(obj.get("user").isString().stringValue());
		} catch (Exception e) {
		}
		try {
			dto.setPassword(obj.get("password").isString().stringValue());
		} catch (Exception e) {
		}
		try {
			dto.setDelimiter(obj.get("delimiter").isString().stringValue());
		} catch (Exception e) {
		}
		try {
			dto.setSourceType(obj.get("sourceType").isString().stringValue());
		} catch (Exception e) {
		}
		try {
			dto.setRecordType(obj.get("recordType").isString().stringValue());
		} catch (Exception e) {
		}
		try {
			dto.setProjectId((long) obj.get("projectId").isNumber().doubleValue());
		} catch (Exception e) {
		}

		JSONArray arr = obj.get("columnTable").isArray();
		for (int i = 0; i < arr.size(); i++) {
			ColumnDto col = new ColumnDto();
			JSONObject cObj = arr.get(i).isObject();
			
			col.setId((long) cObj.get("id").isNumber().doubleValue());
			col.setName(cObj.get("name").isString().stringValue());
			col.setSensitiveFlag(cObj.get("sensitiveFlag").isBoolean().booleanValue());
			col.setPos((int) cObj.get("pos").isNumber().doubleValue());
			col.setDataType(cObj.get("dataType").isString().stringValue());
			
			columnTable.add(col);
		}
		
		dto.setColumns(columnTable);
	}
}
