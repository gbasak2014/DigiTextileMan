package com.gb.wf.client.util;

import com.google.appengine.labs.repackaged.org.json.JSONObject;

public class Tst {

	public static void main(String[] args) throws Exception{
		JSONObject obj = new JSONObject();
		obj.put("name", "Shourya Basak");
		obj.put("address", "Kolkata");
		System.out.println(obj);
	}

}
