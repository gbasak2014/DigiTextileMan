package com.gb.wf.client.util;

public interface ComponentTypes {
	int SOURCE_HDFS = 11;
	int SOURCE_LOCAL = 12;
	int SOURCE_HIVE = 13;
	int SOURCE_RDBMS = 14;
	int SOURCE_HBASE = 15;
	int SOURCE_CASSANDRA = 16;
	int SOURCE_KAFKA = 17;
	int SOURCE_FLUME = 18;
	int SOURCE_FILE_STREAM = 19;
	int SOURCE_TCP = 20;

	int SOURCE_JSON = 21;
	int SOURCE_XML = 22;
	int SOURCE_DELIM = 23;

	int SQOOP = 24;
	int CUSTOM_ACTION = 25;
	int DATAFRAME = 26;
	int ROW = 27;
	int PRIME_TYPE = 28;
	
	int TRANSFORMATION = 101;
	int FILTER = 102;
	int GROUP = 103;
	int JOIN = 104;
	int SPLIT = 105;
	int SORT = 106;

	int START = 0;
	int END = 1;

	int TARGET_HDFS = 201;
	int TARGET_HIVE = 202;
	int TARGET_HBASE = 203;
	int TARGET_CASSANDRA = 204;

	int TARGET_JSON = 205;
	int TARGET_XML = 206;
	int TARGET_DELIM = 207;
	int RESPONSE_JSON = 208;
	
	int SOURCE = 301;
	int DESTINATION = 302;
	int ACTION = 303;
	
	int HDFS_COPY = 401;
	int DEDUP = 402;
	int FUNCTION = 403;
	int VALUE = 404;
	int BRANCH = 405;
	int CUSTOM_SERVICES = 406;
	
	int SUB_WF = 407;
}
