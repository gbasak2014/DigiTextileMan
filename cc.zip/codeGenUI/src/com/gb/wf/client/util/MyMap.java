package com.gb.wf.client.util;

import java.util.ArrayList;
import java.util.List;

import com.gb.wf.client.widget.SDPWidget;

public class MyMap {
	public List<String> keys = new ArrayList<String>();
	public List<SDPWidget> values = new ArrayList<SDPWidget>();

	public void put(String key, SDPWidget value) {
		int i = keys.size();
		keys.add(i, key);
		values.add(i, value);
	}

	public SDPWidget get(String key) {
		for (int i=0; i < keys.size(); i++) {
			if (key.equals(keys.get(i))) {
				return values.get(i);
			}
		}

		return null;
	}

	public boolean containsKey(String key) {
		for (String k : keys) {
			if (key.equals(k)) {
				return true;
			}
		}

		return false;
	}
	
	public List<SDPWidget> values()
	{
		return this.values;
	}
	
	@Override
	public String toString() {
		String kv = "";
		for (int i=0; i<keys.size();i++)
		{
			kv = "[" + keys.get(i) + "-->" + values.get(i).getName() + "]";
 		}
		return kv;
	}
}
