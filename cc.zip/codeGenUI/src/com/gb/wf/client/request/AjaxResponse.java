package com.gb.wf.client.request;

/**
 * Encapsulate response message from server with error code as 0/1
 * (success/fail)
 * 
 * @author Gouranga Basak
 *
 */
public class AjaxResponse {
	public static int SUCCESS = 0;
	public static int FAIL = 1;

	int status;
	String message;

	public AjaxResponse(int status, String message) {
		this.status = status;
		this.message = message;
	}

	public int getStatus() {
		return status;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return this.status + ":" + this.message;
	}
}
