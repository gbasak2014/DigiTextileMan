package com.gb.wf.client.panel.prop;

import com.gb.wf.client.widget.SDPWidget;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DockLayoutPanel;
import com.google.gwt.user.client.ui.FlowPanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;

public class PropPanelSrcLocal extends DockLayoutPanel implements ClickHandler{
	TextBox txtName;
	TextBox txtSource;
	TextBox txtDelimiter;
	TextArea taColumnNames;
	
	SDPWidget widget;
	
	public PropPanelSrcLocal(SDPWidget widget) {
		super(Unit.EM);
		this.widget = widget;
		
		this.txtName = new TextBox();
		this.txtSource = new TextBox();
		this.txtDelimiter = new TextBox();
		this.taColumnNames = new TextArea();
		
		this.txtName.setTitle("Unique name of the component");
		this.txtSource.setTitle("Source file path in local system");
		this.txtDelimiter.setTitle("Field delimiter character of row");
		this.taColumnNames.setTitle("Comma(,) delimited list of fields");
		
		HorizontalPanel hp = new HorizontalPanel();
		hp.add(new Label("Name:"));
		hp.add(this.txtName);
		hp.add(new Label("Delimiter"));
		hp.add(this.txtDelimiter);
		this.addNorth(hp, 25);
		
		hp = new HorizontalPanel();
		hp.add(new Label("Source Path"));
		hp.add(this.txtSource);
		this.addNorth(hp, 25);
		
		hp = new HorizontalPanel();
		hp.add(new Label("Fields"));
		hp.add(this.taColumnNames);
		this.addNorth(hp, 50);

		FlowPanel fp = new FlowPanel();
		Button btnCompileFields = new Button("Get field list");
		btnCompileFields.addClickHandler(this);
		fp.add(btnCompileFields);
		this.addNorth(hp, 30);
		
		this.setSize("200px", "300px");
	}
	
	@Override
	public void onClick(ClickEvent event) {
		// TODO Auto-generated method stub
		
	}
}
