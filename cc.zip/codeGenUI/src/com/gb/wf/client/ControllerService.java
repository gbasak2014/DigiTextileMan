package com.gb.wf.client;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

/**
 * The client-side stub for the RPC service.
 */
@RemoteServiceRelativePath("swf")
public interface ControllerService extends RemoteService {
	String processRequest(String service, String data) throws IllegalArgumentException;

	String openWorkflow(String workflowId) throws IllegalArgumentException;

	String openWorkflow(long projectId, String workflowName) throws IllegalArgumentException;

	String registerUser(String json) throws IllegalArgumentException;

	String loginUser(String json) throws IllegalArgumentException;

	String addUser(String json) throws IllegalArgumentException;

	String addProject(String json) throws IllegalArgumentException;

	String saveSourceMetaDate(String json) throws IllegalArgumentException;

	String getSourceConfig() throws IllegalArgumentException;

	String getProjectSources(long id) throws IllegalArgumentException;

	String getSourceList(long projectId) throws IllegalArgumentException;

	String getDBSourceList(long projectId) throws IllegalArgumentException;

	String saveWorkflow(String json) throws IllegalArgumentException;

	String getJobs(boolean isJob, long projectId) throws IllegalArgumentException;

	String getSubWfs(long projectId) throws IllegalArgumentException;
	
	String compileJob(String json) throws IllegalArgumentException;

	String executeJob(String json) throws IllegalArgumentException;

	String saveService(String json) throws IllegalArgumentException;

	String getServiceList(long projectId) throws IllegalArgumentException;

	String getUDFList(long projectId) throws IllegalArgumentException;

	String getServiceDetail(long serviceId) throws IllegalArgumentException;
	
	String getSubWf(long sWfId) throws IllegalArgumentException;
	
	String getSubWfHeader(long sWfId) throws IllegalArgumentException;
}
