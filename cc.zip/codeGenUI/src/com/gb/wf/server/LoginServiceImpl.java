package com.gb.wf.server;

import javax.servlet.http.HttpSession;

import org.json.JSONObject;

import com.gb.wf.client.LoginService;
import com.gb.wf.server.dto.UserDetails;
import com.gb.wf.server.utils.RestClient;
import com.gb.wf.server.utils.ServiceConfig;
import com.google.appengine.repackaged.org.codehaus.jackson.map.ObjectMapper;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

/**
 * The server-side implementation of the RPC service.
 */
@SuppressWarnings("serial")
public class LoginServiceImpl extends RemoteServiceServlet implements LoginService {
	@Override
	public String registerUser(String json) throws IllegalArgumentException {
		System.out.println("Entered LoginServiceImpl.registerUser: " + json);
		String resp = null;

		try {
			String url = ServiceConfig.get("spark.code.gen.service.url") + "/user/register";
			System.out.println(url);

			resp = RestClient.postRequest(url, json);

		} catch (Exception e) {
			e.printStackTrace();
		}

		if (resp == null) {
			resp = "ERROR";
		}

		System.out.println("Response: " + resp);
		System.out.println("Exiting LoginServiceImpl.registerUser: " + json);
		return resp;
	}

	@Override
	public String loginUser(String json) throws IllegalArgumentException {
		System.out.println("Entered LoginServiceImpl.loginUser()..........................................");
		String url = ServiceConfig.get("spark.code.gen.service.url") + "/user/login";
		String resp = null;
		try {
			resp = RestClient.postRequest(url, json);

			JSONObject obj = new JSONObject(resp);
			ObjectMapper m = new ObjectMapper();

			UserDetails ud = m.readValue(resp, UserDetails.class);

			if ("SUCCESS".equals(obj.getString("status"))) {
				HttpSession session = this.getThreadLocalRequest().getSession(true);
				System.out.println("Session Id:" + session.getId());
				session.setAttribute("username", ud.getUserName());
				session.setAttribute("user", ud);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		if (resp == null) {
			resp = "ERROR";
		}

		System.out.println("Response: " + resp);
		System.out.println("Entered LoginServiceImpl.loginUser()..........................................");
		return resp;
	}
}
