package com.gb.wf.server.filter;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.gb.wf.server.dto.UserDetails;
import com.gb.wf.server.utils.MessageUtils;

//com.gb.wf.server.filter.LogginFilter
public class LogginFilter implements Filter {

	@Override
	public void destroy() {
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
		System.out.println("************************************ Entered doFilter() *****************************************");
		System.out.println("*************************************************************************************************");
		HttpServletRequest request = (HttpServletRequest)req;
		HttpSession session = request.getSession();
		
		UserDetails ud = (UserDetails)session.getAttribute("user");
		if (session.isNew() || ud == null)
		{
			System.out.println("New session or not logged in");
			res.setContentType("application/json");
			res.setCharacterEncoding("UTF-8");
			PrintWriter pw = res.getWriter();
			String response = MessageUtils.getResponseMessage("ERROR", "Invalid User/Session!!");
			System.out.println("Response: " + response);
			pw.println(response);
			pw.close();
		}
		else
		{
			System.out.println("User: " + ud.toString());
			chain.doFilter(req, res);	
		}
		System.out.println("*************************************************************************************************");
		System.out.println("************************************ Exiting doFilter() *****************************************");
	}
	
	@Override
	public void init(FilterConfig fc) throws ServletException {

	}

}
