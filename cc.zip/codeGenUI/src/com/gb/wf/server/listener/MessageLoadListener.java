package com.gb.wf.server.listener;

import java.io.InputStream;
import java.util.Properties;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.gb.wf.server.utils.ServiceConfig;

//com.gb.wf.server.listener.MessageLoadListener
public class MessageLoadListener implements ServletContextListener {

	@Override
	public void contextDestroyed(ServletContextEvent sce) {

	}

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		ServletContext ctx = sce.getServletContext();
		System.out.println("ctx.getContextPath()::" + ctx.getContextPath());
		System.out.println("ctx.getServletContextName()::" + ctx.getServletContextName());
		try{
			InputStream in = ctx.getResourceAsStream("/WEB-INF/config.properties");
			Properties props = new Properties();
			props.load(in);
			ctx.setAttribute("PROPS", props);
			System.out.println(props);
			ServiceConfig.set(props);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
