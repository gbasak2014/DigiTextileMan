package com.gb.wf.server;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;

import com.gb.wf.client.ControllerService;
import com.gb.wf.server.dto.UserDetails;
import com.gb.wf.server.utils.MessageUtils;
import com.gb.wf.server.utils.RestClient;
import com.gb.wf.server.utils.ServiceConfig;
import com.google.appengine.repackaged.org.codehaus.jackson.map.ObjectMapper;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

/**
 * The server-side implementation of the RPC service.
 */
@SuppressWarnings("serial")
public class ControllerServiceImpl extends RemoteServiceServlet implements ControllerService {

	@Override
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		try {
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public String processRequest(String service, String data) throws IllegalArgumentException {

		System.out.println("Service:" + service);
		System.out.println("Data:" + data);

		JSONObject json = new JSONObject();
		try {
			json.put("status", 200);
			json.put("message", "SUCCESS");
			json.put("username", "Shourya Basak");
			this.getThreadLocalRequest().getSession().setAttribute("username", "Shourya Basak");
			System.out.println("JSON:: " + json.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return json.toString();
	}

	@Override
	public String registerUser(String json) throws IllegalArgumentException {
		System.out.println("IN registerUser: " + json);
		try {
			String url = ServiceConfig.get("spark.code.gen.service.url") + "/user/register";
			System.out.println(url);

			String usr = RestClient.postRequest(url, json);

			System.out.println("USER:::" + usr);

			return usr;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "ERROR";
	}

	@Override
	public String loginUser(String json) throws IllegalArgumentException {
		System.out.println("Entered gwt loginUser()..........................................");
		String url = ServiceConfig.get("spark.code.gen.service.url") + "/user/login";
		try {
			String usr = RestClient.postRequest(url, json);

			JSONObject obj = new JSONObject(usr);
			ObjectMapper m = new ObjectMapper();

			UserDetails ud = m.readValue(usr, UserDetails.class);

			if ("SUCCESS".equals(obj.getString("status"))) {
				HttpSession session = this.getThreadLocalRequest().getSession(true);
				System.out.println("Session Id:" + session.getId());
				session.setAttribute("username", usr);
				session.setAttribute("user", ud);
				System.out.println("User:::" + usr);
			}

			return usr;

		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("Exiting gwt loginUser()..........................................");
		return "ERROR";
	}

	@Override
	public String addUser(String json) throws IllegalArgumentException {
		String url = ServiceConfig.get("spark.code.gen.service.url") + "/user/adduser";
		try {
			String usr = RestClient.postRequest(url, json);
			System.out.println("USER:::" + usr);

			return usr;

		} catch (Exception e) {
		}

		return "ERROR";
	}

	@Override
	public String addProject(String json) throws IllegalArgumentException {
		String url = ServiceConfig.get("spark.code.gen.service.url") + "/project/add";
		try {
			String usr = RestClient.postRequest(url, json);
			System.out.println("USER:::" + usr);

			return usr;

		} catch (Exception e) {
		}

		return "ERROR";
	}

	@Override
	public String saveSourceMetaDate(String json) throws IllegalArgumentException {
		String url = ServiceConfig.get("spark.code.gen.service.url") + "/project/savemetadata";
		try {
			String status = RestClient.postRequest(url, json);
			return status;
		} catch (Exception e) {
		}

		return "ERROR";

	}

	@Override
	public String openWorkflow(String workflowId) throws IllegalArgumentException {
		System.out.println("Entered openWorkflow ID: " + workflowId);

		try {
			String url = ServiceConfig.get("spark.code.gen.service.url") + "/job/open/" + workflowId;
			System.out.println(url);
			String jobDtl = RestClient.getRequest(url);
			return jobDtl;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return MessageUtils.getResponseMessage("ERROR", "Server communication ERROR!!");
	}

	@Override
	public String getSubWf(long sWfId) throws IllegalArgumentException {
		System.out.println("Entered getSubWf ID: " + sWfId);
		String resp=null;
		try {
			String url = ServiceConfig.get("spark.code.gen.service.url") + "/job/opensub/" + sWfId;
			System.out.println(url);
			resp = RestClient.getRequest(url);

		} catch (Exception e) {
			e.printStackTrace();
		}

		if (resp == null)
		{
			resp = MessageUtils.getResponseMessage("ERROR", "Server communication ERROR!!");
		}
		
		return resp;
	}

	@Override
	public String getSubWfHeader(long sWfId) throws IllegalArgumentException {
		System.out.println("Entered getSubWf ID: " + sWfId);
		String resp=null;
		try {
			String url = ServiceConfig.get("spark.code.gen.service.url") + "/job/opensubhead/" + sWfId;
			System.out.println(url);
			resp = RestClient.getRequest(url);

		} catch (Exception e) {
			e.printStackTrace();
		}

		if (resp == null)
		{
			resp = MessageUtils.getResponseMessage("ERROR", "Server communication ERROR!!");
		}
		
		return resp;
	}
	
	@Override
	public String openWorkflow(long projectId, String workflowName) throws IllegalArgumentException {
		System.out.println("Entered Project Id: " + projectId + ", Workflow Name:" + workflowName);

		try {
			String url = ServiceConfig.get("spark.code.gen.service.url") + "/job/open/" + projectId + "/" + workflowName;
			System.out.println(url);
			String jobDtl = RestClient.getRequest(url);
			return jobDtl;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return MessageUtils.getResponseMessage("ERROR", "Server communication ERROR!!");
	}

	@Override
	public String saveWorkflow(String json) throws IllegalArgumentException {
		String url = ServiceConfig.get("spark.code.gen.service.url") + "/job/save";
		try {
			String status = RestClient.postRequest(url, json);
			return status;

		} catch (Exception e) {
		}

		return "ERROR";
	}

	@Override
	public String getSourceConfig() throws IllegalArgumentException {
		String url = ServiceConfig.get("spark.code.gen.service.url") + "/project/srcconfdata";
		try {
			String srcConf = RestClient.getRequest(url);
			System.out.println("srcConf:::" + srcConf);

			return srcConf;

		} catch (Exception e) {
		}

		return "ERROR";
	}

	@Override
	public String getProjectSources(long id) throws IllegalArgumentException {
		String url = ServiceConfig.get("spark.code.gen.service.url") + "/project/source/" + id;

		try {
			String srcJson = RestClient.getRequest(url);
			System.out.println("srcConf:::" + srcJson);

			return srcJson;

		} catch (Exception e) {
			e.printStackTrace();
		}

		return "ERROR";
	}

	@Override
	public String getSourceList(long projectId) throws IllegalArgumentException {
		String url = ServiceConfig.get("spark.code.gen.service.url") + "/project/projectsource/" + projectId;
		StringBuffer bff = new StringBuffer();

		try {
			String srcJson = RestClient.getRequest(url);
			System.out.println("srcConf:::" + srcJson);

			JSONArray arr = new JSONArray(srcJson);
			for (int i = 0; i < arr.length(); i++) {
				JSONObject obj = (JSONObject) arr.get(i);
				if (bff.length() > 0) {
					bff.append(",");
				}
				bff.append(obj.getString("id") + "-" + obj.getString("metaName"));
			}

		} catch (Exception e) {
		}

		return bff.toString();
	}

	@Override
	public String getDBSourceList(long projectId) throws IllegalArgumentException {
		String url = ServiceConfig.get("spark.code.gen.service.url") + "/project/projectdbsource/" + projectId;
		StringBuffer bff = new StringBuffer();

		try {
			String srcJson = RestClient.getRequest(url);
			System.out.println("srcConf:::" + srcJson);

			JSONArray arr = new JSONArray(srcJson);
			for (int i = 0; i < arr.length(); i++) {
				JSONObject obj = (JSONObject) arr.get(i);
				if (bff.length() > 0) {
					bff.append(",");
				}
				bff.append(obj.getString("id") + "-" + obj.getString("metaName"));
			}

		} catch (Exception e) {
		}

		return bff.toString();
	}

	@Override
	public String getJobs(boolean isJob, long projectId) throws IllegalArgumentException {
		
		System.out.println("Entered ControllerServiceImpl.getJobs");
		String url = ServiceConfig.get("spark.code.gen.service.url") + "/project/" + (isJob ? "jobs/" : "wfs/") + projectId;
		String jobsJson=null;
		try {
			jobsJson = RestClient.getRequest(url);
			System.out.println("Jobs:::" + jobsJson);
			return jobsJson;
		} catch (Exception e) {
		}

		if (jobsJson==null)
		{
			jobsJson = MessageUtils.getResponseMessage("ERROR", "Server communication ERROR!!");
		}
		System.out.println("Exiting ControllerServiceImpl.getJobs");
		return jobsJson;
	}
	
	@Override
	public String getSubWfs(long projectId) throws IllegalArgumentException {
		String url = ServiceConfig.get("spark.code.gen.service.url") + "/project/wfs/" + projectId;

		try {
			String jobsJson = RestClient.getRequest(url);
			System.out.println("Jobs:::" + jobsJson);
			return jobsJson;
		} catch (Exception e) {
		}

		return MessageUtils.getResponseMessage("ERROR", "Server communication ERROR!!");
	}
	
	
	@Override
	public String compileJob(String json) throws IllegalArgumentException {
		String url = ServiceConfig.get("spark.code.gen.service.url") + "/job/compile";
		try {
			String status = RestClient.postRequest(url, json);
			return status;

		} catch (Exception e) {
		}

		return "ERROR";
	}

	@Override
	public String executeJob(String json) throws IllegalArgumentException {
		String url = ServiceConfig.get("spark.code.gen.service.url") + "/job/execute";
		try {
			String status = RestClient.postRequest(url, json);
			return status;

		} catch (Exception e) {
		}

		return MessageUtils.getResponseMessage("ERROR", "Srervice ERROR.....");
	}

	@Override
	public String saveService(String json) throws IllegalArgumentException {
		String url = ServiceConfig.get("spark.code.gen.service.url") + "/project/addservice";
		try {
			String status = RestClient.postRequest(url, json);
			return status;
		} catch (Exception e) {
		}

		return MessageUtils.getResponseMessage("ERROR", "Srervice ERROR.....");
	}

	@Override
	public String getServiceList(long projectId) throws IllegalArgumentException {
		String url = ServiceConfig.get("spark.code.gen.service.url") + "/project/getservices/" + projectId;
		try {
			String response = RestClient.getRequest(url);
			return response;
		} catch (Exception e) {
		}

		return MessageUtils.getResponseMessage("ERROR", "Server error!!");
	}

	@Override
	public String getUDFList(long projectId) throws IllegalArgumentException {
		String url = ServiceConfig.get("spark.code.gen.service.url") + "/project/getudfs/" + projectId;
		try {
			String response = RestClient.getRequest(url);
			return response;
		} catch (Exception e) {
		}

		return MessageUtils.getResponseMessage("ERROR", "Server error!!");
	}

	@Override
	public String getServiceDetail(long serviceId) throws IllegalArgumentException {
		String url = ServiceConfig.get("spark.code.gen.service.url") + "/project/getservicedetail/" + serviceId;
		try {
			String response = RestClient.getRequest(url);
			return response;
		} catch (Exception e) {
		}
		return MessageUtils.getResponseMessage("ERROR", "Server error!!");
	}

}
