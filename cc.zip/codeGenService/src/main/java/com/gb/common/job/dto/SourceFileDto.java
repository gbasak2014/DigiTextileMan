package com.gb.common.job.dto;

public class SourceFileDto extends BaseDto {
	String sourcePath;
	String fileType;
	String delimiter;
	boolean deleteOnSuccess;
	boolean renameOnSuccess;
	String movePath;
	String suffix;
	String targetPath;

	public String getTargetPath() {
		return targetPath;
	}

	public void setTargetPath(String targetPath) {
		this.targetPath = targetPath;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public boolean isDeleteOnSuccess() {
		return deleteOnSuccess;
	}

	public void setDeleteOnSuccess(boolean deleteOnSuccess) {
		this.deleteOnSuccess = deleteOnSuccess;
	}

	public boolean isRenameOnSuccess() {
		return renameOnSuccess;
	}

	public void setRenameOnSuccess(boolean renameOnSuccess) {
		this.renameOnSuccess = renameOnSuccess;
	}

	public String getMovePath() {
		return movePath;
	}

	public void setMovePath(String movePath) {
		this.movePath = movePath;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	@Override
	public String toString() {
		return super.toString() + ", path:" + this.sourcePath + ", targetPath:" + this.targetPath + ", fileType:" + this.fileType + ", delimiter:" + this.delimiter
				+ ", deleteOnSuccess:" + this.deleteOnSuccess + ", renameOnSuccess:" + this.renameOnSuccess + ", movePath:" + this.movePath + ", suffix:"
				+ this.suffix;
	}

	public String getSourcePath() {
		return sourcePath;
	}

	public void setSourcePath(String sourcePath) {
		this.sourcePath = sourcePath;
	}
}
