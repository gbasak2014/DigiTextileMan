package com.gb.common.job.dto;

public class SourceHdfsDto extends SourceFileDto {

}
