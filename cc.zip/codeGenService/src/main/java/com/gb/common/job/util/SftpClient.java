package com.gb.common.job.util;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class SftpClient {
	String host;
	int port;
	String user;
	String pwd;

	public SftpClient() {
	}

	public SftpClient(String host, int port, String user, String pwd) {
		this.host = host;
		this.port = port;
		this.user = user;
		this.pwd = pwd;
	}

	public void copyFiles(List<String> files, String destination, String jobName) throws Exception {
		Session session=null;
		ChannelSftp channel=null;
		try{
		JSch jsch = new JSch();
		session = jsch.getSession(this.user, this.host, this.port);

		session.setConfig("StrictHostKeyChecking", "no");
		session.setPassword(this.pwd);
		session.connect();
		System.out.println("Connected to server.....");
		channel = (ChannelSftp) session.openChannel("sftp");
		channel.connect();
		System.out.println("Communication channel created.....");
		channel.cd(destination);
		channel.mkdir(jobName);
		destination = destination + "/" + jobName;
		channel.cd(destination);
		for (String src : files) {
			System.out.println("Copying " + src + " to " + destination);
			File file = new File(src);
			channel.put(new FileInputStream(file), destination + "/" + file.getName());
		}
		}catch(Exception e)
		{
			if (channel != null && channel.isConnected())
			{
				channel.disconnect();
			}
			if (session != null && session.isConnected())
			{
				session.disconnect();
			}
			throw new Exception("File copy ERROR!!");
		}
	}

	public int executeOnCluster(String path, String cmd) throws Exception
	{
		Session session=null;
		ChannelExec channelExec=null;
		try{
			JSch jsch = new JSch();
			session = jsch.getSession(this.user, this.host, this.port);

			session.setConfig("StrictHostKeyChecking", "no");
			session.setPassword(this.pwd);
			session.connect();
			System.out.println("Connected to server.....");
			
			channelExec = (ChannelExec)session.openChannel("exec");
			channelExec.setCommand("cd " + path + "; pwd; ls; " + cmd);
			System.out.println("Executing: " + cmd);
			channelExec.connect();
			
			ByteArrayOutputStream oOut = new ByteArrayOutputStream();
			channelExec.setOutputStream(oOut);
			InputStream in = channelExec.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(in));
			String line = br.readLine();
			while (line != null)
			{
				System.out.println(line);
				oOut.writeTo(System.out);
				line = br.readLine();
			}
			
			int st = channelExec.getExitStatus();
			channelExec.disconnect();
			session.disconnect();
			
			return st;			
		}catch(Exception e)
		{
			if (channelExec != null && channelExec.isConnected())
			{
				channelExec.disconnect();
			}
			if (session != null && session.isConnected())
			{
				session.disconnect();
			}
			throw new Exception("Job execution ERROR!!");
		}
	}
	
	public static void copyToServer(File localFile, String targetDir, ChannelSftp channel) throws Exception {
		if (localFile.isDirectory()) {
			channel.cd(targetDir);
			channel.mkdir(localFile.getName());
			String path = targetDir + "/" + localFile.getName();
			System.out.println("Created Dir: " + path);
			for (File file : localFile.listFiles()) {
				copyToServer(file, path, channel);
			}
		} else {
			channel.cd(targetDir);
			System.out.println("Copy " + localFile.getAbsolutePath() + " to " + targetDir + "/" + localFile.getName());
			channel.put(new FileInputStream(localFile), localFile.getName(), ChannelSftp.OVERWRITE);
		}
	}

	public static void main(String[] args) throws Exception {
		System.out.println("1******************Started.............................");
		JSch jsch = new JSch();
		Session session = jsch.getSession("gbasak", "10.77.167.11", 22);

		session.setConfig("StrictHostKeyChecking", "no");
		session.setPassword("Ibm@2017");
		session.connect();

		ChannelExec channelExec = (ChannelExec)session.openChannel("exec");
		System.out.println("Starting Job......................");
		channelExec.setCommand("hadoop fs -cat /user/gbasak/spark/wf/out/tmpuser01/*"); //cd /home/gbasak/sparkWf/wf002; pwd; ls; sh ./startJob.sh
		
		channelExec.connect();
		
		//channelExec.setErrStream(System.out);
		//channelExec.setOutputStream(System.out);
	
		InputStream in = channelExec.getInputStream();
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		String line = br.readLine();
		while (line != null)
		{
			System.out.println(line);
			line = br.readLine();
		}
		
		int st = channelExec.getExitStatus();
		channelExec.disconnect();
		session.disconnect();
		
		
		System.out.println("Done................................" + st);
	}

}
