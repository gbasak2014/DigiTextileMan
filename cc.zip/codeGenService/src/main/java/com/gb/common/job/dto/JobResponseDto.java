package com.gb.common.job.dto;

import java.util.HashMap;
import java.util.Map;

public class JobResponseDto extends BaseDto {
	String targetUrl;
	String targetTable;
	String targetKeyColumn;
	String targetValColumn;
	String targetKey;
	String targetUser;
	String targetPwd;
	
	String responseRoot;
	Map<String, String> dfResponseMap = new HashMap<String, String>();

	public String getTargetUrl() {
		return targetUrl;
	}

	public void setTargetUrl(String targetUrl) {
		this.targetUrl = targetUrl;
	}

	public String getTargetTable() {
		return targetTable;
	}

	public void setTargetTable(String targetTable) {
		this.targetTable = targetTable;
	}

	public String getTargetKeyColumn() {
		return targetKeyColumn;
	}

	public void setTargetKeyColumn(String targetKeyColumn) {
		this.targetKeyColumn = targetKeyColumn;
	}

	public String getTargetValColumn() {
		return targetValColumn;
	}

	public void setTargetValColumn(String targetValColumn) {
		this.targetValColumn = targetValColumn;
	}

	public String getTargetKey() {
		return targetKey;
	}

	public void setTargetKey(String targetKey) {
		this.targetKey = targetKey;
	}

	public String getResponseRoot() {
		return responseRoot;
	}

	public void setResponseRoot(String responseRoot) {
		this.responseRoot = responseRoot;
	}


	@Override
	public String toString() {
		return this.getDfResponseMap().toString();
	}

	public String getTargetUser() {
		return targetUser;
	}

	public void setTargetUser(String targetUser) {
		this.targetUser = targetUser;
	}

	public String getTargetPwd() {
		return targetPwd;
	}

	public void setTargetPwd(String targetPwd) {
		this.targetPwd = targetPwd;
	}

	static class DfMap{
		
	}

	public Map<String, String> getDfResponseMap() {
		return dfResponseMap;
	}

	public void setDfResponseMap(Map<String, String> dfResponseMap) {
		this.dfResponseMap = dfResponseMap;
	}
}
