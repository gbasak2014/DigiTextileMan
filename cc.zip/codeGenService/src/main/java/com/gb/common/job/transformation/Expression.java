package com.gb.common.job.transformation;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.gb.common.util.TaskUtils;

public class Expression implements Transformation {
	String exp;
	String df;

	public Expression(String exp, String dfName) {
		this.exp = exp;
		this.df = dfName;
	}

	private String getColumn(String op, String df) {
		if (op.startsWith("$")) {
			return df + ".col(\"" + op.substring(1) + "\")";
		}

		return "lit(\"" + op + "\")";
	}

	private String makeExpr(String expr) {
		List<String> list = new ArrayList<String>();

		StringBuffer sb = new StringBuffer();
		int len = exp.length();
		for (int i = 0; i < len; i++) {
			char ch = exp.charAt(i);
			if (ch == '(' || ch == ')' || ch == '*' || ch == '-' || ch == '/' || ch == ' ' || ch == '\t') {
				if (sb.length() > 0) {
					list.add(sb.toString());
					sb.delete(0, sb.length());
				}
				if (!(ch == ' ' || ch == '\t')) {
					list.add(String.valueOf(ch));
				}
			} else {
				sb.append(ch);
			}
		}

		if (sb.length() > 0) {
			list.add(sb.toString());
		}

		len = list.size();

		sb.delete(0, sb.length());
		Pattern pattern = Pattern.compile("[*/+-]");
		for (int i = 0; i < len; i++) {
			String op = list.get(i);
			if (op.length() > 1) {
				sb.append(getColumn(op, df));
			} else {
				if (pattern.matcher(op).find()) {
					sb.append(".").append(op);
					if (!"(".equals(list.get(1 + i))) {
						i++;
						op = list.get(i);
						sb.append("(").append(getColumn(op, df)).append(")");
					}
				} else {
					sb.append(op);
				}
			}

		}

		return sb.toString();
	}

	private String makeExprBAK(String expr) {
		int len = expr.length();
		StringBuffer op = new StringBuffer();
		StringBuffer exp = new StringBuffer();
		boolean isExpStart = false;
		for (int i = 0; i < len; i++) {
			char ch = expr.charAt(i);
			if (TaskUtils.isOperator(ch)) {
				if (op.toString().trim().length() > 0) {
					if (isExpStart) {
						exp.append("(");
					}
					exp.append(TaskUtils.getOperand(op.toString().trim(), this.df));
					if (isExpStart) {
						exp.append(")");
					}
				}

				exp.append(".").append(ch);
				isExpStart = true;
				op.delete(0, op.length());
			} else if (ch == '(') {
				StringBuffer tmp = new StringBuffer();
				int expStart = 0;
				i++;
				for (; i < len; i++) {
					char ch1 = expr.charAt(i);
					if (ch1 == ')') {
						if (expStart <= 0) {
							break;
						} else {
							tmp.append(ch1);
						}
						expStart--;
					} else {
						tmp.append(ch1);
					}

					if (ch1 == '(') {
						expStart++;
					}
				}

				if (tmp.length() > 0) {
					if (isExpStart) {
						exp.append("(");
					}
					exp.append(makeExpr(tmp.toString()));
					tmp.delete(0, tmp.length());
					if (isExpStart) {
						exp.append(")");
					}
				}
			} else {
				op.append(ch);
			}
		}

		if (op.toString().trim().length() > 0) {
			if (isExpStart) {
				exp.append("(");
			}
			exp.append(TaskUtils.getOperand(op.toString().trim(), this.df));
			if (isExpStart) {
				exp.append(")");
			}
			op.delete(0, op.length());
		}

		return exp.toString();
	}

	@Override
	public String evaluate() {
		return this.makeExpr(this.exp);
	}
}
