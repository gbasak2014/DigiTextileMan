package com.gb.common.config;

import java.util.Properties;

import org.springframework.core.io.support.PropertiesLoaderUtils;

public class ApplicationConfig {
	String scriptFile;
	String configFile;
	String workflowPackage;
	//String projectBasePath;
	String workflowSourceDir;
	String copyExecuteScript;
	String wfExecuteScript;
	//String projectSource;

	Properties conf = new Properties();
	static ApplicationConfig thisInstance = null;
	public synchronized static ApplicationConfig getInstance()
	{
		if (thisInstance == null)
		{
			thisInstance = new ApplicationConfig();
		}
		
		return thisInstance;
	}
	
	private ApplicationConfig() {
		try {
			conf = PropertiesLoaderUtils.loadAllProperties("sdp-job.properties");
		} catch (Exception e) {
			e.printStackTrace();
		}
		//this.projectSource = "E:/Code/SparkDFWs/sdp-job";
		//this.projectBasePath = "E:/Code/SparkDFWs/sdfService/JOB";
		this.scriptFile = "script/StartJob.sh";
		this.configFile = "resources/job-config.properties";
		this.workflowPackage = "com/gb/sdp/spark/job";
		this.workflowSourceDir = "src/main/scala";
		this.copyExecuteScript = "java -cp \"/home/tom/spark/job/sdp-job-1.0-SNAPSHOT.jar:`hadoop classpath`:$CLASSPATH\" com.gb.spark.job.FileCopyJob";
		this.wfExecuteScript = "spark-submit --class com.gb.sdp.spark.job.SDPJob --master yarn-client sdp-job-1.0-SNAPSHOT.jar";
	}
	/*
	public String getScriptFile() {
		return scriptFile;
	}

	public void setScriptFile(String scriptFile) {
		this.scriptFile = scriptFile;
	}

	public String getConfigFile() {
		return configFile;
	}

	public void setConfigFile(String configFile) {
		this.configFile = configFile;
	}

	public String getWorkflowPackage() {
		return workflowPackage;
	}

	public void setWorkflowPackage(String workflowPackage) {
		this.workflowPackage = workflowPackage;
	}

	public String getWorkflowSourceDir() {
		return workflowSourceDir;
	}

	public void setWorkflowSourceDir(String workflowSourceDir) {
		this.workflowSourceDir = workflowSourceDir;
	}

	public String getCopyExecuteScript() {
		return copyExecuteScript;
	}

	public void setCopyExecuteScript(String copyExecuteScript) {
		this.copyExecuteScript = copyExecuteScript;
	}

	public String getWfExecuteScript() {
		return wfExecuteScript;
	}

	public void setWfExecuteScript(String wfExecuteScript) {
		this.wfExecuteScript = wfExecuteScript;
	}

	public String getProjectSource() {
		return projectSource;
	}

	public void setProjectSource(String projectSource) {
		this.projectSource = projectSource;
	}
	public String getProjectBasePath() {
		return projectBasePath;
	}

	public void setProjectBasePath(String projectBasePath) {
		this.projectBasePath = projectBasePath;
	}
*/
	public String getConfig(String key) {
		return conf.getProperty(key);
	}
	
	public String getValue(String key)
	{
		return conf.getProperty(key);
	}
	
	public Properties getProp()
	{
		return this.conf;
	}
	
}
