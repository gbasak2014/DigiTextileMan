package com.gb.common.job.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class ConfigList {
	Map<String, String> map = new HashMap<String, String>();

	public void setConfig(String key, String value) {
		this.map.put(key, value);
	}

	public void setConfig(String key, String value, String task) {
		String k = key.replace(JobConstants.TASK, task);
		this.map.put(k, value);
	}

	public void addConfig(String key, String value) {
		if (this.map.containsKey(key)) {
			value = this.map.get(key) + "," + value;
		}

		this.map.put(key, value);
	}

	public String getConfig(String key) {
		return this.map.get(key);
	}

	public Map<String, String> getAsMap() {
		return this.map;
	}

	public String getAsString() {
		StringBuffer buff = new StringBuffer();
		for (Entry<String, String> e : this.map.entrySet()) {
			buff.append(e.getKey()).append("=").append(e.getValue()).append("\n");
		}

		return buff.toString();
	}
}
