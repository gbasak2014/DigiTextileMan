package com.gb.common.config;

public class ProjectConfig {
	String name;
	String basePath;

	public ProjectConfig() {
		this.name = "MyProject";
		this.basePath = "E:/Code/SparkDFWs/sdfService/JOB";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBasePath() {
		return basePath;
	}

	public void setBasePath(String basePath) {
		this.basePath = basePath;
	}

}
