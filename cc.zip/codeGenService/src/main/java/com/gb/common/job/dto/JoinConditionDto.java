package com.gb.common.job.dto;

public class JoinConditionDto {
	String leftSchema;
	String rightSchema;
	String leftColumn;
	String rightColumn;
	String joinType;
	String joinCondition;

	public String getLeftSchema() {
		return leftSchema;
	}

	public void setLeftSchema(String leftSchema) {
		this.leftSchema = leftSchema;
	}

	public String getRightSchema() {
		return rightSchema;
	}

	public void setRightSchema(String rightSchema) {
		this.rightSchema = rightSchema;
	}

	public String getLeftColumn() {
		return leftColumn;
	}

	public void setLeftColumn(String leftColumn) {
		this.leftColumn = leftColumn;
	}

	public String getRightColumn() {
		return rightColumn;
	}

	public void setRightColumn(String rightColumn) {
		this.rightColumn = rightColumn;
	}

	public String getJoinType() {
		return joinType;
	}

	public void setJoinType(String joinType) {
		this.joinType = joinType;
	}

	public String getJoinCondition() {
		return joinCondition;
	}

	public void setJoinCondition(String joinCondition) {
		this.joinCondition = joinCondition;
	}

}
