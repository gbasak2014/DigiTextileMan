package com.gb.common.job.util;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;

import com.gb.common.config.ApplicationConfig;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class ExecutionService extends Thread {
	String codePath;
	String host;
	String user;
	String pwd;
	int port;
	String home;
	String jobName;
	String imputParams = "";
	DependencyList dependencyList;
	
	public ExecutionService(String data, DependencyList dependencyList) {
		JSONObject obj = new JSONObject(data);
		JSONObject cluster = obj.getJSONObject("cluster");
		host = cluster.getString("host");
		user = cluster.getString("user");
		pwd = cluster.getString("password");
		port = cluster.getInt("port");
		home = cluster.getString("home");
		jobName = obj.getJSONObject("start").getString("jobName");
		this.dependencyList = dependencyList;
		
		ApplicationConfig applicationConfig = ApplicationConfig.getInstance();
		codePath = applicationConfig.getConfig(JobConstants.CONF_JOB_HOME);
		System.out.println("codePath->" + codePath + ", jobName->" + jobName);
		codePath = codePath.replace("$" + JobConstants.PARAM_JOB_NAME, jobName);

		try {
			JSONObject param = obj.getJSONObject("parameters");
			System.out.println(">>>>>>>>" + param.toString());
			for (String k : param.keySet())
			{
				imputParams = imputParams + " -" + (String) k + " " + param.getString(k);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println(">>>" + this.imputParams);
	}

	public void run() {
		System.out.println("\n\n\n\nExecuting Job..........................");
		System.out.println("Host:" + host);
		System.out.println("Port" + port);
		System.out.println("User:" + user);
		System.out.println("Home:" + home);
		System.out.println("Job Name:" + jobName);
		System.out.println("\nGenerating jor for the workflow.....");
		CommandExecutor ce = new CommandExecutor(codePath + "/compile.cmd");

		try {
			int status = ce.execute();
			if (status != 0) {
				System.out.println("Jar creation ERROR!!!!!!!!!!!!!!!!!");
				return;
			}
			System.out.println("Jar created successfully......");
			System.out.println("\n\n\nCopying required files to cluster....");
			List<String> files = new ArrayList<String>();
			files.add(codePath + "/job-config.properties");
			files.add(codePath + "/startJob.sh");
			files.add(codePath + "/target/" + jobName + "-1.0-SNAPSHOT.jar");
			for (String ej : this.dependencyList.getExternalJars())
			{
				files.add(codePath + "/ext-jars/" + ej);
			}
			
			SftpClient sftp = new SftpClient(host, port, user, pwd);
			System.out.println("\n\n\nCopying required file to cluster");
			sftp.copyFiles(files, home, jobName);
			System.out.println("File copied to cluster");
			System.out.println("\n\n\nStarting workflow.....");

			status = sftp.executeOnCluster(home + "/" + jobName, "sh ./startJob.sh" + this.imputParams);
			if (status == 0) {
				System.out.println("Job execution completed successfully...........................");
			}
		} catch (Exception e) {
			System.out.println("\n\nERROR Processing workflow!!!!!");
			e.printStackTrace();
		}

		System.out.println("..............................Completed Job..........................");
	}
}
