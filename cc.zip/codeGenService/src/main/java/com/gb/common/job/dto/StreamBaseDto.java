package com.gb.common.job.dto;

public class StreamBaseDto extends BaseDto {
	int interval;
	String recordType;
	String delimiter;

	public int getInterval() {
		return interval;
	}

	public void setInterval(int interval) {
		this.interval = interval;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	@Override
	public String toString() {
		return super.toString() + ", interval:" + this.interval + ", recordType:" + this.recordType + ", delimiter:" + this.delimiter;
	}

}
