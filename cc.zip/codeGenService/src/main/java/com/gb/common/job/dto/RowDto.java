package com.gb.common.job.dto;

public class RowDto extends BaseDto {
	@Override
	public String getDataType() {
		return "Row";
	}

	@Override
	public String getVariableName() {
		return this.name;
	}

	@Override
	public String getDataFrameName() {
		return this.name;
	}

}
