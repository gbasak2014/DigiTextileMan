package com.gb.common.job.dto;

public class InParamDto {
	long id;
	String param;
	String type;
	
	public InParamDto(long id, String param, String type) {
		this.id = id;
		this.param = param;
		this.type = type;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getParam() {
		return param;
	}

	public void setParam(String param) {
		this.param = param;
	}
	
	@Override
	public String toString() {
		return "{" + this.id + ", " + this.param + ", " + this.type + "}";
	}
}
