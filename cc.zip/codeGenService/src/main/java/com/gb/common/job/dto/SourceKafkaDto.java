package com.gb.common.job.dto;

public class SourceKafkaDto extends StreamBaseDto {
	String brokers;
	String topics;

	public String getBrokers() {
		return brokers;
	}

	public void setBrokers(String brokers) {
		this.brokers = brokers;
	}

	public String getTopics() {
		return topics;
	}

	public void setTopics(String topics) {
		this.topics = topics;
	}

	@Override
	public String toString() {
		return super.toString() + ", brokers:" + this.brokers + ", topics:" + this.topics;
	}
}
