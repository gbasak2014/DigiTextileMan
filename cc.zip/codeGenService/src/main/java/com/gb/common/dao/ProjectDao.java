package com.gb.common.dao;

import java.util.List;

import com.gb.common.entity.DataType;
import com.gb.common.entity.JobDetails;
import com.gb.common.entity.Project;
import com.gb.common.entity.ProjectConfig;
import com.gb.common.entity.RecordType;
import com.gb.common.entity.Role;
import com.gb.common.entity.ServiceDetail;
import com.gb.common.entity.SourceMetaData;
import com.gb.common.entity.SourceType;

public interface ProjectDao {
	Project getProjectById(Long projectId);

	// List<UserDetails> getProjectUsers(Long projectId);
	// List<ProjectConfig> getProjectConfigurations(Long projectId);
	ProjectConfig saveConfig(ProjectConfig pc);

	ProjectConfig deleteConfig(ProjectConfig pc);

	Project saveProject(Project project);

	Role getRoleByName(String name);

	List<RecordType> getAllRecordType();

	List<SourceType> getAllSourceType();

	List<DataType> getAllDataType();

	long saveSourceMetaData(SourceMetaData data);

	SourceMetaData getSourceMetaData(Long id);

	List<JobDetails> getJobs(long projectId);

	List<JobDetails> getSubWorkflows(long projectId);
	
	ServiceDetail getService(long projectId, String serviceName);

	long saveService(ServiceDetail sd);

	List<ServiceDetail> getServiceList(long projectId, String type);

	ServiceDetail getServiceDetail(long serviceId);
}
