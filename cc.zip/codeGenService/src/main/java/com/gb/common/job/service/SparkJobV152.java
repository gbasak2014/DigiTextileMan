package com.gb.common.job.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Pattern;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.gb.common.SDPConstnts;
import com.gb.common.config.ApplicationConfig;
import com.gb.common.config.JobConfiguration;
import com.gb.common.dao.JobDao;
import com.gb.common.dao.ProjectDao;
import com.gb.common.entity.JobDetails;
import com.gb.common.entity.JobParam;
import com.gb.common.entity.JobStep;
import com.gb.common.entity.ServiceDetail;
import com.gb.common.entity.ServiceParams;
import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.CustomActionDto;
import com.gb.common.job.dto.StartDto;
import com.gb.common.job.transformation.IfElseUdf;
import com.gb.common.job.util.ComponentTypes;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.common.job.util.JobConstants;
import com.gb.common.job.util.ScriptGenerator;
import com.gb.common.job.util.SparkV152CodeGenUtils;
import com.gb.common.service.JobService;
import com.gb.common.util.MessageUtils;
import com.gb.common.util.ServiceUtils;
import com.gb.spark.wf.component.AbstractTask;
import com.gb.spark.wf.component.CustomActionTask;
import com.gb.spark.wf.dependency.mvn.DependencyList;

@Service(value = "jobService")
public class SparkJobV152 implements JobService {
	JobConfiguration jc = new JobConfiguration();

	@Autowired
	@Qualifier("jobDao")
	JobDao jobDao;

	@Autowired
	@Qualifier("projectDao")
	ProjectDao projectDao;

	static final Logger logger = Logger.getLogger(SparkJobV152.class);

	@Override
	@Transactional
	public void generateJob(String json, DependencyList dependencyList) {
		logger.debug("Entered generateJob");
		ApplicationConfig applicationConfig = ApplicationConfig.getInstance();
		String templateHome = applicationConfig.getConfig(JobConstants.CONF_JOB_TMPL_HOME);
		String templateName = applicationConfig.getConfig(JobConstants.CONF_JOB_TMPL_NAME);
		String codePath = applicationConfig.getConfig(JobConstants.CONF_JOB_HOME);
		String tmpPath = applicationConfig.getConfig(JobConstants.CONF_JOB_TMP_PATH);

		Map<String, BaseDto> dtoMap = jc.convertJsonToDtoMap(json);
		StartDto start = (StartDto) dtoMap.get("start");
		Long projectId = start.getProjectId();
		String jobName = start.getJobName();

		logger.debug("No of DTO: " + dtoMap.size());
		ImportList importList = new ImportList();
		ConfigList configList = new ConfigList();
		Map<String, String> inParams = new HashMap<String, String>();
		List<IfElseUdf> udfList = new ArrayList<IfElseUdf>();
		configList.addConfig(SDPConstnts.PROJECT_ID, projectId.toString());
		configList.addConfig(SDPConstnts.TMP_PATH, tmpPath);
		configList.addConfig(SDPConstnts.JOB_NAME, jobName);
		String tmpCodePath = tmpPath + "/" + projectId + "/" + jobName;
		configList.addConfig(SDPConstnts.CODE_TMP_PATH, tmpCodePath);

		addImports(importList);
		Map<String, AbstractTask> taskMap = SparkV152CodeGenUtils.convertDtoToTasksMap(dtoMap, importList, dependencyList, configList, inParams);

		logger.debug("Total Tasks: " + taskMap.size());

		// String jobName = configList.getConfig(JobConstants.PARAM_JOB_NAME);
		logger.debug("codePath->" + codePath + ", jobName->" + jobName);
		codePath = codePath.replace("$" + JobConstants.PARAM_JOB_NAME, jobName);

		String templatePath = templateHome + "/" + templateName;
		String classPath = codePath + "/src/main/scala/" + JobConstants.WF_PACKAGE.replace(".", "/") + "/" + JobConstants.WF_CLASS_FILE;
		logger.debug("1. templatePath: " + templatePath);
		logger.debug("2. codePath: " + codePath);
		logger.debug("3. classPath: " + classPath);

		ScriptGenerator sg = new ScriptGenerator();

		try {
			this.copyTemplate(templatePath, codePath);
			this.updatePomXml(codePath + "/pom.xml", jobName);
			OutputStream out = new FileOutputStream(classPath);
			out.write(SparkV152CodeGenUtils.getSDPWorkFlowClass(importList, dtoMap, taskMap, udfList).getBytes());
			out.close();
			out = new FileOutputStream(codePath + "/" + JobConstants.WF_PROP_FILE);
			StringBuffer code = new StringBuffer();
			code.append("#System generated properties for the Job.\n#Do not modify this without proper knowledge on job\n");
			code.append(configList.getAsString());
			out.write(code.toString().getBytes());
			out.close();

			out = new FileOutputStream(codePath + "/" + JobConstants.WF_SCRIPT_FILE);
			out.write(sg.generateShellScript(applicationConfig, configList, jobName, dependencyList, taskMap, tmpCodePath).getBytes());
			out.close();

			out = new FileOutputStream(codePath + "/compile.cmd");
			out.write(sg.generateCompileCmd(codePath).getBytes());
			out.close();

			out = new FileOutputStream(codePath + "/README.txt");
			out.write(sg.getReadme(inParams).getBytes());
			out.close();

			if (udfList.size() > 0) {
				writeUdfClass(codePath, udfList);
			}

			writeUtilClasses(codePath, taskMap, importList, tmpCodePath);

			createSqoopJobCreateScript(taskMap, configList, tmpCodePath);

			writeCommonServices(codePath, dependencyList);

			Set<Long> lstSwId = dependencyList.getSubWorkflowList();
			if (lstSwId != null && lstSwId.size() > 0) {
				getAndWriteSubWorkflows(lstSwId, codePath, tmpCodePath);
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("ERROR>>" + e.getMessage());
		}

		logger.debug("Entered generateJob");
	}

	void getAndWriteSubWorkflows(Set<Long> subWfIds, String codeBase, String tmpCodePath) {
		logger.debug("Entered getAndWriteSubWorkflows");
		for (Long swId : subWfIds) {
			String swJson = this.getSubWorkflow(swId);
			createSubWorkflow(new JSONObject(swJson).getJSONObject("data"), new DependencyList(), codeBase, tmpCodePath);
		}
		logger.debug("Exiting getAndWriteSubWorkflows");
	}

	void createSubWorkflow(JSONObject wfJson, DependencyList dependencyList, String codeBasePath, String tmpCodePath) {
		logger.debug("Entered createSubWorkflow");
		logger.debug("codeBasePath >>" + codeBasePath);
		logger.debug("tmpCodePath >>" + tmpCodePath);

		logger.debug("================================================================================");
		logger.debug(wfJson.toString());
		logger.debug("================================================================================");
		JSONObject startJson = wfJson.getJSONObject("start");

		Map<String, BaseDto> dtoMap = jc.convertJsonToDtoMap(wfJson.toString());
		// StartDto start = (StartDto) dtoMap.get("start");

		logger.debug("No of DTO: " + dtoMap.size());
		ImportList importList = new ImportList();
		addImports(importList);
		ConfigList configList = new ConfigList();
		Map<String, String> inParams = new HashMap<String, String>();
		List<IfElseUdf> udfList = new ArrayList<IfElseUdf>();

		Map<String, AbstractTask> taskMap = SparkV152CodeGenUtils.convertDtoToTasksMap(dtoMap, importList, dependencyList, configList, inParams);

		String className = startJson.getString("jobName");

		try {
			String classPath = codeBasePath + "/" + JobConstants.PATH_SUB_WF + "/" + className + ".scala";

			OutputStream out = new FileOutputStream(classPath);
			out.write(SparkV152CodeGenUtils.getSubWorkflowCode(importList, dtoMap, taskMap, udfList, startJson).getBytes());
			out.close();

			if (udfList.size() > 0) {
				writeUdfClass(codeBasePath, udfList);
			}

			writeUtilClasses(codeBasePath, taskMap, importList, tmpCodePath);
			createSqoopJobCreateScript(taskMap, configList, tmpCodePath);
			writeCommonServices(codeBasePath, dependencyList);

			Set<Long> lstSwId = dependencyList.getSubWorkflowList();
			if (lstSwId != null && lstSwId.size() > 0) {
				getAndWriteSubWorkflows(lstSwId, codeBasePath, tmpCodePath);
			}

		} catch (Exception e) {
			e.printStackTrace();
			logger.error("ERROR>>" + e.getMessage());
		}

		logger.debug("Exiting createSubWorkflow");
	}

	void writeCommonServices(String basePath, DependencyList dependencyList) {
		Set<Long> serviceIds = dependencyList.getServiceList();
		if (serviceIds.size() > 0) {
			for (Long sId : serviceIds) {
				if (sId != null) {
					ServiceDetail sd = this.projectDao.getServiceDetail(sId);
					if (sd != null && "service".equalsIgnoreCase(sd.getType())) {
						writeCommonService(basePath, sd);
					}
				}
			}
		}
	}

	void writeCommonService(String basePath, ServiceDetail sd) {
		String classPath = basePath + "/" + JobConstants.PATH_COMMON_SERVICE + "/" + sd.getName() + ".scala";
		try {
			PrintWriter pw = new PrintWriter(classPath);
			pw.println("package " + JobConstants.PACKAGE_COMMON_SERVICE + "\n");
			String[] arrImp = sd.getImports().split(Pattern.quote(","));
			for (String imp : arrImp) {
				pw.println("import " + imp);
			}

			StringBuffer bff = new StringBuffer();
			bff.append("\nclass " + sd.getName() + " (hiveContext: HiveContext, inParams:Map[String, String]");
			Set<ServiceParams> spLst = sd.getParams();
			if (spLst != null && spLst.size() > 0) {
				Map<Integer, String> map = new TreeMap<Integer, String>();
				for (ServiceParams sp : spLst) {
					Integer pos = sp.getPos();
					map.put(pos, sp.getName() + ": " + sp.getDataType());
				}

				for (Integer p : map.keySet()) {
					bff.append(", ").append(map.get(p));
				}
			}
			pw.print(bff.toString());
			pw.println("){\n");
			bff.delete(0, bff.length());
			bff.append("   def process(): ").append(sd.getReturnCategory()).append(" = {");
			pw.println(bff.toString());
			pw.println(sd.getCode());
			pw.println("   }\n}");
			pw.flush();
			pw.close();
		} catch (Exception e) {
			logger.error("ERROR creating class for " + sd.getName());
			e.printStackTrace();
		}
	}

	void createSqoopJobCreateScript(Map<String, AbstractTask> taskMap, ConfigList configList, String codePath) {
		String path = configList.getConfig(SDPConstnts.CODE_TMP_PATH);
		for (AbstractTask task : taskMap.values()) {
			if (task.getComponentType() == ComponentTypes.SQOOP) {
				File file = new File(path + task.getName() + "/" + SDPConstnts.SQOOP_JOB_CREATE_SUFF);
				File trgFile = new File(codePath + "/" + task.getName() + SDPConstnts.SQOOP_JOB_CREATE_SUFF);
				System.out.println(file.getAbsolutePath() + "=======>>>>" + trgFile.getAbsolutePath());
				file.renameTo(trgFile);
			}
		}
	}

	void writeUtilClasses(String basePath, Map<String, AbstractTask> taskMap, ImportList importList, String tmpPath) throws Exception {
		for (AbstractTask task : taskMap.values()) {
			if (task.getComponentType() == ComponentTypes.CUSTOM_ACTION) {
				writeUtilClass(basePath, (CustomActionTask) task, importList, tmpPath);
			}
		}
	}

	void writeUtilClass(String basePath, CustomActionTask cat, ImportList importList, String tmpPath) {
		logger.debug("Entered writeUtilClass");
		try {
			CustomActionDto dto = cat.getDto();
			String clsName = dto.getActionName() + ".scala";
			String clsPath = basePath + "/" + JobConstants.CUSTOM_PATH + "/" + clsName;

			OutputStream out = new FileOutputStream(clsPath);
			out.write(("package " + JobConstants.CUSTOM_PACKAGE + "\n\n").getBytes());
			out.write("\n//system generated custom action\n".getBytes());
			String imports = dto.getImports();
			if (imports != null) {
				for (String imp : imports.split(",")) {
					out.write(("import " + imp + "\n").getBytes());
				}
			}

			out.write("\n\n".getBytes());

			BufferedReader br = new BufferedReader(new FileReader(tmpPath + "/" + cat.getDto().getActionName()));
			String line = br.readLine();
			while (line != null) {
				out.write(line.getBytes());
				line = br.readLine();
			}
			br.close();
			out.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		logger.debug("Exiting writeUtilClass");
	}

	void writeUdfClass(String basePath, List<IfElseUdf> udfList) throws Exception {
		logger.debug("Entered writeUdfClass");
		logger.debug("No of UDF: " + udfList.size());
		String udfPath = basePath + "/" + JobConstants.UDF_PATH;
		PrintWriter pw = new PrintWriter(udfPath);
		pw.print("package " + JobConstants.UDF_PACKAGE);
		pw.println("\n");
		pw.println(JobConstants.UDF_IMPORTS);
		pw.println("\n");

		StringBuffer sb = new StringBuffer();

		for (IfElseUdf udf : udfList) {
			if (udf != null) {
				sb.append(udf.getUdfCode()).append("\n");
			}
		}

		pw.write(JobConstants.UDF_CLASS_CODE.replace("<CODE>", sb.toString()));
		pw.close();
		logger.debug("Entered writeUdfClass");
	}

	void addImports(ImportList importList) {
		importList.addImport("org.apache.spark.sql.hive.HiveContext");
		importList.addImport("org.apache.spark.streaming.StreamingContext");
		importList.addImport("com.gb.sdp.spark.common.DataFrameFactory");
		importList.addImport("com.gb.sdp.spark.common.service.DataFrameService");
		importList.addImport("java.util._");
		importList.addImport("com.gb.sdp.spark.common.util._");
		importList.addImport("org.apache.spark.sql.functions._");
		importList.addImport("org.apache.spark.sql._");
	}

	void addConfig(ConfigList configList, ApplicationConfig applicationConfig) {
		configList.setConfig(JobConstants.CONF_JOB_PROP_FILE, applicationConfig.getConfig(JobConstants.CONF_JOB_PROP_FILE));
		configList.setConfig(JobConstants.CONF_JOB_FILE_CP_SCRIPT, applicationConfig.getConfig(JobConstants.CONF_JOB_FILE_CP_SCRIPT));
		configList.setConfig(JobConstants.CONF_JOB_SPARK_SUBMIT_SCRIPT, applicationConfig.getConfig(JobConstants.CONF_JOB_SPARK_SUBMIT_SCRIPT));
		configList.setConfig(JobConstants.CONF_JOB_SHELL_NAME, applicationConfig.getConfig(JobConstants.CONF_JOB_SHELL_NAME));
	}

	@Override
	@Transactional(value = TxType.REQUIRED)
	public String getJob(String jobId) {
		logger.debug("Entered getJob>>" + jobId);

		JobDetails job = this.jobDao.getJob(Long.parseLong(jobId));

		logger.debug("JOB::::::" + job);
		String data;
		if (job != null) {
			data = MessageUtils.getResponseMessage("SUCCESS", ServiceUtils.getJSON(job));
			logger.debug("FROM JSON>>> " + data);
		} else {
			data = MessageUtils.getResponseMessage("FAIL", "Job not found for Id:" + jobId);
		}

		return data;
	}

	@Override
	public String getSubWorkflow(long subWfId) {
		logger.debug("Entered getSubWorkflow>>" + subWfId);

		JobDetails sWf = this.jobDao.getSubWorkflow(subWfId);

		logger.debug("Sub Workflow: " + sWf);
		String data;
		if (sWf != null) {
			data = MessageUtils.getResponseMessage("SUCCESS", ServiceUtils.getJSON(sWf));
			logger.debug("FROM JSON>>> " + data);
		} else {
			data = MessageUtils.getResponseMessage("FAIL", "Sub Workflow not found for Id:" + subWfId);
		}

		logger.debug("Exiting getSubWorkflow");
		return data;
	}

	@Override
	public String getSubWorkflowHeader(long subWfId) {
		logger.debug("Entered getSubWorkflowHeader>>" + subWfId);

		JobDetails sWf = this.jobDao.getSubWorkflow(subWfId);

		logger.debug("Sub Workflow: " + sWf);
		String data;
		if (sWf != null) {
			data = MessageUtils.getResponseMessage("SUCCESS", ServiceUtils.getHeaderJSON(sWf));
			logger.debug("FROM JSON>>> " + data);
		} else {
			data = MessageUtils.getResponseMessage("FAIL", "Sub Workflow not found for Id:" + subWfId);
		}

		logger.debug("Exiting getSubWorkflowHeader");
		return data;
	}

	@Override
	public String getJob(long projectId, String jobName) {
		logger.debug(this.getClass().getName() + ".getJob>>" + projectId + " - " + jobName);
		JobDetails job = this.jobDao.getJobByName(projectId, jobName);
		logger.debug("JOB::::::" + job);
		String data;
		if (job != null) {
			JSONObject jsnJob = new JSONObject(job.getCode());
			JSONObject start = (JSONObject) jsnJob.get("start");
			start.put("id", job.getJobId());
			data = MessageUtils.getResponseMessage("SUCCESS", jsnJob);
		} else {
			data = MessageUtils.getResponseMessage("FAIL", "Job not found for Project Id and Job Name: " + projectId + " - " + jobName);
		}

		return data;
	}

	@Override
	@Transactional(value = TxType.REQUIRED)
	public long saveJob(String json) {
		logger.debug("Entered saveJob()");
		JSONObject jsonMain = new JSONObject(json);
		Map<String, JSONObject> taskMap = jc.getTaskJsonMap(jsonMain);
		JSONObject start = jsonMain.getJSONObject("start");
		String jobName = start.getString("jobName");
		String jobDesc = start.getString("jobDesc");
		Long jobId = start.getLong("jobId");
		Long projectId = start.getLong("projectId");
		String jobType;
		if (JobConstants.TYPE_JOB.equalsIgnoreCase(jsonMain.getString("type"))) {
			jobType = JobConstants.TYPE_JOB;
		} else {
			jobType = JobConstants.TYPE_SUB_WF;
		}

		boolean newJob = false;
		JobDetails job;
		if (jobId <= 0) {
			job = this.jobDao.getJobByName(projectId, jobName);
			if (job != null) {
				logger.debug("Job exist with name!!");
				return -1;
			}
			newJob = true;
		} else {
			job = this.jobDao.getJob(jobId);
			if (job == null || !jobName.equals(job.getName())) {
				newJob = true;
			}
		}

		if (newJob) {
			job = new JobDetails();
			job.setProjectId(projectId);
			job.setParams(new HashSet<JobParam>());
			job.setSteps(new HashSet<JobStep>());
			job.setVersion(0);
			job.setParams(new HashSet<JobParam>());
			job.setSteps(new HashSet<JobStep>());
			job.setName(jobName);
			job.setType(jobType);
		}

		job.setDescription(jobDesc);
		job.setCode(json);

		ServiceUtils.refreshJobParams(job, start);
		ServiceUtils.refreshJobSteps(job, taskMap);

		logger.debug("Update JobDetails>>" + job);
		long newId = jobId;
		if (newJob) {
			newId = this.jobDao.saveJob(job);
		}

		logger.debug("Exiting saveJob():" + newId);
		return newId;
	}

	private void copyTemplate(String src, String dst) throws IOException {
		FileUtils.copyDirectory(new File(src), new File(dst));
	}

	private void updatePomXml(String path, String jobName) throws Exception {
		File oldFile = new File(path);
		oldFile.renameTo(new File(path + ".bak"));

		BufferedReader br = new BufferedReader(new FileReader(path + ".bak"));
		PrintWriter pw = new PrintWriter(path);
		String line = br.readLine();
		while (line != null) {
			pw.println(line.replace("$JOB_NAME", jobName));
			line = br.readLine();
		}

		pw.close();
		br.close();
		oldFile = new File(path + ".bak");
		oldFile.delete();
	}
}
