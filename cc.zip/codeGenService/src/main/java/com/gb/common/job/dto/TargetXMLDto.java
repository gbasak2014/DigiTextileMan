package com.gb.common.job.dto;

public class TargetXMLDto extends BaseDto {
	String rootElement;
	String path;

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getRootElement() {
		return rootElement;
	}

	public void setRootElement(String rootElement) {
		this.rootElement = rootElement;
	}

	@Override
	public String toString() {
		return super.toString() + ", path:" + this.path + ", rootElement:" + this.rootElement;
	}

}
