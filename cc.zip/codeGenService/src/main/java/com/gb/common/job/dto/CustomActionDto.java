package com.gb.common.job.dto;

import java.util.List;

public class CustomActionDto extends BaseDto {
	String actionName;
	String code;
	List<KV> params;
	String imports;
	
	public String getActionName() {
		return actionName;
	}

	public void setActionName(String actionName) {
		this.actionName = actionName;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public List<KV> getParams() {
		return params;
	}

	public void setParams(List<KV> params) {
		this.params = params;
	}

	public String getImports() {
		return imports;
	}

	public void setImports(String imports) {
		this.imports = imports;
	}
}
