package com.gb.common.job.transformation;

import java.util.ArrayList;
import java.util.List;

public class IfElseFunctionDto {
	List<IfElseUdfDto> function = new ArrayList<IfElseUdfDto>();

	public List<IfElseUdfDto> getFunction() {
		return function;
	}

	public void setFunction(List<IfElseUdfDto> function) {
		this.function = function;
	}
	
}
