package com.gb.common.util;

import org.json.JSONObject;

public class MessageUtils {
	public static String getResponseMessage(String status, Object data)
	{
		JSONObject obj = new JSONObject();
		obj.put("status", status);
		obj.put("data", data);
		
		return obj.toString();
	}
	
	public static void main(String[] args) {
		System.out.println("hello");
		
		JSONObject obj = new JSONObject();
		obj.put("name", "My Job");
		obj.put("id", 100);
		
		
		System.out.println(getResponseMessage("FAIL", "JOB NOT FOUND!!!!"));
		
		String s = obj.toString();
		
		System.out.println(s);
		
		JSONObject res = new JSONObject(getResponseMessage("SUCCESS", new JSONObject(s)));
	
		System.out.println(res.toString());
		
		System.out.println(res.get("status"));
		System.out.println(res.getJSONObject("data").get("name"));
		System.out.println(res.getJSONObject("data").get("id"));
	}
}
