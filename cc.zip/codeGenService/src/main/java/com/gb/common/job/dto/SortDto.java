package com.gb.common.job.dto;

import java.util.List;

public class SortDto extends BaseDto {

	List<OrderByDto> orderBy;

	public List<OrderByDto> getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(List<OrderByDto> orderBy) {
		this.orderBy = orderBy;
	}

	@Override
	public String toString() {
		return super.toString() + ", orderBy" + this.orderBy;
	}
}
