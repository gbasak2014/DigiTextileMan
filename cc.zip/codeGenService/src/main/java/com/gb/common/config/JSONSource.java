package com.gb.common.config;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class JSONSource {
	
	public static String getConfigJSON() throws IOException
	{
		BufferedReader br = new BufferedReader(new FileReader("E:/Code/SparkDFWs/sdpWf.json"));
		StringBuffer bff = new StringBuffer();
		String line = null;
				
		while ((line = br.readLine()) != null)
		{
			bff.append(line).append("\n");
		}
		br.close();
		return bff.toString();
	}
	
	public static String getConfigJSON1()
	{
		return "{  " + 
				"   \"start\":{  " + 
				"      \"jobName\":\"MySparkWF\"," + 
				"      \"name\":\"start\"," + 
				"      \"componentType\":0," + 
				"      \"successors\":[  " + 
				"         \"srcEmp\"," + 
				"         \"srcDept\"" + 
				"      ]" + 
				"   }," + 
				"   \"srcDept\":{  " + 
				"      \"name\":\"srcDept\"," + 
				"      \"componentType\":12," + 
				"      \"fields\":[  " + 
				"         \"deptid\"," + 
				"         \"name\"" + 
				"      ]," + 
				"      \"predecessors\":[  " + 
				"         \"start\"" + 
				"      ]," + 
				"      \"successors\":[  " + 
				"         \"hdfsDept\"" + 
				"      ]," + 
				"      \"sourcePath\":\"/home/tom/spark/$job.name/dept\"," + 
				"      \"targetPath\":\"/user/tom/spark/$job.name/in/dept\"," + 
				"      \"fileFormat\":\"Delimited\"," + 
				"      \"delimiter\":\",\"," + 
				"      \"deleteSource\":\"false\"," + 
				"      \"renameSource\":\"false\"," + 
				"      \"renameSuffix\":\"\"" + 
				"   }," + 
				"   \"srcEmp\":{  " + 
				"      \"name\":\"srcEmp\"," + 
				"      \"componentType\":12," + 
				"      \"fields\":[  " + 
				"         \"empid\"," + 
				"         \"name\"," + 
				"         \"salary\"," + 
				"         \"deptid\"" + 
				"      ]," + 
				"      \"predecessors\":[  " + 
				"         \"start\"" + 
				"      ]," + 
				"      \"successors\":[  " + 
				"         \"hdfsEmp\"" + 
				"      ]," + 
				"      \"sourcePath\":\"/home/tom/spark/$job.name/emp\"," + 
				"      \"targetPath\":\"/user/tom/spark/$job.name/in/emp\"," + 
				"      \"fileFormat\":\"Delimited\"," + 
				"      \"delimiter\":\",\"," + 
				"      \"deleteSource\":\"false\"," + 
				"      \"renameSource\":\"true\"," + 
				"      \"renameSuffix\":\"DONE\"" + 
				"   }," + 
				"   \"hdfsDept\":{  " + 
				"      \"name\":\"hdfsDept\"," + 
				"      \"componentType\":11," + 
				"      \"fields\":[  " + 
				"         \"deptid\"," + 
				"         \"name\"" + 
				"      ]," + 
				"      \"predecessors\":[  " + 
				"         \"srcDept\"" + 
				"      ]," + 
				"      \"successors\":[  " + 
				"         \"JOIN_01\"" + 
				"      ]," + 
				"      \"sourcePath\":\"/user/tom/spark/$job.name/in/dept\"," + 
				"      \"fileType\":\"Delimited\"," + 
				"      \"delimiter\":\",\"," + 
				"      \"deleteSource\":\"false\"," + 
				"      \"renameSource\":\"false\"," + 
				"      \"renameSuffix\":\"\"" + 
				"   }," + 
				"   \"hdfsEmp\":{  " + 
				"      \"name\":\"hdfsEmp\"," + 
				"      \"componentType\":11," + 
				"      \"fields\":[  " + 
				"         \"empid\"," + 
				"         \"name\"," + 
				"         \"salary\"," + 
				"         \"deptid\"" + 
				"      ]," + 
				"      \"predecessors\":[  " + 
				"         \"srcEmp\"" + 
				"      ]," + 
				"      \"successors\":[  " + 
				"         \"JOIN_01\"" + 
				"      ]," + 
				"      \"sourcePath\":\"/user/tom/spark/$job.name/in/emp\"," + 
				"      \"fileType\":\"Delimited\"," + 
				"      \"delimiter\":\",\"," + 
				"      \"deleteSource\":\"false\"," + 
				"      \"renameSource\":\"false\"," + 
				"      \"renameSuffix\":\"\"" + 
				"   }," + 
				"   \"JOIN_01\":{  " + 
				"      \"name\":\"JOIN_01\"," + 
				"      \"componentType\":104," + 
				"      \"fields\":[  " + 
				"         \"empId\"," + 
				"         \"empName\"," + 
				"         \"salary\"," + 
				"         \"deptId\"," + 
				"         \"deptName\"" + 
				"      ]," + 
				"      \"predecessors\":[  " + 
				"         \"hdfsEmp\"," + 
				"         \"hdfsDept\"" + 
				"      ]," + 
				"      \"successors\":[  " + 
				"         \"groupEmp\"" + 
				"      ]," + 
				"      \"transformations\":[  " + 
				"         {  " + 
				"            \"index\":0," + 
				"            \"transform\":\"hdfsEmp.empid\"," + 
				"            \"targetField\":\"empId\"" + 
				"         }," + 
				"         {  " + 
				"            \"index\":1," + 
				"            \"transform\":\"hdfsEmp.name\"," + 
				"            \"targetField\":\"empName\"" + 
				"         }," + 
				"         {  " + 
				"            \"index\":2," + 
				"            \"transform\":\"hdfsEmp.salary\"," + 
				"            \"targetField\":\"salary\"" + 
				"         }," + 
				"         {  " + 
				"            \"index\":3," + 
				"            \"transform\":\"hdfsEmp.deptid\"," + 
				"            \"targetField\":\"deptId\"" + 
				"         }," + 
				"         {  " + 
				"            \"index\":4," + 
				"            \"transform\":\"hdfsDept.name\"," + 
				"            \"targetField\":\"deptName\"" + 
				"         }" + 
				"      ]," + 
				"      \"join\":[  " + 
				"         {  " + 
				"            \"leftSchema\":\"hdfsEmp\"," + 
				"            \"rightSchema\":\"hdfsDept\"," + 
				"            \"leftColumn\":\"deptid\"," + 
				"            \"rightColumn\":\"deptid\"," + 
				"            \"joinType\":\"INNER JOIN\"," + 
				"            \"joinCondition\":\" = \"" + 
				"         }" + 
				"      ]" + 
				"   }," + 
				"   \"groupEmp\":{  " + 
				"      \"name\":\"groupEmp\"," + 
				"      \"componentType\":103," + 
				"      \"fields\":[  " + 
				"         \"empName\"," + 
				"         \"totalSalary\"," + 
				"         \"deptName\"" + 
				"      ]," + 
				"      \"predecessors\":[  " + 
				"         \"JOIN_01\"" + 
				"      ]," + 
				"      \"successors\":[  " + 
				"         \"filterEmp\"" + 
				"      ]," + 
				"      \"groupByColumns\":\"empName,deptName\"," + 
				"      \"transformations\":[  " + 
				"         {  " + 
				"            \"index\":0," + 
				"            \"transform\":\"empName\"," + 
				"            \"targetField\":\"empName\"" + 
				"         }," + 
				"         {  " + 
				"            \"index\":1," + 
				"            \"transform\":\"SUM(salary)\"," + 
				"            \"targetField\":\"totalSalary\"" + 
				"         }," + 
				"         {  " + 
				"            \"index\":2," + 
				"            \"transform\":\"deptName\"," + 
				"            \"targetField\":\"deptName\"" + 
				"         }" + 
				"      ]" + 
				"   }," + 
				"   \"filterEmp\":{  " + 
				"      \"name\":\"filterEmp\"," + 
				"      \"componentType\":102," + 
				"      \"fields\":[  " + 
				"         \"empName\"," + 
				"         \"totalSalary\"," + 
				"         \"deptName\"" + 
				"      ]," + 
				"      \"predecessors\":[  " + 
				"         \"groupEmp\"" + 
				"      ]," + 
				"      \"successors\":[  " + 
				"         \"trgJSON\"" + 
				"      ]," + 
				"      \"conditions\":[  " + 
				"         {  " + 
				"            \"column\":\"totalSalary\"," + 
				"            \"condition\":\"Greater Than\"," + 
				"            \"value\":\"5000\"," + 
				"            \"type\":\"none\"" + 
				"         }" + 
				"      ]" + 
				"   }," + 
				"   \"trgJSON\":{  " + 
				"      \"name\":\"trgJSON\"," + 
				"      \"componentType\":205," + 
				"      \"fields\":[  " + 
				"         \"empName\"," + 
				"         \"totalSalary\"," + 
				"         \"deptName\"" + 
				"      ]," + 
				"      \"predecessors\":[  " + 
				"         \"filterEmp\"" + 
				"      ]," + 
				"      \"successors\":[  " + 
				"         \"end\"" + 
				"      ]," + 
				"      \"path\":\"\"" + 
				"   }," + 
				"   \"end\":{  " + 
				"      \"name\":\"end\"," + 
				"      \"componentType\":1," + 
				"      \"predecessors\":[  " + 
				"         \"trgJSON\"" + 
				"      ]" + 
				"   }" + 
				"}";
	}
}
