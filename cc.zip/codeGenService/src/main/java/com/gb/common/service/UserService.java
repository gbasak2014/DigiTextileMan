package com.gb.common.service;

import com.gb.common.dto.AuthenticateDto;
import com.gb.common.dto.ResponseDto;
import com.gb.common.dto.UserDetailReqDto;

public interface UserService {
	ResponseDto getUserById(String userId);
	ResponseDto registerUser(UserDetailReqDto user);
	ResponseDto authenticateUser(AuthenticateDto auth);
	ResponseDto addUserToProject(UserDetailReqDto user);
	ResponseDto addProject(UserDetailReqDto user);
}
