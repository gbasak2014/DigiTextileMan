package com.gb.common.job.transformation;

import com.gb.common.job.util.JobConstants;

public class TransformationFactory {
	public static Transformation getTransformation(String expr, String df)
	{
		if (expr.startsWith("If-Else-If"))
		{
			String[] arr = expr.split("#");
			
			return new IfElseUdf(arr[0], df, JobConstants.UDF_CLASS, arr[1], arr.length > 2 ? arr[2] : "String");
		}
				
		int idx = expr.indexOf('(');
		if (idx > 1)
		{
			String fName = expr.substring(0, idx);
			String args = expr.substring(idx+1, expr.lastIndexOf(')'));
			return new Function(fName, args, df);
		}
		
		return new Expression(expr, df);
	}
}
