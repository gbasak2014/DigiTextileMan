package com.gb.common.dao;

import com.gb.common.entity.Role;
import com.gb.common.entity.UserDetails;

public interface PersonDao {
	UserDetails getUserDetails(long id);
	void createUser(UserDetails ud);
	Long saveUser(UserDetails ud);
	Role getRoleByName(String name);
	Object getByName(Class clazz, String name);
	Object getUserByName(Class clazz, String name);
}
