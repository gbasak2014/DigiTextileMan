package com.gb.common.job.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gb.common.job.dto.ColumnDto;

public class JobUtils {

	static Map<String, String> dataTypeMap = new HashMap<String, String>();
	static Map<String, String> inputParamMap = new HashMap<String, String>();

	static {
		dataTypeMap.put("STRING", "org.apache.spark.sql.types.StringType");
		dataTypeMap.put("NA", "org.apache.spark.sql.types.StringType");
		dataTypeMap.put("NULL", "org.apache.spark.sql.types.StringType");
		dataTypeMap.put("CHAR", "org.apache.spark.sql.types.StringType");
		dataTypeMap.put("DATE", "org.apache.spark.sql.types.StringType");
		dataTypeMap.put("LONG", "org.apache.spark.sql.types.LongType");
		dataTypeMap.put("INT", "org.apache.spark.sql.types.LongType");
		dataTypeMap.put("INTEGER", "org.apache.spark.sql.types.LongType");
		dataTypeMap.put("DOUBLE", "org.apache.spark.sql.types.DoubleType");
		dataTypeMap.put("FLOAT", "org.apache.spark.sql.types.DoubleType");

		inputParamMap.put("$YYYY", "paramYYYY");
		// inputParamMap.put("$YY", "paramYY");
		inputParamMap.put("$MM", "paramMM");
		inputParamMap.put("$DD", "paramDD");
		inputParamMap.put("$HH", "paramDD");
	}

	public static String getSparkType(String dataType)
	{
		if (dataType == null)
		{
			dataType = "NULL";
		}
		
		return dataTypeMap.get(dataType.toUpperCase());
	}
	
	public static String getSchema(List<ColumnDto> fields) {
		StringBuffer buff = new StringBuffer();
		String st = "org.apache.spark.sql.types.StructType";
		String sf = "org.apache.spark.sql.types.StructField";

		for (ColumnDto f : fields) {
			if (buff.length() <= 0) {
				buff.append(st).append("(Array(");
			} else {
				buff.append(",");
			}

			buff.append(sf).append("(");
			buff.append("\"" + f.getName()).append("\", ");
			buff.append(getSparkType(f.getDataType())).append(", false)");
		}
		buff.append("))");

		return buff.toString();
	}
	
	//public static String CODE_PATH_REPLACE_PARAM = "com.gb.sdp.spark.common.util.JobUtils(<VALUE>)";
}
