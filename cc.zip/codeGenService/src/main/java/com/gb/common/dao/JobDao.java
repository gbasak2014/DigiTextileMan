package com.gb.common.dao;

import java.util.List;

import com.gb.common.entity.Dept;
import com.gb.common.entity.JobDetails;
import com.gb.common.entity.JobParam;
import com.gb.common.entity.JobStep;
import com.gb.common.entity.Project;
import com.gb.common.entity.SubWorkflow;

public interface JobDao {
	long saveJob(JobDetails job);
	void updateJob(JobDetails job);
	JobDetails getJob(Long jobId);
	JobDetails getJobByName(long projectId, String jobName);
	Dept getDept(long id);
	void saveDept(Dept d);
	Project getProjectById(Long projectId);
	void deleteSteps(List<JobStep> steps);
	void deleteParams(List<JobParam> params);
	JobDetails getSubWorkflow(Long subWfId);
	long saveSubWorkflow(SubWorkflow sw);
}
