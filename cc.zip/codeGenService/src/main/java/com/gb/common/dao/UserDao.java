package com.gb.common.dao;

import com.gb.common.entity.UserDetails;

public interface UserDao {
	UserDetails getUserById(String userId);
	UserDetails saveUser(UserDetails ud);
}
