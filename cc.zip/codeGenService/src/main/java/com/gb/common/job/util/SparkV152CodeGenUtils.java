package com.gb.common.job.util;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.json.JSONArray;
import org.json.JSONObject;

import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.CommonServiceDto;
import com.gb.common.job.dto.CustomActionDto;
import com.gb.common.job.dto.DataFrameDto;
import com.gb.common.job.dto.FilterDto;
import com.gb.common.job.dto.GroupDto;
import com.gb.common.job.dto.JoinDto;
import com.gb.common.job.dto.PrimeTypeDto;
import com.gb.common.job.dto.RowDto;
import com.gb.common.job.dto.SortDto;
import com.gb.common.job.dto.SourceHdfsDto;
import com.gb.common.job.dto.SourceHiveDto;
import com.gb.common.job.dto.SourceLocalDto;
import com.gb.common.job.dto.SqoopDto;
import com.gb.common.job.dto.StartDto;
import com.gb.common.job.dto.SubWorkflowDto;
import com.gb.common.job.dto.TargetDelimitedDto;
import com.gb.common.job.dto.TargetJSONDto;
import com.gb.common.job.dto.TargetXMLDto;
import com.gb.common.job.dto.TransformationDto;
import com.gb.common.job.transformation.IfElseUdf;
import com.gb.spark.wf.component.AbstractTask;
import com.gb.spark.wf.component.CommonServiceTask;
import com.gb.spark.wf.component.CustomActionTask;
import com.gb.spark.wf.component.DataFrameTask;
import com.gb.spark.wf.component.FilterTask;
import com.gb.spark.wf.component.GroupTask;
import com.gb.spark.wf.component.JobResponseTask;
import com.gb.spark.wf.component.JoinTask;
import com.gb.spark.wf.component.PrimeTypeTask;
import com.gb.spark.wf.component.RowTask;
import com.gb.spark.wf.component.SortTask;
import com.gb.spark.wf.component.SourceHdfsTask;
import com.gb.spark.wf.component.SourceHiveTask;
import com.gb.spark.wf.component.SourceLocalTask;
import com.gb.spark.wf.component.SqoopTask;
import com.gb.spark.wf.component.StartTask;
import com.gb.spark.wf.component.SubWorkflowTask;
import com.gb.spark.wf.component.TargetDelimitedTask;
import com.gb.spark.wf.component.TargetJSONTask;
import com.gb.spark.wf.component.TargetXMLTask;
import com.gb.spark.wf.component.TransformationTask;
import com.gb.spark.wf.dependency.mvn.DependencyList;
import com.gb.common.job.dto.JobResponseDto;

public class SparkV152CodeGenUtils {
	public static String getDriverClass(Map<String, BaseDto> steps, String pkg, String clazz) {
		// TODO Auto-generated method stub
		return null;
	}

	public static String getScript(Map<String, BaseDto> steps, String pkg, String clazz) {
		// TODO Auto-generated method stub
		return null;
	}

	public static Map<String, AbstractTask> convertDtoToTasksMap(Map<String, BaseDto> dtoMap, ImportList imports, DependencyList dependencyList, ConfigList configList,
			Map<String, String> inParams) {
		Map<String, AbstractTask> map = new HashMap<String, AbstractTask>();

		AbstractTask taskStart = getTask(dtoMap.get("start"), dtoMap, imports, dependencyList, configList, inParams);
		System.out.println("----------------------------------------------------------");
		System.out.println("inParams:" + inParams);
		System.out.println("----------------------------------------------------------");
		map.put("start", taskStart);

		for (Entry<String, BaseDto> e : dtoMap.entrySet()) {
			String key = e.getKey();
			if (!"start".equals(key)) {
				AbstractTask task = getTask(e.getValue(), dtoMap, imports, dependencyList, configList, inParams);
				if (task != null) {
					map.put(key, task);
					System.out.println("Done:" + key);
				} else {
					System.out.println("Not Done:" + e.getValue().getComponentType() + ":" + e.getValue().getName());
				}
			}
		}

		return map;
	}

	private static AbstractTask getTask(BaseDto dto, Map<String, BaseDto> dtoMap, ImportList imports, DependencyList dependencyList, ConfigList configList,
			Map<String, String> inParams) {
		AbstractTask task = null;

		switch (dto.getComponentType()) {
		case ComponentTypes.SOURCE_HDFS:
			return new SourceHdfsTask((SourceHdfsDto) dto, dtoMap, imports, dependencyList, configList);
		case ComponentTypes.START:
			return new StartTask((StartDto) dto, dtoMap, imports, dependencyList, configList, inParams);
		case ComponentTypes.SORT:
			return new SortTask((SortDto) dto, dtoMap, imports, dependencyList, configList);
		case ComponentTypes.FILTER:
			return new FilterTask((FilterDto) dto, dtoMap, imports, dependencyList, configList, inParams);
		case ComponentTypes.GROUP:
			return new GroupTask((GroupDto) dto, dtoMap, imports, dependencyList, configList);
		case ComponentTypes.TRANSFORMATION:
			return new TransformationTask((TransformationDto) dto, dtoMap, imports, dependencyList, configList);
		case ComponentTypes.TARGET_JSON:
			return new TargetJSONTask((TargetJSONDto) dto, dtoMap, imports, dependencyList, configList);
		case ComponentTypes.JOIN:
			return new JoinTask((JoinDto) dto, dtoMap, imports, dependencyList, configList);
		case ComponentTypes.SOURCE_LOCAL:
			return new SourceLocalTask((SourceLocalDto) dto, dtoMap, imports, dependencyList, configList);
		case ComponentTypes.SOURCE_HIVE:
			return new SourceHiveTask((SourceHiveDto) dto, dtoMap, imports, dependencyList, configList);
		case ComponentTypes.RESPONSE_JSON:
			return new JobResponseTask((JobResponseDto) dto, dtoMap, imports, dependencyList, configList);
		case ComponentTypes.CUSTOM_ACTION:
			return new CustomActionTask((CustomActionDto) dto, dtoMap, imports, dependencyList, configList, inParams);
		case ComponentTypes.TARGET_DELIM:
			return new TargetDelimitedTask((TargetDelimitedDto) dto, dtoMap, imports, dependencyList, configList);
		case ComponentTypes.TARGET_XML:
			return new TargetXMLTask((TargetXMLDto) dto, dtoMap, imports, dependencyList, configList);
		case ComponentTypes.SQOOP:
			return new SqoopTask((SqoopDto) dto, dtoMap, imports, dependencyList, configList, inParams);
		case ComponentTypes.COMMON_SERVICE:
			return new CommonServiceTask((CommonServiceDto) dto, dtoMap, imports, dependencyList, configList, inParams);
		case ComponentTypes.SUB_WF:
			return new SubWorkflowTask((SubWorkflowDto) dto, dtoMap, imports, dependencyList, configList, inParams);
		case ComponentTypes.DATAFRAME:
			return new DataFrameTask((DataFrameDto) dto, dtoMap, imports, dependencyList, configList);
		case ComponentTypes.ROW:
			return new RowTask((RowDto) dto, dtoMap, imports, dependencyList, configList);
		case ComponentTypes.PRIME_TYPE:
			return new PrimeTypeTask((PrimeTypeDto) dto, dtoMap, imports, dependencyList, configList);
		}

		return task;
	}

	public static String generateCode(Map<String, BaseDto> stepMap, Map<String, AbstractTask> taskMap, List<IfElseUdf> UDFMethods) {
		StringBuffer code = new StringBuffer();
		Deque<String> stack = new ArrayDeque<String>();

		Map<String, BaseDto> map = new HashMap<String, BaseDto>();
		for (String key : stepMap.keySet()) {
			map.put(key, stepMap.get(key));
		}

		stack.push(map.get("start").getName());
		while (!stack.isEmpty()) {

			String taskName = stack.removeLast();// stack.pop();
			BaseDto step = map.get(taskName);

			if (step != null && (step.getComponentType() == ComponentTypes.START || !isParentExist(map, step))) {
				AbstractTask task = taskMap.get(taskName);
				map.remove(taskName);
				if (task != null && task.getCode() != null) {
					String strCode = task.getCode();
					if (strCode != null && strCode.trim().length() > 0) {
						code.append("\n//=== Task ").append(taskName).append(" Start===");
						code.append(strCode);
						code.append("\n");
					}

					if (task.getComponentType() == ComponentTypes.TRANSFORMATION) {
						TransformationTask tfs = (TransformationTask) task;
						IfElseUdf udf = tfs.getIfElseUDF();
						UDFMethods.add(udf);
					}
				}
			}

			if (step != null && step.getSuccessors() != null) {
				for (String s : step.getSuccessors()) {
					stack.push(s);
				}
			}
		}

		return code.toString();
	}

	private static boolean isParentExist(Map<String, BaseDto> stepMap, BaseDto step) {
		Deque<BaseDto> stack = new ArrayDeque<>();

		stack.push(step);
		while (!stack.isEmpty()) {
			BaseDto stp = stack.pop();
			if (stp.getPredecessors() != null) {
				for (String predecessor : step.getPredecessors()) {
					if (stepMap.containsKey(predecessor)) {
						return true;
					}

					BaseDto p = stepMap.get(predecessor);
					if (p != null) {
						stack.push(p);
					}
				}
			}

		}

		return false;
	}

	public static String getSDPWorkFlowClass(ImportList importList, Map<String, BaseDto> stepMap, Map<String, AbstractTask> taskMap, List<IfElseUdf> UDFMethods) {
		StringBuffer code = new StringBuffer();
		code.append("package ").append(JobConstants.WF_PACKAGE).append("\n\n");
		try {
			importList.write(code);
		} catch (Exception e) {
		}

		code.append("\n\n");
		code.append(JobConstants.WF_CLASS).append("{\n");
		code.append(JobConstants.WF_EXEC_METHOD_SIG).append("   {\n");
		code.append(JobConstants.WF_INIT_CODE).append("\n");
		code.append(generateCode(stepMap, taskMap, UDFMethods));
		code.append("\n   }");
		code.append("\n}");

		return code.toString();
	}

	public static String getSubWorkflowCode(ImportList importList, Map<String, BaseDto> stepMap, Map<String, AbstractTask> taskMap, List<IfElseUdf> udfMethods, JSONObject start)
	{
		StringBuffer code = new StringBuffer();
		code.append("package ").append(JobConstants.PACKAGE_SUB_WF).append("\n\n");
		try {
			importList.write(code);
		} catch (Exception e) {
		}

		String className = start.getString("jobName");
		String returnType = stepMap.get("end").getReturnType();
		if (returnType == null || returnType.trim().length() <=0)
		{
			returnType = "Unit";
		}
		
		JSONArray arrPrm = start.getJSONArray("successors");
		
		code.append("\n\n");
		code.append("\nclass ").append(className).append("(hiveContext: HiveContext, inParam: Map[String, String]");
		code.append(getSubWfParams(arrPrm, stepMap)).append(") {");
		code.append("\n   def process(): ").append(returnType).append(" = {\n");
		code.append(generateCode(stepMap, taskMap, udfMethods));
		
		BaseDto endDto = stepMap.get("end");
		if(endDto.getReturnType()!=null && !"unit".equalsIgnoreCase(endDto.getReturnType()))
		{
			BaseDto retDto = stepMap.get(endDto.getPredecessors().get(0));
			code.append("\n").append(retDto.getVariableName());
		}

		code.append("\n   }\n}");

		return code.toString();
	}
	
	static String getSubWfParams(JSONArray arrPrm, Map<String, BaseDto> stepMap)
	{
		StringBuffer bff = new StringBuffer("");
		int s = arrPrm.length();
		for (int i=0; i<s; i++)
		{
			String pName = arrPrm.getString(i);
			BaseDto dto = stepMap.get(pName);
			String type = dto.getDataType();
			bff.append(",").append(pName).append(": ").append(type);
		}
		
		return bff.toString();
	}
	
}
