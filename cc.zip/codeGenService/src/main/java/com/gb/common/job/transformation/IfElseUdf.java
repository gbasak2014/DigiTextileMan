package com.gb.common.job.transformation;

import com.gb.common.job.util.JobConstants;
import com.google.gson.Gson;

public class IfElseUdf implements Transformation {
	String exp;
	String df;
	String column;
	String udfName;
	String udfClasss;
	String udfCode;
	String colType;

	public IfElseUdf(String exprCols, String dfName, String udfClass, String function, String colType) {

		this.column = exprCols.substring("If-Else-If{".length(), exprCols.indexOf("}"));
		this.exp = function;
		this.df = dfName;
		this.udfClasss = udfClass;
		this.colType = colType;

		this.udfName = df + "_" + this.column;
	}

	private String getColumn() {
		return this.udfClasss + "." + this.udfName + "(" + df + ".col(\"" + this.column + "\"))";
	}

	void makeUdf() {
		Gson gson = new Gson();
		IfElseFunctionDto fDto = gson.fromJson(this.exp, IfElseFunctionDto.class);
		StringBuffer sb = new StringBuffer();

		sb.append("\n  val ").append(this.udfName).append(" = udf((").append(this.column).append(": " + this.colType + ") => {\n");
		sb.append("    " + this.column).append(" match {\n");
		String defaultVal = null;
		for (IfElseUdfDto d : fDto.getFunction()) {
			if (getIfBlock(d).equals("DEFAULT")) {
				defaultVal = d.getTarget();
			} else {
				sb.append("      case _ if ").append(getIfBlock(d)).append(" => ").append("\"" + d.getTarget() + "\"\n");
			}
		}
		if (defaultVal != null) {
			sb.append("   case _ => \"").append(defaultVal).append("\"");
		}
		sb.append("     }\n");
		sb.append("  })");

		this.udfCode = sb.toString();
	}

	String getIfBlock(IfElseUdfDto dto) {

		if ("=".equals(dto.getOperation())) {
			return this.column + ".equals(\"" + dto.getSource() + "\")";
		}
		if ("IN".equals(dto.getOperation())) {
			return this.column + ".indexOf(\"" + dto.getSource() + "\") >= 0";
		}
		if ("StartWith".equals(dto.getOperation())) {
			return this.column + ".startsWith(\"" + dto.getSource() + "\")";
		}
		if ("EndWith".equals(dto.getOperation())) {
			return this.column + ".endsWith(\"" + dto.getSource() + "\")";
		}
		if (">".equals(dto.getOperation())) {
			return this.column + " > " + dto.getSource();
		}
		if (">=".equals(dto.getOperation())) {
			return this.column + " >= " + dto.getSource();
		}
		if ("<".equals(dto.getOperation())) {
			return this.column + " < " + dto.getSource();
		}
		if ("<=".equals(dto.getOperation())) {
			return this.column + " <= " + dto.getSource();
		}

		return "DEFAULT";
	}

	public String getUdfCode() {
		return this.udfCode;
	}

	@Override
	public String evaluate() {
		makeUdf();
		return this.getColumn();
	}

	public static void main(String[] args) {
		System.out.println("started.............");
		String expr = "If-Else-If{rate}#{\"function\":[{\"operation\":\"<\", \"source\":\"100\", \"target\":\"LOW\"},{\"operation\":\"<\", \"source\":\"500\", \"target\":\"MEDIUM\"},{\"operation\":\">=\", \"source\":\"500\", \"target\":\"HIGH\"}]}#Double";
		System.out.println(expr);

		String[] arr = expr.split("#");

		IfElseUdf udf = new IfElseUdf(arr[0], "DF", JobConstants.UDF_CLASS, arr[1], arr.length > 2 ? arr[2] : "String");

		String cc = udf.evaluate();
		System.out.println(cc);

		System.out.println(udf.getUdfCode());

	}
}
