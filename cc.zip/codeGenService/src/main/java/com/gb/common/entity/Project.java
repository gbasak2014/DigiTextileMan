package com.gb.common.entity;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "PROJECT_DETAIL")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Project {
	@Id
	@Column(name = "PROJECT_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long id;

	String name;
	String description;

	String clusterHost;
	String clusterPort;
	String clusterHome;
	String clusterUser;
	String clusterPassword;
	
	@ManyToMany(cascade = CascadeType.ALL, mappedBy = "projects")
	Set<UserDetails> users;

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "project")
	Set<ProjectConfig> configSet;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name = "PROJECT_ID", referencedColumnName = "PROJECT_ID")
	List<SourceMetaData> sourceMetaData;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Set<UserDetails> getUsers() {
		return users;
	}

	public void setUsers(Set<UserDetails> users) {
		this.users = users;
	}

	public Set<ProjectConfig> getConfigSet() {
		return configSet;
	}

	public void setConfigSet(Set<ProjectConfig> configSet) {
		this.configSet = configSet;
	}

	@Override
	public String toString() {
		return "{Id:" + this.id + ", Name:" + this.name + "}";
	}

/*	public Set<JobDetails> getJobSet() {
		return jobSet;
	}

	public void setJobSet(Set<JobDetails> jobSet) {
		this.jobSet = jobSet;
	}
*/
	public List<SourceMetaData> getSourceMetaData() {
		return sourceMetaData;
	}

	public void setSourceMetaData(List<SourceMetaData> sourceMetaData) {
		this.sourceMetaData = sourceMetaData;
	}

	public String getClusterHost() {
		return clusterHost;
	}

	public void setClusterHost(String clusterHost) {
		this.clusterHost = clusterHost;
	}

	public String getClusterPort() {
		return clusterPort;
	}

	public void setClusterPort(String clusterPort) {
		this.clusterPort = clusterPort;
	}

	public String getClusterHome() {
		return clusterHome;
	}

	public void setClusterHome(String clusterHome) {
		this.clusterHome = clusterHome;
	}

	public String getClusterUser() {
		return clusterUser;
	}

	public void setClusterUser(String clusterUser) {
		this.clusterUser = clusterUser;
	}

	public String getClusterPassword() {
		return clusterPassword;
	}

	public void setClusterPassword(String clusterPassword) {
		this.clusterPassword = clusterPassword;
	}
}
