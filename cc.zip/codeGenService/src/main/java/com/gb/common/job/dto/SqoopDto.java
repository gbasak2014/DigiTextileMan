package com.gb.common.job.dto;

import java.util.List;

public class SqoopDto extends BaseDto {
	long metaId;
	String schema;
	String table;
	String url;
	String user;
	String pwd;
	String importType;
	String checkColumn;
	String targetDir;
	String outDir;
	String incremental;
	String lastValue;
	String delimiter;
	String dateTmBehav;

	public long getMetaId() {
		return metaId;
	}

	public void setMetaId(long metaId) {
		this.metaId = metaId;
	}

	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}

	public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getImportType() {
		return importType;
	}

	public void setImportType(String importType) {
		this.importType = importType;
	}

	public String getCheckColumn() {
		return checkColumn;
	}

	public void setCheckColumn(String checkColumn) {
		this.checkColumn = checkColumn;
	}

	public String getTargetDir() {
		return targetDir;
	}

	public void setTargetDir(String targetDir) {
		this.targetDir = targetDir;
	}

	public String getOutDir() {
		return outDir;
	}

	public void setOutDir(String outDir) {
		this.outDir = outDir;
	}

	public String getIncremental() {
		return incremental;
	}

	public void setIncremental(String incremental) {
		this.incremental = incremental;
	}

	public String getLastValue() {
		return lastValue;
	}

	public void setLastValue(String lastValue) {
		this.lastValue = lastValue;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public String getDateTmBehav() {
		return dateTmBehav;
	}

	public void setDateTmBehav(String dateTmBehav) {
		this.dateTmBehav = dateTmBehav;
	}

	String getColumns(List<ColumnDto> fields) {
		StringBuffer bf = new StringBuffer();
		for (ColumnDto cd : fields) {
			if (bf.length() > 0) {
				bf.append(",");
			}
			bf.append(cd.getName());
		}

		return bf.toString();
	}

	String getJdbcDriver(String url) {
		if (url.indexOf("mysql") > 0)
			return "com.mysql.jdbc.Driver";

		if (url.indexOf("oracle") > 0)
			return "oracle.jdbc.driver.OracleDriver";

		if (url.indexOf("db2") > 0)
			return "COM.ibm.db2.jdbc.net.DB2Driver";

		if (url.indexOf("sqlserver") > 0)
			return "com.microsoft.sqlserver.jdbc.SQLServerDriver";

		return "com.mysql.jdbc.Driver";
	}

	public String getCreateJobScript()
	{
		StringBuffer bff = new StringBuffer();
		bff.append("sqoop job --create ").append(this.getName());
		bff.append(" -- import --connect ").append(this.getUrl());
		bff.append("?zeroDateTimeBehavior=").append(this.getDateTmBehav());
		bff.append(" --username ").append(this.getUser());
		bff.append(" --password '").append(this.getPwd()).append("'");
		bff.append(" --driver ").append(getJdbcDriver(this.getUrl()));
		bff.append(" --table ").append(this.getTable());
		if (this.getFields() != null && this.getFields().size() > 0) {
			bff.append(" --columns ").append(getColumns(this.getFields()));
		}
		if (this.getOutDir() != null && this.getOutDir().trim().length() > 0) {
			bff.append(" --outdir ").append(this.getOutDir());
		}
		bff.append(" --target-dir ").append(this.getTargetDir());
		bff.append(" --fields-terminated-by").append(this.getDelimiter());
		if ("INCREMENTAL".equalsIgnoreCase(this.getImportType())) {
			bff.append(" --check-column ").append(this.getCheckColumn());
			bff.append(" --incremental ").append(this.getIncremental());
			bff.append(" --last-value ").append(this.getLastValue());
		}

		return bff.toString();
	}

}
