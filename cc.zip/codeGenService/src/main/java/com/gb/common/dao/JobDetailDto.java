package com.gb.common.dao;

public class JobDetailDto {

}
