package com.gb.common.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "META_SOURCE", uniqueConstraints=@UniqueConstraint(columnNames={"metaName","PROJECT_ID"}))
public class SourceMetaData {
	@Id
	@Column(name = "SOURCE_ID")
	@GeneratedValue(strategy=GenerationType.AUTO)
	Long id;

	String metaName;
	String source;
	String description;
	String user;
	String password;
	String delimiter;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "SRC_TYPE_NAME")
	SourceType sourceType;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "REC_TYPE_NAME")
	RecordType recordType;

	@OneToMany(cascade=CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name="SOURCE_ID", referencedColumnName="SOURCE_ID")
	Set<ColumnDetail> columns;

	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="PROJECT_ID")
	Project project;
	
	public String getMetaName() {
		return metaName;
	}

	public void setMetaName(String metaName) {
		this.metaName = metaName;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public SourceType getSourceType() {
		return sourceType;
	}

	public void setSourceType(SourceType sourceType) {
		this.sourceType = sourceType;
	}

	public Set<ColumnDetail> getColumns() {
		return columns;
	}

	public void setColumns(Set<ColumnDetail> columns) {
		this.columns = columns;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public RecordType getRecordType() {
		return recordType;
	}

	public void setRecordType(RecordType recordType) {
		this.recordType = recordType;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}
	
	@Override
	public String toString() {
		return "{metaName:" + metaName + ", columns:" + this.columns + ", sourceType:" + this.getSourceType() + ", recordType" + this.getRecordType() + "}";
	}
}
