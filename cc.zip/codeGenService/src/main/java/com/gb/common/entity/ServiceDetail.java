package com.gb.common.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "SERVICE_DETAIL")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class ServiceDetail {
	@Id
	@Column(name = "SERVICE_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long id;

	@Column(name = "NAME", length = 100)
	String name;

	@Column(name = "DESCRIPTION", length = 256)
	String description;

	@Column(name = "IMPORTS", length = 2048)
	String imports;
	
	@Column(name = "CODE", length = 1048576)
	@JsonIgnoreProperties
	String code;

	@Column(name = "TYPE", length = 50)
	String type;

	@Column(name = "RET_CATEGORY", length = 50)
	String returnCategory;

	@Column(name = "PROJECT_ID")
	Long projectId;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "serviceDetail", orphanRemoval = true)
	Set<ServiceRetType> retTypes;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "serviceDetail", orphanRemoval = true)
	Set<ServiceParams> params;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getReturnCategory() {
		return returnCategory;
	}

	public void setReturnCategory(String returnCategory) {
		this.returnCategory = returnCategory;
	}

	public Set<ServiceRetType> getRetTypes() {
		return retTypes;
	}

	public void setRetTypes(Set<ServiceRetType> retTypes) {
		this.retTypes = retTypes;
	}

	public Set<ServiceParams> getParams() {
		return params;
	}

	public void setParams(Set<ServiceParams> params) {
		this.params = params;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Long getProjectId() {
		return projectId;
	}

	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getImports() {
		return imports;
	}

	public void setImports(String imports) {
		this.imports = imports;
	}

}
