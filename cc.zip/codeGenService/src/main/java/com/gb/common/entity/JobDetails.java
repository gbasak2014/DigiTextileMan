package com.gb.common.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Version;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "JOB_DETAIL")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class JobDetails {

	@Id
	@Column(name = "JOB_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	Long jobId;

	@Column(name = "NAME", length = 100)
	String name;

	@Column(name = "DESCRIPTION", length = 250)
	String description;

	@Column(name = "CODE", length = 1024)
	String code;

	@Column(name = "PROJECT_ID")
	Long projectId;

	@Column(name = "TYPE", length = 50)
	String type;
	
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "jobDetails", orphanRemoval = true)
	Set<JobStep> steps;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, mappedBy = "jobDetails", orphanRemoval = true)
	Set<JobParam> params;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "jobDetails", orphanRemoval = true)
	Set<SubWorkflow> subWorkflowSet;

	@Version
	@Column(name = "VERSION")
	long version;

	public Long getJobId() {
		return jobId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public Set<JobStep> getSteps() {
		return steps;
	}

	public void setSteps(Set<JobStep> steps) {
		this.steps = steps;
	}

	public Set<JobParam> getParams() {
		return params;
	}

	public void setParams(Set<JobParam> params) {
		this.params = params;
	}

	public long getVersion() {
		return version;
	}

	public void setVersion(long version) {
		this.version = version;
	}

	public Long getProjectId() {
		return projectId;
	}

	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}

	public Set<SubWorkflow> getSubWorkflowSet() {
		return subWorkflowSet;
	}

	public void setSubWorkflowSet(Set<SubWorkflow> subWorkflowSet) {
		this.subWorkflowSet = subWorkflowSet;
	}

	@Override
	public String toString() {
		return "{Id:" + this.jobId + ", name:" + this.name + ", Version:" + this.version + ", Desc:" + this.description + ", ProjectId:" + this.projectId + ", Steps:" + this.steps
				+ ", params:" + this.params + "}";
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null || !(obj instanceof JobDetails))
			return false;

		JobDetails jd = (JobDetails) obj;

		return this.jobId != null && this.name != null && this.jobId.equals(jd.jobId) && this.name.equals(jd.name);
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
}
