package com.gb.common.job.dto;

public class ColumnDto {
	long id;
	String name;
	Boolean sensitiveFlag;
	Integer pos;
	String dataType;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getPos() {
		return pos;
	}

	public void setPos(Integer pos) {
		this.pos = pos;
	}

	public Boolean getSensitiveFlag() {
		return sensitiveFlag;
	}

	public void setSensitiveFlag(Boolean sensitiveFlag) {
		this.sensitiveFlag = sensitiveFlag;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "{Id:" + this.id + 
				", Name:" + this.name + 
				", SensitiveFlag:" + this.sensitiveFlag + 
				", DataType:" + this.dataType + 
				",Pos:" + this.pos + "}";
	}
}
