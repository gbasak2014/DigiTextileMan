package com.gb.common.job.transformation;

public class IfElseUdfDto {
	String operation;
	String source;
	String target;

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getTarget() {
		return target;
	}

	public void setTarget(String target) {
		this.target = target;
	}

	@Override
	public String toString() {
		return this.operation + this.source + ">" + this.target;
	}
}
