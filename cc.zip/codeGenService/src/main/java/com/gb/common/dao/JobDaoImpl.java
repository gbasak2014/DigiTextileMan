package com.gb.common.dao;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Component;

import com.gb.common.entity.Dept;
import com.gb.common.entity.JobDetails;
import com.gb.common.entity.JobParam;
import com.gb.common.entity.JobStep;
import com.gb.common.entity.Project;
import com.gb.common.entity.SubWorkflow;

@Component(value = "jobDao")
public class JobDaoImpl extends AbstractDao implements JobDao {

	static final Logger logger = Logger.getLogger(JobDaoImpl.class);

	@Override
	public Dept getDept(long id) {
		Dept d = (Dept) this.getById(Dept.class, id);
		return d;
	}

	@Override
	public void saveDept(Dept d) {
		this.update(d);
	}

	@Override
	public Project getProjectById(Long projectId) {
		return (Project) this.getById(Project.class, projectId);
	}

	@Override
	public long saveJob(JobDetails job) {
		logger.debug("Entered saveJob");
		Long id = (Long) this.save(job);
		logger.debug("Exiting saveJob");
		return id;
	}

	@Override
	public long saveSubWorkflow(SubWorkflow sw) {
		logger.debug("Entered saveSubWorkflow");
		Long id = (Long) this.save(sw);
		logger.debug("Exiting saveSubWorkflow");
		return id;
	}

	@Override
	public void updateJob(JobDetails job) {
		logger.debug("***Entered updateJob***");
		this.update(job);
		logger.debug("***Exiting updateJob***");
	}

	@Override
	public JobDetails getJob(Long jobId) {
		logger.debug("Entered getJob");
		JobDetails jd = (JobDetails) this.getById(JobDetails.class, jobId);
		logger.debug("Exiting getJob");
		return jd;
	}

	@Override
	public JobDetails getSubWorkflow(Long subWfId) {
		logger.debug("Entered getSubWorkflow");
		JobDetails jd = (JobDetails) this.getById(JobDetails.class, subWfId);
		logger.debug("Exiting getSubWorkflow");
		return jd;
	}

	public JobDetails getJobByName(long projectId, String jobName) {
		logger.debug("Entered getJobByName");
		Criteria cr = this.getSession().createCriteria(JobDetails.class);

		cr.add(Restrictions.and(Restrictions.and(Restrictions.eq("projectId", projectId), Restrictions.eq("name", jobName))));
		List<JobDetails> list = cr.list();
		JobDetails jd = null;
		if (list.size() > 0) {
			jd = list.get(0);
		}

		logger.debug("Exiting getJobByName");
		return jd;
	}

	@Override
	public void deleteSteps(List<JobStep> steps) {
		logger.debug("Deleting steps>>" + steps);
		for (JobStep stp : steps) {
			getSession().delete(stp);
		}
	}

	@Override
	public void deleteParams(List<JobParam> params) {
		logger.debug("Deleting params>>" + params);
		for (JobParam jp : params) {
			getSession().delete(jp);
		}
	}
}
