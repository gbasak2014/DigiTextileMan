package com.gb.common.exception;

public class SdfException extends Exception{
	private static final long serialVersionUID = -4801036067921507307L;
	
	public SdfException(String message)
	{
		super(message);
	}
	
}
