package com.gb.common.util;

public class StringUtils {
	static final char SPACE = ' ';
	static final char TAB = '\t';
	static final char COMMA = ',';
	static final char FULL_STOP = '.';
	static final char START_PARENTHESIS = '(';
	static final char END_PARENTHESIS = ')';
	
	public static boolean isSeparator1(char ch)
	{
		return ch == SPACE || ch == TAB || ch == COMMA || ch == FULL_STOP || ch == START_PARENTHESIS || ch == END_PARENTHESIS;
	}
	
	public static boolean isExprSeparator(char ch)
	{
		return ch == SPACE || ch == TAB || ch == START_PARENTHESIS || ch == END_PARENTHESIS;
	}
}
