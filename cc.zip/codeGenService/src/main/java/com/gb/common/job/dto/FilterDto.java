package com.gb.common.job.dto;

public class FilterDto extends BaseDto {
	String conditions;

	@Override
	public String toString() {
		return super.toString() + ", conditions: " + this.conditions;
	}

	public String getConditions() {
		return conditions;
	}

	public void setConditions(String conditions) {
		this.conditions = conditions;
	}
}
