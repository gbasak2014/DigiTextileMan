package com.gb.common.job.util;

public interface JobConstants {
	String TRUE = "true";
	String FALSE = "false";
	String TASK = "<TASK>";

	String PARAM_JOB_NAME = "job.name";

	String PARAM_JOB_HOME = "job.path.home";
	String PARAM_JOB_TMP_HOME = "job.path.tmp.base";
	String PARAM_JOB_DATA_HOME = "job.path.data.base";
	String PARAM_JOB_LOG_PATH_LOCAL = "job.log.path.local";
	String PARAM_LOG_LOCAL_PATH = "job.path.log.local";
	String PARAM_LIST_TASK_FILE_CPPY = "list.task.fileCopy";

	String PARAM_TASK_SOURCE = "<TASK>.source.path";
	String PARAM_TASK_TARGET = "<TASK>.target.path";
	String PARAM_TASK_DEL_SUCCESS = "<TASK>.source.delete.onsuccess";
	String PARAM_TASK_REN_SUCCESS = "<TASK>.source.rename.onsuccess";
	String PARAM_TASK_REN_SUFFIX = "<TASK>.source.rename.suffix";

	String PARAM_TASK_IS_DELETE = "<TASK>.is.delete";
	String PARAM_TASK_IS_RENAME = "<TASK>.is.rename";
	String PARAM_TASK_DELIMITER = "<TASK>.delimiter";
	String PARAM_TASK_MOVE_PATH = "<TASK>.move.path";
	String PARAM_TASK_FORMAT = "<TASK>.format";
	String PARAM_TASK_XML_ROW_TAG = "<TASK>.xml.row.tag";
	String PARAM_TASK_FIELDS = "<TASK>.fields";
	String PARAM_TASK_SQL = "<TASK>.sql";

	String ENV_REQ_ID = "REQ_ID";
	String ENV_YYYYMMDD = "YYYYMMDD";
	String ENV_YYYY = "YYYY";
	String ENV_MM = "MM";
	String ENV_DD = "DD";
	String ENV_HH = "HH";

	String FILE_COPY_LOG = "copy-from-local.log";

	String PARAM_LOCAL_FLAG = "local.flag";
	String PARAM_SPARK_FLAG = "spark.flag";
	String PARAM_HIVE_FLAG = "hive.flag";
	String PARAM_STREAM_FLAG = "stream.flag";
	String PARAM_STREAM_DURATION = "stream.context.duration";

	String WF_PACKAGE = "com.gb.sdp.spark.job";
	String WF_CLASS_FILE = "SDPWorkflow.scala";
	String WF_CLASS = "class SDPWorkflow(hiveContext: HiveContext, streamContext: StreamingContext, inParams:Map[String, String])";
	String WF_EXEC_METHOD_SIG = "def executeWorkflow(): Unit = ";
	String WF_INIT_CODE = "val dataFrameFactory = new DataFrameFactory(hiveContext)\nval dfService = new DataFrameService(hiveContext)";
	String WF_SCRIPT_FILE = "startJob.sh";
	String WF_PROP_FILE = "job-config.properties";

	String VAR_HIVE_CONTEXT = "hiveContext";
	String VAR_SQL_CONTEXT = "sqlContext";

	String CONF_JOB_TMPL_HOME = "job.template.home";
	String CONF_JOB_TMPL_NAME = "job.template.name";
	String CONF_JOB_HOME = "job.create.home";
	String CONF_JOB_TMP_PATH = "job.tmp.home";

	String CONF_JOB_NAME = "job.create.name";
	String CONF_JOB_PROP_FILE = "job.create.prop.file";
	String CONF_JOB_SHELL_NAME = "job.create.exce.shell";
	String CONF_JOB_FILE_CP_SCRIPT = "job.fileCp.exec.script";
	String CONF_JOB_SPARK_SUBMIT_SCRIPT = "job.spark.submit.script";

	String UDF_CLASS = "com.gb.sdp.spark.common.util.SdpUdf";
	String UDF_PATH = "src/main/scala/com/gb/sdp/spark/common/util/SdpUdf.scala";
	String UDF_PACKAGE = "com.gb.sdp.spark.common.util";
	String UDF_IMPORTS = "import org.apache.spark.sql.functions._";
	String UDF_CLASS_CODE = "object SdpUdf {\n" + "<CODE>" + "\n}";

	String CUSTOM_PATH = "src/main/scala/com/gb/sdp/spark/common/util";
	String CUSTOM_PACKAGE = "com.gb.sdp.spark.common.util";

	String PACKAGE_COMMON_SERVICE = "com.gb.sdp.spark.common";
	String PATH_COMMON_SERVICE = "src/main/scala/com/gb/sdp/spark/common";

	String TYPE_JOB = "JOB";
	String TYPE_SUB_WF = "SUB_WORKFLOW";
	
	String PACKAGE_SUB_WF = "com.gb.sdp.spark.common.process";
	String PATH_SUB_WF = "src/main/scala/com/gb/sdp/spark/common/process";
	
}