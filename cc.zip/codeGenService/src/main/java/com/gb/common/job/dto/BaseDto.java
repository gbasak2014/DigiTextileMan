package com.gb.common.job.dto;

import java.util.List;

public class BaseDto {
	String name;
	int componentType;
	List<String> predecessors;
	List<ColumnDto> fields;
	List<String> successors;
	int left;
	int top;
	String returnType;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getComponentType() {
		return componentType;
	}

	public void setComponentType(int componentType) {
		this.componentType = componentType;
	}

	public List<String> getPredecessors() {
		return predecessors;
	}

	public void setPredecessors(List<String> predecessors) {
		this.predecessors = predecessors;
	}

	public List<ColumnDto> getFields() {
		return fields;
	}

	public void setFields(List<ColumnDto> fields) {
		this.fields = fields;
	}

	public List<String> getSuccessors() {
		return successors;
	}

	public void setSuccessors(List<String> successors) {
		this.successors = successors;
	}

	@Deprecated
	public String getSchemaStructBak() {
		StringBuffer buff = new StringBuffer();
		buff.append("StructType(Seq(");

		int cnt = 0;
		for (ColumnDto field : this.fields) {
			if (cnt > 0) {
				buff.append(", ");
			}
			buff.append("StructField(").append(field).append(", StringType, true)");
			cnt++;
		}

		buff.append("");
		buff.append("))");

		return buff.toString();
	}

	public String getRddName() {
		return this.name + "Rdd";
	}

	public String getRddName(String nm) {
		return nm + "Rdd";
	}

	public String getDataFrameName() {
		return this.name + "Df";
	}

	@Deprecated
	public String getDataFrameName111(String nm) {
		return nm + "Df";
	}

	public String getVariableName() {
		return this.name + "Df";
	}
	
	public String getDataType()
	{
		return "DataFrame";
	}
	
	@Override
	public String toString() {
		return "name:" + this.name;
	}

	public int getLeft() {
		return left;
	}

	public void setLeft(int left) {
		this.left = left;
	}

	public int getTop() {
		return top;
	}

	public void setTop(int top) {
		this.top = top;
	}

	public String getReturnType() {
		return returnType;
	}

	public void setReturnType(String returnType) {
		this.returnType = returnType;
	}
}
