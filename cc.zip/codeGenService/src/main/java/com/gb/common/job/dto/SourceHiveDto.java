package com.gb.common.job.dto;

public class SourceHiveDto extends BaseDto {
	String schema;
	String table;
	String condition;
	
	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}

	public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	@Override
	public String toString() {
		return super.toString() + ", schema:" + this.schema + ", table:" + this.table;
	}

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}
}
