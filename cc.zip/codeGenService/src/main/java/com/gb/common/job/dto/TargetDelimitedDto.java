package com.gb.common.job.dto;

public class TargetDelimitedDto extends BaseDto {
	String path;
	String separator;

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getSeparator() {
		return separator;
	}

	public void setSeparator(String separator) {
		this.separator = separator;
	}

	@Override
	public String toString() {
		return super.toString() + ", path:" + this.getPath();
	}
}
