package com.gb.common.controller;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gb.common.SdpActions;
import com.gb.common.job.util.ExecutionService;
import com.gb.common.job.util.SqoopExecutor;
import com.gb.common.service.JobService;
import com.gb.common.util.MessageUtils;
import com.gb.spark.wf.dependency.mvn.DependencyList;

@Controller
@RequestMapping("/job")
public class JobController {
	static final Logger logger = Logger.getLogger(JobController.class);

	@Resource(name = "jobService")
	JobService jobService;

	@RequestMapping(value = "/save", method = RequestMethod.POST, produces = MediaType.ALL_VALUE)
	public @ResponseBody String saveJob(@RequestBody String data) {
		logger.debug("Entered saveJob");
		logger.debug("Request:" + data);
		try {
			long id = this.jobService.saveJob(data);
			if (id > 0) {
				String resp = this.jobService.getJob(String.valueOf(id));
				return resp;
			}

			logger.debug("Exiting saveJob");
			return MessageUtils.getResponseMessage("ERROR", "ERROR - Job Exist with name in the project!!");
		} catch (Exception e) {
			logger.error("ERROR saving workflow");
			e.printStackTrace();
		}
		return MessageUtils.getResponseMessage("ERROR", "ERROR - Job could not save!!");
	}

	@RequestMapping(value = "/savesub", method = RequestMethod.POST, produces = MediaType.ALL_VALUE)
	public @ResponseBody String saveSubJob(@RequestBody String data) {
		logger.debug("Entered saveSubJob");
		logger.debug("Request:" + data);

		return MessageUtils.getResponseMessage("SUCCESS", "FROM SERVER....");
	}
	
	
	@RequestMapping(value = "/compile", method = RequestMethod.POST, produces = MediaType.ALL_VALUE)
	public @ResponseBody String saveGenJob(@RequestBody String data) {
		logger.debug("Entered insertUserDetails");
		// long id = this.jobService.saveJob(data);
		// logger.debug("Saved with Id:" + id);
		logger.debug("Request:" + data);
		DependencyList dl = new DependencyList();
		this.jobService.generateJob(data, dl);
		logger.debug("Exiting insertUserDetails");
		return "SUCCESS";
	}

	@RequestMapping(value = "/execute", method = RequestMethod.POST, produces = MediaType.ALL_VALUE)
	public @ResponseBody String executeJob(@RequestBody String data) {
		logger.debug("Entered insertUserDetails");
		logger.debug("Request:" + data);

		JSONObject obj = new JSONObject(data);
		JSONObject cluster = obj.getJSONObject("cluster");
		int action = cluster.getInt("action");

		switch (action) {
		case SdpActions.EXECUTE_JOB:
			DependencyList dl = new DependencyList();
			this.jobService.generateJob(data, dl);
			ExecutionService es = new ExecutionService(data, dl);
			es.start();
			break;
		case SdpActions.CREATE_SQOOP_JOB:
			try {
				SqoopExecutor se = new SqoopExecutor(data);
				se.createSqoopJob();
				return MessageUtils.getResponseMessage("SUCCESS", "Sqoop job creation success..");
			} catch (Exception e) {
				return MessageUtils.getResponseMessage("FAIL", "Sqoop job creation fail!!!");
			}
		}

		///////

		/////////
		logger.debug("Exiting insertUserDetails");
		return MessageUtils.getResponseMessage("SUCCESS", "Workflow code generated, compilation to jar and execution of WF in cluster under progress...");
	}

	@RequestMapping(value = "/open/{jobId}", method = RequestMethod.GET, produces = MediaType.ALL_VALUE)
	public @ResponseBody String openJob(@PathVariable String jobId) {
		logger.debug("Entered openJob: " + jobId);
		String jobJson = this.jobService.getJob(jobId);
		logger.debug("Fron controller Job:" + jobJson);

		logger.debug("Exiting openJob");
		return jobJson;
	}

	@RequestMapping(value = "/opensub/{subWfId}", method = RequestMethod.GET, produces = MediaType.ALL_VALUE)
	public @ResponseBody String opensubWorkflow(@PathVariable Long subWfId) {
		logger.debug("Entered opensubWorkflow: " + subWfId);
		String jobJson = this.jobService.getSubWorkflow(subWfId);
		
		logger.debug("Fron controller SubWorkflow: " + jobJson);

		logger.debug("Exiting opensubWorkflow");
		return jobJson;
	}
	
	@RequestMapping(value = "/opensubhead/{subWfId}", method = RequestMethod.GET, produces = MediaType.ALL_VALUE)
	public @ResponseBody String opensubWorkflowHeader(@PathVariable Long subWfId) {
		logger.debug("Entered opensubWorkflowHeader: " + subWfId);
		String jobJson = this.jobService.getSubWorkflowHeader(subWfId);
		
		logger.debug("Fron controller opensubWorkflowHeader: " + jobJson);

		logger.debug("Exiting opensubWorkflowHeader");
		return jobJson;
	}	
	
	
	@RequestMapping(value = "/open/{projectId}/{jobName}", method = RequestMethod.GET, produces = MediaType.ALL_VALUE)
	public @ResponseBody String openJob(@PathVariable long projectId, @PathVariable String jobName) {
		logger.debug("Entered openJob() - jobName: " + jobName);
		String jobJson = this.jobService.getJob(projectId, jobName);
		logger.debug("==============jobJson start=================");
		logger.debug(jobJson);
		logger.debug("==============jobJson end=================");

		logger.debug("Exiting openJob");
		return jobJson;
	}

	@RequestMapping(value = "/list/{projectId}", method = RequestMethod.GET, produces = MediaType.ALL_VALUE)
	public @ResponseBody String listJob(@PathVariable String projectId) {
		logger.debug("Entered insertUserDetails");
		logger.debug("Request:" + projectId);
		logger.debug("Exiting insertUserDetails");
		return "";
	}

	@RequestMapping(value = "/list/{jobId}", method = RequestMethod.GET, produces = MediaType.ALL_VALUE)
	public @ResponseBody String download(@PathVariable String jobId) {
		logger.debug("Entered insertUserDetails");
		logger.debug("Request:" + jobId);
		logger.debug("Exiting insertUserDetails");
		return "";
	}
}
