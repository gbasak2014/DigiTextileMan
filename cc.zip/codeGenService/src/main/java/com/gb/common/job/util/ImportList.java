package com.gb.common.job.util;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashSet;
import java.util.Set;

public class ImportList {
	Set<String> imports = new HashSet<String>();

	public void addImport(String pkg) {
		if (!this.imports.contains(pkg)) {
			this.imports.add(pkg);
		}
	}

	public void write(OutputStream out) throws IOException {
		for (String pkg : this.imports) {
			String imprt = "import " + pkg + ";\n";
			out.write(imprt.getBytes());
		}
	}

	public void write(StringBuffer out) throws IOException {
		for (String pkg : this.imports) {
			String imprt = "\nimport " + pkg + ";";
			out.append(imprt);
		}
	}

}
