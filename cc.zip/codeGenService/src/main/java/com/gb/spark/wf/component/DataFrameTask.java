package com.gb.spark.wf.component;

import java.util.Map;

import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.DataFrameDto;
import com.gb.common.job.util.ComponentTypes;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class DataFrameTask extends AbstractTask {
	public DataFrameTask(DataFrameDto dto, Map<String, BaseDto> actions, ImportList imports, DependencyList dependencyList, ConfigList configList) {
		super(dto, actions, imports, dependencyList, configList);
	}

	@Override
	public String getCode() {
		StringBuffer code = new StringBuffer();
		DataFrameDto dfd = (DataFrameDto) this.dto;

		String parentName = dfd.getPredecessors().get(0);
		BaseDto pDto = this.actions.get(parentName);
		if (pDto.getComponentType() != ComponentTypes.START) {
			code.append("\nval ").append(dfd.getVariableName()).append(" = ").append(pDto.getVariableName());
		}

		return code.toString();
	}

	@Override
	public String getCleanupCode() {
		return null;
	}

	@Override
	public String returnType() {
		return "DataFrame";
	}
}
