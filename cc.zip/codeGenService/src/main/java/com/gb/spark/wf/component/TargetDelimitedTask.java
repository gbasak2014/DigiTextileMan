package com.gb.spark.wf.component;

import java.util.Map;

import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.TargetDelimitedDto;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.common.job.util.JobConstants;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class TargetDelimitedTask extends AbstractTask {

	public TargetDelimitedTask(TargetDelimitedDto dto, Map<String, BaseDto> actions, ImportList imports, DependencyList dependencyList, ConfigList configList) {
		super(dto, actions, imports, dependencyList, configList);
	}

	@Override
	public String getCode() {
		StringBuffer code = new StringBuffer();
		TargetDelimitedDto tjd = (TargetDelimitedDto) this.dto;
		
		configList.setConfig(JobConstants.PARAM_TASK_TARGET, tjd.getPath(), tjd.getName());
		configList.setConfig(JobConstants.PARAM_TASK_DELIMITER, tjd.getSeparator(), tjd.getName());
		
		//String dfName = tjd.getDataFrameName(tjd.getPredecessors().get(0));
		String dfName = this.actions.get(tjd.getPredecessors().get(0)).getVariableName();
		
		code.append("\n");
		code.append(InstanceList.dfServiceInstance).append(".saveAsTextFile(")
		.append(dfName).append(", \"")
		.append(tjd.getName()).append("\");\n");

		return code.toString();
	}

	@Override
	public String getCleanupCode() {
		return "";
	}
	
	@Override
	public String returnType() {
		return null;
	}
}
