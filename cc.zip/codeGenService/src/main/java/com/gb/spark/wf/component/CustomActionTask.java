package com.gb.spark.wf.component;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.gb.common.SDPConstnts;
import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.ColumnDto;
import com.gb.common.job.dto.CustomActionDto;
import com.gb.common.job.dto.KV;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class CustomActionTask extends AbstractTask {
	Map<String, String> inParams;

	public CustomActionTask(CustomActionDto dto, Map<String, BaseDto> actions, ImportList imports, DependencyList dependencyList, ConfigList configList,
			Map<String, String> inParams) {
		super(dto, actions, imports, dependencyList, configList);
		this.inParams = inParams;
		this.imports.addImport("org.apache.spark.sql.functions._");
		this.imports.addImport("com.gb.sdp.spark.common.util._");
	}

	@Override
	public String getCode() {
		StringBuffer code = new StringBuffer();
		CustomActionDto ca = (CustomActionDto) this.dto;
		StringBuffer sbObjCd = new StringBuffer();
		
		//this.dependencyList.addDependency(ca.getName(), new MavenDependency(this.getClassCode(ca,sbObjCd), MavenDependency.CLASS));
		writeClassCode(ca,sbObjCd);
		code.append("\n//Custom action for " + dto.getName() + " start");
		code.append("\n   val ").append(ca.getName().toLowerCase()).append(" = ").append(sbObjCd.toString());
		if (ca.getFields().size() > 0)
		{
			code.append("\nval ").append(ca.getDataFrameName()).append(" = ");
		}
		else
		{
			code.append("\n");
		}
		code.append(ca.getName().toLowerCase()).append(".process()");
		code.append("\n//Custom action for " + dto.getName() + " start\n");
		
		return code.toString();
	}

	@Override
	public String getCleanupCode() {
		return null;
	}

	@Override
	public String returnType() {
		return "DataFrame";
	}

	void writeClassCode(CustomActionDto dto, StringBuffer sbObjCd) {
		StringBuffer bff = new StringBuffer();
		bff.append("class ").append(dto.getActionName()).append("(sqlContext:HiveContext, inParams: Map[String, String]");
		sbObjCd.append("new ").append(dto.getActionName()).append("(hiveContext, inParams");
		
		for (KV kv : dto.getParams()) {
			bff.append(", ");
			bff.append(kv.getValue()).append(": DataFrame");
			sbObjCd.append(", ");
			sbObjCd.append(this.actions.get(kv.getType()).getVariableName());
			//sbObjCd.append(dto.getDataFrameName(kv.getType()));
		}
		sbObjCd.append(")");
		bff.append("){\n   def process()").append(dto.getFields().size() > 0 ? ": DataFrame" : ": Unit");
		bff.append(" = {\n    ");
		bff.append(dto.getCode().replace("\n", "\n    "));
		bff.append("\n   }\n}");

		
		try{
			String tmpPath = this.configList.getConfig(SDPConstnts.CODE_TMP_PATH);
			File file = new File(tmpPath);
			if (!file.exists()) {
				file.mkdirs();
			}
			if (file.exists() && !file.isDirectory()) {
				file.delete();
			}

			file = new File(file.getAbsolutePath() + "/" + dto.getActionName());
			if (file.exists()) {
				file.delete();
			}
			
			OutputStream out = new FileOutputStream(file);
			out.write(bff.toString().getBytes());
			out.flush();
			out.close();
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}

		/*
		 * def saveAsParquetFile(df: DataFrame, path: String): Unit = { val
		 * newPath = JobUtils.replacePathParameters(path)
		 * df.write.parquet(newPath); }
		 */
	}

	public static void main(String[] args) {
		System.out.println("Start...");
		CustomActionDto fd = new CustomActionDto();
		fd.setActionName("CalcCumm");
		fd.setCode("println(\"Hello world\");\nprintln(\"Hi............\");");
		List<KV> list = new ArrayList<KV>();
		list.add(new KV("srcUser", "usrDf"));
		list.add(new KV("srcTrans", "trnsDf"));
		fd.setParams(list);
		fd.setFields(new ArrayList<ColumnDto>());

		fd.setPredecessors(Arrays.asList("P01", "P02"));
		CustomActionTask fs = new CustomActionTask(fd, new HashMap<String, BaseDto>(), new ImportList(), new DependencyList(), new ConfigList(), new HashMap<String, String>());
		
		StringBuffer sb = new StringBuffer();
		//System.out.println(fs.getClassCode(fd, sb));
		//System.out.println("\n\n" + sb.toString());
		System.out.println("\n\n" + fs.getCode());
		System.out.println("Done....");
	}
	
	public CustomActionDto getDto()
	{
		return (CustomActionDto)this.dto;
	}
}
