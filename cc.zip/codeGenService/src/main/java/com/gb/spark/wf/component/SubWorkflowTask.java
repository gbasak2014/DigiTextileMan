package com.gb.spark.wf.component;

import java.util.Map;
import java.util.TreeMap;

import com.gb.common.job.dto.ArgParamEntry;
import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.SubWorkflowDto;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class SubWorkflowTask extends AbstractTask {
	public SubWorkflowTask(SubWorkflowDto dto, Map<String, BaseDto> actions, ImportList imports, DependencyList dependencyList, ConfigList configList, Map<String, String> inParams) {
		super(dto, actions, imports, dependencyList, configList);
		this.dependencyList.addSubWorkflow(dto.getSubWfId());
		
		this.imports.addImport("java.util._");
		this.imports.addImport("com.gb.sdp.spark.common.process._");
	}

	@Override
	public String getCode() {
		StringBuffer code = new StringBuffer();
		SubWorkflowDto swd = (SubWorkflowDto) this.dto;
		
		code.append("\n val ").append("_" + swd.getSubWfName()).append(" = new ").append(swd.getSubWfName()).append("(hiveContext, inParams");
		code.append(this.getArguments(swd));
		code.append(")\n");
		if (swd.getReturnType() != null)
		{
			code.append("val ").append(swd.getVariableName()).append(" = ");
		}
		code.append("_" + swd.getSubWfName()).append(".process()");
	    	    
		return code.toString();
	}

	@Override
	public String getCleanupCode() {
		return null;
	}

	String getArguments(SubWorkflowDto swd)
	{
		StringBuffer bff = new StringBuffer("");
		
		if (swd.getParamArgMap() != null && swd.getParamArgMap().size() > 0)
		{
			Map<Integer, String> posMap = new TreeMap<Integer,String>();
			for (ArgParamEntry ape : swd.getParamArgMap())
			{
				posMap.put(ape.getPos(), ape.getType());
			}
			
			for (Integer pos : posMap.keySet())
			{
				BaseDto pred = this.actions.get(posMap.get(pos));
				bff.append(", ").append(pred.getVariableName());
			}
		}
		
		return bff.toString();
	}
	
	@Override
	public String returnType() {
		return ((SubWorkflowDto)this.dto).getReturnType();
	}
}
