package com.gb.spark.wf.component;

import java.util.Map;
import java.util.TreeMap;

import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.CommonServiceDto;
import com.gb.common.job.dto.ParamDto;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.common.job.util.JobConstants;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class CommonServiceTask extends AbstractTask {
	Map<String, String> inParamType;

	public CommonServiceTask(CommonServiceDto dto, Map<String, BaseDto> actions, ImportList imports, DependencyList dependencyList, ConfigList configList,
			Map<String, String> inParams) {
		super(dto, actions, imports, dependencyList, configList);
		this.inParamType = inParams;
		this.imports.addImport(JobConstants.PACKAGE_COMMON_SERVICE + "._");
		this.dependencyList.addServiceId(dto.getServiceId());
	}

	@Override
	public String getCode() {
		CommonServiceDto csd = (CommonServiceDto) this.dto;
		StringBuffer code = new StringBuffer();

		code.append("\nval _").append(csd.getName().toLowerCase()).append(" = new ").append(csd.getServiceName());
		
		Map<Integer, String> map = new TreeMap<Integer, String>();
		
		code.append("(hiveContext, inParams");
		for (ParamDto pd : csd.getParams()) {
			String sIdx = pd.getName().split(":")[0].trim();
			Integer idx = new Integer(sIdx);
			map.put(idx, pd.getType());
		}

		for (Integer pos : map.keySet()) {
			code.append(", ");
			String param = map.get(pos);
			if (param.startsWith("inParam$")) {
				code.append(processInParam(param.split("$")[1]));
			} else {
				code.append(this.actions.get(param).getVariableName());
			}
		}

		code.append(")");
		code.append("\nval ").append(csd.getDataFrameName()).append(" = ").append("_").append(csd.getName().toLowerCase()).append(".process()");

		return code.toString();
	}

	String processInParam(String param) {

		String paramVal = "inParams.get(" + param + ")";

		String type = this.inParamType.get(param);

		if ("LONG".equalsIgnoreCase(type)) {
			paramVal = paramVal + ".toLong";
		} else if ("DOUBLE".equalsIgnoreCase(type)) {
			paramVal = paramVal + ".toDouble";
		}

		return paramVal;
	}

	@Override
	public String getCleanupCode() {
		return null;
	}

	@Override
	public String returnType() {
		return ((CommonServiceDto) dto).getReturnCategory();
	}
}
