package com.gb.spark.wf.component;

import java.io.IOException;
import java.io.OutputStream;

public interface BaseTask {
	String getCode();
	String getCleanupCode();
	String getSchema();
	
	String getName();
	String getRddName();
	String getDataFrameName();
	void write(OutputStream out) throws IOException;
	String returnType();
}
