package com.gb.spark.wf.component;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.ColumnDto;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.common.job.util.JobUtils;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public abstract class AbstractTask implements BaseTask {
	BaseDto dto;
	Map<String, BaseDto> actions;
	ImportList imports;
	DependencyList dependencyList;
	ConfigList configList;

	public AbstractTask(BaseDto dto, Map<String, BaseDto> actions, ImportList imports, DependencyList dependencyList, ConfigList configList) {
		this.dto = dto;
		this.actions = actions;
		this.imports = imports;
		this.dependencyList = dependencyList;
		this.configList = configList;
	}

	@Override
	public String getSchema() {
		List<ColumnDto> list = new ArrayList<ColumnDto>();
		Map<Integer, ColumnDto> map = new TreeMap<Integer, ColumnDto>();

		for (ColumnDto f : dto.getFields()) {
			map.put(f.getPos(), f);
		}

		for (Integer k : map.keySet()) {
			list.add(map.get(k));
		}

		return JobUtils.getSchema(list);
	}

	@Override
	public String getRddName() {
		return this.dto.getRddName();
	}

	@Override
	public String getDataFrameName() {
		return this.dto.getDataFrameName();
	}

	@Override
	public String getName() {
		return this.dto.getName();
	}

	public int getComponentType() {
		return this.dto.getComponentType();
	}

	@Override
	public void write(OutputStream out) throws IOException {
		if (this.getCode() != null) {
			out.write(("\n\n\\" + getName() + " task start\n").getBytes());
			out.write(getCode().getBytes());
			out.write(("\n\\" + getName() + " task end\n").getBytes());
		}
	}
}
