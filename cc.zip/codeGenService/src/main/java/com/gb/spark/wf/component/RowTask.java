package com.gb.spark.wf.component;

import java.util.Map;

import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.RowDto;
import com.gb.common.job.util.ComponentTypes;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class RowTask extends AbstractTask {
	public RowTask(RowDto dto, Map<String, BaseDto> actions, ImportList imports, DependencyList dependencyList, ConfigList configList) {
		super(dto, actions, imports, dependencyList, configList);
	}

	@Override
	public String getCode() {
		StringBuffer code = new StringBuffer();
		RowDto rd = (RowDto) this.dto;

		String parentName = rd.getPredecessors().get(0);
		BaseDto pDto = this.actions.get(parentName);
		if (pDto.getComponentType() == ComponentTypes.START) {
			code.append("\nval ").append(rd.getVariableName()).append(" = ").append(rd.getName());
		} else {
			code.append("\nval ").append(rd.getVariableName()).append(" = ").append(pDto.getVariableName()).append(".first()");
		}

		return code.toString();
	}

	@Override
	public String getCleanupCode() {
		return null;
	}

	@Override
	public String returnType() {
		return "DataFrame";
	}
}
