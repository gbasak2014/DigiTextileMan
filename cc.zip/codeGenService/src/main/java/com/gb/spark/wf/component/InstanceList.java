package com.gb.spark.wf.component;

public interface InstanceList {
	String sparkConfig = "sparkConfig";
	String sparkContext = "sparkContext";
	String streamingContext = "streamContext";
	String hiveContext = "hiveContext";
	String dfFactoryInstance = "dataFrameFactory";
	String dfServiceInstance = "dfService";
}
