package com.gb.spark.wf.component;

import java.util.Map;

import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.SourceHdfsDto;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.common.job.util.JobConstants;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class SourceHdfsTask extends AbstractTask {

	public SourceHdfsTask(SourceHdfsDto dto, Map<String, BaseDto> actions, ImportList imports, DependencyList dependencyList, ConfigList configList) {
		super(dto, actions, imports, dependencyList, configList);
	}

	@Override
	public String getCode() {

		this.imports.addImport("org.apache.spark.sql.Row");
		this.imports.addImport("org.apache.spark.sql.types.{StructType,StructField,StringType}");
		this.configList.setConfig(JobConstants.PARAM_SPARK_FLAG, JobConstants.TRUE);

		StringBuffer code = new StringBuffer();
		SourceHdfsDto shd = (SourceHdfsDto) this.dto;

		configList.setConfig(JobConstants.PARAM_TASK_SOURCE, shd.getSourcePath(), shd.getName());
		configList.setConfig(JobConstants.PARAM_TASK_IS_DELETE, String.valueOf(shd.isDeleteOnSuccess()), shd.getName());
		configList.setConfig(JobConstants.PARAM_TASK_IS_RENAME, String.valueOf(shd.isRenameOnSuccess()), shd.getName());
		configList.setConfig(JobConstants.PARAM_TASK_MOVE_PATH, shd.getMovePath(), shd.getName());
		configList.setConfig(JobConstants.PARAM_TASK_DELIMITER, shd.getDelimiter(), shd.getName());
		configList.setConfig(JobConstants.PARAM_TASK_FORMAT, shd.getFileType(), shd.getName());

		code.append("\n\n//Get DataFrame for the HDFS file");
		code.append("\n val ").append(getDataFrameName()).append(" = ").append(InstanceList.dfFactoryInstance).append(".fromFile(");
		code.append(getSchema()).append(",\n\"");
		code.append(shd.getName()).append("\");");

		return code.toString();
	}

	@Override
	public String getCleanupCode() {
		return "";
	}

	@Override
	public String returnType() {
		return "DataFrame";
	}
}
