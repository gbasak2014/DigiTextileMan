package com.gb.spark.wf.component;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import com.gb.common.job.dto.BaseDto;
import com.gb.common.job.dto.ColumnTransformationDto;
import com.gb.common.job.dto.JoinConditionDto;
import com.gb.common.job.dto.JoinDto;
import com.gb.common.job.util.ConfigList;
import com.gb.common.job.util.ImportList;
import com.gb.spark.wf.dependency.mvn.DependencyList;

public class JoinTask extends AbstractTask {

	public JoinTask(JoinDto dto, Map<String, BaseDto> actions, ImportList imports, DependencyList dependencyList,
			ConfigList configList) {
		super(dto, actions, imports, dependencyList, configList);
	}

	@Override
	public String getCode() {
		StringBuffer code = new StringBuffer();
		JoinDto jd = (JoinDto) this.dto;
		String joinDf = jd.getName() + "jd";

		code.append("\n//Joining DataFrame");
		code.append("\nval ").append(joinDf).append(" = ").append(getJoin(jd));
		code.append("\n//Select from joined DataFrame");
		code.append("\nval ").append(jd.getDataFrameName()).append(" = ").append(joinDf).append(".select(")
				.append(getColumns(jd)).append(")");

		return code.toString();
	}

	private String getColumns(JoinDto jd) {
		StringBuffer bff = new StringBuffer();
		for (ColumnTransformationDto ctd : jd.getTransformations()) {
			String cc = ctd.getTransform();
			String[] col = cc.split(Pattern.quote("."));
			//String df = this.dto.getDataFrameName(col[0]);
			String df = this.actions.get(col[0]).getVariableName();
			if (bff.length() > 0) {
				bff.append(",");
			}
			bff.append(df).append(".col(\"").append(col[1]).append("\").as(\"").append(ctd.getTargetField())
					.append("\")");
		}

		return bff.toString();
	}

	private String getJoin(JoinDto jd) {
		List<JoinConditionDto> joins = jd.getJoin();
		JoinConditionDto jcd = joins.get(0);
		//String lDf = jd.getDataFrameName(jcd.getLeftSchema());
		//String rDf = jd.getDataFrameName(jcd.getRightSchema());
		String lDf = this.actions.get(jcd.getLeftSchema()).getVariableName();
		String rDf = this.actions.get(jcd.getRightSchema()).getVariableName();
		StringBuffer bff = new StringBuffer();
		bff.append(lDf).append(".join(").append(rDf).append(",");
		bff.append(lDf).append(".col(\"").append(jcd.getLeftColumn()).append("\").equalTo(");
		bff.append(rDf).append(".col(\"").append(jcd.getRightColumn()).append("\")");
		if (!"INNER".equalsIgnoreCase(jcd.getJoinType())) {
			bff.append(",\"").append(getJoinType(jcd.getJoinType())).append("\"");
		}
		bff.append("))");

		for (int i = 1; i < joins.size(); i++) {
			jcd = joins.get(i);
			bff.append(".\n");
			bff.append(".join(").append(rDf).append(",");
			bff.append(lDf).append(".col(\"").append(jcd.getLeftColumn()).append("\").equalTo(");
			bff.append(rDf).append(".col(\"").append(jcd.getRightColumn()).append("\"))");
			if (!"INNER".equalsIgnoreCase(jcd.getJoinType())) {
				bff.append(",\"").append(getJoinType(jcd.getJoinType())).append("\"");
			}
			bff.append(")");
		}

		return bff.toString();
	}

	private String getJoinType(String jt) {
		if ("INNER".equalsIgnoreCase(jt)) {
			return "inner";
		}

		if ("LEFT".equalsIgnoreCase(jt)) {
			return "left_outer";
		}

		if ("RIGHT".equalsIgnoreCase(jt)) {
			return "right_outer";
		}

		return "outer";
	}

	@Override
	public String getCleanupCode() {
		return "";
	}

	@Override
	public String returnType() {
		return "DataFrame";
	}
}
