package com.tm.weave.pattern;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

public class WeaveGridPane extends JPanel implements MouseMotionListener, MouseListener {

	private static final long serialVersionUID = 3762737720401304173L;
	int cellWidth = 10;
	BufferedImage img;
	int rgb = Color.BLACK.getRGB();
	boolean repeateHorz = true;
	boolean repeateVert = true;
	int rgbWhite = Color.WHITE.getRGB();
	WeaveCreateWin parent;

	public WeaveGridPane(WeaveCreateWin parent) {
		this.parent = parent;
		this.addMouseMotionListener(this);
		this.addMouseListener(this);
	}

	public void setWeaveImage(BufferedImage img) {
		this.img = img;
		repaint();
	}

	public BufferedImage getWeaveImage() {
		return this.img;
	}

	@Override
	public void paint(Graphics g) {
		g.setColor(Color.LIGHT_GRAY);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		if (img == null)
			return;

		int w = this.img.getWidth() * cellWidth;
		int h = this.img.getHeight() * cellWidth;
		g.drawImage(this.img, 0, 0, w, h, this);

		g.setColor(Color.LIGHT_GRAY);
		if (cellWidth > 2) {
			for (int x = 0; x < w; x = x + this.cellWidth) {
				g.drawLine(x, 0, x, h);
			}

			for (int y = 0; y < h; y = y + this.cellWidth) {
				g.drawLine(0, y, w, y);
			}
		}

		g.setColor(Color.RED);
		g.drawRect(0, 0, img.getWidth() * cellWidth, img.getHeight() * cellWidth);
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		if (img != null) {
			int x = e.getX() / cellWidth;
			int y = e.getY() / cellWidth;
			if (x < img.getWidth() && y < img.getHeight()) {
				img.setRGB(x, y, rgb);
				repaint();
				this.parent.weaveImageChanged();
			}
		}
	}

	@Override
	public void mouseMoved(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
		if (img != null) {
			int x = e.getX() / cellWidth;
			int y = e.getY() / cellWidth;
			if (x < img.getWidth() && y < img.getHeight()) {
				if (e.getButton() == MouseEvent.BUTTON1) {
					img.setRGB(x, y, rgb);
				} else {
					img.setRGB(x, y, rgbWhite);
				}

				repaint();
				this.parent.weaveImageChanged();
			}
		}
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
	}
}