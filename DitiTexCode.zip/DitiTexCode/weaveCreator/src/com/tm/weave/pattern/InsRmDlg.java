package com.tm.weave.pattern;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import com.tm.commons.dlg.DigiTmDlg;

public class InsRmDlg extends DigiTmDlg implements ActionListener {
	private static final long serialVersionUID = -2135573930561969248L;
	private final JPanel contentPanel = new JPanel();
	private JTextField txtValue;
	JRadioButton rdCols;
	JRadioButton rdRows;
	JLabel lblValue;
	JLabel lblSelect;
	int value;

	boolean ok;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			InsRmDlg dialog = new InsRmDlg(false);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public InsRmDlg(boolean isAppend) {
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(Color.LIGHT_GRAY);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		lblSelect = new JLabel("Append:");
		lblSelect.setHorizontalAlignment(SwingConstants.RIGHT);
		lblSelect.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblSelect.setBounds(62, 81, 142, 23);
		contentPanel.add(lblSelect);

		rdRows = new JRadioButton("Rows");
		rdRows.setBackground(Color.LIGHT_GRAY);
		rdRows.setBounds(210, 81, 64, 23);
		contentPanel.add(rdRows);

		rdCols = new JRadioButton("Columns");
		rdCols.setBackground(Color.LIGHT_GRAY);
		rdCols.setBounds(272, 81, 89, 23);
		contentPanel.add(rdCols);

		lblValue = new JLabel("Number of Columns:");
		lblValue.setHorizontalAlignment(SwingConstants.RIGHT);
		lblValue.setFont(new Font("Tahoma", Font.PLAIN, 12));
		lblValue.setBounds(62, 119, 142, 23);
		contentPanel.add(lblValue);

		txtValue = new JTextField();
		txtValue.setBounds(210, 121, 86, 23);
		contentPanel.add(txtValue);
		txtValue.setColumns(10);

		JPanel buttonPane = new JPanel();
		buttonPane.setBackground(Color.LIGHT_GRAY);
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
		getContentPane().add(buttonPane, BorderLayout.SOUTH);

		JButton okButton = new JButton("OK");
		okButton.setActionCommand("OK");
		buttonPane.add(okButton);
		getRootPane().setDefaultButton(okButton);

		JButton cancelButton = new JButton("Cancel");
		cancelButton.setActionCommand("Cancel");
		buttonPane.add(cancelButton);

		okButton.addActionListener(this);
		cancelButton.addActionListener(this);

		if (isAppend) {
			this.lblSelect.setText("Append:");
		} else {
			this.lblSelect.setText("Remove:");
		}

		ButtonGroup bg = new ButtonGroup();
		bg.add(rdCols);
		bg.add(rdRows);

		rdRows.setActionCommand("ROW");
		rdCols.setActionCommand("COL");
		rdRows.addActionListener(this);
		rdCols.addActionListener(this);

		setModal(true);
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();

		if ("ROW".equals(cmd)) {
			this.lblValue.setText("Number of Rows");
		} else if ("COL".equals(cmd)) {
			this.lblValue.setText("Number of Columns");
		} else if ("OK".equals(cmd)) {
			try {
				this.value = Integer.parseInt(this.txtValue.getText());
				this.ok = true;
				this.setVisible(false);
			} catch (Exception ex) {
			}
		} else {
			ok = false;
			setVisible(false);
		}
	}

	public boolean isOk() {
		return this.ok;
	}

	public int getValue() {
		return this.value;
	}

	public boolean isRow() {
		return this.rdRows.isSelected();
	}
}
