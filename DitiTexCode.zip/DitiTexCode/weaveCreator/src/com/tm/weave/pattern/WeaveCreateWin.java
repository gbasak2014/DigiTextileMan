package com.tm.weave.pattern;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTextField;

import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.components.pane.WeavePreviewPane;
import com.tm.commons.dlg.NewGraphDlg;
import com.tm.commons.dto.DigiTmConstants;
import com.tm.commons.dto.LibOptions;
import com.tm.commons.secure.TmSecure;
import com.tm.commons.theme.DigiTmTheme;
import com.tm.commons.win.DigiTmWin;

public class WeaveCreateWin extends DigiTmWin implements ActionListener, ItemListener {
	// com.tm.weave.pattern.WeaveCreateWin
	private static final long serialVersionUID = -3210518052540567931L;
	static final int NEW = 0;
	static final int SAVE = 1;
	static final int CLOSE = 2;
	static final int INSERT = 3;
	static final int REMOVE = 4;
	static final int COLOR = 5;
	static final int ZOOM_IN = 6;
	static final int ZOOM_OUT = 7;
	static final int PREVIEW_NEW = 10;
	static final int PREVIEW_LIB = 11;
	static final int EXIT = 12;

	JSplitPane splitPane;
	JPanel panelNorth;

	WeaveGridPane gridPane;
	WeavePreviewPane previewPane;

	JComboBox<String> comboBoxLib;
	JComboBox<String> comboBoxWeave;
	// JRadioButton radioPreviewNew;
	// JRadioButton radioPreviewLib;
	// ButtonGroup previewGroup = new ButtonGroup();
	JTextField txtName = new JTextField();
	JTextField txtLib = new JTextField();

	LibOptions libOptions;

	String user;

	public WeaveCreateWin(String user) {
		super();
		this.user = user;
		readInitParams();
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		this.gridPane = new WeaveGridPane(this);
		this.previewPane = new WeavePreviewPane();

		this.setExtendedState(JFrame.MAXIMIZED_BOTH);

		decorateWin();
		try {
			initLibrary();
		} catch (Exception e) {
		}

		addComboboxListener();

		this.pack();
		this.setVisible(true);
	}

	public void readInitParams() {
		this.libOptions = new LibOptions();

		Properties props = new Properties();
		File file = new File(DigiTmConstants.PROP_FILE_MOTIF);
		try {
			props.load(new FileInputStream(file));
		} catch (Exception e) {

		}

		libOptions.setProperties(props);
		// this.weaveHome = libOptions.getWeaveHome();
	}

	void addComboboxListener() {
		this.comboBoxLib.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent ie) {
				if (ie.getStateChange() == ItemEvent.SELECTED) {
					refreshWeaveList();
				}
			}
		});
	}

	void refreshWeaveList() {
		this.comboBoxWeave.removeItemListener(this);
		this.comboBoxWeave.removeAllItems();
		this.comboBoxWeave.addItem("Select Weave");

		if (this.comboBoxLib.getSelectedIndex() > 0) {
			try {
				this.txtLib.setText(this.comboBoxLib.getSelectedItem().toString());
				File lib = new File(this.libOptions.getWeaveHome() + "/" + this.comboBoxLib.getSelectedItem());
				this.txtLib.setText((String) this.comboBoxLib.getSelectedItem());
				for (String weave : lib.list()) {
					this.comboBoxWeave.addItem(weave);
				}
			} catch (Exception e) {
			}
		}
		this.comboBoxWeave.setSelectedIndex(0);
		this.comboBoxWeave.addItemListener(this);
		this.previewPane.setImgWeave(null);
	}

	@Override
	public void itemStateChanged(ItemEvent ie) {
		if (ie.getStateChange() == ItemEvent.SELECTED) {
			previewLib();
		}
	}

	void previewLib() {
		if (this.comboBoxWeave.getSelectedIndex() > 0) {
			String path = this.libOptions.getWeaveHome() + "/" + this.comboBoxLib.getSelectedItem() + "/"
					+ this.comboBoxWeave.getSelectedItem();
			this.txtName.setText(this.comboBoxWeave.getSelectedItem().toString());
			try {
				BufferedImage img = ImageIO.read(new File(path));
				this.previewPane.setImgWeave(img);
				this.gridPane.setWeaveImage(img);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			this.previewPane.setImgWeave(null);
		}
	}

	void decorateWin() {
		Container container = this.getContentPane();
		container.setLayout(new BorderLayout(0, 0));
		container.setBackground(DigiTmTheme.getBgColor());

		JPanel panelGrid = new JPanel(new BorderLayout());
		panelGrid.add(getGridTools(), BorderLayout.NORTH);
		panelGrid.add(this.gridPane, BorderLayout.CENTER);

		JPanel panelPreview = new JPanel(new BorderLayout());
		panelPreview.add(this.previewPane, BorderLayout.CENTER);
		panelPreview.add(getPreviewTools(), BorderLayout.NORTH);

		this.splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, panelGrid, panelPreview);
		this.splitPane.setBackground(DigiTmTheme.getBgColor());

		container.add(this.splitPane, BorderLayout.CENTER);
	}

	JPanel getGridTools() {
		JPanel pnl = new JPanel(new GridLayout(3, 1));
		pnl.setBackground(DigiTmTheme.getBgColor());
		pnl.setBorder(BorderFactory.createRaisedBevelBorder());

		JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 1, 2));
		panel.setOpaque(false);

		panel.add(new ButtonMenuItem(NEW, this, "/img/new.jpg", "New Pattern"));
		panel.add(new ButtonMenuItem(SAVE, this, "/img/save.jpg", "Save Pattern to selected library..."));
		panel.add(new ButtonMenuItem(INSERT, this, "/img/insertcell.jpg", "Add rows/columns"));
		panel.add(new ButtonMenuItem(REMOVE, this, "/img/removecell.jpg", "Remove rows/columns"));

		JPanel pnlLib = new JPanel();
		pnlLib.setOpaque(false);
		this.txtLib.setPreferredSize(new Dimension(150, 20));
		pnlLib.add(new JLabel("Library:"));
		pnlLib.add(this.txtLib);

		JPanel pnlName = new JPanel();
		pnlName.setOpaque(false);
		this.txtName.setPreferredSize(new Dimension(150, 20));
		pnlName.add(new JLabel("  Name:"));
		pnlName.add(this.txtName);

		pnl.add(panel);
		pnl.add(pnlLib);
		pnl.add(pnlName);

		return pnl;
	}

	JPanel getPreviewTools() {
		JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 1, 1));
		panel.setBackground(DigiTmTheme.getBgColor());
		panel.setBorder(BorderFactory.createRaisedBevelBorder());

		this.comboBoxLib = new JComboBox<String>(new DefaultComboBoxModel<String>());
		this.comboBoxWeave = new JComboBox<String>(new DefaultComboBoxModel<String>());
		this.comboBoxLib.setSize(50, 20);
		this.comboBoxLib.setPreferredSize(new Dimension(150, 20));
		this.comboBoxWeave.setPreferredSize(new Dimension(250, 20));

		panel.add(new JLabel("Select Library"));
		panel.add(this.comboBoxLib);
		panel.add(new JLabel("Select Weave"));
		panel.add(this.comboBoxWeave);
		panel.add(new JLabel("    "));
		panel.add(new ButtonMenuItem(ZOOM_IN, this, "/img/z2.jpg", "Zoom In"));
		panel.add(new ButtonMenuItem(ZOOM_OUT, this, "/img/z1.jpg", "Zoom Out"));
		panel.add(new ButtonMenuItem(EXIT, this, "/img/close.jpg", "Zoom Out"));
		return panel;
	}

	void initLibrary() throws Exception {
		this.comboBoxLib.addItem("Select Library");
		File root = new File(this.libOptions.getWeaveHome());
		for (File lib : root.listFiles()) {
			if (lib.isDirectory()) {
				this.comboBoxLib.addItem(lib.getName());
			}
		}

		this.comboBoxLib.setSelectedIndex(0);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		int action = Integer.parseInt(e.getActionCommand());

		switch (action) {
		case ZOOM_IN:
			this.previewPane.setZoom(1);
			break;
		case ZOOM_OUT:
			this.previewPane.setZoom(-1);
			break;
		case NEW:
			this.newPattern();
			break;
		case INSERT:
			this.insertRowsCols();
			break;
		case REMOVE:
			this.removeRowsCols();
			break;
		case SAVE:
			this.savePattern();
			break;
		case CLOSE:
			this.closePattern();
			break;
		case PREVIEW_LIB:
			this.previewLib();
			break;
		case PREVIEW_NEW:
			this.updatePreviewImage();
			break;
		case EXIT:
			this.saveProperties();
			System.exit(0);
		}
	}

	void newPattern() {
		NewGraphDlg dlg = new NewGraphDlg(10, 10, false);
		dlg.setModal(true);
		dlg.setVisible(true);
		if (!dlg.isOkPressed()) {
			return;
		}

		int width = dlg.getColumn();
		int height = dlg.getRow();
		dlg.dispose();

		BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		Graphics g = img.getGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, img.getWidth(), img.getHeight());

		this.gridPane.setWeaveImage(img);
		updatePreviewImage();
	}

	void savePattern() {
		TmSecure.validateKey();
		String name = this.txtName.getText();
		if (this.gridPane.getWeaveImage() == null) {
			JOptionPane.showMessageDialog(this, "Please create Weave Pattern...");
			return;
		}

		if (name == null || name.trim().length() <= 0) {
			JOptionPane.showMessageDialog(this, "Please enter Name...");
			return;
		}

		if (this.txtLib.getText().trim().length() <= 0) {
			JOptionPane.showMessageDialog(this, "Please select/Enter Library...");
			return;
		}

		String lib = this.txtLib.getText().trim();
		File dir = new File(this.libOptions.getWeaveHome() + "/" + lib);
		boolean libExists = true;
		if (!dir.exists()) {
			dir.mkdirs();
			libExists = false;
		}

		File file = new File(dir + "/" + name);

		boolean patternExists = false;
		if (file.exists()) {
			patternExists = true;
			if (JOptionPane.showConfirmDialog(this,
					"Pattern with the name already exists, do you want to replace old pattern?", "DigiTex",
					JOptionPane.YES_NO_OPTION) == JOptionPane.NO_OPTION) {
				return;
			}
		}

		try {
			ImageIO.write(this.gridPane.getWeaveImage(), "BMP", file);
			if (!patternExists) {
				this.comboBoxWeave.removeItemListener(this);
				this.comboBoxWeave.addItem(name);
			}

			if (!libExists) {
				this.comboBoxLib.addItem(lib);
			}

			this.comboBoxWeave.addItemListener(this);
		} catch (Exception e) {
			System.out.println("Error - " + file.getAbsolutePath());
			JOptionPane.showMessageDialog(this, "Configure weave library..");
		}

	}

	void closePattern() {
	}

	public void weaveImageChanged() {
		this.previewPane.repaint();
	}

	private void insertRowsCols() {
		InsRmDlg dlg = new InsRmDlg(true);
		if (dlg.isOk()) {
			int val = dlg.getValue();
			if (dlg.isRow()) {
				this.insertRows(val);
			} else {
				this.insertColumn(val);
			}

			this.repaint();
			updatePreviewImage();
		}
	}

	private void removeRowsCols() {
		InsRmDlg dlg = new InsRmDlg(true);
		if (dlg.isOk()) {
			int val = dlg.getValue();
			if (dlg.isRow()) {
				this.removeRows(val);
			} else {
				this.removeCols(val);
			}

			this.repaint();
			updatePreviewImage();
		}
	}

	private void insertRows(int rows) {
		BufferedImage bi = new BufferedImage(this.gridPane.getWeaveImage().getWidth(),
				this.gridPane.getWeaveImage().getHeight() + rows, BufferedImage.TYPE_INT_RGB);
		Graphics g = bi.getGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, bi.getWidth(), bi.getHeight());
		g.drawImage(this.gridPane.getWeaveImage(), 0, 0, this);
		this.gridPane.setWeaveImage(bi);
	}

	private void insertColumn(int cols) {
		BufferedImage bi = new BufferedImage(this.gridPane.getWeaveImage().getWidth() + cols,
				this.gridPane.getWeaveImage().getHeight(), BufferedImage.TYPE_INT_RGB);
		Graphics g = bi.getGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, bi.getWidth(), bi.getHeight());
		g.drawImage(this.gridPane.getWeaveImage(), 0, 0, this);

		this.gridPane.setWeaveImage(bi);
	}

	private void removeRows(int rows) {
		int h = this.gridPane.getWeaveImage().getHeight() - rows;
		if (h > 1) {
			BufferedImage bi = new BufferedImage(this.gridPane.getWeaveImage().getWidth(), h,
					BufferedImage.TYPE_INT_RGB);
			Graphics g = bi.getGraphics();
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, bi.getWidth(), bi.getHeight());
			g.drawImage(this.gridPane.getWeaveImage(), 0, 0, this);
		}

	}

	private void removeCols(int cols) {
		int w = this.gridPane.getWeaveImage().getWidth() - cols;
		if (w > 1) {
			BufferedImage bi = new BufferedImage(w, this.gridPane.getWeaveImage().getHeight(),
					BufferedImage.TYPE_INT_RGB);
			Graphics g = bi.getGraphics();
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, bi.getWidth(), bi.getHeight());
			g.drawImage(this.gridPane.getWeaveImage(), 0, 0, this);
			this.gridPane.setWeaveImage(bi);
		}
	}

	void updatePreviewImage() {
		this.previewPane.setImgWeave(this.gridPane.getWeaveImage());
	}

	@Override
	public void saveProperties() {

	}
}
