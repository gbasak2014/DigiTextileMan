package com.tm.design.motif;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.tm.design.TmUtil;
import com.tm.design.pane.MotifPane;

public abstract class Motif
{
	BufferedImage image;
	int width;
	int height;
	int left;
	int top;

	int leftSpace;
	int rightSpace;
	int topSpace;
	int bottomSpace;

	boolean selected = false;
	boolean repeate = false;

	MotifPane group;

	Color color = Color.WHITE;

	public Motif(BufferedImage image, MotifPane group)
	{
		this.image = image;
		this.group = group;
		this.width = this.image.getWidth();
		this.height = this.image.getHeight();
	}

	public Motif(int width, int height, MotifPane group)
	{
		this.image = null;
		this.group = group;
		this.width = width;
		this.height = height;
	}

	public abstract void paint(Graphics g, boolean isBorder);
	public abstract void paint(Graphics g, Color background);
	public abstract void paint(BufferedImage newImage);
	
	public abstract void select(Graphics g);

	public BufferedImage getImage()
	{
		return image;
	}

	public int getWidth()
	{
		if (this.image == null)
		{
			return width;
		}

		return this.leftSpace + this.image.getWidth() + this.rightSpace;
	}

	public int getHeight()
	{
		if (this.image == null)
		{
			return height;
		}

		return this.topSpace + this.image.getHeight() + this.bottomSpace;
	}

	public int getLeft()
	{
		return left;
	}

	public int getTop()
	{
		return top;
	}

	public int getLeftSpace()
	{
		return leftSpace;
	}

	public int getRightSpace()
	{
		return rightSpace;
	}

	public int getTopSpace()
	{
		return topSpace;
	}

	public int getBottomSpace()
	{
		return bottomSpace;
	}

	public boolean isSelected()
	{
		return selected;
	}

	public boolean isRepeate()
	{
		return repeate;
	}

	public MotifPane getGroup()
	{
		return group;
	}

	public Color getColor()
	{
		return color;
	}

	public void setImage(BufferedImage image)
	{
		this.image = image;
	}

	public void setWidth(int width)
	{
		this.width = width;
	}

	public void setHeight(int height)
	{
		this.height = height;
	}

	public void setLeft(int left)
	{
		this.left = left;
	}

	public void setTop(int top)
	{
		this.top = top;
	}

	public void setLeftSpace(int leftSpace)
	{
		this.leftSpace = leftSpace;
	}

	public void setRightSpace(int rightSpace)
	{
		this.rightSpace = rightSpace;
	}

	public void setTopSpace(int topSpace)
	{
		this.topSpace = topSpace;
	}

	public void setBottomSpace(int bottomSpace)
	{
		this.bottomSpace = bottomSpace;
	}

	public void setSelected(boolean selected)
	{
		this.selected = selected;
	}

	public void setRepeate(boolean repeate)
	{
		this.repeate = repeate;
	}

	public void setGroup(MotifPane group)
	{
		this.group = group;
	}

	public void setColor(Color color)
	{
		this.color = color;
	}
	
	public void flipVertical()
	{
		if (this.image != null)
		{
			BufferedImage img = TmUtil.flipVertical(this.image);
			if (img != null)
			{
				this.image = img;
				int tmp = this.topSpace;
				this.topSpace = this.bottomSpace;
				this.bottomSpace = tmp;
			}
		}
	}

	public void flipHorizontal()
	{
		if (this.image != null)
		{
			BufferedImage img = TmUtil.flipHorizontal(this.image);
			if (img != null)
			{
				this.image = img;
				int tmp = this.leftSpace;
				this.leftSpace = this.rightSpace;
				this.rightSpace = tmp;
			}
		}
	}
	
	public abstract Motif createCopy(MotifPane group);
}
