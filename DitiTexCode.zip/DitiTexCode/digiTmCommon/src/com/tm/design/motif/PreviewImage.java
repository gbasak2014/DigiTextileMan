package com.tm.design.motif;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

public class PreviewImage
{
	int left;
	int top;
	boolean horizontal;
	// boolean repeate;
	BufferedImage img;
	JPanel parent;
	int horizRepeat;
	int vertRepeat;

	public PreviewImage(BufferedImage img, int left, int top, boolean horizontal, int horizRepeat, int vertRepeat, JPanel parent)
	{
		this.img = img;
		this.left = left;
		this.top = top;
		// this.repeate = repeate;
		this.horizontal = horizontal;
		this.horizRepeat = horizRepeat;
		this.vertRepeat = vertRepeat;
		this.parent = parent;
	}

	public void paint(Graphics g)
	{
		g.drawImage(this.img, this.left, this.top, this.parent);
		paintRepeat(g);
	}

	private void paintRepeat(Graphics g)
	{
		if (this.horizRepeat != 1 || this.vertRepeat != 1)
		{

			int hCount = 1;
			for (int x = this.left + img.getWidth(); x < this.parent.getWidth() + img.getWidth(); x = x + img.getWidth())
			{
				int vCount = 1;

				for (int y = this.top + img.getHeight(); y < this.parent.getHeight(); y = y + img.getHeight())
				{
					vCount++;
					if (this.vertRepeat > 0 && vCount > this.vertRepeat)
					{
						break;
					}
					g.drawImage(img, x - img.getWidth(), y, this.parent);
				}

				hCount++;
				if (this.horizRepeat > 0 && hCount > this.horizRepeat)
				{
					break;
				}
				g.drawImage(img, x, this.top, this.parent);
			}

		}

	}
}
