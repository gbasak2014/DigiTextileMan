package com.tm.design.motif;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.tm.design.pane.MotifPane;

public class Border extends Motif
{
	
	public Border(int width, int height, MotifPane group)
	{
		this(width, height, Color.BLACK, group);
	}

	public Border(int width, int height, Color color, MotifPane group)
	{
		super(width, height, group);
		this.setColor(color);
	}

	@Override
	public void paint(BufferedImage newImage)
	{
		Graphics g = newImage.getGraphics();
		g.setColor(this.getColor());

		int w, h;
		int l = this.left;
		int t = this.top;
		if (this.group.isHorizontalAlign())
		{
			w = this.width;
			h = this.group.getSize().height;
		} else
		{
			w = this.group.getSize().width;
			h = this.height;
		}

		g.fillRect(l, t, w, h);
	}
	
	@Override
	public void paint(Graphics g, boolean isBorder)
	{
		g.setColor(this.getColor());

		int w, h;
		int l = this.group.getLeft() + this.left;
		int t = this.group.getTop() + this.top;
		if (this.group.isHorizontalAlign())
		{
			w = this.width;
			h = this.group.getSize().height;
		} else
		{
			w = this.group.getSize().width;
			h = this.height;
		}

		g.fillRect(l, t, w, h);
		if (isBorder)
		{
			g.setColor(Color.GRAY);
			g.drawRect(l, t, w, h);
		}
	}

	@Override
	public void paint(Graphics g, Color background)
	{
		g.setColor(this.getColor());

		int w, h;
		int l = this.left;
		int t = this.top;
		if (this.group.isHorizontalAlign())
		{
			w = this.width;
			h = this.group.getSize().height;
		} else
		{
			w = this.group.getSize().width;
			h = this.height;
		}

		g.fillRect(l, t, w, h);

	}
	
	@Override
	public void select(Graphics g)
	{
		int w, h;
		int l = this.group.getLeft() + this.left;
		int t = this.group.getTop() + this.top;
		
		if (this.group.isHorizontalAlign())
		{
			w = this.width;
			h = this.group.getSize().height;
		} else
		{
			w = this.group.getSize().width;
			h = this.height;
		}

		g.setColor(Color.GREEN);
		g.drawRect(l, t, w, h);
	}

	@Override
	public Motif createCopy(MotifPane group)
	{
		Motif motif = new Border(this.width, this.height, group);

		motif.setLeft(this.getLeft());
		motif.setTop(this.getTop());
		motif.setLeftSpace(this.getLeftSpace());
		motif.setTopSpace(this.getTopSpace());
		motif.setBottomSpace(this.getBottomSpace());
		motif.setRightSpace(this.getRightSpace());
		motif.setRepeate(this.isRepeate());
		motif.setColor(this.getColor());

		return motif;
	}
}
