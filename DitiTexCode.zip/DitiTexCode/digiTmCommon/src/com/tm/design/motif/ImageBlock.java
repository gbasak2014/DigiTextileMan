package com.tm.design.motif;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import com.tm.design.pane.MotifPane;

public class ImageBlock extends Motif {

	public ImageBlock(BufferedImage image, MotifPane group) {
		super(image, group);
	}

	public ImageBlock(int width, int height, MotifPane group) {
		super(width, height, group);
	}

	@Override
	public void paint(BufferedImage newImage) {
		int l = this.left + this.leftSpace;
		int t = this.top + this.topSpace;
		int w = this.getWidth();
		int h = this.getHeight();
		int sx = l;
		int sy = t;

		int right = this.group.getSize().width;
		int bottom = this.group.getSize().height;

		Graphics g = newImage.getGraphics();
		g.drawImage(this.image, l, t, null);

		if (isRepeate()) {
			if (this.group.isHorizontalAlign()) {
				for (int y = t; y <= bottom - h; y = y + h) {
					g.drawImage(this.image, l, y + this.topSpace, null);
				}
			} else {
				for (int x = l; x <= right - w; x = x + w) {
					g.drawImage(this.image, x + this.leftSpace, t, null);
				}
			}

		}

		if (isSelected()) {
			g.setColor(Color.GREEN);
			g.drawRect(sx, sy, w, h);
		}
	}

	@Override
	public void paint(Graphics g, boolean isBorder) {
		int l = this.group.getLeft() + this.left + this.leftSpace;
		int t = this.group.getTop() + this.top + this.topSpace;
		int w = this.getWidth();
		int h = this.getHeight();
		int sx = l;
		int sy = t;

		int right = this.group.getLeft() + this.group.getSize().width;
		int bottom = this.group.getTop() + this.group.getSize().height;

		g.drawImage(this.image, l, t, null);

		if (isRepeate()) {
			if (this.group.isHorizontalAlign()) {
				for (int y = t; y <= bottom - h; y = y + h) {
					g.drawImage(this.image, l, y + this.topSpace, null);
				}
			} else {
				for (int x = l; x <= right - w; x = x + w) {
					g.drawImage(this.image, x + this.leftSpace, t, null);
				}
			}

		}

		if (isBorder) {
			g.setColor(Color.GRAY);
			g.drawRect(this.group.getLeft() + this.getLeft(), this.group.getTop() + this.getTop(), w, h);
		}

		if (isSelected()) {
			g.setColor(Color.GREEN);
			g.drawRect(sx, sy, w, h);
		}

	}

	@Override
	public void paint(Graphics g, Color background) {
		int l = this.left + this.leftSpace;
		int t = this.top + this.topSpace;
		int w = this.getWidth();
		int h = this.getHeight();
		int sx = l;
		int sy = t;

		int right = this.group.getSize().width;
		int bottom = this.group.getSize().height;

		g.drawImage(this.image, l, t, null);

		if (isRepeate()) {
			if (this.group.isHorizontalAlign()) {
				for (int y = t; y <= bottom - h; y = y + h) {
					g.drawImage(this.image, l, y + this.topSpace, null);
				}
			} else {
				for (int x = l; x <= right - w; x = x + w) {
					g.drawImage(this.image, x + this.leftSpace, t, null);
				}
			}

		}

		if (isSelected()) {
			g.setColor(Color.GREEN);
			g.drawRect(sx, sy, w, h);
			if (w > 3 && h > 3) {
				g.setColor(Color.WHITE);
				g.drawRect(sx + 1, sy + 1, w - 2, h - 2);
			}
		}
	}

	@Override
	public void select(Graphics g) {
		int w = this.getWidth();
		int h = this.getHeight();

		g.setColor(Color.GREEN);
		g.drawRect(this.group.getLeft() + this.left, this.group.getTop() + this.top, w, h);
		if (w>3 && h>3)
		{
			g.setColor(Color.WHITE);
			g.drawRect(this.group.getLeft() + this.left+1, this.group.getTop() + this.top+1, w-2, h-2);
		}
	}

	@Override
	public Motif createCopy(MotifPane group) {
		BufferedImage img = new BufferedImage(this.image.getWidth(), this.image.getHeight(),
				BufferedImage.TYPE_INT_RGB);
		img.getGraphics().drawImage(this.image, 0, 0, null);
		Motif motif = new ImageBlock(img, group);

		motif.setLeft(this.getLeft());
		motif.setTop(this.getTop());
		motif.setLeftSpace(this.getLeftSpace());
		motif.setTopSpace(this.getTopSpace());
		motif.setBottomSpace(this.getBottomSpace());
		motif.setRightSpace(this.getRightSpace());
		motif.setRepeate(this.isRepeate());
		motif.setColor(this.getColor());

		return motif;
	}
}