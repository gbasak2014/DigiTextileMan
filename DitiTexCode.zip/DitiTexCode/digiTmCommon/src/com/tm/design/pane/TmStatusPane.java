package com.tm.design.pane;

import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JPanel;
import javax.swing.JTextField;

public class TmStatusPane extends JPanel
{
	private JTextField txtDesignWH;
	private JTextField txtGroupProp;
	private JTextField txtMotifProp;
	
	public TmStatusPane()
	{
		FlowLayout flowLayout = (FlowLayout) getLayout();
		flowLayout.setVgap(1);
		flowLayout.setHgap(1);
		flowLayout.setAlignment(FlowLayout.LEFT);
		flowLayout.setAlignOnBaseline(true);
		
		txtDesignWH = new JTextField();
		txtDesignWH.setEditable(false);
		txtDesignWH.setFont(new Font("Arial", Font.PLAIN, 10));
		txtDesignWH.setText("Design W: XXXX, H: XXXX");
		add(txtDesignWH);
		txtDesignWH.setColumns(17);
		
		txtGroupProp = new JTextField();
		txtGroupProp.setEditable(false);
		txtGroupProp.setText("Group W: XXXXX, H: XXXXX");
		txtGroupProp.setFont(new Font("Arial", Font.PLAIN, 10));
		txtGroupProp.setColumns(17);
		add(txtGroupProp);
		
		txtMotifProp = new JTextField();
		txtMotifProp.setEditable(false);
		txtMotifProp.setText("Motif Left: XXXXX, Top: XXXXX");
		txtMotifProp.setFont(new Font("Arial", Font.PLAIN, 10));
		txtMotifProp.setColumns(17);
		add(txtMotifProp);

	}

	public void setDesignProperties(String prop)
	{
		this.txtDesignWH.setText(prop);
	}
	
	public void setGroupProperties(String prop)
	{
		this.txtGroupProp.setText(prop);
	}
	
	public void setMotifProperties(String prop)
	{
		this.txtMotifProp.setText(prop);
	}
}
