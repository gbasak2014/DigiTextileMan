package com.tm.design.pane;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import com.tm.design.TmUtil;
import com.tm.design.motif.Border;
import com.tm.design.motif.ImageBlock;
import com.tm.design.motif.Motif;

public class MotifPane {

	List<Motif> list = new ArrayList<Motif>();

	boolean horizontalAlign;
	boolean selected;
	boolean locked;

	Motif selectedMotif;
	int selectedIndex;

	int left;
	int top;
	Dimension size;

	Color background;

	boolean border;
	Color borderColor;

	int horizontalRepeate = 1;
	int verticalRepeate = 1;

	public MotifPane(Color color) {
		this.background = color;
		this.borderColor = Color.BLACK;
	}

	public MotifPane(int width, boolean horizontalAlign) {
		Border border = new Border(width, width, this);

		this.list.add(border);
		this.horizontalAlign = horizontalAlign;
		this.setBounds(0, 0, border.getWidth(), border.getHeight());
		this.setBorder(false);
	}

	public MotifPane(int width, int height, Color color, boolean horizontalAlign) {
		Border border = new Border(width, height, color, this);

		this.list.add(border);
		this.horizontalAlign = horizontalAlign;
		this.setBounds(0, 0, border.getWidth(), border.getHeight());
		this.setBorder(false);
	}

	public MotifPane(BufferedImage motif, boolean horizontalAlign) {
		ImageBlock block = new ImageBlock(motif, this);
		this.list.add(block);
		this.horizontalAlign = horizontalAlign;
		this.setBounds(0, 0, block.getWidth(), block.getHeight());
		this.setBorder(true);
	}

	public void setLocation(int left, int top) {
		this.left = left;
		this.top = top;
	}

	public Dimension getSize() {
		return size;
	}

	public void setSize(Dimension size) {
		this.size = size;
	}

	public void setBorder(boolean border) {
		this.border = border;
	}

	public boolean isBorder() {
		return this.border;
	}

	public void updateProperties(Graphics g) {

		Dimension s = this.getSize();
		int l = 0;
		int t = 0;
		for (Motif m : list) {
			if (this.horizontalAlign) {
				m.setLeft(l);
				m.setTop(0);
				l = l + m.getWidth();
				if (t < m.getHeight()) {
					t = m.getHeight();
				}
			} else {
				m.setLeft(0);
				m.setTop(t);
				t = t + m.getHeight();
				if (l < m.getWidth()) {
					l = m.getWidth();
				}
			}
		}

		s.setSize(l, t);
		this.setSize(s);
		this.paint(g);
	}

	public void setBounds(int left, int top, int width, int height) {
		this.left = left;
		this.top = top;
		this.size = new Dimension(width, height);
	}

	public void setBounds(Rectangle rectengle) {
		this.left = rectengle.x;
		this.top = rectengle.y;
		this.size = new Dimension(rectengle.width, rectengle.height);
	}

	public Rectangle getBounds() {
		return new Rectangle(this.left, this.top, this.getSize().width, this.getSize().height);
	}

	public int getLeft() {
		return this.left;
	}

	public int getTop() {
		return this.top;
	}

	public List<Motif> getMotifList() {
		return list;
	}

	public MotifPane createClone() {
		MotifPane pane = new MotifPane(this.background);

		pane.horizontalAlign = this.horizontalAlign;
		pane.setBounds(this.left, this.top, (int) this.getSize().getWidth(), (int) this.getSize().getHeight());
		pane.setBorder(this.isBorder());

		for (Motif motif : this.list) {
			pane.list.add(motif.createCopy(pane));
		}

		return pane;
	}

	public Motif addMotif(BufferedImage motif) {

		Motif block = new ImageBlock(motif, this);
		Rectangle r = this.getBounds();

		int w;
		int h;
		if (this.horizontalAlign) {
			block.setLeft((int) r.getWidth());
			w = (int) r.getWidth() + block.getWidth();
			h = (int) r.getHeight();
			if (h < (int) r.getHeight()) {
				h = block.getHeight();
			}
		} else {
			block.setTop((int) r.getHeight());
			h = (int) r.getHeight() + block.getHeight();
			w = (int) r.getWidth();
			if (w < block.getWidth()) {
				w = block.getWidth();
			}
		}

		r.setSize(w, h);
		this.list.add(block);

		this.setBounds(r);

		return block;
	}

	public Motif addMotif(int width) {
		Motif border;

		Rectangle r = this.getBounds();

		int w;
		int h;
		if (this.horizontalAlign) {
			border = new Border(width, width, this);
			border.setLeft((int) r.getWidth());
			w = (int) r.getWidth() + border.getWidth();
			h = (int) r.getHeight();
		} else {
			border = new Border(width, width, this);
			border.setTop((int) r.getHeight());
			h = (int) r.getHeight() + border.getHeight();
			w = (int) r.getWidth();
		}

		r.setSize(w, h);
		this.list.add(border);

		this.setBounds(r);

		return border;
	}

	public Motif addMotif(int width, int height, Color color) {
		Motif border;

		Rectangle r = this.getBounds();

		int w;
		int h;
		if (this.horizontalAlign) {
			border = new Border(width, height, color, this);
			border.setLeft((int) r.getWidth());
			w = (int) r.getWidth() + border.getWidth();
			h = (int) r.getHeight();
		} else {
			border = new Border(width, height, color, this);
			border.setTop((int) r.getHeight());
			h = (int) r.getHeight() + border.getHeight();
			w = (int) r.getWidth();
		}

		r.setSize(w, h);
		this.list.add(border);

		this.setBounds(r);

		return border;
	}

	public void paint(Graphics g) {
		for (Motif motif : list) {
			motif.paint(g, true);
		}
	}

	public void paintBorder(Graphics g) {
		if (this.selected) {
			g.setColor(Color.GREEN);
		} else {
			g.setColor(Color.GRAY);
		}
		g.drawRect(this.left+1, this.top+1, this.size.width-2, this.size.height-2);
	}

	public void paint(Graphics g, Color background) {
		for (Motif motif : list) {
			motif.paint(g, background);
		}
	}

	public List<Motif> getList() {
		return list;
	}

	public boolean isHorizontalAlign() {
		return horizontalAlign;
	}

	public void setList(List<Motif> list) {
		this.list = list;
	}

	public void setHorizontalAlign(boolean horizontalAlign) {
		this.horizontalAlign = horizontalAlign;
	}

	public boolean isSelected() {
		return selected;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
		if (this.selectedMotif != null) {
			this.selectedMotif.setSelected(selected);
			if (!this.selected) {
				this.selectedMotif = null;
			}
		}
	}

	public void selecteMotif(int x, int y) {
		if (this.selectedMotif != null) {
			this.selectedMotif.setSelected(false);
			this.selectedMotif = null;
		}

		this.selectedIndex = -1;

		for (int i = list.size() - 1; i >= 0; i--) {
			Motif motif = list.get(i);
			if (this.isHorizontalAlign()) {
				if (this.left + motif.getLeft() < x && x < this.left + motif.getLeft() + motif.getWidth()) {
					this.selectedMotif = motif;
					this.selectedIndex = i;
					break;
				}
			} else {
				if (this.top + motif.getTop() < y && y < this.top + motif.getTop() + motif.getHeight()) {
					this.selectedMotif = motif;
					this.selectedIndex = i;
					break;
				}
			}
		}

		if (this.selectedMotif != null) {
			this.selectedMotif.setSelected(true);
		}
	}

	public void selectMotif(int index) {
		if (index >= list.size()) {
			index = list.size() - 1;
		}

		this.selectedMotif = list.get(index);
		this.selectedIndex = index;
	}

	/**
	 * Move up or left bases on alignment.
	 */
	public void moveUp(Graphics g) {
		if (this.selectedMotif != null && this.selectedIndex > 0) {
			this.list.remove(this.selectedIndex);
			this.selectedIndex--;
			this.list.add(this.selectedIndex, this.selectedMotif);
			this.updateProperties(g);
		}
	}

	/**
	 * Move up or left bases on alignment.
	 */
	public void moveDown(Graphics g) {
		if (this.selectedMotif != null && this.selectedIndex < (this.list.size() - 1)) {
			this.list.remove(this.selectedIndex);
			this.selectedIndex++;
			this.list.add(this.selectedIndex, this.selectedMotif);
			this.updateProperties(g);
		}
	}

	public Motif getSelectedMotif() {
		return selectedMotif;
	}

	public int getSelectedIndex() {
		return selectedIndex;
	}

	public void setSelectedMotif(Motif selectedMotif) {
		this.selectedMotif = selectedMotif;
	}

	public void setSelectedIndex(int selectedIndex) {
		this.selectedIndex = selectedIndex;
	}

	public boolean isLocked() {
		return locked;
	}

	public void setLocked(boolean locked) {
		this.locked = locked;
	}

	public void removeSelectedMotif(Graphics g) {
		if (this.selectedIndex >= 0 && this.selectedIndex < this.list.size()) {
			this.list.remove(this.selectedIndex);
			this.selectedIndex = -1;
			this.selectedMotif = null;
		}

		this.updateProperties(g);
	}

	public void reverseMotifList() {
		int size = this.list.size() - 1;
		int len = this.list.size() / 2;
		for (int i = 0; i < len; i++) {
			Motif tmp1 = this.list.remove(size);
			Motif tmp2 = this.list.remove(i);
			this.list.add(i, tmp1);
			this.list.add(size, tmp2);
			size--;
		}
	}

	public void flipVertical(Graphics g) {
		if (!this.isHorizontalAlign()) {
			reverseMotifList();
		}

		for (Motif motif : this.list) {
			if (motif.getImage() != null) {
				motif.setImage(TmUtil.flipVertical(motif.getImage()));
				int tmp = motif.getTopSpace();
				motif.setTopSpace(motif.getBottomSpace());
				motif.setBottomSpace(tmp);
			}
		}

		this.updateProperties(g);
	}

	public void flipHorizontal(Graphics g) {
		if (this.isHorizontalAlign()) {
			reverseMotifList();
		}

		for (Motif motif : this.list) {
			if (motif.getImage() != null) {
				motif.setImage(TmUtil.flipHorizontal(motif.getImage()));
				int tmp = motif.getLeftSpace();
				motif.setLeftSpace(motif.getRightSpace());
				motif.setRightSpace(tmp);
			}
		}

		this.updateProperties(g);
	}

	public void flipVerticalSelectedMotif(Graphics g) {
		if (this.selectedMotif != null) {
			this.selectedMotif.flipVertical();
			this.paint(g);
		}
	}

	public void flipHorizontalSelectedMotif(Graphics g) {
		if (this.selectedMotif != null) {
			this.selectedMotif.flipHorizontal();
			this.paint(g);
		}
	}

	public BufferedImage createPaneImage() {
		int w = this.size.width;
		int h = this.size.height;

		BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = img.createGraphics();
		g.setColor(new Color(255, 255, 255, 0));
		g.fillRect(0, 0, w, h);

		for (Motif motif : list) {
			motif.paint(img);
		}

		return img;

	}

	public boolean isIntersect(int x, int y) {
		return this.getBounds().contains(x, y);
	}

	public int getHorizontalRepeate() {
		return horizontalRepeate;
	}

	public int getVerticalRepeate() {
		return verticalRepeate;
	}

	public void setHorizontalRepeate(int horizontalRepeate) {
		this.horizontalRepeate = horizontalRepeate;
	}

	public void setVerticalRepeate(int verticalRepeate) {
		this.verticalRepeate = verticalRepeate;
	}
}
