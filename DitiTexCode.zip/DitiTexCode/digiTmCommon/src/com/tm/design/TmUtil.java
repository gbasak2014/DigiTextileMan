package com.tm.design;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayDeque;
import java.util.Deque;

public class TmUtil {
	public static BufferedImage flipVertical(BufferedImage image) {
		int w = image.getWidth();
		int h = image.getHeight();
		BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);

		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				img.setRGB(x, (h - y - 1), image.getRGB(x, y));
			}
		}

		return img;
	}

	public static BufferedImage flipHorizontal(BufferedImage image) {
		int w = image.getWidth();
		int h = image.getHeight();
		BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);

		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				img.setRGB((w - x - 1), y, image.getRGB(x, y));
			}
		}

		return img;
	}

	public static BufferedImage mirrorVertical(BufferedImage image,
			int skipTop, int skipBottom) {
		int w = image.getWidth();
		int imgH = image.getHeight();

		int h = imgH - skipTop - skipBottom;

		if (h > 0) {
			BufferedImage img = new BufferedImage(w, (imgH + h),
					BufferedImage.TYPE_INT_RGB);

			for (int x = 0; x < w; x++) {
				for (int y = 0; y < h; y++) {
					img.setRGB(x, (imgH + h - y - 1),
							image.getRGB(x, y + skipTop));
				}
			}

			img.getGraphics().drawImage(image, 0, 0, null);
			return img;
		}

		return image;
	}

	public static BufferedImage mirrorHorizontal(BufferedImage image,
			int skipLeft, int skipRight) {
		int imgW = image.getWidth();
		int h = image.getHeight();
		int w = imgW - skipLeft - skipRight;

		if (w > 0) {
			BufferedImage img = new BufferedImage((imgW + w), h,
					BufferedImage.TYPE_INT_RGB);

			for (int x = 0; x < w; x++) {
				for (int y = 0; y < h; y++) {
					img.setRGB((imgW + w - x - 1), y,
							image.getRGB(x + skipLeft, y));
				}
			}

			img.getGraphics().drawImage(image, 0, 0, null);

			return img;
		}

		return image;
	}

	public static BufferedImage rotate90(BufferedImage image) {
		double r = Math.toRadians(90);
		double sin = Math.abs(Math.sin(r));
		double cos = Math.abs(Math.cos(r));
		int w = image.getWidth();
		int h = image.getHeight();
		int neww = (int) Math.floor(w * cos + h * sin);
		int newh = (int) Math.floor(h * cos + w * sin);
		BufferedImage newImage = new BufferedImage(neww, newh,
				BufferedImage.TYPE_INT_RGB);
		Graphics2D g = newImage.createGraphics();

		g.setColor(Color.WHITE);
		g.fillRect(0, 0, neww, newh);
		g.translate((neww - w) / 2, (newh - h) / 2);
		g.rotate(r, w / 2, h / 2);
		g.drawRenderedImage(image, null);
		g.dispose();

		return newImage;
	}

	public static BufferedImage replaceColor(BufferedImage image, int oldRGB,
			int newRGB) {
		int w = image.getWidth();
		int h = image.getHeight();
		BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);

		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				if (image.getRGB(x, y) == oldRGB) {
					img.setRGB(x, y, newRGB);
				} else {
					img.setRGB(x, y, image.getRGB(x, y));
				}
			}
		}

		return img;
	}

	public static BufferedImage fill(BufferedImage img, int x, int y, int newRgb) {
		if (img != null && isValidPoint(img, x, y)
				&& img.getRGB(x, y) != newRgb) {
			int oldRgb = img.getRGB(x, y);
			BufferedImage imgNew = new BufferedImage(img.getWidth(),
					img.getHeight(), BufferedImage.TYPE_INT_RGB);
			imgNew.getGraphics().drawImage(img, 0, 0, null);
			solidFill(imgNew, oldRgb, newRgb, x, y);
			return imgNew;
		}

		return null;
	}

	public static BufferedImage replaceColor(BufferedImage img, int x, int y,
			int newRgb) {
		if (img != null && isValidPoint(img, x, y)
				&& img.getRGB(x, y) != newRgb) {
			int oldRgb = img.getRGB(x, y);
			BufferedImage imgNew = new BufferedImage(img.getWidth(),
					img.getHeight(), BufferedImage.TYPE_INT_RGB);
			imgNew.getGraphics().drawImage(img, 0, 0, null);
			int w = imgNew.getWidth();
			int h = imgNew.getHeight();
			for (int c = 0; c < w; c++) {
				for (int r = 0; r < h; r++) {
					if (imgNew.getRGB(c, r) == oldRgb) {
						imgNew.setRGB(c, r, newRgb);
					}
				}
			}

			return imgNew;
		}

		return null;
	}

	private static void solidFill(BufferedImage image, int oldRgb, int newRgb,
			int x, int y) {
		Deque<Integer> sx, sy;
		int xx, yy;
		sx = new ArrayDeque<Integer>();
		sy = new ArrayDeque<Integer>();

		sx.push(Integer.valueOf(x));
		sy.push(Integer.valueOf(y));

		while (!sx.isEmpty()) {
			try {
				xx = sx.pop().intValue();
				yy = sy.pop().intValue();

				if ((xx >= 0 && xx < image.getWidth())
						&& (yy >= 0 && yy < image.getHeight())
						&& image.getRGB(xx, yy) == oldRgb) {
					image.setRGB(xx, yy, newRgb);

					if ((xx - 1 >= 0 && xx - 1 < image.getWidth())
							&& (yy >= 0 && yy < image.getHeight())
							&& image.getRGB(xx - 1, yy) == oldRgb) {
						sx.push(Integer.valueOf(xx - 1));
						sy.push(Integer.valueOf(yy));
					}

					if ((xx + 1 >= 0 && xx + 1 < image.getWidth())
							&& (yy >= 0 && yy < image.getHeight())
							&& image.getRGB(xx + 1, yy) == oldRgb) {
						sx.push(Integer.valueOf(xx + 1));
						sy.push(Integer.valueOf(yy));
					}

					if ((xx >= 0 && xx < image.getWidth())
							&& (yy - 1 >= 0 && yy - 1 < image.getHeight())
							&& image.getRGB(xx, yy - 1) == oldRgb) {
						sx.push(Integer.valueOf(xx));
						sy.push(Integer.valueOf(yy - 1));
					}

					if ((xx >= 0 && xx < image.getWidth())
							&& (yy + 1 >= 0 && yy + 1 < image.getHeight())
							&& image.getRGB(xx, yy + 1) == oldRgb) {
						sx.push(Integer.valueOf(xx));
						sy.push(Integer.valueOf(yy + 1));
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public static BufferedImage resize(BufferedImage img, int newWidth,
			int newHeight) {
		BufferedImage newImg = new BufferedImage(newWidth, newHeight,
				BufferedImage.TYPE_INT_RGB);
		Graphics2D g = newImg.createGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, newWidth, newHeight);
		double sx = (double) newWidth / img.getWidth();
		double sy = (double) newHeight / img.getHeight();
		g.scale(sx, sy);
		g.drawImage(img, 0, 0, null);

		return newImg;

	}

	public static boolean isValidPoint(BufferedImage img, int x, int y) {
		return (x >= 0 && x < img.getWidth())
				&& (y >= 0 && y < img.getHeight());
	}

	public static BufferedImage arrangeRight(BufferedImage img) {
		int w = img.getWidth();
		int h = img.getHeight();

		BufferedImage newImg = new BufferedImage(2 * w, h,
				BufferedImage.TYPE_INT_RGB);
		Graphics g = newImg.getGraphics();
		g.drawImage(img, 0, 0, null);
		g.drawImage(img, w, 0, null);

		return newImg;
	}

	public static BufferedImage arrangeDown(BufferedImage img) {
		int w = img.getWidth();
		int h = img.getHeight();

		BufferedImage newImg = new BufferedImage(w, 2 * h,
				BufferedImage.TYPE_INT_RGB);
		Graphics g = newImg.getGraphics();
		g.drawImage(img, 0, 0, null);
		g.drawImage(img, 0, h, null);

		return newImg;
	}
}