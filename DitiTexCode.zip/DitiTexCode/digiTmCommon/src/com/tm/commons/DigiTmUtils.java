package com.tm.commons;

import java.awt.GraphicsEnvironment;
import java.io.File;
import java.io.PrintStream;

import com.tm.commons.dto.DigiTmConstants;

public class DigiTmUtils {

	public static String[] getFonts() {
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		return ge.getAvailableFontFamilyNames();
	}

	public static void main(String[] args) {
		for (String s : getFonts()) {
			System.out.println(s);
		}
	}

	public static String WriteLog(Exception e) {
		String path = null;
		try {
			File file = new File(DigiTmConstants.ERROR_FILE);
			PrintStream ps = new PrintStream(file);
			e.printStackTrace(ps);
			ps.close();
			path = file.getAbsolutePath();
		} catch (Exception e2) {
			e2.printStackTrace();
		}

		return path;
	}
}
