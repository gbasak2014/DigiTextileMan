package com.tm.commons.components;

import java.awt.Color;
import java.awt.Component;

import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JScrollPane;

public class ScrollableColorList extends JScrollPane {
	private static final long serialVersionUID = 4478267054230037234L;
	JList<Integer> list;
	DefaultListModel<Integer> mdl;

	public ScrollableColorList(int visibleRowCount) {
		this.mdl = new DefaultListModel<Integer>();
		this.list = new JList<Integer>(this.mdl);
		this.list.setVisibleRowCount(visibleRowCount);
		this.list.setCellRenderer(new ColorListCellRenderer());
		this.setViewportView(list);
	}

	public void addItem(Integer value) {
		this.mdl.addElement(value);
	}

	public Integer getItem(int index) {
		return this.mdl.get(index);
	}

	public int getSelectedIndex() {
		return this.list.getSelectedIndex();
	}

	public void removeItem(int index) {
		this.mdl.removeElementAt(index);
	}

	public void removeAllItems() {
		this.mdl.removeAllElements();
	}

	public int itemCount() {
		return this.mdl.size();
	}

	static class ColorListCellRenderer extends DefaultListCellRenderer {
		private static final long serialVersionUID = -1319760413362415176L;

		@Override
		public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected,
				boolean cellHasFocus) {
			Component component = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
			Color color = new Color(((Integer) value).intValue());
			component.setBackground(color);
			component.setForeground(color);
			return component;
		}
	}
}
