package com.tm.commons.components;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

/**
 * The class provide drawing image in graphPane, all graph pane will share same
 * instance.
 * 
 * @author Gouranga Basak
 * 
 */
public class DrawingImage {
	BufferedImage image;

	public DrawingImage(int w, int h) {
		if (this.image == null) {
			this.image = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		}
	}

	/**
	 * Resize drawingImage with specified width and height
	 * 
	 * @param w
	 * @param h
	 */
	public void resizeImage(int w, int h) {
		if (this.image == null || w != this.image.getWidth() || h != this.image.getHeight()) {
			this.image = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		}
	}

	/**
	 * Copy the image specified to the drawingImage
	 * 
	 * @param img
	 */
	public void copyImage(BufferedImage img) {
		int w = img.getWidth();
		int h = img.getHeight();
		if (this.image == null || w != this.image.getWidth() || h != this.image.getHeight()) {
			this.resizeImage(w, h);
		}
		Graphics2D g = this.image.createGraphics();
		g.setColor(Color.GRAY);
		g.fillRect(0, 0, this.image.getWidth(), this.image.getHeight());
		g.drawImage(img, 0, 0, null);
		g.dispose();
	}

	public BufferedImage getImage() {
		return image;
	}

	public void setImage(BufferedImage image) {
		this.image = image;
	}
}
