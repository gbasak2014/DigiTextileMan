package com.tm.commons.components.pane;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.tm.commons.dto.GridOptions;

public class GrdOptionPane extends JPanel implements ActionListener {

	private static final long serialVersionUID = 1407172632816941281L;
	JButton jbColor1 = new JButton("Color Unit");
	JButton jbColor2 = new JButton("Color 5th");
	JButton jbColor3 = new JButton("Color 10th");
	JButton jbPreview = new JButton("Preview");
	// JTextField jtCellWidth = new JTextField();
	JTextField jtPoint = new JTextField(5);
	PreviewPane previewPane = new PreviewPane();

	GridOptions gridOption;

	Color cUnit;
	Color cPoint;
	Color cPoint1;
	int cellWidth;
	int point;

	public GrdOptionPane(GridOptions gridOption) {
		this.gridOption = gridOption;
		this.cPoint1 = this.gridOption.getColorPoint1();
		this.cPoint = this.gridOption.getColorPoint();
		this.cUnit = this.gridOption.getColorUnit();
		this.cellWidth = this.gridOption.getZoom();
		this.point = this.gridOption.getPoint();

		this.setLayout(new BorderLayout(10, 10));

		JPanel panelButton = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 5));
		panelButton.add(jbColor1);
		panelButton.add(jbColor2);
		panelButton.add(jbColor3);
		panelButton.add(new JLabel("warp/weft size"));
		panelButton.add(jtPoint);
		panelButton.add(jbPreview);

		jbColor1.setActionCommand("COLOR1");
		jbColor2.setActionCommand("COLOR2");
		jbColor3.setActionCommand("COLOR3");
		jbPreview.setActionCommand("PREVIEW");

		jbColor1.addActionListener(this);
		jbColor2.addActionListener(this);
		jbColor3.addActionListener(this);
		jbPreview.addActionListener(this);

		this.add(previewPane, BorderLayout.CENTER);
		this.add(panelButton, BorderLayout.NORTH);
		this.jtPoint.setText(String.valueOf(this.gridOption.getPoint()));
	}

	class PreviewPane extends JPanel {
		@Override
		public void paint(Graphics g) {
			super.paint(g);
			int w = this.getWidth();
			int h = this.getHeight();
			g.setColor(Color.WHITE);

			int c = 0;
			int point2 = point * 2;
			for (int i = cellWidth; i < w; i += cellWidth) {
				c++;
				if (c % point2 == 0)
					g.setColor(cPoint1);
				else if (c % point == 0)
					g.setColor(cPoint);
				else
					g.setColor(cUnit);

				g.drawLine(i, 0, i, h);
			}

			c = 0;
			for (int i = cellWidth; i < h; i += cellWidth) {
				c++;
				if (c % point2 == 0)
					g.setColor(cPoint1);
				else if (c % point == 0)
					g.setColor(cPoint);
				else
					g.setColor(cUnit);

				g.drawLine(0, i, w, i);
			}

			g.setColor(Color.DARK_GRAY);
			g.drawRect(0, 0, w, h);
		}
	}

	public GridOptions getGridOption() {
		return gridOption;
	}

	public void setGridOption(GridOptions gridOption) {
		this.gridOption = gridOption;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();

		if ("PREVIEW".equals(cmd)) {
			try {
				point = Integer.parseInt(jtPoint.getText());
			} catch (Exception es) {
				point = 10;
			}
		} else {
			Color c = JColorChooser.showDialog(this, "Select Grid Color", null);
			if (c != null) {
				if ("COLOR1".equals(cmd)) {
					this.cUnit = c;
				} else if ("COLOR2".equals(cmd)) {
					this.cPoint = c;
				} else {
					this.cPoint1 = c;
				}
			}
		}
		previewPane.repaint();
	}

	public void saveProperties() {
		this.gridOption.setColorPoint(this.cPoint);
		this.gridOption.setColorUnit(this.cUnit);
		this.gridOption.setColorPoint1(this.cPoint1);

		this.gridOption.setPoint(this.point);
		this.gridOption.setZoom(this.cellWidth);
	}
}
