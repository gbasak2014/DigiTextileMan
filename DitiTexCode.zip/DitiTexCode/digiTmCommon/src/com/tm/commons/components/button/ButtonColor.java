package com.tm.commons.components.button;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import com.tm.commons.theme.DigiTmTheme;

public class ButtonColor extends JButton {
	private static final long serialVersionUID = -2488644663921589744L;

	public ButtonColor(ActionListener listener, Color bgColor, String title) {
		super();
		this.setBackground(bgColor);
		this.setBorder(DigiTmTheme.getLineBorder());
		this.addActionListener(listener);
		this.setToolTipText(title);
		this.setPreferredSize(new Dimension(20, 20));
	}
}
