package com.tm.commons.components.button;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import com.tm.commons.theme.DigiTmTheme;

/**
 * Base class for drawing toolbar button
 * 
 * @author Gouranga Basak
 * 
 */
public class ButtonDrawingTool extends JButton {
	private static final long serialVersionUID = 2588302121587005260L;
	BufferedImage img;
	boolean prevPressed = false;

	public ButtonDrawingTool(int action, ActionListener listener,
			String imagePath, String title, boolean saveImage, boolean opaque) {
		super();
		this.setBackground(DigiTmTheme.getBgColor());
		this.setOpaque(opaque);
		this.setActionCommand(String.valueOf(action));
		if (listener != null) {
			this.addActionListener(listener);
		}

		if (imagePath != null) {
			URL url = this.getClass().getResource(imagePath);
			if (url != null) {
				this.setIcon(new ImageIcon(url));
				try {
					this.img = ImageIO.read(url);
				} catch (Exception e) {
				}
			}
		}
		this.setToolTipText(title);

		this.setPreferredSize(new Dimension(35, 20));
		this.setBorder(BorderFactory.createEmptyBorder());
	}

	public ButtonDrawingTool(int action, ActionListener listener,
			String imagePath, String title, boolean saveImage) {
		this(action, listener, imagePath, title, saveImage, true);
	}

	public ButtonDrawingTool(int action, ActionListener listener, String title) {
		this(action, listener, null, title, false);
	}

	public ButtonDrawingTool(int action, String title) {
		this(action, null, null, title, false);
	}

	@Override
	protected void paintComponent(Graphics g) {
		if (getModel().isRollover()) {
			this.setBackground(DigiTmTheme.getHighlightColor());
		} else if (getModel().isPressed()) {
			setBorder(BorderFactory.createLoweredBevelBorder());
		} else {
			this.setBackground(DigiTmTheme.getBgColor());
		}

		super.paintComponent(g);
	}

	public void selectMe() {
		this.setBorder(BorderFactory.createLoweredBevelBorder());
	}

	public void deselectMe() {
		this.setBorder(BorderFactory.createEmptyBorder());
	}

	public BufferedImage getImage() {
		return this.img;
	}

}
