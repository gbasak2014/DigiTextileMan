package com.tm.commons.components.button;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import com.tm.commons.theme.DigiTmTheme;

public class ButtonMenuItem extends JButton {

	private static final long serialVersionUID = 3509399029493926529L;

	public ButtonMenuItem(int action, ActionListener listener, String imagePath, String title) {
		super();
		this.setBackground(DigiTmTheme.getBgColor());
		this.setActionCommand(String.valueOf(action));
		if (listener != null) {
			this.addActionListener(listener);
		}

		if (imagePath != null) {
			try {
				URL url = this.getClass().getResource(imagePath);
				if (url != null) {
					this.setIcon(new ImageIcon(url));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (title != null) {
			this.setToolTipText(title);
			this.setText(title);
		}

		this.setPreferredSize(new Dimension(20, 20));
		this.setBorder(BorderFactory.createEmptyBorder());
	}

	public ButtonMenuItem(int action, ActionListener listener, String title) {
		this(action, listener, null, title);
	}

	public ButtonMenuItem(int action, String title) {
		this(action, null, null, title);
	}

	@Override
	protected void paintComponent(Graphics g) {
		if (getModel().isRollover()) {
			this.setBackground(DigiTmTheme.getHighlightColor());
			setBorder(DigiTmTheme.getLineBorderHighlight());
		} else if (getModel().isPressed())
			setBorder(BorderFactory.createLineBorder(Color.RED));
		else {
			this.setBackground(DigiTmTheme.getBgColor());
			this.setBorder(BorderFactory.createEmptyBorder());
		}

		super.paintComponent(g);
	}
}
