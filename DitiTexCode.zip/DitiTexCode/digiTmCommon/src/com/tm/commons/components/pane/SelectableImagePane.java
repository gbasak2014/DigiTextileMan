package com.tm.commons.components.pane;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

public class SelectableImagePane extends JPanel implements MouseMotionListener, MouseListener {
	static final int MAX_ZOOM = 5;

	BufferedImage image;
	BufferedImage drawImage;

	int zoom = 1;

	int x1, y1, x2, y2;
	boolean isSelected;
	boolean isReplaceColor;

	Color color;

	int moveX;
	int moveY;

	final byte FULL = 0;
	final byte LEFT = 1;
	final byte RIGHT = 2;
	final byte TOP = 3;
	final byte BOTTOM = 4;
	byte selectMode = FULL;

	final float dsh[] = { 5.0f };
	final BasicStroke dashed = new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 2.0f, dsh, 0.0f);

	public SelectableImagePane() {
		addEventListener();
	}

	public void addEventListener() {
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
	}

	public void removeEventListener() {
		this.removeMouseListener(this);
		this.removeMouseMotionListener(this);
	}

	public void refreshSize() {
		this.setSize(image.getWidth() * zoom, image.getHeight() * zoom);
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		if (drawImage != null) {
			Graphics2D g2d = (Graphics2D) g;
			g2d.scale(zoom, zoom);
			g2d.setColor(Color.DARK_GRAY);
			g2d.fillRect(0, 0, this.getWidth(), this.getHeight());
			g2d.drawImage(drawImage, 0, 0, this);
		}
	}

	void paintOld(Graphics g) {
		// Graphics2D g2d = (Graphics2D) g;
		g.setColor(Color.DARK_GRAY);
		g.fillRect(0, 0, this.drawImage.getWidth(), this.drawImage.getHeight());
		g.drawImage(image, 0, 0, this);
	}

	public void zoom(int val) {
		this.zoom = this.zoom + val;
		if (this.zoom < 1) {
			this.zoom = 1;

		} else if (this.zoom > MAX_ZOOM) {
			this.zoom = MAX_ZOOM;
		}
		repaint();

		int w = this.image.getWidth() * zoom;
		int h = this.image.getHeight() * zoom;

		Dimension d = new Dimension(w, h);
		this.setPreferredSize(d);
		this.setSize(d);
	}

	public BufferedImage getImage() {
		return this.image;
	}

	@Override
	public void mousePressed(MouseEvent e) {
		int x = e.getX() / zoom;
		int y = e.getY() / zoom;

		if (this.isSelected) {
			if ((x >= x1 - 1 && x <= x1 + 1) && y > y1 && y < y2) {
				this.selectMode = LEFT;

			} else if ((x >= x2 - 1 && x <= x2 + 1) && y > y1 && y < y2) {
				this.selectMode = RIGHT;
			} else if ((y >= y1 - 1 && y <= y1 + 1) && x > x1 && x < x2) {
				this.selectMode = TOP;
			} else if ((y >= y2 - 1 && y <= y2 + 1) && x > x1 && x < x2) {
				this.selectMode = BOTTOM;
			} else {
				this.selectMode = FULL;
				this.isSelected = false;
				x1 = x;
				y1 = y;
			}
		} else {
			x1 = x;
			y1 = y;
			this.isSelected = false;
		}

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		this.saveSelect();
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		int x = e.getX() / zoom;
		int y = e.getY() / zoom;
		this.moveX = x;
		this.moveY = y;
		if (isReplaceColor) {
			this.drawSelect();
		} else if (this.isSelected) {
			if ((x >= x1 - 1 && x <= x1 + 1) && y > y1 && y < y2) {
				this.setCursor(new Cursor(Cursor.E_RESIZE_CURSOR));
			} else if ((x >= x2 - 1 && x <= x2 + 1) && y > y1 && y < y2) {
				this.setCursor(new Cursor(Cursor.W_RESIZE_CURSOR));
			} else if ((y >= y1 - 1 && y <= y1 + 1) && x > x1 && x < x2) {
				this.setCursor(new Cursor(Cursor.N_RESIZE_CURSOR));
			} else if ((y >= y2 - 1 && y <= y2 + 1) && x > x1 && x < x2) {
				this.setCursor(new Cursor(Cursor.S_RESIZE_CURSOR));
			} else {
				this.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}
		}
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		int x = e.getX() / zoom;
		int y = e.getY() / zoom;

		if (this.isSelected) {
			switch (this.selectMode) {
			case LEFT:
				x1 = x;
				break;
			case RIGHT:
				x2 = x;
				break;
			case TOP:
				y1 = y;
				break;
			case BOTTOM:
				y2 = y;
				break;
			default:
				x2 = x;
				y2 = y;
				break;
			}
		} else {
			x2 = x;
			y2 = y;
		}

		this.drawSelect();
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	public void drawSelect() {
		int x = x1 > x2 ? x2 : x1;
		int y = y1 > y2 ? y2 : y1;
		int w = Math.abs(x2 - x1);
		int h = Math.abs(y2 - y1);

		Graphics2D g = this.drawImage.createGraphics();
		paintOld(g);
		g.setXORMode(Color.WHITE);
		g.setColor(Color.RED);
		g.setStroke(dashed);
		g.drawRect(x, y, w, h);
		repaint();
	}

	public void saveSelect() {
		int tmp;
		if (x1 > x2) {
			tmp = x1;
			x1 = x2;
			x2 = tmp;
		}
		if (y1 > y2) {
			tmp = y1;
			y1 = y2;
			y2 = tmp;
		}
		isSelected = true;
		isReplaceColor = false;
	}

	public BufferedImage getSelectedImage() {
		try {
			if (isSelected) {
				int x = x1 > x2 ? x2 : x1;
				int y = y1 > y2 ? y2 : y1;
				int w = Math.abs(x2 - x1) + 1;
				int h = Math.abs(y2 - y1) + 1;

				//System.out.println(x + "," + y + "," + w + "," + h);
				BufferedImage img = image.getSubimage(x, y, w, h);
				if (img != null) {
					BufferedImage tmp = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_RGB);
					Graphics g = tmp.getGraphics();
					g.setColor(Color.WHITE);
					g.fillRect(0, 0, tmp.getWidth(), tmp.getHeight());
					g.drawImage(img, 0, 0, this);
					return tmp;
				}
			}
		} catch (Exception e) {
		}

		return null;
	}

	public void setImage(BufferedImage img) {
		this.image = img;
		int w = img.getWidth() * zoom;
		int h = img.getHeight() * zoom;
		if (this.drawImage == null || this.drawImage.getWidth() < w || this.drawImage.getHeight() < h) {
			this.drawImage = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);

			Graphics g = drawImage.getGraphics();
			g.setColor(Color.DARK_GRAY);
			g.fillRect(0, 0, this.drawImage.getWidth(), this.drawImage.getHeight());
			g.drawImage(image, 0, 0, this);
			this.setSize(image.getWidth() * zoom, image.getHeight() * zoom);
		}

		Dimension d = new Dimension(w, h);
		this.setPreferredSize(d);
		this.setSize(d);

		repaint();
	}
}
