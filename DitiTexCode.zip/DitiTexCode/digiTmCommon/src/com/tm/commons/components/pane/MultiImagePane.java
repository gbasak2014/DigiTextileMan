package com.tm.commons.components.pane;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class MultiImagePane extends JPanel {
	private static final long serialVersionUID = 1489154126528123495L;
	BufferedImage img1;
	BufferedImage img2;
	boolean isHorizontal = true;
	int zoom = 1;
	int x = 0;
	int y = 0;

	public MultiImagePane() {
		// TODO Auto-generated constructor stub
	}

	public void setHorizontal(boolean horizontal) {
		this.isHorizontal = horizontal;
	}

	@Override
	public void paint(Graphics g) {
		int w = this.getWidth();
		int h = this.getHeight();
		g.setColor(Color.DARK_GRAY);
		g.fillRect(0, 0, w, h);
		g.setColor(Color.WHITE);
		if (img1 != null) {
			g.drawImage(img1, -x * zoom + 1, -y * zoom + 1, img1.getWidth() * zoom, img1.getHeight() * zoom, this);
			g.drawRect(-x*zoom, -y*zoom, img1.getWidth() * zoom + 2, img1.getHeight() * zoom + 2);
			if (img2 != null) {
				int l = -x * zoom + 1;
				int t = -y * zoom + 1;
				if (this.isHorizontal) {
					l = l + img1.getWidth() * zoom + 2;
				} else {
					t = t + img1.getHeight() * zoom + 2;
				}
				g.drawImage(img2, l, t, img2.getWidth() * zoom, img2.getHeight() * zoom, this);
				g.drawRect(l-1, t-1, img2.getWidth() * zoom + 2, img2.getHeight() * zoom + 2);
			}
		}

	}

	public void setZoom(int z) {
		this.zoom = this.zoom + z;
		if (this.zoom < 1) {
			this.zoom = 1;
		}

		int w = 0;
		int h = 0;
		if (this.img1 != null) {
			w = img1.getWidth() * zoom;
			h = img1.getHeight() * zoom;
		}
		if (this.img2 != null) {
			if (this.isHorizontal) {
				w = w + img2.getWidth() * zoom;
				if (this.img1.getHeight() < this.img2.getHeight()) {
					h = this.img2.getHeight() * this.zoom;
				}
			} else {
				h = h + img2.getHeight() * zoom;
				if (this.img1.getWidth() < this.img2.getWidth()) {
					w = this.img2.getWidth() * this.zoom;
				}
			}
		}

		if (w > 0 && h > 0) {
			this.setSize(w+4, h+4);
			this.setPreferredSize(new Dimension(w+4, h+4));
		}
	}

	public void clearImages()
	{
		this.img1 = null;
		this.img2 = null;
	}
	
	public void setImage(BufferedImage img) {
		if (img1 == null) {
			this.img1 = img;
			this.setZoom(0);
		} else if (img2 == null) {
			this.img2 = img;
			this.setZoom(0);
		} else {
			JOptionPane.showMessageDialog(this, "You already have two images!!", "Image Mix", JOptionPane.ERROR_MESSAGE);
		}
	}

	public void setImages(BufferedImage img1, BufferedImage img2)
	{
		this.img1 = img1;
		this.img2 = img2;
	}
	
	public void swapImage() {
		if (this.img1 != null && this.img2 != null) {
			BufferedImage img = this.img1;
			this.img1 = this.img2;
			this.img2 = img;
		}
	}

	public void setPos(int x, int y) {
		this.x = x;
		this.y = y;
		this.repaint();
	}

	public BufferedImage mergeImages(int start) {
		if (this.img1 == null || this.img2 == null) {
			JOptionPane.showMessageDialog(this, "Please open two imags to merge!!");
			return null;
		}

		int w = this.img1.getWidth();
		int h = this.img1.getHeight();
		if (this.isHorizontal) {
			w = w + this.img2.getWidth();

			if (this.img1.getHeight() < this.img2.getHeight()) {
				h = this.img2.getHeight();
			}
		} else {
			h = h + this.img2.getHeight();
			if (this.img1.getWidth() < this.img2.getWidth()) {
				w = this.img2.getWidth();
			}
		}

		BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
		Graphics2D g = img.createGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, w, h);
		g.dispose();

		if(this.isHorizontal)
		{
			horizontalMix(img, start);
		}
		else
		{
			verticalMix(img, start);
		}

		return img;
	}

	void verticalMix(BufferedImage img, int start)
	{

		int[] data = ((DataBufferInt) img.getRaster().getDataBuffer()).getData();
		int[] data1 = ((DataBufferInt) this.img1.getRaster().getDataBuffer()).getData();
		int[] data2 = ((DataBufferInt) this.img2.getRaster().getDataBuffer()).getData();

		int x = 0, x1 = 0, x2 = 0;
		int y = 0, y1 = 0, y2 = 0;
		int w = img.getWidth();
		int h = img.getHeight();
		int w1 = this.img1.getWidth();
		int h1 = this.img1.getHeight();
		int w2 = this.img2.getWidth();
		int h2 = this.img2.getHeight();

		for (y1 = 0; y1 < start && y1 < h1; y1++) {
			for (x1 = 0; x1 < w1; x1++) {
				data[x1 + y1 * w] = data1[x1 + y1 * w1];
			}
		}

		y = y1;
		while (y1 < h1 && y2 < h2) {
			for (x1 = 0; x1 < w1; x1++) {
				data[x1 + y * w] = data1[x1 + y1 * w1];
			}

			y++;
			for (x2 = 0; x2 < w2; x2++) {
				data[x2 + y * w] = data2[x2 + y2 * w2];
			}

			y1++;
			y2++;
			y++;
		}

		while (y1 < h1) {
			for (x1 = 0; x1 < w1; x1++) {
				data[x1 + y * w] = data1[x1 + y1 * w1];
			}
			y1++;
			y++;
		}
		while (y2 < h2) {
			for (x2 = 0; x2 < w2; x2++) {
				data[x2 + y * w] = data2[x2 + y2 * w2];
			}
			y2++;
			y++;
		}
	}
	
	void horizontalMix(BufferedImage img, int start) {
		int[] data = ((DataBufferInt) img.getRaster().getDataBuffer()).getData();
		int[] data1 = ((DataBufferInt) this.img1.getRaster().getDataBuffer()).getData();
		int[] data2 = ((DataBufferInt) this.img2.getRaster().getDataBuffer()).getData();

		int x = 0, x1 = 0, x2 = 0;
		int y = 0, y1 = 0, y2 = 0;
		int w = img.getWidth();
		int h = img.getHeight();
		int w1 = this.img1.getWidth();
		int h1 = this.img1.getHeight();
		int w2 = this.img2.getWidth();
		int h2 = this.img2.getHeight();

		for (x1 = 0; x1 < start && x1 < w1; x1++) {
			for (y1 = 0; y1 < h1; y1++) {
				data[x1 + y1 * w] = data1[x1 + y1 * w1];
			}
		}
		x = x1;

		while (x1 < w1 && x2 < w2) {
			for (y1 = 0; y1 < h1; y1++) {
				data[x + y1 * w] = data1[x1 + y1 * w1];
			}

			x++;
			for (y2 = 0; y2 < h2; y2++) {
				data[x + y2 * w] = data2[x2 + y2 * w2];
			}

			x1++;
			x2++;
			x++;
		}

		while (x1 < w1) {
			for (y1 = 0; y1 < h1; y1++) {
				data[x + y1 * w] = data1[x1 + y1 * w1];
			}
			x1++;
			x++;
		}
		while (x2 < w2) {
			for (y2 = 0; y2 < h2; y2++) {
				data[x + y2 * w] = data2[x2 + y2 * w2];
			}
			x2++;
			x++;
		}
	}

	public BufferedImage getImageOne()
	{
		return this.img1;
	}
	public BufferedImage getImageTwo()
	{
		return this.img2;
	}	
}
