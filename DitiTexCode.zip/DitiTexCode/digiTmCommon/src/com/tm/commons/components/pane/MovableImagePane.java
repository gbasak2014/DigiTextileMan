package com.tm.commons.components.pane;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

public class MovableImagePane extends JPanel {

	private static final long serialVersionUID = 1216739676666674837L;

	int left, top, x1, y1, x2, y2;
	BufferedImage image;

	int zoom = 1;

	void draggMe(int x, int y) {
		x2 = x;
		y2 = y;
		repaint();
	}

	public MovableImagePane() {
		this.setCursor(new Cursor(Cursor.HAND_CURSOR));
		this.addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseDragged(MouseEvent e) {
				draggMe(e.getX() / zoom, e.getY() / zoom);
			}
		});

		this.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				x1 = x2 = e.getX() / zoom;
				y1 = y2 = e.getY() / zoom;
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				left = left + x2 - x1;
				top = top + y2 - y1;
			}
		});
	}

	public MovableImagePane(BufferedImage img) {
		this();
		this.image = img;
		left = top = x1 = y1 = x2 = y2 = 0;
	}

	public void setImage(BufferedImage img) {
		this.image = img;
		if (img != null) {
			left = (getWidth() - img.getWidth()) / 2;
			top = (getHeight() - img.getHeight()) / 2;

			if (left < 0) {
				left = 0;
			}
			if (top < 0) {
				top = 0;
			}

			x1 = y1 = x2 = y2 = 0;
		}
		repaint();
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		g.setColor(Color.LIGHT_GRAY);
		g.fillRect(0, 0, getWidth(), getHeight());
		if (image != null) {
			int x = left / zoom + x2 - x1;
			int y = top / zoom + y2 - y1;
			g.setColor(Color.WHITE);
			g.drawRect((x - 2) * zoom, (y - 2) * zoom, (image.getWidth() + 4) * zoom, (image.getHeight() + 4) * zoom);
			g.drawImage(image, x * zoom, y * zoom, image.getWidth() * zoom, image.getHeight() * zoom, this);
		}
	}

	public BufferedImage getImage() {
		return image;
	}

	public void zoom(int zoom) {
		this.zoom = this.zoom + zoom;
		if (this.zoom < 1) {
			this.zoom = 1;
		}

		repaint();
	}
}