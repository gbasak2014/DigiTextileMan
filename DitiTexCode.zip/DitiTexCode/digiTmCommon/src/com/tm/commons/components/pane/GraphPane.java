package com.tm.commons.components.pane;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.JPanel;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.DrawingImage;
import com.tm.commons.components.GridImage;
import com.tm.commons.drawing.tool.Pen;
import com.tm.commons.drawing.tool.PenHolder;
import com.tm.commons.drawing.tool.SelectFreeHand;
import com.tm.commons.image.ImageUtils;
import com.tm.commons.listener.DrawingListener;
import com.tm.commons.listener.RulerListener;
import com.tm.commons.tool.Ruler;
import com.tm.commons.undo.UndoManager;
import com.tm.commons.undo.UndoType;
import com.tm.commons.undo.Undoable;

public class GraphPane extends JPanel implements RulerListener {

	private static final long serialVersionUID = -6193490864190695878L;

	BufferedImage savedImage;
	DrawingImage drawingImage;
	GridImage gridImage;

	int imgLeft = 0;
	int imgTop = 0;
	int imgWidth;
	int imgHeight;

	PenHolder penHolder;

	int rulerStartIndex;
	int rulerEndIndex;
	byte rulerType;
	String filePath;

	Rectangle drawingArea;

	UndoManager undoManager;

	Rectangle arrangeArea;

	Cursor cursor;

	public GraphPane(BufferedImage savedImage, DrawingImage drawingImage, GridImage gridImage,
			DrawingListener drawingHandler, PenHolder penHolder, String filePath) {
		this.savedImage = savedImage;
		this.drawingImage = drawingImage;
		this.gridImage = gridImage;

		this.imgWidth = this.savedImage.getWidth();
		this.imgHeight = this.savedImage.getHeight();
		if (drawingHandler != null) {
			setDrawingHandler(drawingHandler);
		}
		this.penHolder = penHolder;
		this.gridImage.createGrid(0, 0, this.savedImage.getWidth(), this.savedImage.getHeight());
		this.filePath = filePath;
		this.undoManager = new UndoManager(PathOptionPane.getTempDir() + "/" + System.currentTimeMillis(), this);

		this.cursor = new Cursor(Cursor.DEFAULT_CURSOR);
	}

	public GraphPane(BufferedImage savedImage, DrawingImage drawingImage, GridImage gridImage, PenHolder penHolder,
			String filePath) {
		this(savedImage, drawingImage, gridImage, null, penHolder, filePath);
	}

	@Override
	public void paint(Graphics g) {
		BufferedImage img = this.drawingImage.getImage();
		int zoom = this.gridImage.getGridOptions().getZoom();
		g.setColor(Color.GRAY);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		g.drawImage(img, -this.imgLeft * zoom, -this.imgTop * zoom, img.getWidth() * zoom, img.getHeight() * zoom,
				this);

		if (this.penHolder.getPen() != null) {
			this.penHolder.getPen().select((Graphics2D) g, this.imgLeft, this.imgTop);
			if (this.drawingArea != null) {
				this.penHolder.getPen().select(this.drawingArea, (Graphics2D) g, this.imgLeft, this.imgTop);
			}
		}

		if (this.gridImage != null && zoom > 2) {
			g.drawImage(this.gridImage.getImage(), 0, 0, this);
		}

		if (this.rulerStartIndex > 0) {
			g.setColor(Color.GREEN);
			g.setXORMode(Color.WHITE);
			if (this.rulerType == Ruler.HORZ) {
				g.fillRect(this.rulerStartIndex * zoom, 0, zoom, this.getHeight());
			} else {
				g.fillRect(0, this.rulerStartIndex * zoom, this.getWidth(), zoom);
			}
		}
		if (this.rulerEndIndex > 0) {
			g.setColor(Color.GREEN);
			g.setXORMode(Color.WHITE);
			if (this.rulerType == Ruler.HORZ) {
				g.fillRect(this.rulerEndIndex * zoom, 0, zoom, this.getHeight());
			} else {
				g.fillRect(0, this.rulerEndIndex * zoom, this.getWidth(), zoom);
			}
		}
		g.dispose();
	}

	public void setDrawingHandler(DrawingListener drawingHandler) {
		this.addMouseListener(drawingHandler);
		this.addMouseMotionListener(drawingHandler);
		drawingHandler.setGraphPane(this);
	}

	public void removeDrawingHandler(DrawingListener drawingHandler) {
		this.removeMouseListener(drawingHandler);
		this.removeMouseMotionListener(drawingHandler);
	}

	public void scroll(int x, int y) {
		if (this.imgLeft != x || this.imgTop != y) {
			this.imgLeft = x;
			this.imgTop = y;
			this.gridImage.createGrid(imgLeft, imgTop, this.savedImage.getWidth(), this.savedImage.getHeight());

			// this.repaint();
		}
	}

	public BufferedImage getSavedImage() {
		return savedImage;
	}

	public DrawingImage getDrawingImage() {
		return drawingImage;
	}

	public int getImgLeft() {
		return imgLeft;
	}

	public int getImgTop() {
		return imgTop;
	}

	public void setSavedImage(BufferedImage savedImage) {
		this.savedImage = savedImage;
		this.imgWidth = this.savedImage.getWidth();
		this.imgHeight = this.savedImage.getHeight();
	}

	public void setDrawingImage(DrawingImage drawingImage) {
		this.drawingImage = drawingImage;
	}

	public void setZoom(int zoom) {
		if (this.gridImage.getGridOptions().getZoom() != zoom) {
			this.gridImage.getGridOptions().setZoom(zoom);
			this.gridImage.createGrid(this.imgLeft, this.imgTop, this.savedImage.getWidth(),
					this.savedImage.getHeight());
			this.repaint();
		}
	}

	public int getZoom() {
		return this.gridImage.getGridOptions().getZoom();
	}

	public void setImgLeft(int imgLeft) {
		this.imgLeft = imgLeft;
	}

	public void setImgTop(int imgTop) {
		this.imgTop = imgTop;
	}

	public int getImgWidth() {
		return this.savedImage.getWidth();
	}

	public int getImgHeight() {
		return this.savedImage.getHeight();
	}

	public void setImgWidth(int imgWidth) {
		this.imgWidth = imgWidth;
	}

	public void setImgHeight(int imgHeight) {
		this.imgHeight = imgHeight;
	}

	@Override
	public void endIndexSet(byte type, int index, int button, int clickCount) {
		this.rulerEndIndex = index;
		repaint();
	}

	@Override
	public void startIndexSet(byte type, int index, int button, int clickCount) {

		if (clickCount >= 2 && button != 3) {
			if (Ruler.VERTZ == type) {
				this.removeRow(index);
			} else {
				this.removeColumn(index);
			}

		} else if (button == 3) {
			if (Ruler.VERTZ == type) {
				this.insertRows(index, 1);
			} else {
				this.insertColumns(index, 1);
			}
		} else {
			this.rulerStartIndex = index;
			this.rulerType = type;
			this.rulerEndIndex = -1;
		}
		repaint();
	}

	public void clearRulerIndex() {
		this.rulerEndIndex = this.rulerStartIndex = -1;
		repaint();
	}

	public void moveShape(int dx, int dy) {
		Pen pen = this.penHolder.getPen();
		if (pen != null) {
			pen.move(dx, dy);
			pen.draw();
			this.repaint();
		}
	}

	public void setDrawingArea(Rectangle area) {
		if (area != null) {
			this.drawingArea = new Rectangle(area);
		} else {
			this.drawingArea = null;
		}
		this.repaint();
	}

	public Rectangle getDrawingArea() {
		return this.drawingArea;
	}

	public void commit() {
		if (this.penHolder.getPen() != null) {
			this.penHolder.getPen().save();
			this.repaint();
		}
	}

	public void cancel() {
		if (this.penHolder.getPen() != null) {
			Pen pen = this.penHolder.getPen();
			pen.clear();
			pen.setStartPoint(-1, -1);
			pen.draw();
			this.repaint();
		}
	}

	public BufferedImage getSelectedImage() {
		if (this.penHolder.getPen().getType() == DrawingToolEnum.SELECT
				|| this.penHolder.getPen().getType() == DrawingToolEnum.SELECT_RAND) {

			Rectangle select = this.penHolder.getPen().getBound();
			Rectangle imgSize = new Rectangle(0, 0, this.imgWidth, this.imgHeight);

			Rectangle size = imgSize.intersection(select);

			if (size.width <= 0 || size.height <= 0) {
				return null;
			}

			BufferedImage img = this.savedImage.getSubimage(size.x, size.y, size.width, size.height);

			if (img != null) {
				if (this.penHolder.getPen().getType() == DrawingToolEnum.SELECT) {
					BufferedImage newImg = new BufferedImage(size.width, size.height, BufferedImage.TYPE_INT_RGB);
					Graphics2D g = newImg.createGraphics();
					g.drawImage(img, 0, 0, this);
					return newImg;
				} else {
					List<Point> pts = ((SelectFreeHand) this.penHolder.getPen()).getPoints();
					return this.getSelectedImage(pts, img, size.x, size.y);
				}
			}

		}

		return null;

	}

	public BufferedImage getSelectedImage(List<Point> points, BufferedImage img, int left, int top) {
		int w = img.getWidth() + 2;
		int h = img.getHeight() + 2;
		BufferedImage tmpImg = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = tmpImg.createGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, w, h);
		g.drawImage(img, 1, 1, this);
		g.dispose();

		left = left - 1;
		top = top - 1;

		int argb = (new Color(0, 0, 0, 0)).getRGB();

		int[] data = ((DataBufferInt) tmpImg.getRaster().getDataBuffer()).getData();

		int i = 0;
		Point pt2 = null;
		Point pt1 = points.get(0);
		int x1 = pt1.x;
		int y1 = pt1.y;

		for (i = 1; i < points.size(); i++) {
			pt2 = points.get(i);
			ImageUtils.drawLine(data, x1 - left, y1 - top, pt2.x - left, pt2.y - top, w, h, argb);
			x1 = pt2.x;
			y1 = pt2.y;
		}

		ImageUtils.drawLine(data, pt1.x - left, pt1.y - top, pt2.x - left, pt2.y - top, w, h, argb);

		ImageUtils.floodFill(data, argb, w, h, 0, 0);

		return tmpImg.getSubimage(2, 2, w - 4, h - 4);
	}

	public void clearSelectedArea() {
		if (this.penHolder.getPen().getType() == DrawingToolEnum.SELECT
				|| this.penHolder.getPen().getType() == DrawingToolEnum.SELECT_RAND) {
			Rectangle select = this.penHolder.getPen().getBound();
			Rectangle imgSize = new Rectangle(0, 0, this.imgWidth, this.imgHeight);

			Rectangle size = imgSize.intersection(select);

			if (size.width <= 0 || size.height <= 0) {
				return;
			}
			Graphics2D g;
			if (this.penHolder.getPen().getType() == DrawingToolEnum.SELECT) {
				g = this.savedImage.createGraphics();
				g.setColor(Color.WHITE);
				g.fillRect(size.x, size.y, size.width, size.height);
				g.dispose();
				g = this.drawingImage.getImage().createGraphics();
				g.setColor(Color.WHITE);
				g.fillRect(size.x, size.y, size.width, size.height);
				g.dispose();
			} else if (this.penHolder.getPen().getType() == DrawingToolEnum.SELECT_RAND) {
				BufferedImage img = this.getSelectedImage();
				if (img != null) {
					g = this.savedImage.createGraphics();
					g.setXORMode(Color.WHITE);
					g.drawImage(img, size.x + 1, size.y + 1, this);
					g.dispose();
					g = this.drawingImage.getImage().createGraphics();
					g.drawImage(this.savedImage, 0, 0, this);
					g.dispose();
				}
			}

		}

	}

	public PenHolder getPenHolder() {
		return penHolder;
	}

	public int getRulerStartIndex() {
		return rulerStartIndex;
	}

	public int getRulerEndIndex() {
		return rulerEndIndex;
	}

	public byte getRulerType() {
		return rulerType;
	}

	public void insertRows(int index, int rows) {
		this.undoManager.addUndoState(-1, -1, this.getSavedImage());

		BufferedImage img = ImageUtils.insertRows(this.getSavedImage(), index + this.getImgTop(), rows);

		this.setSavedImage(img);
		drawingImage.copyImage(img);
		this.gridImage.createGrid(this.getImgLeft(), this.getImgTop(), this.getImgWidth(), this.getImgHeight());
		this.penHolder.getPen().setGraphPane(this);
	}

	public void cropImage(BufferedImage img) {
		this.undoManager.addUndoState(-1, -1, this.getSavedImage());
		this.setSavedImage(img);
		drawingImage.copyImage(img);
		this.gridImage.createGrid(this.getImgLeft(), this.getImgTop(), this.getImgWidth(), this.getImgHeight());
		this.penHolder.getPen().setGraphPane(this);
	}

	public void makeBlackColored() {
		int[] data = ((DataBufferInt) this.getSavedImage().getRaster().getDataBuffer()).getData();
		int rgb = 0xFFFFFFFF;
		int rgbBlack = Color.BLACK.getRGB();
		int len = data.length;
		for (int i = 0; i < len; i++) {
			if ((data[i] | 0xFF000000) != rgb) {
				data[i] = rgbBlack;
			}
		}

		Graphics2D g = this.drawingImage.getImage().createGraphics();
		g.drawImage(this.savedImage, 0, 0, this);
		g.dispose();
	}

	public void slidUp() {
		int[] data = ((DataBufferInt) this.getSavedImage().getRaster().getDataBuffer()).getData();
		int[] bak = new int[this.imgWidth];

		for (int x = 0; x < this.imgWidth; x++) {
			bak[x] = data[x];
		}

		for (int y = 1; y < this.imgHeight; y++) {
			for (int x = 0; x < this.imgWidth; x++) {
				data[(y - 1) * this.imgWidth + x] = data[y * this.imgWidth + x];
			}
		}

		int y = (this.imgHeight) * (this.imgWidth - 1);
		for (int x = 0; x < this.imgWidth; x++) {
			data[y + x] = bak[x];
		}

		Graphics2D g = this.drawingImage.getImage().createGraphics();
		g.drawImage(this.savedImage, 0, 0, this);
		g.dispose();
	}

	public void slidDown() {
		int[] data = ((DataBufferInt) this.getSavedImage().getRaster().getDataBuffer()).getData();
		int[] bak = new int[this.imgWidth];
		int y = (this.imgHeight) * (this.imgWidth - 1);
		for (int x = 0; x < this.imgWidth; x++) {
			bak[x] = data[y + x];
		}

		for (y = this.imgHeight - 2; y >= 0; y--) {
			for (int x = 0; x < this.imgWidth; x++) {
				data[(y + 1) * this.imgWidth + x] = data[y * this.imgWidth + x];
			}
		}

		for (int x = 0; x < this.imgWidth; x++) {
			data[x] = bak[x];
		}

		Graphics2D g = this.drawingImage.getImage().createGraphics();
		g.drawImage(this.savedImage, 0, 0, this);
		g.dispose();
	}

	public void slidLeft() {
		int[] data = ((DataBufferInt) this.getSavedImage().getRaster().getDataBuffer()).getData();
		int[] bak = new int[this.imgHeight];

		for (int y = 0; y < this.imgHeight; y++) {
			bak[y] = data[y * this.imgWidth];
		}

		for (int x = 1; x < this.imgWidth; x++) {
			for (int y = 0; y < this.imgHeight; y++) {
				data[(y) * this.imgWidth + x - 1] = data[y * this.imgWidth + x];
			}
		}

		for (int y = 0; y < this.imgHeight; y++) {
			data[y * this.imgWidth + this.imgWidth - 1] = bak[y];
		}

		Graphics2D g = this.drawingImage.getImage().createGraphics();
		g.drawImage(this.savedImage, 0, 0, this);
		g.dispose();
	}

	public void slidRight() {
		int[] data = ((DataBufferInt) this.getSavedImage().getRaster().getDataBuffer()).getData();
		int[] bak = new int[this.imgHeight];

		for (int y = 0; y < this.imgHeight; y++) {
			bak[y] = data[y * (this.imgWidth) + this.imgWidth - 1];
		}

		for (int y = 0; y < this.imgHeight; y++) {
			for (int x = this.imgWidth - 1; x > 0; x--) {
				data[(y) * (this.imgWidth) + x] = data[(y) * (this.imgWidth) + x - 1];
			}
		}

		for (int y = 0; y < this.imgHeight; y++) {
			data[y * (this.imgWidth)] = bak[y];
		}

		Graphics2D g = this.drawingImage.getImage().createGraphics();
		g.drawImage(this.savedImage, 0, 0, this);
		g.dispose();
	}

	public void reverseColor() {
		this.undoManager.addUndoState(-1, -1, this.getSavedImage());
		int[] data = ((DataBufferInt) this.getSavedImage().getRaster().getDataBuffer()).getData();
		int rgb = 0xFFFFFFFF;
		int rgbBlack = Color.BLACK.getRGB();
		int len = data.length;
		for (int i = 0; i < len; i++) {
			if ((data[i] | 0xFF000000) == rgb) {
				data[i] = rgbBlack;
			} else {
				data[i] = rgb;
			}
		}

		Graphics2D g = this.drawingImage.getImage().createGraphics();
		g.drawImage(this.savedImage, 0, 0, this);
		g.dispose();
	}

	public void replaceColors(int[] oldRgbs, int newRgb) {
		this.undoManager.addUndoState(-1, -1, this.getSavedImage());
		int[] data = ((DataBufferInt) this.getSavedImage().getRaster().getDataBuffer()).getData();
		int len = data.length;
		for (int i = 0; i < len; i++) {
			for (int rgb : oldRgbs) {
				if ((data[i] | 0xff000000) == rgb) {
					data[i] = newRgb;
					break;
				}
			}
		}
		Graphics2D g = this.drawingImage.getImage().createGraphics();
		g.drawImage(this.savedImage, 0, 0, this);
		g.dispose();
	}

	public List<Integer> getUsedColors() {
		Set<Integer> set = new HashSet<Integer>();
		int[] data = ((DataBufferInt) this.getSavedImage().getRaster().getDataBuffer()).getData();
		for (int rgb : data) {
			int tmp = rgb | 0xFF000000;
			if (!set.contains(tmp)) {
				set.add(tmp);
			}
		}

		return new ArrayList<Integer>(set);
	}

	public void insertColumns(int index, int cols) {
		this.undoManager.addUndoState(-1, -1, this.getSavedImage());

		BufferedImage img = ImageUtils.insertCols(this.getSavedImage(), index + this.getImgLeft(), cols);

		this.setSavedImage(img);
		drawingImage.copyImage(img);
		this.gridImage.createGrid(this.getImgLeft(), this.getImgTop(), this.getImgWidth(), this.getImgHeight());
		this.penHolder.getPen().setGraphPane(this);
	}

	public void removeRow(int index) {
		this.undoManager.addUndoState(-1, -1, this.getSavedImage());
		int w = this.getSavedImage().getWidth();
		int h = this.getSavedImage().getHeight();
		int h1 = index + this.getImgTop();
		int h2 = (h - h1 - 1);

		BufferedImage imgTop = this.getSavedImage().getSubimage(0, 0, w, h1);
		BufferedImage imgBottom = this.getSavedImage().getSubimage(0, h1 + 1, w, h2);

		BufferedImage img = new BufferedImage(w, h1 + h2, BufferedImage.TYPE_INT_RGB);
		Graphics g = img.getGraphics();
		g.drawImage(imgTop, 0, 0, this);
		g.drawImage(imgBottom, 0, h1, this);

		this.setSavedImage(img);
		drawingImage.copyImage(img);
		this.gridImage.createGrid(this.getImgLeft(), this.getImgTop(), this.getImgWidth(), this.getImgHeight());
		this.penHolder.getPen().setGraphPane(this);
	}

	public void removeColumn(int index) {
		this.undoManager.addUndoState(-1, -1, this.getSavedImage());
		int w = this.getSavedImage().getWidth();
		int h = this.getSavedImage().getHeight();
		int w1 = index + this.getImgLeft();
		int w2 = (w - w1 - 1);

		//System.out.println("Remove Column>>" + w + ":" + h + ":" + w1 + ":" + w2);
		BufferedImage imgTop = this.getSavedImage().getSubimage(0, 0, w1, h);
		BufferedImage imgBottom = this.getSavedImage().getSubimage(w1 + 1, 0, w2, h);

		BufferedImage img = new BufferedImage(w1 + w2, h, BufferedImage.TYPE_INT_RGB);
		Graphics g = img.getGraphics();
		g.drawImage(imgTop, 0, 0, this);
		g.drawImage(imgBottom, w1, 0, this);

		this.setSavedImage(img);
		drawingImage.copyImage(img);
		this.gridImage.createGrid(this.getImgLeft(), this.getImgTop(), this.getImgWidth(), this.getImgHeight());
		this.penHolder.getPen().setGraphPane(this);
	}

	public void removeRows(int index1, int index2) {
		this.undoManager.addUndoState(-1, -1, this.getSavedImage());

		BufferedImage img = ImageUtils.removeRows(this.getSavedImage(), index1, index2);

		this.setSavedImage(img);
		drawingImage.copyImage(img);
		this.gridImage.createGrid(this.getImgLeft(), this.getImgTop(), this.getImgWidth(), this.getImgHeight());
		this.penHolder.getPen().setGraphPane(this);
	}

	public void removeCols(int index1, int index2) {
		this.undoManager.addUndoState(-1, -1, this.getSavedImage());

		BufferedImage img = ImageUtils.removeCols(this.getSavedImage(), index1, index2);

		this.setSavedImage(img);
		drawingImage.copyImage(img);
		this.gridImage.createGrid(this.getImgLeft(), this.getImgTop(), this.getImgWidth(), this.getImgHeight());
		this.penHolder.getPen().setGraphPane(this);
	}

	public void undo() {
		Undoable state = this.undoManager.undo();
		if (state != null) {
			restoreState(state);
		}
	}

	public void redo() {
		Undoable state = this.undoManager.redo();
		if (state != null) {
			restoreState(state);
		}
	}

	void restoreState(Undoable state) {
		int x;
		int y;
		if (state.getDataType() == UndoType.IMAGE) {
			x = state.getX();
			y = state.getY();
			BufferedImage img = (BufferedImage) state.getObject();
			if (x < 0 || y < 0) {
				this.setSavedImage(img);
			} else {
				Graphics g = this.getSavedImage().getGraphics();
				g.drawImage(img, x, y, this);
				g.dispose();
			}
		} else {
			int[] data = (int[]) state.getObject();
			for (int i = 0; i < data.length - 2; i = i + 3) {
				x = data[i];
				y = data[i + 1];
				int rgb = data[i + 2];
				this.getSavedImage().setRGB(x, y, rgb);
			}
		}

		this.getDrawingImage().copyImage(getSavedImage());
	}

	public void addUndoState(int[] data) {
		this.undoManager.addUndoState(data);
	}

	public void addUndoState(int x, int y, BufferedImage img) {
		this.undoManager.addUndoState(x, y, img);
	}

	public GridImage getGridImage() {
		return gridImage;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public void cleanup() {
		File file = new File(this.undoManager.getResuourcePath());
		if (file.exists()) {
			if (file.isDirectory()) {
				for (File f : file.listFiles()) {
					f.delete();
				}
			}
			file.delete();
		}
	}

	public Rectangle getArrangeArea() {
		return arrangeArea;
	}

	public void setArrangeArea(Rectangle arrangeArea) {
		this.arrangeArea = arrangeArea;
	}

	public void setShowGrid(boolean show) {
		if (this.gridImage.isShowGrid() != show) {
			this.gridImage.setShowGrid(show);
			this.gridImage.createGrid(imgLeft, imgTop, this.savedImage.getWidth(), this.savedImage.getHeight());
		}
	}

	public void addUndoState() {
		this.undoManager.addUndoState(-1, -1, this.getSavedImage());
	}

	public void resetCursor() {
		this.setCursor(this.cursor);
	}

	public void setCustomCurson(Cursor cursor) {
		this.cursor = cursor;
		this.setCursor(this.cursor);
	}
}
