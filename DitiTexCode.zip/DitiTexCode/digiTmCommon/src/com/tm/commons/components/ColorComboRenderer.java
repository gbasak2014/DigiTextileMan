package com.tm.commons.components;

import java.awt.Color;
import java.awt.Component;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

public class ColorComboRenderer extends JLabel implements ListCellRenderer<Integer>{
	private static final long serialVersionUID = -3092742144186932970L;

	@Override
	public Component getListCellRendererComponent(JList<? extends Integer> list, Integer value, int index,
			boolean isSelected, boolean cellHasFocus) {
		if (value != null)
		{
			this.setBackground(new Color(value.intValue()));
			this.setText(value.toString());
			this.setOpaque(true);
		}
		
		if (isSelected)
		{
			this.setBorder(BorderFactory.createLoweredSoftBevelBorder());
		}
		else
		{
			this.setBorder(BorderFactory.createEmptyBorder());
		}
		
		return this;
	}
	

}
