package com.tm.commons.components.pane;

import java.awt.GridLayout;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.tm.commons.dto.OtherOptions;

public class OtherOptionsPane extends JPanel {
	private static final long serialVersionUID = 9167734284890925248L;
	JCheckBox chkCustomCursor = new JCheckBox("Custom Cursor");
	OtherOptions otherOptions;

	public OtherOptionsPane(OtherOptions otherOptions) {
		this.otherOptions = otherOptions;

		this.setLayout(null);
		JPanel pnl = new JPanel(new GridLayout(1, 2));
		pnl.setBounds(10, 10, 300, 40);
		pnl.add(new JLabel("Is Custom Cursor"));
		pnl.add(this.chkCustomCursor);

		this.add(pnl);

		this.chkCustomCursor.setSelected(this.otherOptions.isCustomCursor());
	}

	public boolean isCustomCursor() {
		return this.chkCustomCursor.isSelected();
	}

	public void saveProperties() {
		this.otherOptions.setCustomCursor(this.chkCustomCursor.isSelected());
	}

}
