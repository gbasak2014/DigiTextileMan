package com.tm.commons.components.pane;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.listener.StatusBarListener;
import com.tm.commons.theme.DigiTmTheme;

public class DigiTmStatusBar extends JPanel {

	private static final long serialVersionUID = -3636899372302266576L;
	JLabel lblCurrentPos;
	JLabel lblImageSize;
	JLabel lblImagePos;
	JLabel lblLength;
	JCheckBox jcDrawingArea;
	JTextField jtLeft;
	JTextField jtTop;
	JTextField jtWidth;
	JTextField jtHeight;
	StatusBarListener statusBarListener;
	Rectangle bound;
	JCheckBox jcGrid;

	public DigiTmStatusBar(StatusBarListener statusBarListener) {
		this.statusBarListener = statusBarListener;
		this.setBorder(BorderFactory.createLineBorder(Color.lightGray));
		this.setLayout(new FlowLayout(FlowLayout.LEFT, 2, 0));

		this.setBackground(new Color(200, 200, 200));

		this.lblImageSize = new JLabel();
		this.lblImageSize.setPreferredSize(new Dimension(150, 22));
		this.lblImageSize.setBorder(BorderFactory.createLineBorder(Color.WHITE));
		this.add(this.lblImageSize);

		this.lblImagePos = new JLabel();
		this.lblImagePos.setPreferredSize(new Dimension(150, 22));
		this.lblImagePos.setBorder(BorderFactory.createLineBorder(Color.WHITE));
		this.add(this.lblImagePos);

		this.lblCurrentPos = new JLabel();
		this.lblCurrentPos.setPreferredSize(new Dimension(150, 22));
		this.lblCurrentPos.setBorder(BorderFactory.createLineBorder(Color.WHITE));
		this.add(this.lblCurrentPos);

		this.lblLength = new JLabel();
		this.lblLength.setPreferredSize(new Dimension(150, 22));
		this.lblLength.setBorder(BorderFactory.createLineBorder(Color.WHITE));
		this.add(this.lblLength);

		JPanel pnlDrawingArea = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
		pnlDrawingArea.setOpaque(false);
		pnlDrawingArea.setBorder(DigiTmTheme.getLineBorder());
		this.jcDrawingArea = new JCheckBox("Set Drawing Area");
		this.jcDrawingArea.setOpaque(false);
		this.jtLeft = new JTextField();
		this.jtTop = new JTextField();
		this.jtWidth = new JTextField();
		this.jtHeight = new JTextField();
		this.jcDrawingArea.setPreferredSize(new Dimension(130, 20));
		this.jtLeft.setPreferredSize(new Dimension(50, 20));
		this.jtTop.setPreferredSize(new Dimension(50, 20));
		this.jtWidth.setPreferredSize(new Dimension(50, 20));
		this.jtHeight.setPreferredSize(new Dimension(50, 20));

		pnlDrawingArea.add(new JLabel("Left:"));
		pnlDrawingArea.add(jtLeft);
		pnlDrawingArea.add(new JLabel("Top:"));
		pnlDrawingArea.add(jtTop);
		pnlDrawingArea.add(new JLabel("Width:"));
		pnlDrawingArea.add(jtWidth);
		pnlDrawingArea.add(new JLabel("Height:"));
		pnlDrawingArea.add(jtHeight);
		pnlDrawingArea.add(jcDrawingArea);
		JButton btn = new ButtonMenuItem(1, null, "/img/refresh.jpg", "Refresh Drawing Area");
		btn.setPreferredSize(new Dimension(20, 20));
		btn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				refreshDrawingArea();
			}
		});

		this.jcDrawingArea.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				toggleDrawingArea(jcDrawingArea.isSelected());
			}
		});

		pnlDrawingArea.add(btn);
		this.add(pnlDrawingArea);
		this.jcGrid = new JCheckBox("Grid", true);
		this.jcGrid.setOpaque(false);
		this.add(this.jcGrid);
		this.jcGrid.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				showHideGrid();
			}
		});
	}

	void showHideGrid() {
		this.statusBarListener.showGrid(this.jcGrid.isSelected());
	}

	public void setCurrentPos(int x, int y) {
		this.lblCurrentPos.setText("X:" + x + " , Y:" + y);
	}

	public void setImageSize(int w, int h) {
		this.lblImageSize.setText(w + " X " + h);
	}

	public void setImagePos(int left, int top) {
		this.lblImagePos.setText("L:" + left + " , T:" + top);
	}

	public void setShapeSize(int w, int h) {
		this.lblLength.setText(w + " X " + h);
	}

	public void setLength(int len) {
		this.lblLength.setText("Length:" + len);
	}

	void refreshDrawingArea() {
		try {
			Rectangle newBound = new Rectangle();
			newBound.x = Integer.parseInt(jtLeft.getText()) - 1;
			newBound.y = Integer.parseInt(jtTop.getText()) - 1;
			newBound.width = Integer.parseInt(jtWidth.getText());
			newBound.height = Integer.parseInt(jtHeight.getText());

			if (!newBound.equals(this.bound)) {
				this.bound = newBound;
				this.statusBarListener.drawingAreaChanges(this.bound);
				this.jcDrawingArea.setSelected(true);
			}

		} catch (Exception e) {
		}

	}

	public void toggleDrawingArea(boolean value) {
		this.jcDrawingArea.setSelected(value);
		if (value) {
			setDrawingArea();
		} else {
			this.statusBarListener.clearDrawingArea();
		}
	}

	public void setDrawingArea() {
		this.bound = this.statusBarListener.getDrawingArea();
		this.jtLeft.setText(String.valueOf(bound.x + 1));
		this.jtTop.setText(String.valueOf(bound.y + 1));
		this.jtWidth.setText(String.valueOf(bound.width));
		this.jtHeight.setText(String.valueOf(bound.height));
		this.jcDrawingArea.setSelected(true);
	}

}
