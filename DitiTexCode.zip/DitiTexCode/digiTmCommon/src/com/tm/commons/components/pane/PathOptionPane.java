package com.tm.commons.components.pane;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

import com.tm.commons.dto.DigiTmConstants;
import com.tm.commons.dto.LibOptions;

public class PathOptionPane extends JPanel implements ActionListener {
	private static final long serialVersionUID = -1898946067580668179L;

	static final int MOTIF = 0;
	static final int PATTERN = 1;
	static final int CODE = 2;

	JTextField jtMotifPath = new JTextField();
	JTextField jtPatternPath = new JTextField();
	JTextField jtCodePath = new JTextField();
	JTextField jtScannerPath = new JTextField();
	JTextField jtNewAppPath = new JTextField();
	JTextField jtNewAppName = new JTextField();
	
	LibOptions libOption;

	JButton btnBrowseMotif;
	JButton btnBrowseCode;
	JButton btnBrowsePattern;

	public PathOptionPane(LibOptions libOption, boolean isDesign) {
		this(libOption);
		if (isDesign) {
			jtPatternPath.setEnabled(false);
			jtCodePath.setEnabled(false);
			btnBrowseCode.setEnabled(false);
			btnBrowsePattern.setEnabled(false);
		}
	}

	/**
	 * Create the panel.
	 */
	public PathOptionPane(LibOptions libOption) {
		this.libOption = libOption;

		setLayout(null);

		JPanel pnlLib = new JPanel();
		pnlLib.setBounds(21, 23, 550, 100);
		pnlLib.setBorder(new TitledBorder("Library Path"));
		pnlLib.setLayout(new GridLayout(2, 1));
		JPanel pnl = new JPanel();
		pnl.add(new JLabel("Motif Home:"));
		jtMotifPath.setPreferredSize(new Dimension(350, 20));
		pnl.add(jtMotifPath);
		btnBrowseMotif = new JButton("Browse");
		btnBrowseMotif.addActionListener(this);
		btnBrowseMotif.setActionCommand(String.valueOf(MOTIF));
		pnl.add(btnBrowseMotif);
		pnlLib.add(pnl);

		pnl = new JPanel();
		pnl.add(new JLabel("Pattern Home:"));
		jtPatternPath.setPreferredSize(new Dimension(350, 20));
		pnl.add(jtPatternPath);
		btnBrowsePattern = new JButton("Browse");
		btnBrowsePattern.addActionListener(this);
		btnBrowsePattern.setActionCommand(String.valueOf(PATTERN));
		pnl.add(btnBrowsePattern);
		pnlLib.add(pnl);

		add(pnlLib);

		JPanel pnlCode = new JPanel();
		pnlCode.setBounds(21, 146, 550, 50);
		pnlCode.setBorder(new TitledBorder("Code Generation"));
		pnlCode.add(new JLabel("Graph Code Home: "));
		jtCodePath.setPreferredSize(new Dimension(300, 20));
		pnlCode.add(this.jtCodePath);
		btnBrowseCode = new JButton("Browse");
		btnBrowseCode.addActionListener(this);
		btnBrowseCode.setActionCommand(String.valueOf(CODE));
		pnlCode.add(btnBrowseCode);

		add(pnlCode);

/*		
		JPanel pnlScanner = new JPanel();
		pnlScanner.setBounds(21, 200, 550, 50);
		jtScannerPath.setPreferredSize(new Dimension(300, 20));
		pnlScanner.setBorder(new TitledBorder("Scanner"));
		pnlScanner.add(new JLabel("Scanner Path: "));
		pnlScanner.add(jtScannerPath);
		add(pnlScanner);
		
		JPanel pnlApp = new JPanel();
		pnlApp.setBounds(21, 260, 550, 50);
		jtNewAppName.setPreferredSize(new Dimension(60, 20));
		jtNewAppPath.setPreferredSize(new Dimension(200, 20));
		
		pnlApp.setBorder(new TitledBorder("New Menu Item"));
		pnlApp.add(new JLabel("App Name"));
		pnlApp.add(jtNewAppName);
		pnlApp.add(new JLabel("App Path"));
		pnlApp.add(jtNewAppPath);
		add(pnlApp);
*/		
		this.jtCodePath.setText(this.libOption.getCodeHome());
		this.jtMotifPath.setText(this.libOption.getMotifHome());
		this.jtPatternPath.setText(this.libOption.getWeaveHome());
		this.jtScannerPath.setText(this.libOption.getScannerPath());
		
		if (this.libOption.getNewApp() != null)
		{
			String[] app = this.libOption.getNewApp().split("@");
			if (app.length == 2)
			{
				this.jtNewAppName.setText(app[0]);
				this.jtNewAppPath.setText(app[1]);
			}
		}
	}

	public LibOptions getLibOptions() {
		this.libOption.setCodeHome(this.jtCodePath.getText());
		this.libOption.setMotifHome(this.jtMotifPath.getText());
		this.libOption.setWeaveHome(this.jtPatternPath.getText());
		this.libOption.setScannerPath(this.jtScannerPath.getText());
		if (jtNewAppName.getText().length() > 0 && jtNewAppPath.getText().length() > 0)
		{
			this.libOption.setNewApp(jtNewAppName.getText() + "@" + jtNewAppPath.getText());
		}
		
		return this.libOption;
	}

	public void saveLibPaths() {
		this.libOption.setCodeHome(this.jtCodePath.getText());
		this.libOption.setMotifHome(this.jtMotifPath.getText());
		this.libOption.setWeaveHome(this.jtPatternPath.getText());
		this.libOption.setScannerPath(jtScannerPath.getText());
		if (jtNewAppName.getText().length() > 0 && jtNewAppPath.getText().length() > 0)
		{
			this.libOption.setNewApp(jtNewAppName.getText() + "@" + jtNewAppPath.getText());
		}
		
		//System.out.println(libOption.toString());
	}

	public static String getTempDir() {
		return System.getProperty(DigiTmConstants.PROP_TEMP_DIR) + "/" + DigiTmConstants.APP_NAME;
	}

	@Override
	public void actionPerformed(ActionEvent ae) {

		JFileChooser jfc = new JFileChooser();
		jfc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		if (jfc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
			int cmd = Integer.parseInt(ae.getActionCommand());
			String path = jfc.getSelectedFile().getAbsolutePath().replaceAll(Pattern.quote("\\"), "/");
			switch (cmd) {
			case MOTIF:
				this.jtMotifPath.setText(path);
				break;
			case PATTERN:
				this.jtPatternPath.setText(path);
				break;
			case CODE:
				this.jtCodePath.setText(path);
				break;
			}
		}
	}
}
