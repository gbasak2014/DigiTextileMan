package com.tm.commons.components.button;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class ButtonImageToggle extends JButton {
	private static final long serialVersionUID = 4041301502885131105L;
	ImageIcon icoLocked;
	ImageIcon icoUnlocked;
	boolean locked = true;
	
	public ButtonImageToggle(Integer rgb, String unlockedImg, String lockedImg, boolean isLocked) {
		super();
		this.locked = isLocked;
		this.setBackground(new Color(rgb));

		if (unlockedImg != null) {
			URL url = this.getClass().getResource(unlockedImg);
			if (url != null) {
				icoUnlocked = new ImageIcon(url);
			}
			
			URL url1 = this.getClass().getResource(lockedImg);
			if (url1 != null) {
				icoLocked = new ImageIcon(url1);
			}
			
			if (this.locked)
			{
				this.setIcon(icoLocked);				
			}
			else
			{
				this.setIcon(icoUnlocked);
			}
			
		}

		this.setPreferredSize(new Dimension(30, 30));
		this.setBorder(BorderFactory.createEmptyBorder());
		this.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				toggleIcon();
			}
		});
	}

	void toggleIcon()
	{
		this.locked = !this.locked;
		if (this.locked)
		{
			this.setIcon(this.icoLocked);
		}
		else
		{
			this.setIcon(this.icoUnlocked);
		}
	}
	
	public boolean isLocked()
	{
		return this.locked;
	}
}
