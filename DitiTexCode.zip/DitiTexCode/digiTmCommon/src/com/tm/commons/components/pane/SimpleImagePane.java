package com.tm.commons.components.pane;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

/**
 * The class is for holding and showing image on UI
 * 
 * @author Gouranga Basak
 * 
 */
public class SimpleImagePane extends JPanel {
	private static final long serialVersionUID = -2071761141741617151L;
	BufferedImage image;

	public SimpleImagePane() {

	}

	@Override
	public void paint(Graphics g) {
		int w = this.getWidth();
		int h = this.getHeight();
		if (this.image != null) {
			g.drawImage(this.image, 1, 1, w - 2, h - 2, this);
		}
		g.drawRect(0, 0, w-1, h-1);
		g.dispose();
	}

	public BufferedImage getImage() {
		return image;
	}

	public void setImage(BufferedImage image) {
		this.image = image;
	}

}
