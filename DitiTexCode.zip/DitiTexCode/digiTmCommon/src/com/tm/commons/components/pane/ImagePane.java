package com.tm.commons.components.pane;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

/**
 * The class is for holding and showing image on UI
 * 
 * @author Gouranga Basak
 * 
 */
public class ImagePane extends JPanel implements MouseListener{

	private static final long serialVersionUID = 7999805882599719987L;
	BufferedImage image;
	int zoom;
	boolean repeatHorizontal;
	boolean repeatVartical;
	boolean stretch;
	boolean pattern;

	boolean customePattern;
	
	public ImagePane(BufferedImage image, boolean repeatHorizontal, boolean repeatVartical, MouseAdapter listener,
			boolean stretch, boolean pattern, boolean customePattern) {
		this.image = image;
		this.repeatHorizontal = repeatHorizontal;
		this.repeatVartical = repeatVartical;
		this.zoom = 1;
		if (listener != null) {
			this.addMouseListener(listener);
			this.addMouseMotionListener(listener);
		}
		this.stretch = stretch;
		this.pattern = pattern;
		this.customePattern = customePattern;
		this.setBorder(BorderFactory.createRaisedBevelBorder());
		this.addMouseListener(this);
	}

	public ImagePane(BufferedImage image, boolean stretch, boolean pattern) {
		this(image, false, false, null, stretch, pattern, false);
	}

	public ImagePane() {
		this(null, false, false, null, false, false, false);
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		if (this.image != null) {

			int w = this.getWidth();
			int h = this.getHeight();
			int iw = this.stretch ? w : this.image.getWidth() * this.zoom;
			int ih = this.stretch ? h : this.image.getHeight() * this.zoom;

			for (int x = 1; x < w; x = x + iw) {
				for (int y = 1; y < h; y = y + ih) {
					g.drawImage(this.image, x, y, iw-2, ih-2, this);
					if (!this.repeatVartical) {
						break;
					}
				}
				if (!this.repeatHorizontal) {
					break;
				}
			}

		}

		
	}

	public BufferedImage getImage() {
		return image;
	}

	public int getZoom() {
		return zoom;
	}

	public boolean isRepeatHorizontal() {
		return repeatHorizontal;
	}

	public boolean isRepeatVartical() {
		return repeatVartical;
	}

	public void setImage(BufferedImage image) {
		this.image = image;
	}

	public void setZoom(int zoom) {
		this.zoom = zoom;
	}

	public void setRepeatHorizontal(boolean repeatHorizontal) {
		this.repeatHorizontal = repeatHorizontal;
	}

	public void setRepeatVartical(boolean repeatVartical) {
		this.repeatVartical = repeatVartical;
	}

	public boolean isStretch() {
		return stretch;
	}

	public boolean isPattern() {
		return pattern;
	}

	public void setStretch(boolean stretch) {
		this.stretch = stretch;
	}

	public void setPattern(boolean pattern) {
		this.pattern = pattern;
	}
	
	@Override
	public void mouseEntered(MouseEvent e) {
		this.setBorder(BorderFactory.createLineBorder(Color.RED));		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		this.setBorder(BorderFactory.createRaisedBevelBorder());			
	}
	
	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public boolean isCustomePattern() {
		return customePattern;
	}

	public void setCustomePattern(boolean customePattern) {
		this.customePattern = customePattern;
	}
}
