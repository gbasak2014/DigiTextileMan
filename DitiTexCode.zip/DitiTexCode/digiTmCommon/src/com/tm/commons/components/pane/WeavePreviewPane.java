package com.tm.commons.components.pane;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.TexturePaint;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

public class WeavePreviewPane extends JPanel {
	private static final long serialVersionUID = -5766086816621329697L;
	boolean horizRepeate;
	boolean vertRepeate;
	int zoom;
	BufferedImage imgWeave;

	public WeavePreviewPane() {
		this.horizRepeate = true;
		this.vertRepeate = true;
		this.zoom = 1;
	}

	@Override
	public void paint(Graphics g) {
		int w = this.getWidth();
		int h = this.getHeight();

		if (this.imgWeave != null) {
			int iw = this.imgWeave.getWidth();
			int ih = this.imgWeave.getHeight();
			TexturePaint tp = new TexturePaint(this.imgWeave, new Rectangle(iw, ih));
			Graphics2D g2d = (Graphics2D) g;
			g2d.scale((double) zoom, (double) zoom);
			g2d.setPaint(tp);
			g2d.fillRect(0, 0, w, h);
			g2d.dispose();
		} else {
			g.setColor(Color.LIGHT_GRAY);
			g.fillRect(0, 0, w, h);
		}

	}

	public boolean isHorizRepeate() {
		return horizRepeate;
	}

	public boolean isVertRepeate() {
		return vertRepeate;
	}

	public int getZoom() {
		return zoom;
	}

	public BufferedImage getImgWeave() {
		return imgWeave;
	}

	public void setHorizRepeate(boolean horizRepeate) {
		this.horizRepeate = horizRepeate;
		this.repaint();
	}

	public void setVertRepeate(boolean vertRepeate) {
		this.vertRepeate = vertRepeate;
		this.repaint();
	}

	public void setZoom(int zoom) {

		this.zoom = this.zoom + zoom;
		if (this.zoom < 1) {
			this.zoom = 1;
		}
		this.repaint();
	}

	public void setImgWeave(BufferedImage imgWeave) {
		this.imgWeave = imgWeave;
		this.repaint();
	}
}
