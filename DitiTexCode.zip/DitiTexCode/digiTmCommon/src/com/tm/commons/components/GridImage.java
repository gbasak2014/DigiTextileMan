package com.tm.commons.components;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;

import com.tm.commons.dto.GridOptions;

public class GridImage {
	BufferedImage image;
	GridOptions gridOptions;

	boolean showGrid = true;

	public boolean isShowGrid() {
		return showGrid;
	}

	public void setShowGrid(boolean showGrid) {
		this.showGrid = showGrid;
	}

	public GridImage(GridOptions gridOptions) {
		this.gridOptions = gridOptions;
		int w = Toolkit.getDefaultToolkit().getScreenSize().width;
		int h = Toolkit.getDefaultToolkit().getScreenSize().height;

		if (this.image == null) {
			this.image = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		}
	}

	public void createGrid(int drawingLeft, int drawingTop, int drawingWidth, int drawingHeight) {

		int zoom = this.gridOptions.getZoom();
		Color colorUnit = this.gridOptions.getColorUnit();
		Color colorPoint = this.gridOptions.getColorPoint();
		Color colorPoint1 = this.gridOptions.getColorPoint1();
		int pointWidth = this.gridOptions.getPoint();

		int lineWidth;
		int lineHeight;
		int w = this.image.getWidth();
		int h = this.image.getHeight();

		lineWidth = drawingWidth - drawingLeft;
		lineHeight = drawingHeight - drawingTop;

		if (lineWidth > (w / zoom)) {
			lineWidth = w / zoom;
		}
		if (lineHeight > (h / zoom)) {
			lineHeight = h / zoom;
		}

		Color color = new Color(0, 0, 0, 0);
		Graphics2D g = this.image.createGraphics();
		g.setColor(color);
		g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_IN, 0.0f));
		g.fillRect(0, 0, w, h);
		g.dispose();
		if (!this.showGrid) {
			return;
		}

		g = this.image.createGraphics();

		int c = drawingLeft;
		int i;
		int pointWidth2 = pointWidth * 2;

		for (i = 0; i < lineWidth; i++) {
			if (c % pointWidth2 == 0) {
				g.setColor(colorPoint1);
			} else if (c % pointWidth == 0) {
				g.setColor(colorPoint);
			} else {
				g.setColor(colorUnit);
			}
			c++;
			g.drawLine(i * zoom, 0, i * zoom, lineHeight * zoom);
		}
		g.setColor(Color.BLACK);
		g.drawLine(i * zoom, 0, i * zoom, lineHeight * zoom);

		c = drawingTop;
		for (i = 0; i < lineHeight; i++) {
			if (c % pointWidth2 == 0) {
				g.setColor(colorPoint1);
			} else if (c % pointWidth == 0) {
				g.setColor(colorPoint);
			} else {
				g.setColor(colorUnit);
			}
			c++;
			g.drawLine(0, i * zoom, lineWidth * zoom, i * zoom);
		}
		g.setColor(Color.BLACK);
		g.drawLine(0, i * zoom, lineWidth * zoom, i * zoom);

		g.dispose();
	}

	public BufferedImage getImage() {
		return image;
	}

	public GridOptions getGridOptions() {
		return gridOptions;
	}
}
