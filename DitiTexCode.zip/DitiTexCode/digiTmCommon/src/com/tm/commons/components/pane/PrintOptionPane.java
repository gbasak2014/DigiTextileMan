package com.tm.commons.components.pane;

import java.awt.Font;

import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.tm.commons.dto.PrintOption;

public class PrintOptionPane extends JPanel {
	private static final long serialVersionUID = -4815935526492250478L;
	private JTextField txtHeader;
	private JTextField txtFooter;
	//JCheckBox chkPageNumber;
	JCheckBox chkPtintPath;
	//JRadioButton rdFooter;
	//JRadioButton rdHeader;

	PrintOption printOption;

	/**
	 * Create the panel.
	 */
	public PrintOptionPane(PrintOption printOption) {
		this.printOption = printOption;

		setLayout(null);

		JLabel lblHeader = new JLabel("Header:");
		lblHeader.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblHeader.setHorizontalAlignment(SwingConstants.RIGHT);
		lblHeader.setBounds(40, 40, 50, 25);
		add(lblHeader);

		JLabel lblFooter = new JLabel("Footer:");
		lblFooter.setHorizontalAlignment(SwingConstants.RIGHT);
		lblFooter.setFont(new Font("Tahoma", Font.BOLD, 11));
		lblFooter.setBounds(40, 70, 50, 25);
		add(lblFooter);

		txtHeader = new JTextField();
		txtHeader.setBounds(92, 42, 525, 20);
		add(txtHeader);
		txtHeader.setColumns(10);

		txtFooter = new JTextField();
		txtFooter.setColumns(10);
		txtFooter.setBounds(92, 72, 525, 20);
		add(txtFooter);

		//chkPageNumber = new JCheckBox("Print Page Number");
		//chkPageNumber.setBounds(53, 120, 150, 23);
		//add(chkPageNumber);

		chkPtintPath = new JCheckBox("Print File Path");
		chkPtintPath.setBounds(53, 156, 150, 23);
		add(chkPtintPath);

		//rdHeader = new JRadioButton("Header");
		//rdHeader.setBounds(200, 200, 69, 23);
		//add(rdHeader);

		//rdFooter = new JRadioButton("Footer");
		//rdFooter.setBounds(281, 200, 109, 23);
		//add(rdFooter);

		//ButtonGroup bg = new ButtonGroup();
		//bg.add(rdHeader);
		//bg.add(rdFooter);

		JLabel lblPageNumberPosition = new JLabel("Page Number Position:");
		lblPageNumberPosition.setHorizontalAlignment(SwingConstants.RIGHT);
		lblPageNumberPosition.setBounds(40, 153, 149, 29);
		add(lblPageNumberPosition);

		this.txtHeader.setText(this.printOption.getHeader());
		this.txtFooter.setText(this.printOption.getFooter());
		
		//this.chkPageNumber.setSelected(this.printOption.isPageNo());
		//if (this.printOption.isPageHeader()) {
		//	this.rdHeader.setSelected(true);
		//} else {
		//	this.rdFooter.setSelected(true);
		//}

		this.chkPtintPath.setSelected(this.printOption.isPrintPath());
	}

	public PrintOption savePrintOption() {
		this.printOption.setHeader(this.txtHeader.getText());
		this.printOption.setFooter(this.txtFooter.getText());
		//this.printOption.setPageNo(this.chkPageNumber.isSelected());
		//this.printOption.setPageHeader(this.rdHeader.isSelected());
		this.printOption.setPrintPath(this.chkPtintPath.isSelected());
		return this.printOption;
	}
}
