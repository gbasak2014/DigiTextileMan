package com.tm.commons.drawing.tool;

import java.awt.Color;
import java.awt.Point;
import java.util.ArrayList;
import java.util.List;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.pane.GraphPane;

public class SelectFreeHand extends Pen {

	int minX;
	int minY;
	int maxX;
	int maxY;

	int rgb = Color.GREEN.getRGB();

	List<Point> pts = new ArrayList<Point>();

	public SelectFreeHand() {
		super(DrawingToolEnum.SELECT_RAND);
	}

	public SelectFreeHand(GraphPane graphPane, Color color, FillPattern fillPattern) {
		super(DrawingToolEnum.SELECT_RAND, graphPane, color, fillPattern);
	}

	@Override
	public void setStartPoint(int x, int y) {
		super.setStartPoint(x, y);
		if (x > 0 && y > 0) {
			int[] drawingData = this.getDrawingData();
			
			if (drawingData[y * this.drawingWidth + x] == rgb) {
				drawingData[y * this.drawingWidth + x] = drawingData[y * this.drawingWidth + x] ^ rgb;
			} else {
				drawingData[y * this.drawingWidth + x] = rgb;
			}
		}

		minX = maxX = x;
		minY = maxY = y;
		pts.clear();
		pts.add(new Point(x, y));
		this.rect.x = minX;
		this.rect.y = minY;
		this.rect.width = maxX - minX + 1;
		this.rect.height = maxY - minY + 1;
	}

	@Override
	public void draw(int x, int y) {
		super.draw(x, y);
		// int rgb = this.color.getRGB();
		int[] drawingData = this.getDrawingData();
		if (startX == x && startY == y) {

			if (drawingData[y * this.drawingWidth + x] != rgb) {
				drawingData[y * this.drawingWidth + x] = drawingData[y * this.drawingWidth + x] ^ rgb;
			} else {
				drawingData[y * this.drawingWidth + x] = rgb;
			}

		} else {
			drawLine(drawingData, this.drawingWidth, this.drawingHeight);
			if (minX > x) {
				minX = x;
			} else if (maxX < x) {
				maxX = x;
			}

			if (minY > y) {
				minY = y;
			} else if (maxY < y) {
				maxY = y;
			}
		}

		this.startX = x;
		this.startY = y;
		pts.add(new Point(x, y));
		this.rect.x = minX;
		this.rect.y = minY;
		this.rect.width = maxX - minX + 1;
		this.rect.height = maxY - minY + 1;
	}

	@Override
	public void save() {
		startX = startY = currentX = currentY = -1;
		int[] drawingData = this.getDrawingData();
		Point p1 = pts.get(0);
		Point p2 = pts.get(pts.size() - 1);
		drawLine(drawingData, p1.x, p1.y, p2.x, p2.y, this.drawingWidth, this.drawingHeight);

		this.rect.x = minX;
		this.rect.y = minY;
		this.rect.width = maxX - minX + 1;
		this.rect.height = maxY - minY + 1;

	}

	void drawLine(int[] data, int width, int height) {
		if (startX == currentX && startY == currentY) {
			return;
		}

		int dx;
		int dy;

		int e = 0;
		int px = startX;
		int py = startY;
		// int rgb = color.getRGB();
		int mx;
		int my;
		if (startX < currentX) {
			dx = currentX - startX;
			mx = 1;
		} else {
			dx = startX - currentX;
			mx = -1;
		}

		if (startY < currentY) {
			dy = currentY - startY;
			my = 1;
		} else {
			dy = startY - currentY;
			my = -1;
		}

		if (dx > dy) {
			while (px != currentX) {
				if (data[py * width + px] == rgb) {
					data[py * width + px] = data[py * width + px] ^ rgb;
				} else {
					data[py * width + px] = rgb;
				}

				if (2 * (e + dy) < dx) {
					e = e + dy;
				} else {
					py = py + my;
					e = e + dy - dx;
				}
				px = px + mx;
			}
		} else {
			while (py != currentY) {

				if (data[py * width + px] == rgb) {
					data[py * width + px] = data[py * width + px] ^ rgb;
				} else {
					data[py * width + px] = rgb;
				}

				if (2 * (e + dx) < dy) {
					e = e + dx;
				} else {
					px = px + mx;
					e = e + dx - dy;
				}
				py = py + my;
			}
		}

		if (data[currentY * width + currentX] == rgb) {
			data[currentY * width + currentX] = data[currentY * width + currentX] ^ rgb;
		} else {
			data[currentY * width + currentX] = rgb;
		}

	}

	void drawLine(int[] data, int x1, int y1, int x2, int y2, int width, int height) {
		if (x1 == x2 && y1 == y2) {
			return;
		}

		int dx;
		int dy;

		int e = 0;
		int px = x1;
		int py = y1;
		// int rgb = color.getRGB();
		int mx;
		int my;
		if (x1 < x2) {
			dx = x2 - x1;
			mx = 1;
		} else {
			dx = x1 - x2;
			mx = -1;
		}

		if (y1 < y2) {
			dy = y2 - y1;
			my = 1;
		} else {
			dy = y1 - y2;
			my = -1;
		}

		if (dx > dy) {
			while (px != x2) {
				if (py >= 0 && py < height && px >= 0 && px < width) {
					if (data[py * width + px] == rgb) {
						data[py * width + px] = data[py * width + px] ^ rgb;
					} else {
						data[py * width + px] = rgb;
					}
				}

				if (2 * (e + dy) < dx) {
					e = e + dy;
				} else {
					py = py + my;
					e = e + dy - dx;
				}
				px = px + mx;
			}
		} else {
			while (py != y2) {

				if (py >= 0 && py < height && px >= 0 && px < width) {
					if (data[py * width + px] == rgb) {
						data[py * width + px] = data[py * width + px] ^ rgb;
					} else {
						data[py * width + px] = rgb;
					}
				}

				if (2 * (e + dx) < dy) {
					e = e + dx;
				} else {
					px = px + mx;
					e = e + dx - dy;
				}
				py = py + my;
			}
		}

		if (y2 >= 0 && y2 < height && x2 >= 0 && x2 < width) {
			if (data[y2 * width + x2] == rgb) {
				data[y2 * width + x2] = data[y2 * width + x2] ^ rgb;
			} else {
				data[y2 * width + x2] = rgb;
			}
		}

	}

	public List<Point> getPoints() {
		return this.pts;
	}
}
