package com.tm.commons.drawing.tool;

import java.awt.Color;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.pane.GraphPane;

public class Mouse extends Pen {

	public Mouse() {
		super(DrawingToolEnum.MOUSE);
	}

	public Mouse(GraphPane graphPane, Color color, FillPattern fillPattern) {
		super(DrawingToolEnum.MOUSE, graphPane, color, fillPattern);
	}

	@Override
	public void draw(int x, int y) {
	}
}
