package com.tm.commons.drawing.tool;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashSet;
import java.util.Set;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.pane.GraphPane;

public class Fill extends Pen {

	public Fill() {
		super(DrawingToolEnum.FILL);
	}

	public Fill(GraphPane graphPane, Color color, FillPattern fillPattern) {
		super(DrawingToolEnum.FILL, graphPane, color, fillPattern);
	}

	@Override
	public void setStartPoint(int x, int y) {
	}

	@Override
	public void save() {
		this.resetColor();
	}

	@Override
	public void draw(int x, int y) {
		int minX;
		int minY;
		int maxX;
		int maxY;

		minX = maxX = -1;
		minY = maxY = -1;

		int newRgb = this.fillColor.getRGB() | 0xff000000;

		boolean isPattern = false;
		if (this.fillPattern.getPattern() != null) {
			int[][] pat = this.getPatternData();
			isPattern = this.isPattern(pat);
			if (isPattern) {
				this.patternFill(x, y, pat);
			}
		}

		int[] savedData = this.getSavedData();
		int[] drawingData = this.getDrawingData();

		if (!isPattern && (x >= 0 && x < this.imgWidth) && (y >= 0 && y < this.imgHeight)
				&& (newRgb != (drawingData[y * this.drawingWidth + x] | 0xff000000))) {

			int oldRgb = drawingData[y * this.drawingWidth + x] | 0xff000000;
			Deque<Integer> queueX = new ArrayDeque<Integer>();
			Deque<Integer> queueY = new ArrayDeque<Integer>();

			queueX.push(x);
			queueY.push(y);
			minX = maxX = x;
			minY = maxY = y;
			while (!queueX.isEmpty()) {
				int px = queueX.pop();
				int py = queueY.pop();
				if (drawingData[py * this.drawingWidth + px] != newRgb) {
					drawingData[py * this.drawingWidth + px] = newRgb;

					if (minX > px) {
						minX = px;
					} else if (maxX < px) {
						maxX = px;
					}

					if (minY > py) {
						minY = py;
					} else if (maxY < py) {
						maxY = py;
					}

				}

				if (px - 1 >= 0 && oldRgb == (drawingData[py * this.drawingWidth + (px - 1)] | 0xff000000)) {
					queueX.push(px - 1);
					queueY.push(py);
				}

				if (px + 1 < this.imgWidth && oldRgb == (drawingData[py * this.drawingWidth + (px + 1)] | 0xff000000)) {
					queueX.push(px + 1);
					queueY.push(py);
				}

				if (py - 1 >= 0 && oldRgb == (drawingData[(py - 1) * this.drawingWidth + px] | 0xff000000)) {
					queueX.push(px);
					queueY.push(py - 1);
				}

				if (py + 1 < this.imgHeight
						&& oldRgb == (drawingData[(py + 1) * this.drawingWidth + px] | 0xff000000)) {
					queueX.push(px);
					queueY.push(py + 1);
				}
			}

			if (minX >= 0) {
				if (minX == maxX && minY == maxY) {
					this.graphPane.addUndoState(new int[] { minX, minY, savedData[minY * this.imgHeight + minX] });
				} else {

					// System.out.println(this.graphPane.getSavedImage().getWidth()
					// + "," + this.graphPane.getSavedImage().getHeight());
					// System.out.println(minX + "," + minY + "," + maxX + "," +
					// maxY);
					// System.out.println();
					BufferedImage img = this.graphPane.getSavedImage().getSubimage(minX, minY, (maxX - minX + 1),
							(maxY - minY + 1));
					this.graphPane.addUndoState(minX, minY, img);
				}

				Graphics2D g = this.graphPane.getSavedImage().createGraphics();
				g.drawImage(this.graphPane.getDrawingImage().getImage(), 0, 0, this.graphPane);
				g.dispose();
			}
		}
	}

	public void patternFill(int x, int y, int[][] patData) {
		int minX;
		int minY;
		int maxX;
		int maxY;

		int patW = patData.length;
		int patH = patData[0].length;

		minX = maxX = -1;
		minY = maxY = -1;
		int[] savedData = this.getSavedData();
		int[] drawingData = this.getDrawingData();

		int oldRgb = drawingData[y * this.drawingWidth + x] | 0xff000000;
		Deque<Integer> queueX = new ArrayDeque<Integer>();
		Deque<Integer> queueY = new ArrayDeque<Integer>();

		queueX.push(x);
		queueY.push(y);
		minX = maxX = x;
		minY = maxY = x;

		Set<Integer> bakPos = new HashSet<Integer>();

		while (!queueX.isEmpty()) {
			int px = queueX.pop();
			int py = queueY.pop();
			// ////
			int pos = py * this.drawingWidth + px;
			int newRgb = patData[px % patW][py % patH];
			if (newRgb == oldRgb) {
				bakPos.add(pos);
				drawingData[pos] = newRgb - 1;
			} else {
				drawingData[pos] = newRgb;
			}

			if (minX > px) {
				minX = px;
			} else if (maxX < px) {
				maxX = px;
			}

			if (minY > py) {
				minY = py;
			} else if (maxY < py) {
				maxY = py;
			}

			// //////

			if (px - 1 >= 0 && oldRgb == (drawingData[py * this.drawingWidth + (px - 1)] | 0xff000000)) {
				queueX.push(px - 1);
				queueY.push(py);
			}

			if (px + 1 < this.imgWidth && oldRgb == (drawingData[py * this.drawingWidth + (px + 1)] | 0xff000000)) {
				queueX.push(px + 1);
				queueY.push(py);
			}

			if (py - 1 >= 0 && oldRgb == (drawingData[(py - 1) * this.drawingWidth + px] | 0xff000000)) {
				queueX.push(px);
				queueY.push(py - 1);
			}

			if (py + 1 < this.imgHeight && oldRgb == (drawingData[(py + 1) * this.drawingWidth + px] | 0xff000000)) {
				queueX.push(px);
				queueY.push(py + 1);
			}
		}

		for (int pos : bakPos) {
			drawingData[pos] = oldRgb;
		}

		if (minX >= 0) {
			if (minX == maxX && minY == maxY) {
				this.graphPane.addUndoState(new int[] { minX, minY, savedData[minY * this.imgHeight + minX] });
			} else {
				BufferedImage img = this.graphPane.getSavedImage().getSubimage(minX, minY, (maxX - minX + 1),
						(maxY - minY + 1));
				this.graphPane.addUndoState(minX, minY, img);
			}

			Graphics2D g = this.graphPane.getSavedImage().createGraphics();
			g.drawImage(this.graphPane.getDrawingImage().getImage(), 0, 0, this.graphPane);
			g.dispose();
		}

	}

	int[][] getPatternData() {
		BufferedImage pat = this.fillPattern.getPattern();
		int pw = pat.getWidth();
		int ph = pat.getHeight();
		int[][] data = new int[pw][ph];

		for (int i = 0; i < pw; i++) {
			for (int j = 0; j < ph; j++) {
				data[i][j] = pat.getRGB(i, j) | 0xff000000;
			}
		}

		return data;
	}

	boolean isPattern(int[][] pat) {
		int pw = pat.length;
		int ph = pat[0].length;

		int rgb = pat[0][0];

		for (int i = 0; i < pw; i++)
			for (int j = 0; j < ph; j++) {
				if (rgb != pat[i][j]) {
					return true;
				}
			}

		return false;
	}
}
