package com.tm.commons.drawing.tool;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.pane.GraphPane;
import com.tm.commons.image.ImageUtils;

public class Paste extends Pen {
	BufferedImage image;

	Pen previousPen;
	boolean pasteXor = true;

	public Paste() {
		super(DrawingToolEnum.PASTE);
	}

	public Paste(GraphPane graphPane, Color color, FillPattern fillPattern) {
		super(DrawingToolEnum.PASTE, graphPane, color, fillPattern);
	}

	@Override
	public void draw(int x, int y) {
		super.draw(x, y);
		Graphics2D g = this.graphPane.getDrawingImage().getImage().createGraphics();
		g.drawImage(this.graphPane.getSavedImage(), 0, 0, this.graphPane);

		if (this.image != null) {
			if (!pasteXor) {
				g.setXORMode(Color.WHITE);
			}
			g.drawImage(this.image, this.rect.x, this.rect.y, rect.width, rect.height, null);
		}
		g.dispose();
	}

	@Override
	public void save() {
		if (rect.width > 0 && rect.height > 0) {
			Rectangle bound = new Rectangle(rect.x, rect.y, rect.width, rect.height);
			Rectangle imgSize = new Rectangle(0, 0, this.graphPane.getImgWidth(), this.graphPane.getImgHeight());
			bound = imgSize.intersection(bound);

			try {
				BufferedImage img = this.graphPane.getSavedImage().getSubimage(bound.x, bound.y, bound.width,
						bound.height);
				this.graphPane.addUndoState(bound.x, bound.y, img);
			} catch (Exception e) {
				System.out.println(bound);
				e.printStackTrace();
			}

			Graphics2D g = this.graphPane.getSavedImage().createGraphics();
			if (!pasteXor) {
				g.setXORMode(Color.WHITE);
			}
			g.drawImage(this.image, rect.x, rect.y, rect.width, rect.height, null);
			if (this.previousPen != null) {
				this.graphPane.getPenHolder().setPen(this.previousPen);
			}
		}

		this.resetColor();
	}

	@Override
	public void move(int x, int y) {
		super.move(x, y);
		this.draw(this.currentX, this.currentY);
	}

	@Override
	public void draw() {
		this.draw(this.currentX, this.currentY);
	}

	public void setImage(BufferedImage image) {
		if (this.pasteXor) {
			this.image = ImageUtils.getTransperantImage(image, Color.WHITE);
		} else {
			this.image = image;
		}
		int x = this.graphPane.getImgLeft();
		int y = this.graphPane.getImgTop();
		this.setStartPoint(x, y);
		this.draw(x + image.getWidth() - 1, y + image.getHeight() - 1);
	}

	public Pen getPreviousPen() {
		return previousPen;
	}

	public void setPreviousPen(Pen previousPen) {
		this.previousPen = previousPen;
	}

	public boolean isPasteXor() {
		return pasteXor;
	}

	public void setPasteXor(boolean pasteXor) {
		if (this.pasteXor != pasteXor && this.image != null) {
			if (pasteXor) {
				this.image = ImageUtils.getTransperantImage(this.image, Color.WHITE);
			} else {
				this.image = ImageUtils.getOpaqueImage(this.image, Color.WHITE);
			}
		}

		this.pasteXor = pasteXor;
	}
}
