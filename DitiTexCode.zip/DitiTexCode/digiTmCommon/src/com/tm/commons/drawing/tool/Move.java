package com.tm.commons.drawing.tool;

import java.awt.Color;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.pane.GraphPane;

public class Move extends Pen {

	public Move() {
		super(DrawingToolEnum.MOVE);
	}

	public Move(GraphPane graphPane, Color color, FillPattern fillPattern) {
		super(DrawingToolEnum.MOVE, graphPane, color, fillPattern);
	}

	@Override
	public void draw(int x, int y) {
		this.currentX = x;
		this.currentY = y;
		int dx = this.graphPane.getImgLeft() + this.startX - this.currentX;
		int dy = this.graphPane.getImgTop() + this.startY - this.currentY;

		this.graphPane.scroll(dx, dy);
		this.graphPane.repaint();
		this.startX = x;
		this.startY = y;
	}

	@Override
	public void save() {
		this.resetColor();
	}
}
