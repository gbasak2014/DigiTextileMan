package com.tm.commons.drawing.tool;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

import com.tm.commons.Point;
import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.clipboard.ClipboardUtil;
import com.tm.commons.components.pane.GraphPane;
import com.tm.commons.image.ImageUtils;

public class ColorSelect extends Pen {
	BufferedImage img;

	public ColorSelect() {
		super(DrawingToolEnum.COLOR_SELECT);
	}

	public ColorSelect(GraphPane graphPane, Color color, FillPattern fillPattern) {
		super(DrawingToolEnum.COLOR_SELECT, graphPane, color, fillPattern);
	}

	@Override
	public void draw(int x, int y) {
		if (this.img != null) {
			this.save();
		} else {
			selectColor(x, y);
		}
	}

	public void selectColor(int x, int y) {

		int minX;
		int minY;
		int maxX;
		int maxY;

		minX = maxX = minY = maxY = 0;

		List<Point> list = new ArrayList<Point>();

		if ((x >= 0 && x < this.imgWidth) && (y >= 0 && y < this.imgHeight)) {
			this.graphPane.setCursor(new Cursor(Cursor.WAIT_CURSOR));

			int[] drawingData = this.getDrawingData();
			
			int oldRgb = drawingData[y * this.drawingWidth + x] | 0xff000000;
			int newRgb = oldRgb + 1;

			Deque<Integer> queueX = new ArrayDeque<Integer>();
			Deque<Integer> queueY = new ArrayDeque<Integer>();

			queueX.push(x);
			queueY.push(y);
			minX = maxX = x;
			minY = maxY = y;

			while (!queueX.isEmpty()) {
				int px = queueX.pop();
				int py = queueY.pop();
				if (drawingData[py * this.drawingWidth + px] != newRgb) {
					drawingData[py * this.drawingWidth + px] = newRgb;
					list.add(new Point(px, py));

					if (minX > px) {
						minX = px;
					}
					if (maxX < px) {
						maxX = px;
					}

					if (minY > py) {
						minY = py;
					}
					if (maxY < py) {
						maxY = py;
					}

				}

				if (px - 1 >= 0 && oldRgb == (drawingData[py * this.drawingWidth + (px - 1)] | 0xff000000)) {
					queueX.push(px - 1);
					queueY.push(py);
				}

				if (px + 1 < this.imgWidth
						&& oldRgb == (drawingData[py * this.drawingWidth + (px + 1)] | 0xff000000)) {
					queueX.push(px + 1);
					queueY.push(py);
				}

				if (py - 1 >= 0 && oldRgb == (drawingData[(py - 1) * this.drawingWidth + px] | 0xff000000)) {
					queueX.push(px);
					queueY.push(py - 1);
				}

				if (py + 1 < this.imgHeight
						&& oldRgb == (drawingData[(py + 1) * this.drawingWidth + px] | 0xff000000)) {
					queueX.push(px);
					queueY.push(py + 1);
				}
			}

			if (minX >= 0) {
				Graphics2D g = this.graphPane.getDrawingImage().getImage().createGraphics();
				g.drawImage(this.graphPane.getSavedImage(), 0, 0, this.graphPane);
				g.dispose();
			}

			if (list.size() > 1) {
				int w = maxX - minX + 1;
				int h = maxY - minY + 1;
				BufferedImage image = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
				Graphics2D g = image.createGraphics();
				g.setColor(Color.WHITE);
				g.fillRect(0, 0, w, h);
				g.dispose();

				for (Point p : list) {
					image.setRGB(p.x - minX, p.y - minY, oldRgb);
				}

				this.img = ImageUtils.getTransperantImage(image, Color.WHITE);
				ClipboardUtil.copyToClipboard(this.img);
				this.currentX = this.startX = this.rect.x = minX;
				this.currentY = this.startY = this.rect.y = minY;
				//this.currentX = x;
				//this.currentY = y;
				this.rect.width = this.img.getWidth();
				this.rect.height = this.img.getHeight();
				this.graphPane.setCursor(new Cursor(Cursor.MOVE_CURSOR));
			}

		}

	}

	@Override
	public void move(int x, int y) {
		super.move(x, y);
		if (this.img != null) {
			Graphics2D g = this.graphPane.getDrawingImage().getImage().createGraphics();
			g.drawImage(this.graphPane.getSavedImage(), 0, 0, this.graphPane);
			g.drawImage(this.img, this.rect.x, this.rect.y, rect.width, rect.height, null);
		}
	}

	@Override
	public void save() {

		if (this.img != null && rect.width > 0 && rect.height > 0) {
			Rectangle bound = new Rectangle(rect.x, rect.y, rect.width, rect.height);
			Rectangle imgSize = new Rectangle(0, 0, this.graphPane.getImgWidth(), this.graphPane.getImgHeight());
			bound = imgSize.intersection(bound);

			try {
				BufferedImage img = this.graphPane.getSavedImage().getSubimage(bound.x, bound.y, bound.width,
						bound.height);
				this.graphPane.addUndoState(bound.x, bound.y, img);
			} catch (Exception e) {
				System.out.println(bound);
				e.printStackTrace();
			}

			Graphics2D g = this.graphPane.getSavedImage().createGraphics();
			g.drawImage(this.img, rect.x, rect.y, rect.width, rect.height, null);
			this.setStartPoint(-1, -1);
		}
		this.img = null;
	}

}
