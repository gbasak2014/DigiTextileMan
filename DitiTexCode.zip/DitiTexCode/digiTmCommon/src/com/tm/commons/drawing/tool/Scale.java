package com.tm.commons.drawing.tool;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.TexturePaint;
import java.awt.image.BufferedImage;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.pane.GraphPane;

public class Scale extends Pen {
	public Scale(DrawingToolEnum type) {
		super(type);
		if (type == DrawingToolEnum.SCALE_H) {
			this.scalePaint = this.getHorizontalTexture();
		} else {
			this.scalePaint = this.getVerticalTexture();
		}
	}

	public Scale(DrawingToolEnum type, GraphPane graphPane, Color color, FillPattern fillPattern) {
		super(type, graphPane, color, fillPattern);
		if (type == DrawingToolEnum.SCALE_H) {
			this.scalePaint = this.getHorizontalTexture();
		} else {
			this.scalePaint = this.getVerticalTexture();
		}
	}

	@Override
	public void draw(int x, int y) {
		super.draw(x, y);
		if (this.type == DrawingToolEnum.SCALE_H) {
			this.rect.y = y;
			this.rect.height = 0;
		} else {
			this.rect.x = x;
			this.rect.width = 0;
		}
	}

	@Override
	public void save() {
		this.resetColor();
	}

	@Override
	public void move(int x, int y) {
		super.move(x, y);
		this.draw(this.currentX, this.currentY);
	}

	TexturePaint getHorizontalTexture() {
		BufferedImage bi = new BufferedImage(25, 20, BufferedImage.TYPE_INT_RGB);
		Graphics g = bi.getGraphics();
		g.setColor(Color.yellow);
		g.fillRect(0, 0, 25, 20);
		g.setColor(Color.black);
		g.drawLine(0, 0, 0, 20);
		for (int i = 5; i < 25; i += 5)
			g.drawLine(i, 0, i, 10);

		return new TexturePaint(bi, new Rectangle(bi.getWidth(), bi.getHeight()));
	}

	TexturePaint getVerticalTexture() {
		BufferedImage bi = new BufferedImage(20, 25, BufferedImage.TYPE_INT_RGB);
		Graphics g = bi.getGraphics();
		g.setColor(Color.yellow);
		g.fillRect(0, 0, 20, 25);
		g.setColor(Color.black);
		g.drawLine(0, 0, 0, 20);
		for (int i = 5; i < 25; i += 5)
			g.drawLine(0, i, 10, i);

		return new TexturePaint(bi, new Rectangle(bi.getWidth(), bi.getHeight()));
	}

}
