package com.tm.commons.drawing.tool;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.pane.GraphPane;

public class Line extends Pen {
	int x;
	int y;
	int w;
	int h;

	public Line() {
		super(DrawingToolEnum.LINE);
		this.shape = new Line2D.Double();
	}

	public Line(GraphPane graphPane, Color color, FillPattern fillPattern) {
		super(DrawingToolEnum.LINE, graphPane, color, fillPattern);
		this.shape = new Line2D.Double();
	}

	@Override
	public void draw(int x, int y) {
		super.draw(x, y);

		if (this.getPenWidth() > 1) {
			this.w = rect.width - 1;
			this.h = rect.height - 1;
			this.x = rect.x;
			this.y = rect.y;

			((Line2D) this.shape).setLine(this.startX, this.startY, x, y);
			draw();
		} else {
			int[] drawingData = this.getDrawingData();
			BufferedImage img = this.graphPane.getDrawingImage().getImage();
			Graphics2D g = img.createGraphics();
			g.setColor(color);
			g.drawImage(this.graphPane.getSavedImage(), 0, 0, this.graphPane);
			this.drawLine(drawingData, this.drawingWidth, this.drawingHeight);

		}
	}

	@Override
	public void move(int x, int y) {
		super.move(x, y);
		this.draw(this.currentX, this.currentY);
	}

	@Override
	public void save() {
		if (this.getPenWidth() > 1) {
			super.save();
		} else {
			saveLine();
		}
	}

	public void saveLine() {
		if (startX == currentX && startY == currentY) {
			return;
		}

		int[] savedData = this.getSavedData();
		int idx = 0;
		if (this.rect.width < 4 && this.rect.height < 4) {
			int[] data = new int[this.rect.width * this.rect.height * 3];
			for (int i = 0; i < rect.width; i++) {
				for (int j = 0; j < rect.height; j++) {
					data[idx++] = rect.x + i;
					data[idx++] = rect.y + j;
					data[idx++] = savedData[(rect.y + j) * this.imgWidth + (rect.x + i)];
				}
			}
			this.graphPane.addUndoState(data);
		} else {
			BufferedImage img = this.graphPane.getSavedImage().getSubimage(rect.x, rect.y, rect.width, rect.height);
			this.graphPane.addUndoState(rect.x, rect.y, img);
		}

		this.drawLine(savedData, this.imgWidth, this.imgHeight);
		this.resetColor();
	}

}
