package com.tm.commons.drawing.tool;

import java.awt.Point;

public class BezPoints {
	public Point start;
	public Point end;
	public Point ctrl;
	
	@Override
	public String toString() {
		return "start: " + start + ", end: " + end + ", ctrl: " + ctrl;
	}
}
