package com.tm.commons.drawing.tool;

public class PenHolder {
	Pen pen;
	static int cnt = 0;
	int brush = 1;
	int[] lockedRGB;
	
	public PenHolder() {
	}

	public PenHolder(Pen pen) {
		this.pen = pen;
	}

	public Pen getPen() {
		return pen;
	}

	public void setPen(Pen pen) {
		this.pen = pen;
		this.pen.setPenWidth(this.brush);
		this.pen.setLockedRGB(this.lockedRGB);
	}

	public void setBrush(int brush)
	{
		this.brush = brush;
		this.pen.setPenWidth(brush);
	}
	
	public int[] getLockedRGBs()
	{
		return this.lockedRGB;
	}
	
	public void setLockedColor(int[] rgb)
	{
		this.lockedRGB = rgb;
		this.pen.setLockedRGB(rgb);
		System.out.println("Locked RGBs: " + (rgb != null ? rgb.length : "NULL"));
	}
}
