package com.tm.commons.drawing.tool;

import java.awt.Color;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.pane.GraphPane;

public class Select extends Pen {
	public Select() {
		super(DrawingToolEnum.SELECT);
	}

	public Select(GraphPane graphPane, Color color, FillPattern fillPattern) {
		super(DrawingToolEnum.SELECT, graphPane, color, fillPattern);
	}

	@Override
	public void draw(int x, int y) {
		super.draw(x, y);
		draw();
	}
}
