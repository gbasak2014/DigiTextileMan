package com.tm.commons.drawing.tool;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.Arc2D;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.pane.GraphPane;

public class Pencil extends Pen {

	int minX;
	int minY;
	int maxX;
	int maxY;

	Arc2D circle;
	Line2D line;

	public Pencil() {
		super(DrawingToolEnum.PEN);
		this.circle = new Arc2D.Double();
		this.line = new Line2D.Double();
	}

	public Pencil(GraphPane graphPane, Color color, FillPattern fillPattern) {
		super(DrawingToolEnum.PEN, graphPane, color, fillPattern);
	}

	@Override
	public void setStartPoint(int x, int y) {
		super.setStartPoint(x, y);
		if (x >= 0 && y >= 0) {
			int rgb = this.getColorRGB();
			int[] drawingData = this.getDrawingData();
			if (this.penWidth < 2) {
				if (!this.isLocked(drawingData[y * this.drawingWidth + x] | 0xFF000000))
				{
					drawingData[y * this.drawingWidth + x] = rgb;
				}
			} else {
				this.circle.setArc(x - this.penWidth / 2, y - this.penWidth / 2, this.penWidth, this.penWidth, 0, 360, Arc2D.OPEN);
				Graphics2D g = this.graphPane.getDrawingImage().getImage().createGraphics();
				g.setColor(this.color);
				g.fill(this.circle);
				g.dispose();
			}

		}

		minX = maxX = x;
		minY = maxY = y;
	}

	@Override
	public void draw(int x, int y) {
		super.draw(x, y);
		int rgb = this.color.getRGB();
		Rectangle area = this.graphPane.getDrawingArea();
		int[] drawingData = this.getDrawingData();
		
		if (startX == x && startY == y) {
			if (drawingData[y * this.drawingWidth + x] != rgb && !this.isLocked(drawingData[y * this.drawingWidth + x] | 0xFF000000)) {
				if (this.penWidth < 2) {
					drawingData[y * this.drawingWidth + x] = rgb;

					if (area != null && !area.contains(x, y)) {
						setInDrawingArea(drawingData, area, x, y, rgb, this.drawingWidth, this.drawingHeight);
					}
				} else {
					this.circle.setArc(x - this.penWidth / 2, y - this.penWidth / 2, this.penWidth, this.penWidth, 0, 360, Arc2D.OPEN);
					Graphics2D g = this.graphPane.getDrawingImage().getImage().createGraphics();
					g.setColor(this.color);
					g.fill(this.circle);
					g.dispose();
				}
			}
		} else {
			if (this.penWidth < 2) {
				drawLine(drawingData, this.drawingWidth, this.drawingHeight);
			} else {
				drawBrushedLine();
			}

			if (minX > x) {
				minX = x;
			} else if (maxX < x) {
				maxX = x;
			}

			if (minY > y) {
				minY = y;
			} else if (maxY < y) {
				maxY = y;
			}
		}

		this.startX = x;
		this.startY = y;
	}

	void drawBrushedLine() {
		this.line.setLine(startX, startY, currentX, currentY);
		Graphics2D g = this.graphPane.getDrawingImage().getImage().createGraphics();
		g.setColor(this.color);
		g.setStroke(new BasicStroke(this.penWidth));
		g.draw(this.line);
		g.dispose();
	}

	@Override
	public void save() {
		if (this.startX > 0) {
			if (this.penWidth > 1) {
				minX = minX - (this.penWidth / 2);
				minY = minY - (this.penWidth / 2);

				maxX = maxX + (this.penWidth / 2) + 1;
				maxY = maxY + (this.penWidth / 2) + 1;
			}

			System.out.println("A:" + minX + "," + minY + "-" + maxX + "," + maxY);
			
			if (minX < 0)
				minX = 0;
			if (minY < 0)
				minY = 0;
			if (maxX >= this.graphPane.getImgWidth())
				maxX = this.graphPane.getImgWidth() - 1;
			if (maxY >= this.graphPane.getImgHeight())
				maxY = this.graphPane.getImgHeight() - 1;
			
			if (minX == maxX) {
				this.graphPane.addUndoState(new int[] { this.startX, this.startY, this.graphPane.getSavedImage().getRGB(this.startX, this.startY) });
			} else {
				BufferedImage si = this.graphPane.getSavedImage();
				int siW = si.getWidth();
				int siH = si.getHeight();
				int sw = (maxX - minX + 1);
				int sh = (maxY - minY + 1);
				
				System.out.println("B:" + minX + "," + minY + "-" + maxX + "," + maxY);
				System.out.println(siW + "-" + siH + ">>" + minX + "+"+ sw + ", " +  minY + "+" + sh);
				
				try {
					BufferedImage img = this.graphPane.getSavedImage().getSubimage(minX, minY, sw, sh);
					this.graphPane.addUndoState(minX, minY, img);					
				} catch (Exception e) {
					e.printStackTrace();
				}

			}

			Graphics2D g = this.graphPane.getSavedImage().createGraphics();
			g.drawImage(this.graphPane.getDrawingImage().getImage(), 0, 0, this.graphPane);
			g.dispose();

			this.setStartPoint(-1, -1);
		}

		this.resetColor();
	}
}
