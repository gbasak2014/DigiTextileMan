package com.tm.commons.drawing.tool;

import java.awt.image.BufferedImage;

public class FillPattern {
	boolean solid;
	BufferedImage pattern;

	public boolean isSolid() {
		return solid;
	}

	public BufferedImage getPattern() {
		return pattern;
	}

	public void setSolid(boolean solid) {
		this.solid = solid;
		if (this.solid)
		{
			this.pattern = null;
		}
	}

	public void setPattern(BufferedImage pattern) {
		this.pattern = pattern;
		if (this.pattern != null)
		{
			this.solid = false;
		}
	}

}
