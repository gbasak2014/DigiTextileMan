package com.tm.commons.drawing.tool;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.TexturePaint;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.pane.GraphPane;

public abstract class Pen {
	public static final byte ALL = 0;
	public static final byte START_X = 1;
	public static final byte START_Y = 2;
	public static final byte CURRENT_X = 3;
	public static final byte CURRENT_Y = 4;

	public static final byte STARTX_STARTY = 5;
	public static final byte STARTX_CURRENTY = 6;
	public static final byte CURRENTX_STARTY = 7;
	public static final byte CURRENTX_CURRENTY = 8;

	int startX;
	int startY;
	int currentX;
	int currentY;

	Rectangle rect = new Rectangle();

	GraphPane graphPane;
	Color color;
	Color bakColor;

	Color fillColor;
	Color bakFillColor;

	FillPattern fillPattern;
	DrawingToolEnum pattern;

	Shape shape;

	// int[] drawingData;
	// int[] savedData;

	int imgWidth;
	int imgHeight;
	int drawingWidth;
	int drawingHeight;

	byte mode;

	int linePattern[] = { 1 };

	DrawingToolEnum type;

	//TexturePaint texturePaint;
	TexturePaint scalePaint;
	
	int penWidth = 1;

	int[] lockedRGB;

	boolean pickFillColor;

	public void setLockedRGB(int[] rgb) {
		this.lockedRGB = rgb;
	}

	public boolean isLocked(int rgb) {
		if (this.lockedRGB == null) {
			return false;
		}

		for (int lcRGB : this.lockedRGB) {
			if (rgb == lcRGB) {
				return true;
			}
		}

		return false;
	}

	public Pen(DrawingToolEnum type) {
		this.type = type;
	}

	public Pen(DrawingToolEnum type, GraphPane graphPane, Color color, FillPattern fillPattern) {
		this.type = type;
		this.graphPane = graphPane;
		this.color = color;
		this.fillPattern = fillPattern;
		// this.drawingData = ((DataBufferInt)
		// this.graphPane.getDrawingImage().getImage().getRaster().getDataBuffer()).getData();
		// this.savedData = ((DataBufferInt)
		// this.graphPane.getSavedImage().getRaster().getDataBuffer()).getData();

		this.imgWidth = this.graphPane.getSavedImage().getWidth();
		this.imgHeight = this.graphPane.getSavedImage().getHeight();

		this.drawingWidth = this.graphPane.getDrawingImage().getImage().getWidth();
		this.drawingHeight = this.graphPane.getDrawingImage().getImage().getHeight();
		this.startX = this.startY = this.currentX = this.currentY = -1;
	}

	public void setStartPoint(int x, int y) {
		this.currentX = this.startX = x;
		this.currentY = this.startY = y;
		this.rect.x = this.rect.y = this.rect.width = this.rect.height = -1;
	}

	public void setCurrentPoint(int x, int y) {
		if (x < 0)
			x = 0;
		else if (x >= this.graphPane.getImgWidth())
			x = this.graphPane.getImgWidth() - 1;

		if (y < 0)
			y = 0;
		else if (y >= this.graphPane.getImgHeight())
			y = this.graphPane.getImgHeight();

		this.currentX = x;
		this.currentY = y;
	}

	public void draw(int x, int y) {
		if (x < 0)
			x = 0;
		else if (x >= this.graphPane.getImgWidth())
			x = this.graphPane.getImgWidth();

		if (y < 0)
			y = 0;
		else if (y >= this.graphPane.getImgHeight())
			y = this.graphPane.getImgHeight();

		switch (this.mode) {
		case ALL:
			this.currentX = x;
			this.currentY = y;
			break;
		case START_X:
			this.startX = x;
			break;
		case START_Y:
			this.startY = y;
			break;
		case CURRENT_X:
			this.currentX = x;
			break;
		case CURRENT_Y:
			this.currentY = y;
			break;
		case STARTX_STARTY:
			this.startX = x;
			this.startY = y;
			break;
		case STARTX_CURRENTY:
			this.startX = x;
			this.currentY = y;
			break;
		case CURRENTX_STARTY:
			this.currentX = x;
			this.startY = y;
			break;
		default:
			this.currentX = x;
			this.currentY = y;
		}

		int x1 = startX;
		int y1 = startY;
		int x2 = currentX;
		int y2 = currentY;

		int tmp;
		if (x1 > x2) {
			tmp = x1;
			x1 = x2;
			x2 = tmp;
		}
		if (y1 > y2) {
			tmp = y1;
			y1 = y2;
			y2 = tmp;
		}

		rect.x = x1;
		rect.y = y1;
		rect.width = x2 - x1 + 1;
		rect.height = y2 - y1 + 1;
	}

	public void select(Graphics2D g) {
		if (rect.width > 0) {
			int zoom = this.graphPane.getZoom();
			g.setColor(Color.BLACK);
			float dash1[] = { 5.0f };
			BasicStroke dashed = new BasicStroke(3.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, dash1,
					0.0f);
			g.setStroke(dashed);
			g.draw(new Rectangle(rect.x * zoom, rect.y * zoom, (rect.width) * zoom, (rect.height) * zoom));
		}
	}

	public void select(Graphics2D g, int imageLeft, int imageTop) {
		int zoom = this.graphPane.getZoom();
		if (this.scalePaint != null) {
			g.setPaint(this.scalePaint);
			int sw;
			int sh;
			if (this.type == DrawingToolEnum.SCALE_H) {
				sh = 20;
				sw = this.rect.width * this.graphPane.getZoom();
			} else {
				sw = 20;
				sh = this.rect.height * this.graphPane.getZoom();
			}
			//g.fillRect((rect.x - imageLeft) * zoom, (rect.y - imageTop) * zoom, rect.width, rect.height);
			g.fillRect((rect.x - imageLeft) * zoom, (rect.y - imageTop) * zoom, sw, sh);
		} else {
			g.setColor(Color.BLACK);
			float dash1[] = { 5.0f };
			BasicStroke dashed = new BasicStroke(3.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, dash1,
					0.0f);
			g.setStroke(dashed);
			g.draw(new Rectangle((rect.x - imageLeft) * zoom, (rect.y - imageTop) * zoom, (rect.width) * zoom,
					(rect.height) * zoom));
		}
	}

	public void select(Rectangle rect, Graphics2D g, int imageLeft, int imageTop) {
		int zoom = this.graphPane.getZoom();
		g.setColor(Color.RED);
		float dash1[] = { 5.0f };
		BasicStroke dashed = new BasicStroke(3.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, dash1, 0.0f);
		g.setStroke(dashed);
		g.draw(new Rectangle((rect.x - imageLeft) * zoom, (rect.y - imageTop) * zoom, (rect.width) * zoom,
				(rect.height) * zoom));
	}

	public void move(int x, int y) {
		if (rect.width > 0) {
			rect.translate(x, y);
			this.startX = this.startX + x;
			this.currentX = this.currentX + x;
			this.startY = this.startY + y;
			this.currentY = this.currentY + y;
		}
	}

	public void draw() {
		Graphics2D g = this.graphPane.getDrawingImage().getImage().createGraphics();
		g.setStroke(new BasicStroke(this.penWidth));
		g.setColor(this.fillColor);
		g.drawImage(this.graphPane.getSavedImage(), 0, 0, this.graphPane);
		if (this.shape != null && rect.width > 0) {

			Paint oldPaint = g.getPaint();

			if (fillPattern.isSolid()) {
				g.fill(this.shape);
			} else if (fillPattern.getPattern() != null) {
				TexturePaint tp = new TexturePaint(fillPattern.getPattern(),
						new Rectangle(fillPattern.getPattern().getWidth(), fillPattern.getPattern().getHeight()));
				g.setPaint(tp);
				g.fill(this.shape);
			}

			g.setPaint(oldPaint);
			g.setColor(this.color);
			g.draw(this.shape);
			g.dispose();
			Rectangle area = this.graphPane.getDrawingArea();
			Rectangle shapeBound = this.shape.getBounds();
			if (area != null && !area.contains(shapeBound) && (shapeBound.width > 2 || shapeBound.height > 2)) {
				drawInDrawingArea(this.graphPane.getDrawingImage().getImage(), area);
			}

		} else {
			g.dispose();
		}
	}

	public void save() {
		if (this.shape != null && this.rect.width > 0) {
			int tmp = this.penWidth / 2;
			Rectangle bound = new Rectangle(rect.x - tmp, rect.y - tmp, rect.width + this.penWidth,
					rect.height + this.penWidth);
			Rectangle imgSize = new Rectangle(0, 0, this.graphPane.getImgWidth(), this.graphPane.getImgHeight());
			bound = imgSize.intersection(bound);

			try {
				BufferedImage img = this.graphPane.getSavedImage().getSubimage(bound.x, bound.y, bound.width,
						bound.height);
				this.graphPane.addUndoState(bound.x, bound.y, img);
			} catch (Exception e) {
				e.printStackTrace();
			}
			Graphics2D g = this.graphPane.getSavedImage().createGraphics();
			g.setStroke(new BasicStroke(this.penWidth));
			g.setColor(this.fillColor);
			Paint oldPaint = g.getPaint();

			if (fillPattern.isSolid()) {
				g.fill(this.shape);
			} else if (fillPattern.getPattern() != null) {
				TexturePaint tp = new TexturePaint(fillPattern.getPattern(),
						new Rectangle(fillPattern.getPattern().getWidth(), fillPattern.getPattern().getHeight()));
				g.setPaint(tp);
				g.fill(this.shape);
			}

			g.setPaint(oldPaint);
			g.setColor(this.color);
			g.draw(this.shape);
			g.dispose();

			Rectangle area = this.graphPane.getDrawingArea();
			Rectangle shapeBound = this.shape.getBounds();
			if (area != null && !area.contains(shapeBound) && (shapeBound.width > 2 || shapeBound.height > 2)) {
				drawInDrawingArea(this.graphPane.getSavedImage(), area);
			}

			this.setStartPoint(-1, -1);
		}

		this.resetColor();
	}

	public FillPattern getFillPattern() {
		return fillPattern;
	}

	public void setFillPattern(FillPattern fillPattern) {
		this.fillPattern = fillPattern;
	}

	public DrawingToolEnum getPattern() {
		return pattern;
	}

	public void setPattern(DrawingToolEnum pattern) {
		this.pattern = pattern;
	}

	public Color getColor() {
		return color;
	}

	public int getColorRGB() {
		return this.color.getRGB();
	}

	public void setColor(Color color) {
		this.color = color;
		this.bakColor = null;
	}

	public void setClearColor() {
		this.bakColor = this.color;
		this.color = Color.WHITE;
	}

	public void resetColor() {
		if (this.bakColor != null) {
			this.color = this.bakColor;
			this.bakColor = null;
		}
	}

	public void resetFillColor() {
		if (this.bakColor != null) {
			this.color = this.bakColor;
			this.bakColor = null;
		}
	}

	public GraphPane getGraphPane() {
		return graphPane;
	}

	public void setGraphPane(GraphPane graphPane) {
		this.graphPane = graphPane;
		this.imgWidth = this.graphPane.getSavedImage().getWidth();
		this.imgHeight = this.graphPane.getSavedImage().getHeight();

		this.drawingWidth = this.graphPane.getDrawingImage().getImage().getWidth();
		this.drawingHeight = this.graphPane.getDrawingImage().getImage().getHeight();

	}

	public int[] getDrawingData() {
		return ((DataBufferInt) this.graphPane.getDrawingImage().getImage().getRaster().getDataBuffer()).getData();
	}

	public int[] getSavedData() {
		return ((DataBufferInt) this.graphPane.getSavedImage().getRaster().getDataBuffer()).getData();
	}

	public boolean inside(int x, int y) {
		return rect.contains(x, y);
	}

	public Rectangle getBound() {
		return this.rect;
	}

	public byte getMode() {
		return mode;
	}

	public void setMode(byte mode) {
		this.mode = mode;
	}

	public int getStartX() {
		return startX;
	}

	public int getStartY() {
		return startY;
	}

	public int getCurrentX() {
		return currentX;
	}

	public int getCurrentY() {
		return currentY;
	}

	public void setStartX(int startX) {
		this.startX = startX;
	}

	public void setStartY(int startY) {
		this.startY = startY;
	}

	public void setCurrentX(int currentX) {
		this.currentX = currentX;
	}

	public void setCurrentY(int currentY) {
		this.currentY = currentY;
	}

	public DrawingToolEnum getType() {
		return type;
	}

	public int[] getLinePattern() {
		return linePattern;
	}

	public void setLinePattern(int[] linePattern) {
		this.linePattern = linePattern;
	}

	void drawLine() {
		if (startX == currentX && startY == currentY) {
			return;
		}

		int dx;
		int dy;

		int e = 0;
		int px = startX;
		int py = startY;
		int rgb = color.getRGB();
		int mx;
		int my;
		if (startX < currentX) {
			dx = currentX - startX;
			mx = 1;
		} else {
			dx = startX - currentX;
			mx = -1;
		}

		if (startY < currentY) {
			dy = currentY - startY;
			my = 1;
		} else {
			dy = startY - currentY;
			my = -1;
		}

		Rectangle area = this.graphPane.getDrawingArea();
		int[] savedData = this.getSavedData();
		int[] drawingData = this.getDrawingData();

		if (dx > dy) {
			while (px != currentX) {
				savedData[py * this.imgWidth + px] = rgb;
				drawingData[py * this.drawingWidth + px] = rgb;

				if (area != null && !area.contains(px, py)) {
					setInDrawingArea(area, px, py, rgb);
				}

				if (2 * (e + dy) < dx) {
					e = e + dy;
				} else {
					py = py + my;
					e = e + dy - dx;
				}
				px = px + mx;
			}
		} else {
			while (py != currentY) {
				savedData[py * this.imgWidth + px] = rgb;
				drawingData[py * this.drawingWidth + px] = rgb;

				if (area != null && !area.contains(px, py)) {
					setInDrawingArea(area, px, py, rgb);
				}

				if (2 * (e + dx) < dy) {
					e = e + dx;
				} else {
					px = px + mx;
					e = e + dx - dy;
				}
				py = py + my;
			}
		}

		savedData[currentY * this.imgWidth + currentX] = rgb;
		drawingData[currentY * this.drawingWidth + currentX] = rgb;

		if (area != null && !area.contains(currentX, currentY)) {
			setInDrawingArea(area, currentX, currentY, rgb);
		}
	}

	void setInDrawingArea(Rectangle area, int x, int y, int rgb) {
		if (x < area.x) {
			x = x + area.width;
		} else if (x >= (area.x + area.width)) {
			x = x - area.width;
		}

		if (y < area.y) {
			y = y + area.height;
		} else if (y >= (area.y + area.height)) {
			y = y - area.height;
		}

		if (area.contains(x, y)) {
			int[] savedData = this.getSavedData();
			int[] drawingData = this.getDrawingData();
			drawingData[y * this.drawingWidth + x] = rgb;
			savedData[y * this.imgWidth + x] = rgb;
		}
	}

	void drawLine(int[] data, int width, int height) {
		if (startX == currentX && startY == currentY) {
			return;
		}

		int dx;
		int dy;

		int e = 0;
		int px = startX;
		int py = startY;
		int rgb = color.getRGB();
		int mx;
		int my;
		if (startX < currentX) {
			dx = currentX - startX;
			mx = 1;
		} else {
			dx = startX - currentX;
			mx = -1;
		}

		if (startY < currentY) {
			dy = currentY - startY;
			my = 1;
		} else {
			dy = startY - currentY;
			my = -1;
		}

		Rectangle area = this.graphPane.getDrawingArea();
		int pIdx = 0;
		int pLen = linePattern.length;
		if (dx > dy) {
			while (px != currentX) {
				if (linePattern[pIdx] != 0) {
					if (!this.isLocked(data[py * width + px] | 0xFF000000)) {
						data[py * width + px] = rgb;
					}
					if (area != null && !area.contains(px, py)) {
						setInDrawingArea(data, area, px, py, rgb, width, height);
					}
				}

				pIdx = (pIdx + 1) % pLen;

				if (2 * (e + dy) < dx) {
					e = e + dy;
				} else {
					py = py + my;
					e = e + dy - dx;
				}
				px = px + mx;
			}
		} else {
			while (py != currentY) {

				if (linePattern[pIdx] != 0) {
					if (!this.isLocked(data[py * width + px] | 0xFF000000)) {
						data[py * width + px] = rgb;
					}
					if (area != null && !area.contains(px, py)) {
						setInDrawingArea(data, area, px, py, rgb, width, height);
					}
				}

				pIdx = (pIdx + 1) % pLen;

				if (2 * (e + dx) < dy) {
					e = e + dx;
				} else {
					px = px + mx;
					e = e + dx - dy;
				}
				py = py + my;
			}
		}

		if (!this.isLocked(data[currentY * width + currentX] | 0xFF000000)) {
			data[currentY * width + currentX] = rgb;
		}

		if (area != null && !area.contains(currentX, currentY)) {
			setInDrawingArea(data, area, currentX, currentY, rgb, width, height);
		}
	}

	void setInDrawingArea(int[] data, Rectangle area, int x, int y, int rgb, int width, int height) {
		if (x < area.x) {
			x = x + area.width;
		} else if (x >= (area.x + area.width)) {
			x = x - area.width;
		}

		if (y < area.y) {
			y = y + area.height;
		} else if (y >= (area.y + area.height)) {
			y = y - area.height;
		}

		if (area.contains(x, y) && !this.isLocked(data[y * width + x] | 0xFF000000)) {
			data[y * width + x] = rgb;
		}
	}

	void drawInDrawingArea(BufferedImage drawingImg, Rectangle area) {
		Rectangle rect1 = (Rectangle) this.rect.clone();
		BufferedImage drawingAreaImg = drawingImg.getSubimage(area.x, area.y, area.width, area.height);
		BufferedImage shapeImg = getShapeImage(drawingImg, rect1);

		rect1.x = rect1.x + area.width;
		if (area.intersects(rect1)) {
			rect1.translate(-area.x, -area.y);
			drawingAreaImg.getGraphics().drawImage(shapeImg, rect1.x, rect1.y, null);
		}

		rect1 = (Rectangle) this.rect.clone();
		rect1.y = rect1.y + area.height;
		if (area.intersects(rect1)) {
			rect1.translate(-area.x, -area.y);
			drawingAreaImg.getGraphics().drawImage(shapeImg, rect1.x, rect1.y, null);
		}

		rect1 = (Rectangle) this.rect.clone();
		rect1.x = rect1.x - area.width;
		if (area.intersects(rect1)) {
			rect1.translate(-area.x, -area.y);
			drawingAreaImg.getGraphics().drawImage(shapeImg, rect1.x, rect1.y, null);
		}

		rect1 = (Rectangle) this.rect.clone();
		rect1.y = rect1.y - area.height;
		if (area.intersects(rect1)) {
			rect1.translate(-area.x, -area.y);
			drawingAreaImg.getGraphics().drawImage(shapeImg, rect1.x, rect1.y, null);
		}

		rect1 = (Rectangle) this.rect.clone();
		rect1.x = rect1.x + area.width;
		rect1.y = rect1.y - area.height;
		if (area.intersects(rect1)) {
			rect1.translate(-area.x, -area.y);
			drawingAreaImg.getGraphics().drawImage(shapeImg, rect1.x, rect1.y, null);
		}

		rect1 = (Rectangle) this.rect.clone();
		rect1.x = rect1.x + area.width;
		rect1.y = rect1.y + area.height;
		if (area.intersects(rect1)) {
			rect1.translate(-area.x, -area.y);
			drawingAreaImg.getGraphics().drawImage(shapeImg, rect1.x, rect1.y, null);
		}

		rect1 = (Rectangle) this.rect.clone();
		rect1.x = rect1.x - area.width;
		rect1.y = rect1.y - area.height;
		if (area.intersects(rect1)) {
			rect1.translate(-area.x, -area.y);
			drawingAreaImg.getGraphics().drawImage(shapeImg, rect1.x, rect1.y, null);
		}

		rect1 = (Rectangle) this.rect.clone();
		rect1.x = rect1.x - area.width;
		rect1.y = rect1.y + area.height;
		if (area.intersects(rect1)) {
			rect1.translate(-area.x, -area.y);
			drawingAreaImg.getGraphics().drawImage(shapeImg, rect1.x, rect1.y, null);
		}
	}

	BufferedImage getShapeImage(BufferedImage img, Rectangle area) {
		BufferedImage img1 = img.getSubimage(rect.x, rect.y, rect.width, rect.height);
		return img1;
	}

	public int getPenWidth() {
		return penWidth;
	}

	public void setPenWidth(int penWidth) {
		this.penWidth = penWidth;
	}

	public Color getFillColor() {
		return fillColor;
	}

	public void setFillColor(Color fillColor) {
		this.fillColor = fillColor;
	}

	public void setPickFill(boolean isFill) {
		this.pickFillColor = isFill;
	}

	public void clear() {
	}
}
