package com.tm.commons.drawing.tool;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.pane.GraphPane;

public class LineBak extends Pen {

	public LineBak() {
		super(DrawingToolEnum.LINE);
	}

	public LineBak(GraphPane graphPane, Color color, FillPattern fillPattern) {
		super(DrawingToolEnum.LINE, graphPane, color, fillPattern);
	}

	@Override
	public void draw(int x, int y) {
		super.draw(x, y);
		int[] drawingData = this.getDrawingData();
		BufferedImage img = this.graphPane.getDrawingImage().getImage();
		Graphics2D g = img.createGraphics();
		g.setColor(color);
		g.drawImage(this.graphPane.getSavedImage(), 0, 0, this.graphPane);
		this.drawLine(drawingData, this.drawingWidth, this.drawingHeight);
	}

	@Override
	public void save() {
		if (startX == currentX && startY == currentY) {
			return;
		}

		int[] savedData = this.getSavedData();
		int idx = 0;
		if (this.rect.width < 4 && this.rect.height < 4) {
			int[] data = new int[this.rect.width * this.rect.height * 3];
			for (int i = 0; i < rect.width; i++) {
				for (int j = 0; j < rect.height; j++) {
					data[idx++] = rect.x + i;
					data[idx++] = rect.y + j;
					data[idx++] = savedData[(rect.y + j) * this.imgWidth + (rect.x + i)];
				}
			}
			this.graphPane.addUndoState(data);
		}
		else
		{
			BufferedImage img = this.graphPane.getSavedImage().getSubimage(rect.x, rect.y, rect.width, rect.height);
			this.graphPane.addUndoState(rect.x, rect.y, img);
		}
		
		this.drawLine(savedData, this.imgWidth, this.imgHeight);
		this.resetColor();
	}

	@Override
	public void move(int x, int y) {
		super.move(x, y);
		this.draw(this.currentX, this.currentY);
	}
}
