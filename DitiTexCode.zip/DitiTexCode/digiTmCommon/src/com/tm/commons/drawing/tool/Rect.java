package com.tm.commons.drawing.tool;

import java.awt.Color;
import java.awt.geom.Rectangle2D;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.pane.GraphPane;

public class Rect extends Pen {
	public Rect() {
		super(DrawingToolEnum.RECT);
		this.shape = new Rectangle2D.Double();
	}

	public Rect(GraphPane graphPane, Color color, FillPattern fillPattern) {
		super(DrawingToolEnum.RECT, graphPane, color, fillPattern);
		this.shape = new Rectangle2D.Double();
	}

	@Override
	public void draw(int x, int y) {
		super.draw(x, y);
		((Rectangle2D) this.shape).setRect(this.rect.x, this.rect.y, this.rect.width - 1, this.rect.height - 1);
		draw();
	}

	@Override
	public void move(int x, int y) {
		super.move(x, y);
		this.draw(this.currentX, this.currentY);
	}
}
