package com.tm.commons.drawing.tool;

import java.awt.Color;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.pane.GraphPane;

public class PickColor extends Pen {

	public PickColor() {
		super(DrawingToolEnum.PICK);
	}

	public PickColor(GraphPane graphPane, Color color, FillPattern fillPattern) {
		super(DrawingToolEnum.PICK, graphPane, color, fillPattern);
	}
	
	@Override
	public void draw(int x, int y) {
		this.startX = this.currentX = x;
		this.startY = this.currentY = y;
	}

	@Override
	public void save() {
		this.resetColor();
	}
}
