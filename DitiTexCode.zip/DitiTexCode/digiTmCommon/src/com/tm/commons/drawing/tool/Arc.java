package com.tm.commons.drawing.tool;

import java.awt.Color;
import java.awt.geom.Arc2D;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.pane.GraphPane;

public class Arc extends Pen {

	int x;
	int y;
	int w;
	int h;
	int startAngle;
	int angle;

	public Arc() {
		super(DrawingToolEnum.CIRCLE);
		this.pattern = DrawingToolEnum.CIRCLE_FULL;
		this.startAngle = 0;
		this.angle = 360;
		this.shape = new Arc2D.Double();
		//this.shape = new Line2D.Double();
	}

	public Arc(GraphPane graphPane, Color color, FillPattern fillPattern) {
		super(DrawingToolEnum.CIRCLE, graphPane, color, fillPattern);
		this.pattern = DrawingToolEnum.CIRCLE_FULL;
		this.startAngle = 0;
		this.angle = 360;
		this.shape = new Arc2D.Double();
	}

	@Override
	public void draw(int x, int y) {
		super.draw(x, y);
		this.w = rect.width - 1;
		this.h = rect.height - 1;
		this.x = rect.x;
		this.y = rect.y;
		int closure = Arc2D.PIE;

		switch (this.pattern) {
		case CIRCLE_FULL:
			closure = Arc2D.OPEN;
			this.startAngle = 0;
			this.angle = 360;
			break;
		case CIRCLE_LEFT:
			this.w = this.w + this.w;
			this.startAngle = 90;
			this.angle = 180;
			break;
		case CIRCLE_RIGHT:
			this.x = this.x - this.w;
			this.w = this.w + this.w;
			this.startAngle = 270;
			this.angle = 180;
			break;
		case CIRCLE_TOP:
			this.h = this.h + this.h;
			this.startAngle = 0;
			this.angle = 180;
			break;
		case CIRCLE_BOTTOM:
			this.y = this.y - this.h;
			this.h = this.h + this.h;
			this.startAngle = 180;
			this.angle = 180;
			break;
		case CIRCLE_TOP_LEFT:
			this.w = this.w + this.w;
			this.h = this.h + this.h;
			this.startAngle = 90;
			this.angle = 90;
			break;
		case CIRCLE_TOP_RIGHT:
			this.x = this.x - this.w;
			this.w = this.w + this.w;
			this.h = this.h + this.h;
			this.startAngle = 0;
			this.angle = 90;
			break;
		case CIRCLE_BOTTOM_LEFT:
			this.y = this.y - this.h;
			this.w = this.w + this.w;
			this.h = this.h + this.h;
			this.startAngle = 180;
			this.angle = 90;
			break;
		case CIRCLE_BOTTOM_RIGHT:
			this.x = this.x - this.w;
			this.y = this.y - this.h;
			this.w = this.w + this.w;
			this.h = this.h + this.h;
			this.startAngle = 270;
			this.angle = 90;
			break;
		default:
			this.startAngle = 0;
			this.angle = 360;
		}

		((Arc2D) this.shape).setArc(this.x, this.y, this.w, this.h, startAngle, angle, closure);
		draw();
	}

	@Override
	public void move(int x, int y) {
		super.move(x, y);
		this.draw(this.currentX, this.currentY);
	}
}
