package com.tm.commons.drawing.tool;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.pane.GraphPane;

public class ReplaceColor extends Pen {

	public ReplaceColor() {
		super(DrawingToolEnum.REPLACE_COLOR);
	}

	public ReplaceColor(GraphPane graphPane, Color color, FillPattern fillPattern) {
		super(DrawingToolEnum.REPLACE_COLOR, graphPane, color, fillPattern);
	}

	@Override
	public void draw(int x, int y) {
		this.startX = this.currentX = x;
		this.startY = this.currentY = y;
		save();
	}

	@Override
	public void save() {
		if (this.currentX >= 0 && this.currentY >= 0 && this.currentX < this.graphPane.getImgWidth()
				&& this.currentY < this.graphPane.getImgHeight()) {
			int oldRgb = this.graphPane.getSavedImage().getRGB(this.currentX, this.currentY) | 0xff000000;
			int newRgb = this.fillColor.getRGB();
			Rectangle rect = this.graphPane.getDrawingArea();
			int x1;
			int y1;
			int x2;
			int y2;

			if (rect != null && rect.contains(this.currentX, this.currentY)) {
				x1 = rect.x;
				y1 = rect.y;
				x2 = x1 + rect.width;
				y2 = y1 + rect.height;
			} else {
				x1 = 0;
				y1 = 0;
				x2 = this.graphPane.getImgWidth();
				y2 = this.graphPane.getImgHeight();
			}

			int replaceCnt=0;
			int[] sd = getSavedData();
			int[] dd = getDrawingData();
			
			for (int x = x1; x < x2; x++) {
				for (int y = y1; y < y2; y++) {
					if ((sd[y * this.imgWidth + x] | 0xff000000) == oldRgb) {
						dd[y * this.imgWidth + x] = newRgb;
						replaceCnt++;
					}
				}
			}
			if (replaceCnt > 0)
			{
				this.graphPane.addUndoState();
				Graphics2D g = this.graphPane.getSavedImage().createGraphics();
				g.drawImage(this.graphPane.getDrawingImage().getImage(), 0, 0, this.graphPane);
				g.dispose();
			}
			
			this.startX = this.currentX = this.startY = this.currentY = -1;
		}
		
		this.resetColor();
	}
}
