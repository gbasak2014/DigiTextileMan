package com.tm.commons.drawing.tool;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.pane.GraphPane;

public class Arrange extends Pen {
	BufferedImage image;

	public Arrange() {
		super(DrawingToolEnum.ARRANGE);
	}

	public Arrange(GraphPane graphPane, Color color, FillPattern fillPattern) {
		super(DrawingToolEnum.ARRANGE, graphPane, color, fillPattern);
	}
	
	@Override
	public void draw() {
		// TODO Auto-generated method stub
		super.draw();
	}
	
	@Override
	public void setStartPoint(int x, int y) {
		super.setStartPoint(x, y);
		this.draw(x + this.image.getWidth(), y + this.image.getHeight());
	}
	
	@Override
	public void save() {
		//super.draw(x, y);
		this.graphPane.getSavedImage().getGraphics().drawImage(this.image, this.rect.x, this.rect.y, this.graphPane);
		Graphics2D g = this.graphPane.getDrawingImage().getImage().createGraphics();
		g.setColor(color);
		g.drawImage(this.graphPane.getSavedImage(), 0, 0, this.graphPane);
		g.dispose();
		this.resetColor();
	}

	public void setImage(BufferedImage image) {
		this.image = image;
	}
}
