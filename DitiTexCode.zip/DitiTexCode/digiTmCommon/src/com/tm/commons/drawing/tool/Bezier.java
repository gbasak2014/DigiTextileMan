package com.tm.commons.drawing.tool;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.Shape;
import java.awt.geom.Line2D;
import java.awt.geom.QuadCurve2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.pane.GraphPane;

public class Bezier extends Pen {
	Point pt3 = null;
	boolean controlPoint = false;

	List<BezPoints> list = new ArrayList<BezPoints>();

	Point currPt;
	BezPoints currBez;

	Image imgEdge;
	Image imgCtrl;

	public Bezier() {
		super(DrawingToolEnum.BEZ);
		loadImage();
	}

	public Bezier(GraphPane graphPane, Color color, FillPattern fillPattern) {
		super(DrawingToolEnum.BEZ, graphPane, color, fillPattern);
		loadImage();
	}

	void loadImage() {
		this.imgEdge = (new ImageIcon(this.getClass().getResource("/img/curve-edge.jpg"))).getImage();
		this.imgCtrl = (new ImageIcon(this.getClass().getResource("/img/curve-ctrl.jpg"))).getImage();
	}

	@Override
	public void setStartPoint(int x, int y) {
		if (x == -1 && y == -1) {
			this.rect.x = this.rect.y = this.rect.width = this.rect.height = -1;
			return;
		}

		if (!isControlPoint(x, y)) {
			int idx = this.list.size() - 1;

			this.currBez = new BezPoints();
			if (idx >= 0) {
				BezPoints bp = this.list.get(idx);
				this.currBez.start = bp.end;
			} else {
				this.currBez.start = new Point(x, y);
			}

			this.currBez.end = new Point(x, y);
			this.list.add(this.currBez);
			this.currPt = this.currBez.end;
			this.rect.x = this.rect.y = this.rect.width = this.rect.height = -1;
			controlPoint = false;
		}

	}

	public boolean isControlPoint(int x, int y) {
		int len = this.list.size();
		for (int i = 0; i < len; i++) {
			BezPoints pt = this.list.get(i);
			this.currPt = pt.ctrl;
			if (this.currPt != null && (x >= this.currPt.x - 1 && x <= this.currPt.x + 1)
					&& (y >= this.currPt.y - 1 && y <= this.currPt.y + 1)) {
				this.currBez = pt;
				this.controlPoint = true;
				return true;
			}
			this.currPt = pt.start;
			if (this.currPt != null && (x >= this.currPt.x - 1 && x <= this.currPt.x + 1)
					&& (y >= this.currPt.y - 1 && y <= this.currPt.y + 1)) {
				this.currBez = pt;
				this.controlPoint = true;
				return true;
			}
			this.currPt = pt.end;
			if (this.currPt != null && (x >= this.currPt.x - 1 && x <= this.currPt.x + 1)
					&& (y >= this.currPt.y - 1 && y <= this.currPt.y + 1)) {
				this.controlPoint = true;
				return true;
			}
		}
		return false;
	}

	@Override
	public void draw(int x, int y) {

		super.draw(x, y);
		this.currPt.x = this.currentX;
		this.currPt.y = this.currentY;

		BufferedImage img = this.graphPane.getDrawingImage().getImage();
		Graphics2D g = img.createGraphics();
		g.setColor(color);
		g.setStroke(new BasicStroke(this.penWidth));

		g.drawImage(this.graphPane.getSavedImage(), 0, 0, this.graphPane);

		Shape shape;

		for (BezPoints bp : this.list) {
			if (bp.ctrl == null) {
				shape = new Line2D.Double(bp.start.x, bp.start.y, bp.end.x, bp.end.y);
			} else {
				shape = new QuadCurve2D.Double(bp.start.x, bp.start.y, bp.ctrl.x, bp.ctrl.y, bp.end.x, bp.end.y);
			}

			g.draw(shape);
		}

		g.dispose();
	}

	public void setControlPoint() {
		if (!controlPoint 
				&& (this.currBez.start.x != this.currBez.end.x || this.currBez.start.y != this.currBez.end.y)) {
			this.currBez.ctrl = new Point((this.currBez.start.x + this.currBez.end.x) / 2,
					(this.currBez.start.y + this.currBez.end.y) / 2);
		}
		controlPoint = false;
	}

	@Override
	public void select(Graphics2D g, int imageLeft, int imageTop) {
		int zoom = this.graphPane.getZoom();
		// g.setXORMode(Color.WHITE);
		for (BezPoints bp : this.list) {
			Point pt = bp.start;
			if (pt != null) {
				// g.setColor(Color.BLUE);
				g.drawImage(this.imgEdge, ((pt.x - imageLeft) * zoom) - 10, ((pt.y - imageTop) * zoom) - 10, null);
				// g.setColor(Color.BLACK);
				// g.drawArc((pt.x - 1 - imageLeft) * zoom - 1, (pt.y - 1 -
				// imageTop) * zoom - 1, 2 * zoom + 2, 2 * zoom + 2, 0, 360);
			}

			pt = bp.end;
			if (pt != null) {
				g.drawImage(this.imgEdge, ((pt.x - imageLeft) * zoom) - 10, ((pt.y - imageTop) * zoom) - 10, null);

				/*
				 * g.setColor(Color.BLUE); g.fillArc((pt.x - 1 - imageLeft) *
				 * zoom, (pt.y - 1 - imageTop) * zoom, 2 * zoom, 2 * zoom, 0,
				 * 360); g.setColor(Color.BLACK); g.drawArc((pt.x - 1 -
				 * imageLeft) * zoom - 1, (pt.y - 1 - imageTop) * zoom - 1, 2 *
				 * zoom + 2, 2 * zoom + 2, 0, 360);
				 */
			}
			pt = bp.ctrl;
			if (pt != null) {
				g.drawImage(this.imgCtrl, ((pt.x - imageLeft) * zoom) - 10, ((pt.y - imageTop) * zoom) - 10, null);

				/*
				 * g.setColor(Color.RED); g.fillArc((pt.x - 1 - imageLeft) *
				 * zoom, (pt.y - 1 - imageTop) * zoom, 2 * zoom, 2 * zoom, 0,
				 * 360); g.setColor(Color.BLACK); g.drawArc((pt.x - 1 -
				 * imageLeft) * zoom - 1, (pt.y - 1 - imageTop) * zoom - 1, 2 *
				 * zoom + 2, 2 * zoom + 2, 0, 360);
				 */
			}
		}
	}

	public void selectBAK(Graphics2D g, int imageLeft, int imageTop) {
		int zoom = this.graphPane.getZoom();
		// g.setXORMode(Color.WHITE);
		for (BezPoints bp : this.list) {
			Point pt = bp.start;
			if (pt != null) {
				g.setColor(Color.BLUE);
				g.fillArc((pt.x - 1 - imageLeft) * zoom, (pt.y - 1 - imageTop) * zoom, 2 * zoom, 2 * zoom, 0, 360);
				g.setColor(Color.BLACK);
				g.drawArc((pt.x - 1 - imageLeft) * zoom - 1, (pt.y - 1 - imageTop) * zoom - 1, 2 * zoom + 2,
						2 * zoom + 2, 0, 360);
			}

			pt = bp.end;
			if (pt != null) {
				g.setColor(Color.BLUE);
				g.fillArc((pt.x - 1 - imageLeft) * zoom, (pt.y - 1 - imageTop) * zoom, 2 * zoom, 2 * zoom, 0, 360);
				g.setColor(Color.BLACK);
				g.drawArc((pt.x - 1 - imageLeft) * zoom - 1, (pt.y - 1 - imageTop) * zoom - 1, 2 * zoom + 2,
						2 * zoom + 2, 0, 360);
			}
			pt = bp.ctrl;
			if (pt != null) {
				g.setColor(Color.RED);
				g.fillArc((pt.x - 1 - imageLeft) * zoom, (pt.y - 1 - imageTop) * zoom, 2 * zoom, 2 * zoom, 0, 360);
				g.setColor(Color.BLACK);
				g.drawArc((pt.x - 1 - imageLeft) * zoom - 1, (pt.y - 1 - imageTop) * zoom - 1, 2 * zoom + 2,
						2 * zoom + 2, 0, 360);
			}
		}
	}

	@Override
	public void save() {
		if (this.list.size() <= 0) {
			return;
		}

		BufferedImage savedImg = this.graphPane.getSavedImage();
		this.graphPane.addUndoState(0, 0, savedImg);

		Graphics2D g = savedImg.createGraphics();
		g.setColor(this.color);
		g.setStroke(new BasicStroke(this.penWidth));

		for (BezPoints pt : this.list) {
			QuadCurve2D cc = new QuadCurve2D.Double(pt.start.x, pt.start.y, pt.ctrl.x, pt.ctrl.y, pt.end.x, pt.end.y);
			g.draw(cc);
		}

		controlPoint = false;
		pt3 = null;
		this.list.clear();
		this.setStartPoint(-1, -1);
	}

	@Override
	public void move(int x, int y) {
		super.move(x, y);
		if (pt3 != null) {
			pt3.x = pt3.x + x;
			pt3.y = pt3.y + y;
		}
		controlPoint = false;
		this.draw(this.currentX, this.currentY);

	}

	@Override
	public void clear() {
		this.list.clear();
	}
}
