package com.tm.commons.drawing.tool;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

import javax.swing.JOptionPane;

import com.tm.commons.Point;
import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.pane.GraphPane;
import com.tm.commons.image.ImageUtils;

public class AddBorder extends Pen {
	BufferedImage img;
	public static final int OUTER = 0;
	public static final int INNER = 1;
	int opt = 0;

	public AddBorder() {
		super(DrawingToolEnum.ADD_BORDER);
	}

	public AddBorder(GraphPane graphPane, Color color, FillPattern fillPattern) {
		super(DrawingToolEnum.ADD_BORDER, graphPane, color, fillPattern);
	}

	public void setOption(int opt) {
		this.opt = opt;
	}

	@Override
	public void draw(int x, int y) {
		processBorder(x, y);
	}

	public void processBorder(int x, int y) {

		int minX;
		int minY;
		int maxX;
		int maxY;

		minX = maxX = minY = maxY = -1;

		List<Point> list = new ArrayList<Point>();

		if ((x >= 0 && x < this.imgWidth) && (y >= 0 && y < this.imgHeight)) {
			this.graphPane.setCursor(new Cursor(Cursor.WAIT_CURSOR));

			int[] drawingData = this.getDrawingData();

			int oldRgb = drawingData[y * this.drawingWidth + x] | 0xff000000;
			int bgRgb = Color.WHITE.getRGB() | 0xff000000;
			if (oldRgb == bgRgb) {
				bgRgb = bgRgb - 1;
			}

			int borderRGB = this.getColor().getRGB() | 0xff000000;
			if (borderRGB == oldRgb) {
				JOptionPane.showMessageDialog(null, "Image Color and Border color are same!!!");
				return;
			}

			int newRgb = oldRgb + 1;

			Deque<Integer> queueX = new ArrayDeque<Integer>();
			Deque<Integer> queueY = new ArrayDeque<Integer>();

			queueX.push(x);
			queueY.push(y);
			minX = maxX = x;
			minY = maxY = y;

			while (!queueX.isEmpty()) {
				int px = queueX.pop();
				int py = queueY.pop();
				if (drawingData[py * this.drawingWidth + px] != newRgb) {
					drawingData[py * this.drawingWidth + px] = newRgb;
					list.add(new Point(px, py));

					if (minX > px) {
						minX = px;
					}
					if (maxX < px) {
						maxX = px;
					}

					if (minY > py) {
						minY = py;
					}
					if (maxY < py) {
						maxY = py;
					}

				}

				if (px - 1 >= 0 && oldRgb == (drawingData[py * this.drawingWidth + (px - 1)] | 0xff000000)) {
					queueX.push(px - 1);
					queueY.push(py);
				}

				if (px + 1 < this.imgWidth && oldRgb == (drawingData[py * this.drawingWidth + (px + 1)] | 0xff000000)) {
					queueX.push(px + 1);
					queueY.push(py);
				}

				if (py - 1 >= 0 && oldRgb == (drawingData[(py - 1) * this.drawingWidth + px] | 0xff000000)) {
					queueX.push(px);
					queueY.push(py - 1);
				}

				if (py + 1 < this.imgHeight && oldRgb == (drawingData[(py + 1) * this.drawingWidth + px] | 0xff000000)) {
					queueX.push(px);
					queueY.push(py + 1);
				}
				///////////////////
				if (px - 1 >= 0 && (py - 1) >= 0 && oldRgb == (drawingData[(py - 1) * this.drawingWidth + (px - 1)] | 0xff000000)) {
					queueX.push(px - 1);
					queueY.push(py - 1);
				}

				if (px + 1 < this.imgWidth && (py - 1) >= 0 && oldRgb == (drawingData[(py - 1) * this.drawingWidth + (px + 1)] | 0xff000000)) {
					queueX.push(px + 1);
					queueY.push(py - 1);
				}

				if (py + 1 < this.imgHeight && (px + 1) < this.imgWidth && oldRgb == (drawingData[(py + 1) * this.drawingWidth + px + 1] | 0xff000000)) {
					queueX.push(px + 1);
					queueY.push(py + 1);
				}

				if (py + 1 < this.imgHeight && (px - 1) > 0 && oldRgb == (drawingData[(py + 1) * this.drawingWidth + px - 1] | 0xff000000)) {
					queueX.push(px - 1);
					queueY.push(py + 1);
				}
				///////////////////
			}

			if (minX >= 0) {
				Graphics2D g = this.graphPane.getDrawingImage().getImage().createGraphics();
				g.drawImage(this.graphPane.getSavedImage(), 0, 0, this.graphPane);
				g.dispose();
			}

			if (list.size() > 1) {
				int w = maxX - minX + 1 + (this.opt == OUTER ? (2 * this.penWidth) : 0);
				int h = maxY - minY + 1 + (this.opt == OUTER ? (2 * this.penWidth) : 0);
				BufferedImage image = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
				Graphics2D g = image.createGraphics();
				g.setColor(new Color(bgRgb));
				g.fillRect(0, 0, w, h);
				g.dispose();

				int[] data = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();
				for (Point p : list) {
					int cx = p.x - minX + (this.opt == OUTER ? this.penWidth : 0);
					int cy = p.y - minY + (this.opt == OUTER ? this.penWidth : 0);
					if (cx >= 0 && cx < w && cy >= 0 && cy < h) {
						data[cx + cy * w] = oldRgb;
					}
				}

				int px = 0;
				int py = 0;

				if (w > h) {
					px = w / 2;
					for (py = 0; py < h && (oldRgb != data[px + py * w]); py++) {
						// NOTHING
					}
				} else {
					py = h / 2;
					for (px = 0; px < w && (oldRgb != data[px + py * w]); px++) {
						// NOTHING
					}
				}

				// int data[] = ((DataBufferInt)
				// image.getRaster().getDataBuffer()).getData();
				int bg = borderRGB;
				int sg = borderRGB - 1;
				int backRGB = sg;
				while (sg == oldRgb || sg == borderRGB || sg == bgRgb) {
					sg = sg - 1;
				}

				if (this.opt == OUTER) {
					Point pt = setOuterBorder(data, w, h, oldRgb, borderRGB, bgRgb, px, py);

					for (int i = 1; i < this.penWidth; i++) {
						int t = sg;
						sg = bg;
						bg = t;
						pt = setOuterBorder(data, w, h, sg, bg, bgRgb, pt.x, pt.y);
					}
				} else {
					Point pt = setInnerBorder(data, w, h, oldRgb, borderRGB, bgRgb, px, py);
				}

				if (this.penWidth > 1) {
					int ln = data.length;
					for (int i = 0; i < ln; i++) {
						if (data[i] == backRGB) {
							data[i] = borderRGB;
						}
					}
				}

				this.img = ImageUtils.getTransperantImage(image, new Color(bgRgb));
				// ClipboardUtil.copyToClipboard(this.img);
				this.currentX = this.startX = this.rect.x = minX - (this.opt == OUTER ? this.penWidth : 0);
				this.currentY = this.startY = this.rect.y = minY - (this.opt == OUTER ? this.penWidth : 0);
				this.rect.width = this.img.getWidth();
				this.rect.height = this.img.getHeight();
				// this.graphPane.setCursor(new Cursor(Cursor.MOVE_CURSOR));
				this.save();
			}
		}
	}

	Point setOuterBorder(int[] data, int w, int h, int selRGB, int borderRGB, int bgRGB, int x, int y) {
		Deque<Integer> dqx = new ArrayDeque<>();
		Deque<Integer> dqy = new ArrayDeque<>();
		dqx.push(x);
		dqy.push(y);

		Point pt = new Point();
		while (!dqx.isEmpty()) {
			int ix = dqx.pop();
			int iy = dqy.pop();
			// System.out.println("IX-IY:" + ix + "-" + iy);
			x = ix - 1;
			y = iy;
			if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == bgRGB) {
				data[x + y * w] = borderRGB;
				pt.x = x;
				pt.y = y;
				savePointOuter(data, x, y, w, h, selRGB, dqx, dqy);
			}
			x = ix + 1;
			y = iy;
			if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == bgRGB) {
				data[x + y * w] = borderRGB;
				pt.x = x;
				pt.y = y;
				savePointOuter(data, x, y, w, h, selRGB, dqx, dqy);
			}
			x = ix;
			y = iy - 1;
			if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == bgRGB) {
				data[x + y * w] = borderRGB;
				pt.x = x;
				pt.y = y;
				savePointOuter(data, x, y, w, h, selRGB, dqx, dqy);
			}
			x = ix;
			y = iy + 1;
			if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == bgRGB) {
				data[x + y * w] = borderRGB;
				pt.x = x;
				pt.y = y;
				savePointOuter(data, x, y, w, h, selRGB, dqx, dqy);
			}
		}

		return pt;
	}

	void savePointOuter(int[] data, int ix, int iy, int w, int h, int selRGB, Deque<Integer> dqx, Deque<Integer> dqy) {
		int x = ix - 1;
		int y = iy;
		if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB) {
			dqx.push(x);
			dqy.push(y);
		}
		x = ix + 1;
		y = iy;
		if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB) {
			dqx.push(x);
			dqy.push(y);
		}
		x = ix - 1;
		y = iy - 1;
		if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB) {
			dqx.push(x);
			dqy.push(y);
		}
		x = ix + 1;
		y = iy - 1;
		if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB) {
			dqx.push(x);
			dqy.push(y);
		}
		x = ix - 1;
		y = iy + 1;
		if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB) {
			dqx.push(x);
			dqy.push(y);
		}
		x = ix + 1;
		y = iy + 1;
		if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB) {
			dqx.push(x);
			dqy.push(y);
		}
		x = ix;
		y = iy - 1;
		if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB) {
			dqx.push(x);
			dqy.push(y);
		}
		x = ix;
		y = iy + 1;
		if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB) {
			dqx.push(x);
			dqy.push(y);
		}
	}

	Point setInnerBorder(int[] data, int w, int h, int selRGB, int borderRGB, int bgRGB, int x, int y) {
		Deque<Integer> dqx = new ArrayDeque<>();
		Deque<Integer> dqy = new ArrayDeque<>();
		dqx.push(x);
		dqy.push(y);

		Point pt = new Point();
		while (!dqx.isEmpty()) {
			int ix = dqx.pop();
			int iy = dqy.pop();
			System.out.println("IX-IY:" + ix + "-" + iy);
			data[ix + iy * w] = borderRGB;
			x = ix - 1;
			y = iy;
			if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB) {
				// data[x + y * w] = borderRGB;
				pt.x = x;
				pt.y = y;
				savePointInner(data, x, y, w, h, bgRGB, dqx, dqy);
			}
			x = ix + 1;
			y = iy;
			if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB) {
				System.out.println("----------" + x + "-" + y);
				// data[x + y * w] = borderRGB;
				pt.x = x;
				pt.y = y;
				savePointInner(data, x, y, w, h, bgRGB, dqx, dqy);
			}
			x = ix;
			y = iy - 1;
			if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB) {
				// data[x + y * w] = borderRGB;
				pt.x = x;
				pt.y = y;
				savePointInner(data, x, y, w, h, bgRGB, dqx, dqy);
			}
			x = ix;
			y = iy + 1;
			if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB) {
				// data[x + y * w] = borderRGB;
				pt.x = x;
				pt.y = y;
				savePointInner(data, x, y, w, h, bgRGB, dqx, dqy);
			}

			////////////////////////////////////////////////////////////////
			x = ix - 1;
			y = iy + 1;
			if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB) {
				// data[x + y * w] = borderRGB;
				pt.x = x;
				pt.y = y;
				savePointInner(data, x, y, w, h, bgRGB, dqx, dqy);
			}
			x = ix + 1;
			y = iy + 1;
			if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB) {
				// data[x + y * w] = borderRGB;
				pt.x = x;
				pt.y = y;
				savePointInner(data, x, y, w, h, bgRGB, dqx, dqy);
			}
			x = ix - 1;
			y = iy - 1;
			if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB) {
				// data[x + y * w] = borderRGB;
				pt.x = x;
				pt.y = y;
				savePointInner(data, x, y, w, h, bgRGB, dqx, dqy);
			}
			x = ix + 1;
			y = iy - 1;
			if ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB) {
				// data[x + y * w] = borderRGB;
				pt.x = x;
				pt.y = y;
				savePointInner(data, x, y, w, h, bgRGB, dqx, dqy);
			}
			////////////////////////////////////////////////////////////////
		}

		return pt;
	}

	void savePointInner(int[] data, int ix, int iy, int w, int h, int selRGB, Deque<Integer> dqx, Deque<Integer> dqy) {
		int x = ix - 1;
		int y = iy;
		if (x <0 || ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB)) {
			dqx.push(ix);
			dqy.push(iy);
			return;
		}
		x = ix + 1;
		y = iy;
		if (x >= w || ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB)) {
			dqx.push(ix);
			dqy.push(iy);
			return;
		}
		x = ix;
		y = iy - 1;
		if (y<0 || ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB)) {
			dqx.push(ix);
			dqy.push(iy);
			return;
		}
		x = ix;
		y = iy + 1;
		if (y>=h || ((x >= 0 && x < w && y >= 0 && y < h) && data[x + y * w] == selRGB)) {
			dqx.push(ix);
			dqy.push(iy);
			return;
		}
	}

	@Override
	public void move(int x, int y) {

	}

	@Override
	public void save() {

		if (this.img != null && rect.width > 0 && rect.height > 0) {
			Rectangle bound = new Rectangle(rect.x, rect.y, rect.width, rect.height);
			Rectangle imgSize = new Rectangle(0, 0, this.graphPane.getImgWidth(), this.graphPane.getImgHeight());
			bound = imgSize.intersection(bound);

			try {
				BufferedImage img1 = this.graphPane.getSavedImage().getSubimage(bound.x, bound.y, bound.width, bound.height);
				this.graphPane.addUndoState(bound.x, bound.y, img1);
			} catch (Exception e) {
				System.out.println(bound);
				e.printStackTrace();
			}

			Graphics2D g = this.graphPane.getDrawingImage().getImage().createGraphics();
			g.drawImage(this.img, rect.x, rect.y, rect.width, rect.height, this.graphPane);
			g.dispose();
			g = this.getGraphPane().getSavedImage().createGraphics();
			g.drawImage(this.graphPane.getDrawingImage().getImage(), 0, 0, this.graphPane);
			g.dispose();
			this.setStartPoint(-1, -1);
		}
		this.img = null;
	}
}
