package com.tm.commons;

public class TextUtils {
	public static String textToByte(String text) {
		StringBuffer sb = new StringBuffer();
		int len = text.length();
		for (int i = 0; i < len; i++) {
			char ch = text.charAt(i);
			int bite = (int) ch;
			if (String.valueOf(bite).length() < 2) {
				sb.append("00");
			}
			else if (String.valueOf(bite).length() < 3) {
				sb.append("0");
			}
			sb.append(bite);
		}

		return sb.toString();
	}

	public static String byteToText(String bytes) {
		int len = bytes.length() / 3;
		byte[] bff = new byte[len];
		for (int i = 0; i < len; i++) {
			String bite = bytes.substring(i * 3, i * 3 + 3);
			bff[i] = Byte.valueOf(bite);
		}

		return new String(bff);
	}

	public static void main(String[] args) {
		String b = textToByte("Gouranga Basak");
		System.out.println(b);
		System.out.println(byteToText(b));
	}
}
