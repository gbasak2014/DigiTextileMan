package com.tm.commons.menu;

import javax.swing.JToolBar;

import com.tm.commons.theme.DigiTmTheme;

public class DigiTmToolBar extends JToolBar{

	private static final long serialVersionUID = 2210769918806326611L;

	public DigiTmToolBar() {
		super();
		this.setBackground(DigiTmTheme.getBgColor());
		this.setBorder(DigiTmTheme.getLineBorder());
	}
}
