package com.tm.commons.menu;

import javax.swing.JMenuBar;

import com.tm.commons.theme.DigiTmTheme;

public class DigiTmMenuBar extends JMenuBar {
	private static final long serialVersionUID = -8867083547049378690L;

	public DigiTmMenuBar() {
		super();
		this.setBackground(DigiTmTheme.getMenuBarColor());
	}
}
