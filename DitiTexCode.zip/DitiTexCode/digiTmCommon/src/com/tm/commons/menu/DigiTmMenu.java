package com.tm.commons.menu;

import java.awt.Font;

import javax.swing.JMenu;

import com.tm.commons.theme.DigiTmTheme;

public class DigiTmMenu extends JMenu {
	private static final long serialVersionUID = -1965447832484508643L;

	public DigiTmMenu(String name) {
		super(name);
		this.setBackground(DigiTmTheme.getBgColor());
		this.setFont(new Font("Serif", Font.BOLD, 12));
	}

	public DigiTmMenu(String name, int key) {
		this(name);
		this.setMnemonic(key);
	}
}
