package com.tm.commons.menu;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;

import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

public class DigiTmMenuItem extends JMenuItem {
	private static final long serialVersionUID = -3868124831788180521L;

	public DigiTmMenuItem(String name) {
		super(name);
		//this.setBackground(DigiTmTheme.getBgColor());
		this.setFont(new Font("Serif", 0, 12));
	}

	public DigiTmMenuItem(String name, int action, ActionListener listener) {
		this(name);
		this.setActionCommand(String.valueOf(action));
		this.addActionListener(listener);
	}

	public DigiTmMenuItem(String name, int action, ActionListener listener, int key) {
		this(name, action, listener);
		this.setAccelerator(KeyStroke.getKeyStroke(key, InputEvent.CTRL_MASK));
	}

	public DigiTmMenuItem(String name, int action, ActionListener listener, int key, int mask) {
		this(name, action, listener);

		if (mask > 0) {
			this.setAccelerator(KeyStroke.getKeyStroke(key, mask));
		} else {
			this.setMnemonic(key);
		}
	}
}
