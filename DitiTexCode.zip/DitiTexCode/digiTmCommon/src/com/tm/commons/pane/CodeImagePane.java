package com.tm.commons.pane;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Toolkit;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;

import javax.print.PrintServiceLookup;
import javax.swing.JPanel;

import com.tm.commons.dto.GridOptions;

public class CodeImagePane extends JPanel {
	private static final long serialVersionUID = -1743489183803769690L;
	BufferedImage img;
	BufferedImage imgDrawing;
	int cellWidth;

	int left;
	int top;

	int imageLeft = 0;
	int imageTop = 0;
	Color gridColor1;
	Color gridColor2;
	Color gridColor3;
	int pointWidth;

	public CodeImagePane(BufferedImage image, GridOptions gridOption, MouseListener ml) {
		this.img = image;
		this.cellWidth = gridOption.getZoom();
		this.gridColor1 = gridOption.getColorUnit();
		this.gridColor2 = gridOption.getColorPoint();
		this.gridColor3 = gridOption.getColorPoint1();
		this.pointWidth = gridOption.getPoint();

		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();

		imgDrawing = new BufferedImage((int) d.getWidth(), (int) d.getHeight(), BufferedImage.TYPE_INT_RGB);

		this.addMouseListener(ml);
	}

	@Override
	public void paint(Graphics graphics) {
		super.paint(graphics);
		init();
		graphics.drawImage(imgDrawing, 0, 0, this);
	}

	void init() {
		int width = imgDrawing.getWidth();
		int height = imgDrawing.getHeight();

		Graphics g = imgDrawing.getGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, imgDrawing.getWidth(), imgDrawing.getHeight());
		g.drawImage(img, -imageLeft * cellWidth, -imageTop * cellWidth, img.getWidth() * cellWidth,
				img.getHeight() * cellWidth, this);

		g.drawRect(-imageLeft * cellWidth, -imageTop * cellWidth, img.getWidth() * cellWidth,
				img.getHeight() * cellWidth);
		if (width > ((img.getWidth() - imageLeft) * cellWidth)) {
			width = (img.getWidth() - imageLeft) * cellWidth;
		}

		if (height > ((img.getHeight() - imageTop) * cellWidth)) {
			height = (img.getHeight() - imageTop) * cellWidth;
		}

		int c = this.imageLeft;

		int pointWidth2 = pointWidth * 2;

		if (this.cellWidth > 2) {
			for (int i = cellWidth; i < width; i += cellWidth) {
				c++;
				if (c % pointWidth2 == 0)
					g.setColor(gridColor3);
				else if (c % pointWidth == 0)
					g.setColor(gridColor2);
				else
					g.setColor(gridColor1);

				g.drawLine(i, 0, i, height);
			}

			c = imageTop;
			for (int i = cellWidth; i < height; i += cellWidth) {
				c++;
				if (c % pointWidth2 == 0)
					g.setColor(gridColor3);
				else if (c % pointWidth == 0)
					g.setColor(gridColor2);
				else
					g.setColor(gridColor1);

				g.drawLine(0, i, width, i);
			}
		}
		g.setColor(Color.GRAY);
		g.drawRect(-imageLeft * cellWidth, -imageTop * cellWidth, img.getWidth() * cellWidth,
				img.getHeight() * cellWidth);
	}

	void printCode() {
		PrintServiceLookup.lookupDefaultPrintService();

	}

	public void scroll(int x, int y) {
		this.imageLeft = x;
		this.imageTop = y;
		repaint();
	}

	public void zoom(int z) {
		this.cellWidth = this.cellWidth + z;
		if (this.cellWidth < 0) {
			this.cellWidth = 1;
		}

		repaint();
	}

	public void mirrorHorizontal() {
		int w = img.getWidth();
		int h = img.getHeight();
		// BufferedImage tmpImg = new BufferedImage(w, h,
		// BufferedImage.TYPE_INT_RGB);
		/*
		 * for (int x = 0; x < w; x++) { for (int y = 0; y < h; y++) {
		 * tmpImg.setRGB((w - x - 1), y, img.getRGB(x, y)); } }
		 */
		int x1 = 0;
		int x2 = w - 1;
		for (; x1 < x2; x1++, x2--) {
			for (int y = 0; y < h; y++) {
				int rgb = img.getRGB(x1, y);
				img.setRGB(x1, y, img.getRGB(x2, y));
				img.setRGB(x2, y, rgb);
			}
		}
		repaint();
	}

	public void mirrorVertical() {
		int w = img.getWidth();
		int h = img.getHeight();

		int y1 = 0;
		int y2 = h - 1;
		for (; y1 < y2; y1++, y2--) {
			for (int x = 0; x < w; x++) {
				int rgb = img.getRGB(x, y1);
				img.setRGB(x, y1, img.getRGB(x, y2));
				img.setRGB(x, y2, rgb);
			}
		}

		repaint();
	}

	public int getRGB(int x, int y) {
		x = x / cellWidth + imageLeft;
		y = y / cellWidth + imageTop;
		if (x >= 0 && x < img.getWidth() && y >= 0 && y < img.getHeight()) {
			return img.getRGB(x, y);
		}

		return 0;
	}

	public void setRGB(int x, int y, int rgb) {
		x = x / cellWidth + imageLeft;
		y = y / cellWidth + imageTop;
		if (x >= 0 && x < img.getWidth() && y >= 0 && y < img.getHeight()) {
			img.setRGB(x, y, rgb);
			repaint();
		}
	}

	public void replaceColor(int oldRgb, int newRgb) {
		int w = img.getWidth();
		int h = img.getHeight();
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				if (oldRgb == img.getRGB(x, y)) {
					try {
						img.setRGB(x, y, newRgb);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}

		repaint();
	}

	public void setImage(BufferedImage img) {
		this.img = img;
		repaint();
	}

	public BufferedImage getImage() {
		return this.img;
	}
}
