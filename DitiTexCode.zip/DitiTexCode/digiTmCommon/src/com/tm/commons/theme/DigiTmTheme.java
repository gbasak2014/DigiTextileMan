package com.tm.commons.theme;

import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.border.Border;

public class DigiTmTheme {
	//static Color bgColor = new Color(200, 210, 240);
	static Color bgColor = new Color(170, 210, 220);
	static Color highlightColor = new Color(100, 100, 255);
	static Color borderColor = Color.WHITE;
	static Border lineBorder = BorderFactory.createLineBorder(Color.WHITE);
	static Border lineBorderHighlight = BorderFactory.createLineBorder(Color.WHITE);
	static Color titleColor = new Color(180, 200, 230);
	static Color menuBarColor = new Color(215, 220, 255);

	public static Color getBgColor() {
		return bgColor;
	}

	public static void setBgColor(Color bgColor) {
		DigiTmTheme.bgColor = bgColor;
	}

	public static Color getBorderColor() {
		return borderColor;
	}

	public static void setBorderColor(Color borderColor) {
		DigiTmTheme.borderColor = borderColor;
	}

	public static Border getLineBorder() {
		return lineBorder;
	}

	public static void setLineBorder(Border lineBorder) {
		DigiTmTheme.lineBorder = lineBorder;
	}

	public static Color getHighlightColor() {
		return highlightColor;
	}

	public static void setHighlightColor(Color highlightColor) {
		DigiTmTheme.highlightColor = highlightColor;
	}

	public static Border getLineBorderHighlight() {
		return lineBorderHighlight;
	}

	public static Color getTitleColor() {
		return titleColor;
	}

	public static Color getMenuBarColor() {
		return bgColor; //menuBarColor;
	}
}
