package com.tm.commons.dlg;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.image.BufferedImage;
import java.awt.print.Book;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.text.DecimalFormat;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JTextField;

import com.tm.commons.action.FileMenuActionEnum;
import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.win.DigiTmWin;

public class PrintImageDlg extends DigiTmWin implements ActionListener {
	private static final long serialVersionUID = 6307640446109828503L;
	Pan jpmain = new Pan();
	ButtonMenuItem btnPrint;
	ButtonMenuItem btnClose;
	PrinterJob printerJob;
	PageFormat pageFormat;
	BufferedImage img = null;

	JScrollBar jsh = new JScrollBar();
	JScrollBar jsv = new JScrollBar();

	JTextField txtColInch = new JTextField();
	JTextField txtRowInch = new JTextField();

	double pageWidth;
	double pageHeight;

	int imgWidthPerPage;
	int imgHeightPerPage;

	int pageCount;

	double scaleWidth;
	double scaleHeight;

	int rowPerInch;
	int colPerInch;

	int left = 0;
	int top = 0;

	JLabel jlWidth = new JLabel();
	JLabel jlHeight = new JLabel();

	double screenScaleWidth;
	double screenScaleHeight;

	static double PRINTER_DPI = 72.0;

	int pgRow;
	int pgCol;

	int printableX;
	int printableY;

	@Override
	public void saveProperties() {
		// TODO Auto-generated method stub

	}

	public PrintImageDlg(BufferedImage bi) {
		super();
		try {
			img = bi;
			this.rowPerInch = Toolkit.getDefaultToolkit().getScreenResolution();
			this.colPerInch = Toolkit.getDefaultToolkit().getScreenResolution();
			jbInit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void jbInit() throws Exception {
		this.printerJob = PrinterJob.getPrinterJob();
		this.printerJob.setJobName("Print Design");
		this.pageFormat = this.printerJob.defaultPage();
		refresh();
		setIconImage(Toolkit.getDefaultToolkit().getImage("img/gm.jpg"));
		this.getContentPane().setLayout(new BorderLayout());
		this.setSize(new Dimension(700, 500));
		this.setPreferredSize(new Dimension(700, 500));
		this.setTitle("Print Image");

		jsh.setOrientation(JScrollBar.HORIZONTAL);

		JPanel toolPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 2, 2));

		JButton btnRefresh = new ButtonMenuItem(FileMenuActionEnum.REFRESH.value, this, "/img/refresh.jpg", "Refresh");

		btnPrint = new ButtonMenuItem(FileMenuActionEnum.PRINT_IMAGE.value, this, "/img/printdesign.jpg", "Print Design");
		btnClose = new ButtonMenuItem(FileMenuActionEnum.CLOSE.value, this, "/img/close.jpg", "Close");

		this.txtColInch.setPreferredSize(new Dimension(50, 25));
		this.txtRowInch.setPreferredSize(new Dimension(50, 25));

		this.jlWidth.setPreferredSize(new Dimension(150, 25));
		this.jlHeight.setPreferredSize(new Dimension(150, 25));

		JLabel jlSize = new JLabel("Size: " + img.getWidth() + " X " + img.getHeight() + " ");
		jlSize.setBorder(BorderFactory.createLineBorder(Color.BLACK));

		toolPanel.add(jlSize);
		toolPanel.add(new JLabel("PPI: "));
		toolPanel.add(this.txtColInch);
		toolPanel.add(this.jlWidth);
		toolPanel.add(new JLabel("EPI: "));
		toolPanel.add(this.txtRowInch);
		toolPanel.add(this.jlHeight);

		this.jlWidth.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		this.jlHeight.setBorder(BorderFactory.createLineBorder(Color.BLACK));

		toolPanel.add(btnRefresh);
		toolPanel.add(btnPrint);
		toolPanel.add(btnClose);

		this.getContentPane().add(jsh, BorderLayout.SOUTH);
		this.getContentPane().add(jsv, BorderLayout.EAST);
		this.getContentPane().add(toolPanel, BorderLayout.NORTH);
		this.getContentPane().add(jpmain, BorderLayout.CENTER);

		jsh.setMaximum(img.getWidth());
		jsv.setMaximum(img.getHeight());

		this.txtColInch.setText(String.valueOf(this.colPerInch));
		this.txtRowInch.setText(String.valueOf(this.rowPerInch));

		jsh.addAdjustmentListener(new AdjustmentListener() {

			public void adjustmentValueChanged(AdjustmentEvent e) {
				left = jsh.getValue();
				jpmain.repaint();
			}
		});
		jsv.addAdjustmentListener(new AdjustmentListener() {

			public void adjustmentValueChanged(AdjustmentEvent e) {
				top = jsv.getValue();
				jpmain.repaint();
			}
		});

	}

	void printDesign() {
		Book bk = new Book();
		double w = this.pageFormat.getImageableWidth();
		double h = this.pageFormat.getImageableHeight();
		double scaleW = PRINTER_DPI / this.colPerInch;
		double scaleH = PRINTER_DPI / this.rowPerInch;

		int ptW = (int) (w * scaleW);
		int ptH = (int) (h * scaleH);

		int rowPage = (int) (img.getHeight() / ptH + (img.getHeight() % ptH != 0 ? 1 : 0));
		int colPage = (int) (img.getWidth() / ptW + (img.getWidth() % ptW != 0 ? 1 : 0));

		PaintContent paintContent = new PaintContent(img, scaleW, scaleH, rowPage, colPage);
		bk.append(paintContent, this.pageFormat, rowPage * colPage);

		this.printerJob.setPageable(bk);
		this.printerJob.setJobName("Print Design");

		try {
			this.printerJob.print();
		} catch (Exception ee) {
			ee.printStackTrace();
		}
	}

	void refresh() {

		double r = Toolkit.getDefaultToolkit().getScreenResolution() * 1.15;
		this.colPerInch = (int) r;
		this.rowPerInch = (int) r;

		try {
			this.colPerInch = Integer.parseInt(this.txtColInch.getText());
			this.rowPerInch = Integer.parseInt(this.txtRowInch.getText());
		} catch (Exception e) {
		}

		this.txtColInch.setText(String.valueOf(this.colPerInch));
		this.txtRowInch.setText(String.valueOf(this.rowPerInch));

		this.pageFormat = this.printerJob.validatePage(this.pageFormat);
		this.pageWidth = this.pageFormat.getImageableWidth();
		this.pageHeight = this.pageFormat.getImageableHeight();

		double pageWidthInch = this.pageWidth / PRINTER_DPI;
		double pageHeightInch = this.pageHeight / PRINTER_DPI;

		int imgColPerPage = (int) (pageWidthInch * this.colPerInch);
		int imgRowPerPage = (int) (pageHeightInch * this.rowPerInch);

		this.scaleWidth = PRINTER_DPI / this.colPerInch;
		this.scaleHeight = PRINTER_DPI / this.rowPerInch;

		this.imgWidthPerPage = imgColPerPage; // (int) (this.pageWidth *
																					// this.scaleWidth);
		this.imgHeightPerPage = imgRowPerPage; // (int) (this.pageHeight *
																						// this.scaleHeight);

		pgRow = (this.img.getHeight() / imgRowPerPage + (this.img.getHeight() % imgRowPerPage > 0 ? 1 : 0));
		pgCol = (this.img.getWidth() / imgColPerPage + (this.img.getWidth() % imgColPerPage > 0 ? 1 : 0));

		this.pageCount = pgRow * pgCol;

		DecimalFormat df = new DecimalFormat(".####");
		this.jlWidth.setText("Width: " + df.format((double) this.img.getWidth() / this.colPerInch) + " Inches");
		this.jlHeight.setText("Height: " + df.format((double) this.img.getHeight() / this.rowPerInch) + " Inches");

		this.screenScaleWidth = r / (double) this.colPerInch;
		this.screenScaleHeight = r / (double) this.rowPerInch;

		this.printableX = (int) this.pageFormat.getImageableX();
		this.printableY = (int) this.pageFormat.getImageableY();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		FileMenuActionEnum action = FileMenuActionEnum.fromString(e.getActionCommand());

		switch (action) {
		case PRINT_IMAGE:
			printDesign();
			break;
		case CLOSE:
			close();
			break;
		case REFRESH:
			this.refresh();
			this.jpmain.repaint();
			break;
		default:
			break;
		}
	}

	void close() {
		this.setVisible(false);
		this.dispose();
	}

	class Pan extends JPanel {
		private static final long serialVersionUID = 4926401009157313940L;

		public void paint(Graphics g) {
			int w = (int) ((double) img.getWidth() * screenScaleWidth);
			int h = (int) ((double) img.getHeight() * screenScaleHeight);
			g.setColor(Color.white);
			g.fillRect(0, 0, getWidth(), getHeight());
			g.setColor(Color.black);
			g.drawRect(-left, -top, w + 20, h + 20);
			g.setColor(Color.lightGray);
			g.drawImage(img, -left + 10, -top + 10, w, h, this);
			g.drawRect(-left + 9, -top + 9, w + 2, h + 2);
		}
	}

	class PaintContent implements Printable {
		BufferedImage img;
		PageFormat pf;

		int drawWidth;
		int drawHeight;

		int imageWidth;
		int imageHeight;

		int rowPageCnt;
		int colPageCnt;

		public PaintContent(BufferedImage i, double scaleWidth, double scaleHeight, int rowPageCnt, int colPageCnt) {
			img = i;
			this.imageWidth = this.img.getWidth();
			this.imageHeight = this.img.getHeight();

			this.drawWidth = (int) ((double) this.imageWidth * scaleWidth);
			this.drawHeight = (int) ((double) this.imageHeight * scaleHeight);

			this.rowPageCnt = rowPageCnt;
			this.colPageCnt = colPageCnt;
		}

		public int print(Graphics g, PageFormat pf, int pageIndex) throws PrinterException {
			int x = (int) pf.getImageableX();
			int y = (int) pf.getImageableY();
			BufferedImage sImg = getSubImage(pageIndex);

			g.drawImage(sImg, x, y, PrintImageDlg.this);
			g.dispose();
			//System.out.println("Printed.....");
			return Printable.PAGE_EXISTS;
		}

		BufferedImage getSubImage(int idx) {
			int ix = idx % this.colPageCnt;
			int iy = idx / this.colPageCnt;
			int startX = ix * imgWidthPerPage;
			int startY = iy * imgHeightPerPage;
			int w = startX + imgWidthPerPage > this.imageWidth ? this.imageWidth - startX : imgWidthPerPage;
			int h = startY + imgHeightPerPage > this.imageHeight ? this.imageHeight - startY : imgHeightPerPage;
			int iw = (int) (w * scaleWidth);
			int ih = (int) (h * scaleHeight);
			BufferedImage sImg = this.img.getSubimage(startX, startY, w, h);

			BufferedImage img1 = new BufferedImage(iw, ih, BufferedImage.TYPE_INT_RGB);
			Graphics2D gg = img1.createGraphics();
			gg.setStroke(new BasicStroke((float) 0.05, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER));
			gg.drawImage(sImg, 0, 0, iw, ih, PrintImageDlg.this);
			gg.dispose();
			return img1;
		}
	}
}