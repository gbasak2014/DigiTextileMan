package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JTextField;
import javax.swing.KeyStroke;

public class ImageRotateDlg extends DigiTmDlg implements ActionListener
{
	private static final long serialVersionUID = 3700869307715798069L;
	JPanel jpDrawing = new JPanel();
	JButton jbOk = new JButton("OK");
	JButton jbCancel = new JButton("Cancel");
	JButton jbRotate = new JButton("Rotate");
	JScrollBar scrollBar = new JScrollBar(JScrollBar.HORIZONTAL);
	JTextField jtAngle = new JTextField("0");
	JTextField jtScale = new JTextField("1");

	boolean okPressed = false;

	BufferedImage image;

	int cellWidth = 1;
	int x;
	int y;
	boolean firstTime = true;
	int rotateAngle;

	public ImageRotateDlg(BufferedImage image)
	{
		super();
		this.setModal(true);
		this.setTitle("Rotate");
		this.image = image;
		this.getContentPane().setLayout(new BorderLayout());
		this.jbOk.setActionCommand("OK");
		this.jbOk.registerKeyboardAction(this, "OK", KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), JComponent.WHEN_IN_FOCUSED_WINDOW);
		this.jbOk.addActionListener(this);

		this.jbCancel.setActionCommand("CANCEL");
		this.jbCancel.registerKeyboardAction(this, "CANCEL", KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
				JComponent.WHEN_IN_FOCUSED_WINDOW);
		this.jbCancel.addActionListener(this);

		this.jbRotate.setActionCommand("ROTATE");
		this.jbRotate.addActionListener(this);

		this.scrollBar.setMaximum(365);
		this.scrollBar.setValues(0, 1, 0, 361);
		this.scrollBar.setBlockIncrement(15);

		this.scrollBar.addAdjustmentListener(new scrollHandler());
		this.scrollBar.addMouseWheelListener(new scrollWheelHandler());

		this.jpDrawing.setBorder(BorderFactory.createLoweredBevelBorder());
		this.jpDrawing.addMouseWheelListener(new ImageScaleHandler());

		JPanel jpAction = new JPanel(new GridLayout(2, 1, 4, 4));
		JPanel jpRotate = new JPanel(new FlowLayout(FlowLayout.CENTER, 2, 2));
		JPanel jpCommand = new JPanel(new FlowLayout(FlowLayout.RIGHT, 2, 2));

		jpRotate.add(new JLabel("Scale:"));
		jpRotate.add(jtScale);
		jpRotate.add(scrollBar);
		jpRotate.add(jtAngle);
		jpRotate.add(jbRotate);

		jpCommand.add(jbOk);
		jpCommand.add(jbCancel);

		jpAction.add(jpRotate);
		jpAction.add(jpCommand);

		this.getContentPane().add(jpAction, BorderLayout.SOUTH);
		this.getContentPane().add(jpDrawing, BorderLayout.CENTER);

		this.setBounds(100, 50, 400, 450);
		this.scrollBar.setPreferredSize(new Dimension(100, 20));
		this.jtAngle.setPreferredSize(new Dimension(50, 20));
		this.jtScale.setPreferredSize(new Dimension(20, 20));

		this.pack();
		this.setBounds(100, 50, 400, 450);

		this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowOpened(WindowEvent e)
			{
				previewRotate();
			}
		});
	}

	@Override
	public void paint(Graphics g)
	{
		super.paint(g);
		paintPreviewRotate();
	}

	void paintPreviewRotate()
	{
		int angle = Integer.parseInt(jtAngle.getText());
		cellWidth = Integer.parseInt(jtScale.getText());

		double r = Math.toRadians(angle);
		int w = image.getWidth();
		int h = image.getHeight();

		Graphics2D g = (Graphics2D) jpDrawing.getGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, jpDrawing.getWidth(), jpDrawing.getHeight());
		g.scale(cellWidth, cellWidth);
		int cx = (jpDrawing.getWidth() - w * cellWidth) / (2 * cellWidth);
		int cy = (jpDrawing.getHeight() - h * cellWidth) / (2 * cellWidth);
		g.translate(cx, cy);
		g.rotate(r, w / (2), h / (2));
		g.drawRenderedImage(image, null);
		g.dispose();
	}

	public BufferedImage rotate()
	{
		try
		{
			int angle = Integer.parseInt(jtAngle.getText());
			rotateAngle = angle;
			double r = Math.toRadians(angle);
			double sin = Math.abs(Math.sin(r));
			double cos = Math.abs(Math.cos(r));
			int w = image.getWidth();
			int h = image.getHeight();
			int neww = (int) Math.floor(w * cos + h * sin);
			int newh = (int) Math.floor(h * cos + w * sin);
			BufferedImage newImage = new BufferedImage(neww, newh, BufferedImage.TYPE_INT_RGB);
			Graphics2D g = newImage.createGraphics();

			g.setColor(Color.WHITE);
			g.fillRect(0, 0, neww, newh);
			g.translate((neww - w) / 2, (newh - h) / 2);
			g.rotate(r, w / 2, h / 2);
			g.drawRenderedImage(image, null);
			g.dispose();
			return newImage;
		} catch (Exception e)
		{
		}

		return image;
	}

	void previewRotate()
	{
		repaint();
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		String cmd = e.getActionCommand();

		if ("ROTATE".equals(cmd))
		{
			previewRotate();
			return;
		}

		if ("OK".equals(cmd))
		{
			this.okPressed = true;
			// rotate();
		} else
		{
			this.okPressed = false;
		}

		this.setVisible(false);
	}

	class scrollHandler implements AdjustmentListener
	{
		@Override
		public void adjustmentValueChanged(AdjustmentEvent e)
		{
			int angle = e.getValue();
			jtAngle.setText(String.valueOf(angle));
			previewRotate();
		}
	}

	class scrollWheelHandler implements MouseWheelListener
	{
		@Override
		public void mouseWheelMoved(MouseWheelEvent e)
		{
			int val = scrollBar.getValue() + e.getWheelRotation();
			if (val >= scrollBar.getMinimum() && val < scrollBar.getMaximum())
			{
				scrollBar.setValue(val);
			}
		}
	}

	class ImageScaleHandler implements MouseWheelListener
	{
		@Override
		public void mouseWheelMoved(MouseWheelEvent event)
		{
			scaleImage(event.getWheelRotation());
		}
	}

	public boolean isOk()
	{
		return okPressed;
	}

	public BufferedImage getImage()
	{
		return rotate();
	}

	void scaleImage(int increment)
	{
		cellWidth = cellWidth + increment;

		if (cellWidth < 1)
			cellWidth = 1;
		if (cellWidth > 10)
			cellWidth = 10;
		jtScale.setText(String.valueOf(cellWidth));
		repaint();
	}
}
