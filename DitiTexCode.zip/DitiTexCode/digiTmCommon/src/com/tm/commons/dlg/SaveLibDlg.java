package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;

public class SaveLibDlg extends DigiTmDlg implements ActionListener {
	private static final long serialVersionUID = -8823716011951830517L;
	private final JPanel contentPanel = new JPanel();
	DefaultListModel<String> mdlLib = new DefaultListModel<String>();
	JList<String> listLib = new JList<>(mdlLib);

	String libHome;

	boolean ok;

	public SaveLibDlg(String libHome) {
		this();
		this.libHome = libHome;
		initLibs();
	}

	/**
	 * Create the dialog.
	 */
	public SaveLibDlg() {
		super();

		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));

		this.contentPanel.add(new JLabel("Select Library"), BorderLayout.NORTH);
		this.contentPanel.add(new JScrollPane(this.listLib), BorderLayout.CENTER);
		this.listLib.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		JButton createLibButton = new JButton("Create New Library");
		createLibButton.setActionCommand("CREATE");
		JPanel pnl = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		pnl.add(createLibButton);
		this.contentPanel.add(pnl, BorderLayout.SOUTH);

		getContentPane().add(contentPanel, BorderLayout.CENTER);
		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
		getContentPane().add(buttonPane, BorderLayout.SOUTH);
		JButton okButton = new JButton("OK");
		okButton.setActionCommand("OK");
		buttonPane.add(okButton);
		getRootPane().setDefaultButton(okButton);
		JButton cancelButton = new JButton("Cancel");
		cancelButton.setActionCommand("CANCEL");
		buttonPane.add(cancelButton);

		okButton.addActionListener(this);
		cancelButton.addActionListener(this);
		createLibButton.addActionListener(this);
	}

	void initLibs() {
		File dir = new File(this.libHome);
		for (File file : dir.listFiles()) {
			if (file.isDirectory()) {
				this.mdlLib.addElement(file.getName());
			}
		}
	}

	void createNewLib() {
		String lib = JOptionPane.showInputDialog("Enter New Library Name");

		if (lib != null) {
			File dir = new File(this.libHome + File.separator + lib);
			if (!dir.exists()) {
				dir.mkdir();
				this.mdlLib.addElement(lib);
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();

		if ("OK".equals(cmd)) {
			if (this.listLib.getSelectedIndex() >= 0) {
				ok = true;
				this.setVisible(false);
			}
		} else if ("CANCEL".equals(cmd)) {
			ok = false;
			this.setVisible(false);
		} else if ("CREATE".equals(cmd)) {
			this.createNewLib();
		}
	}

	public String getSelectedLibrary() {
		return this.listLib.getSelectedValue();
	}

	public boolean isOk() {
		return ok;
	}

	public static void main(String[] args) {
		SaveLibDlg dlg = new SaveLibDlg("E:/TM01/pattern");
		dlg.setVisible(true);
	}
}
