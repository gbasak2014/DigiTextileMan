package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSplitPane;
import javax.swing.JToolBar;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.tm.commons.action.FileMenuActionEnum;
import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.components.pane.MovableImagePane;
import com.tm.commons.components.pane.MultiImagePane;
import com.tm.commons.image.ImageUtils;
import com.tm.commons.menu.DigiTmToolBar;

public class ImageSplitDlg extends DigiTmDlg implements ActionListener {
	private static final long serialVersionUID = -4907041612182068526L;
	MovableImagePane imgSrcPane = new MovableImagePane();
	MultiImagePane imgTrgPane = new MultiImagePane();
	String lastPath;
	boolean isHorizontal = true;

	/*
	 * JLabel lblStart1 = new JLabel(" Start: "); JLabel lblLength2 = new JLabel(
	 * " Length: 000 "); JTextField jtLength1 = new JTextField(); JTextField
	 * jtStart2 = new JTextField();
	 */
	JLabel lblW = new JLabel(" Width: 0000");
	JLabel lblH = new JLabel(" Heigth: 0000");

	public ImageSplitDlg() {
		this.setTitle("Image split");
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(getToolBar(), BorderLayout.NORTH);

		JScrollPane scrollSrc = new JScrollPane(this.imgSrcPane);
		JScrollPane scrollTrg = new JScrollPane(this.imgTrgPane);

		JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollSrc, scrollTrg);
		splitPane.setDividerLocation(400);
		this.getContentPane().add(splitPane, BorderLayout.CENTER);

		this.setPreferredSize(new Dimension(1000, 700));
		this.setSize(1000, 700);
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		int l = ((int)d.getWidth() - 1000)/2;
		int t = ((int)d.getHeight() - 700)/2;
		if (l<0) l=0;
		if (t<0) t=0;
		this.setLocation(l, t);
	}

	JToolBar getToolBar() {
		JToolBar tool = new DigiTmToolBar();
		tool.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
		tool.add(new ButtonMenuItem(FileMenuActionEnum.OPEN.value, this, "/img/open.jpg", "Open"));
		tool.add(new ButtonMenuItem(FileMenuActionEnum.SAVE.value, this, "/img/save.jpg", "Save split images"));
		JRadioButton jrH = new JRadioButton("Horozontal");
		JRadioButton jrV = new JRadioButton("Vertical");
		ButtonGroup bg = new ButtonGroup();
		bg.add(jrV);
		bg.add(jrH);
		jrH.setActionCommand(String.valueOf(FileMenuActionEnum.HORIZ.value));
		jrV.setActionCommand(String.valueOf(FileMenuActionEnum.VERT.value));
		jrH.addActionListener(this);
		jrV.addActionListener(this);
		jrH.setSelected(true);
		jrH.setOpaque(false);
		jrV.setOpaque(false);
		tool.add(jrH);
		tool.add(jrV);

		JPanel pnl = new JPanel(new FlowLayout(FlowLayout.LEFT, 3, 0));
		pnl.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.WHITE), "Image Size"));
		pnl.add(this.lblW);
		pnl.add(this.lblH);
		pnl.setOpaque(false);
		tool.add(pnl);
		/*
		 * pnl = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
		 * pnl.setBorder(BorderFactory.createTitledBorder("Image One")); pnl.add(new
		 * JLabel(" Start: 000, Length: ")); pnl.add(this.jtLength1);
		 * this.jtLength1.setSize(30, 20); this.jtLength1.setPreferredSize(new
		 * Dimension(40, 20)); pnl.setOpaque(false); tool.add(pnl); pnl = new
		 * JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
		 * pnl.setBorder(BorderFactory.createTitledBorder("Image Two")); pnl.add(new
		 * JLabel(" Start: ")); pnl.add(this.jtStart2); pnl.add(this.lblLength2);
		 * this.jtStart2.setSize(30, 20); this.jtStart2.setPreferredSize(new
		 * Dimension(40, 20)); pnl.setOpaque(false); tool.add(pnl);
		 */
		tool.add(new ButtonMenuItem(FileMenuActionEnum.SPLIT.value, this, "/img/split.jpg", "Split Image"));
		tool.add(new ButtonMenuItem(FileMenuActionEnum.ZOOM_IN.value, this, "/img/z2.jpg", "Zoom In"));
		tool.add(new ButtonMenuItem(FileMenuActionEnum.ZOOM_OUT.value, this, "/img/z1.jpg", "Zoom Out"));

		tool.add(new JSeparator(JSeparator.VERTICAL));

		tool.add(new ButtonMenuItem(FileMenuActionEnum.CLOSE.value, this, "/img/close.jpg", "Close"));

		return tool;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		FileMenuActionEnum cmd = FileMenuActionEnum.fromString(e.getActionCommand());

		switch (cmd) {
		case OPEN:
			openImage();
			break;
		case SAVE:
			saveImage();
		case ZOOM_IN:
			this.imgSrcPane.zoom(1);
			this.imgTrgPane.setZoom(1);
			this.imgTrgPane.repaint();
			break;
		case ZOOM_OUT:
			this.imgSrcPane.zoom(-1);
			this.imgTrgPane.setZoom(-1);
			this.imgTrgPane.repaint();
			break;
		case HORIZ:
			this.isHorizontal = true;
			break;
		case VERT:
			this.isHorizontal = false;
			break;
		case SPLIT:
			splitImage();
			break;
		case CLOSE:
			this.setVisible(false);
			this.dispose();
		}

	}

	void splitImage() {
		BufferedImage img = this.imgSrcPane.getImage();
		int w = img.getWidth();
		int h = img.getHeight();
		int w1, w2;
		int h1, h2;
		if (this.isHorizontal) {
			h1 = h2 = h;
			w1 = w / 2;
			w2 = w1;
			if (w > (w1 + w2)) {
				w1++;
			}
		} else {
			w1 = w2 = w;
			h1 = h / 2;
			h2 = h1;
			if (h > (h1 + h2)) {
				h1++;
			}
		}

		BufferedImage img1 = new BufferedImage(w1, h1, BufferedImage.TYPE_INT_RGB);
		BufferedImage img2 = new BufferedImage(w2, h2, BufferedImage.TYPE_INT_RGB);
		int[] data = ((DataBufferInt) img.getRaster().getDataBuffer()).getData();
		int[] data1 = ((DataBufferInt) img1.getRaster().getDataBuffer()).getData();
		int[] data2 = ((DataBufferInt) img2.getRaster().getDataBuffer()).getData();

		if (this.isHorizontal) {
			for (int x = 0; x < w1; x++) {
				for (int y = 0; y < h1; y++) {
					data1[x + y * w1] = data[(x * 2) + y * w];
				}
			}
			for (int x = 0; x < w2; x++) {
				for (int y = 0; y < h2; y++) {
					data2[x + y * w2] = data[(x * 2) + 1 + y * w];
				}
			}
		} else {
			for (int x = 0; x < w1; x++) {
				for (int y = 0; y < h1; y++) {
					data1[x + y * w1] = data[x + (y * 2) * w];
				}
			}
			for (int x = 0; x < w2; x++) {
				for (int y = 0; y < h2; y++) {
					data2[x + y * w2] = data[x + (y * 2 + 1) * w];
				}
			}
		}

		this.imgTrgPane.setImages(img1, img2);
		this.imgTrgPane.repaint();
	}

	void saveImage() {
		BufferedImage img1 = this.imgTrgPane.getImageOne();
		BufferedImage img2 = this.imgTrgPane.getImageTwo();
		if (img1 != null) {

			JFileChooser jfc;
			if (this.lastPath != null)
				jfc = new JFileChooser(new File(lastPath));
			else {
				jfc = new JFileChooser();
			}

			jfc.setFileFilter(new FileNameExtensionFilter("24-bit Bitmap", "bmp"));

			if (jfc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
				File file = jfc.getSelectedFile();
				String path = file.getAbsolutePath().toLowerCase();
				if (!path.endsWith(".bmp")) {
					path = path + ".bmp";
				}
				String[] pathPart = path.split("\\.");
				String path1 = pathPart[0] + "-1." + pathPart[1];
				String path2 = pathPart[0] + "-2." + pathPart[1];
				ImageUtils.saveImage(img1, path1, "BMP");
				ImageUtils.saveImage(img2, path2, "BMP");
			}
		}
	}

	void openImage() {
		ImageOpenDlgTree dlg = new ImageOpenDlgTree(null, this.lastPath);
		dlg.setVisible(true);
		BufferedImage img = dlg.getSelectedImage();
		if (img != null) {
			this.lastPath = dlg.getSelectedFile().getParentFile().getAbsolutePath();
			this.imgSrcPane.setImage(img);

			this.lblW.setText(" Width: " + img.getWidth());
			this.lblH.setText(" Height: " + img.getHeight());
		}
	}
}
