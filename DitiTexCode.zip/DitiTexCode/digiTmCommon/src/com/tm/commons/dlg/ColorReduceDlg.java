package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.JLabel;
import javax.swing.SwingConstants;

import com.tm.commons.components.ScrollableColorList;
import com.tm.commons.tool.ColorImagePane;

public class ColorReduceDlg extends JDialog implements ActionListener {

	private static final long serialVersionUID = 1175426268639932910L;

	private final JPanel contentPanel = new JPanel();

	static final int ADD = 0;
	static final int ADD_ALL = 1;
	static final int REMOVE = 2;
	static final int REMOVE_ALL = 3;
	static final int OK = 4;
	static final int REDUCE_COLORS = 5;
	
	ScrollableColorList availableColors;
	ScrollableColorList selectedColors;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			BufferedImage img = new BufferedImage(10, 10, BufferedImage.TYPE_INT_RGB);
			ColorReduceDlg dialog = new ColorReduceDlg(img);
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public ColorReduceDlg(BufferedImage img) {
		this.availableColors = new ScrollableColorList(10);
		this.selectedColors = new ScrollableColorList(10);
		setBounds(100, 100, 515, 378);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		this.availableColors.setBounds(37, 42, 100, 200);
		contentPanel.add(this.availableColors);

		// JPanel LISTCOLOR = new JPanel();
		this.selectedColors.setBounds(246, 42, 100, 200);
		contentPanel.add(this.selectedColors);

		JButton btnAdd = new JButton(">");
		btnAdd.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnAdd.setBounds(147, 56, 89, 23);
		contentPanel.add(btnAdd);

		JButton btnAddAll = new JButton(">>");
		btnAddAll.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnAddAll.setBounds(147, 80, 89, 23);
		contentPanel.add(btnAddAll);

		JButton btnRemove = new JButton("<");
		btnRemove.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnRemove.setBounds(147, 105, 89, 23);
		contentPanel.add(btnRemove);

		JButton btnRemoveAll = new JButton("<<");
		btnRemoveAll.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnRemoveAll.setBounds(147, 132, 89, 23);
		contentPanel.add(btnRemoveAll);

		JLabel lblAvailableColors = new JLabel("Available Colors");
		lblAvailableColors.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblAvailableColors.setHorizontalAlignment(SwingConstants.CENTER);
		lblAvailableColors.setBounds(37, 11, 100, 27);
		contentPanel.add(lblAvailableColors);

		JLabel lblSelectedColors = new JLabel("Selected Colors");
		lblSelectedColors.setHorizontalAlignment(SwingConstants.CENTER);
		lblSelectedColors.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblSelectedColors.setBounds(244, 11, 100, 27);
		contentPanel.add(lblSelectedColors);

		JButton btnReduceColor = new JButton("Remove Selected Colors");
		btnReduceColor.setBounds(100, 253, 180, 23);
		contentPanel.add(btnReduceColor);

		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
		getContentPane().add(buttonPane, BorderLayout.SOUTH);

		JButton btnOk = new JButton("Close");
		buttonPane.add(btnOk);
		getRootPane().setDefaultButton(btnOk);

		btnAdd.setActionCommand(String.valueOf(ADD));
		btnAddAll.setActionCommand(String.valueOf(ADD_ALL));
		btnRemove.setActionCommand(String.valueOf(REMOVE));
		btnRemoveAll.setActionCommand(String.valueOf(REMOVE_ALL));
		btnOk.setActionCommand(String.valueOf(OK));
		btnReduceColor.setActionCommand(String.valueOf(REDUCE_COLORS));
		btnAdd.addActionListener(this);
		btnAddAll.addActionListener(this);
		btnRemove.addActionListener(this);
		btnRemoveAll.addActionListener(this);
		btnOk.addActionListener(this);
		btnReduceColor.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		int cmd = Integer.parseInt(ae.getActionCommand());
		int idx;
		int cnt;
		switch (cmd) {
		case ADD:
			idx = availableColors.getSelectedIndex();
			if (idx >= 0) {
				this.selectedColors.addItem(this.availableColors.getItem(idx));
				this.availableColors.removeItem(idx);
			}
			break;
		case ADD_ALL:
			cnt = this.availableColors.itemCount();
			if (cnt > 0) {
				for (int i = 0; i < cnt; i++) {
					this.selectedColors.addItem(this.availableColors.getItem(i));
				}
				this.availableColors.removeAllItems();
			}
			break;
		case REMOVE:
			idx = this.selectedColors.getSelectedIndex();
			if (idx >= 0) {
				this.availableColors.addItem(this.selectedColors.getItem(idx));
				this.selectedColors.removeItem(idx);
			}
			break;
		case REMOVE_ALL:
			cnt = this.selectedColors.itemCount();
			if (cnt > 0) {
				for (int i = 0; i < cnt; i++) {
					this.availableColors.addItem(this.selectedColors.getItem(i));
				}
				this.selectedColors.removeAllItems();
			}
			break;
		case OK:
			this.setVisible(false);
			break;
		case REDUCE_COLORS:
			this.reduceColors();
			break;
		}
	}
	
	private void reduceColors()
	{
		System.out.println("Reduce Colors...............");
	}
}
