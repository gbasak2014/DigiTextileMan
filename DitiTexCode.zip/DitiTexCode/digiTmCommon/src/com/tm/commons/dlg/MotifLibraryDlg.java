package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileFilter;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.tm.commons.action.DigiTmEnum;
import com.tm.commons.components.pane.MovableImagePane;
import com.tm.commons.theme.DigiTmTheme;

public class MotifLibraryDlg extends DigiTmDlg implements ActionListener {
	private static final long serialVersionUID = 8814945136345626755L;
	DefaultListModel<String> listDir = new DefaultListModel<String>();
	DefaultListModel<String> listFile = new DefaultListModel<String>();

	JList<String> jlDir = new JList<String>(listDir);
	JList<String> jlFile = new JList<String>(listFile);

	boolean okPresses = false;

	MovableImagePane imgPane = new MovableImagePane();

	File selectedFile;

	JCheckBox checkImgPreview = new JCheckBox("No Image Preview");

	String libHome;
	String selectedLib;
	String selectedFileName;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			MotifLibraryDlg dialog = new MotifLibraryDlg(null, "E:/TM01/pattern");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	void setThemeColor() {
		this.getContentPane().setBackground(DigiTmTheme.getBgColor());
		this.jlDir.setBackground(DigiTmTheme.getBgColor());
		this.jlFile.setBackground(DigiTmTheme.getBgColor());
	}

	/**
	 * Create the dialog.
	 */
	public MotifLibraryDlg(JFrame parent, String libHome) {
		super(parent);
		this.libHome = libHome;
		setBounds(100, 100, 800, 500);
		getContentPane().setLayout(new BorderLayout());
		imgPane.setBorder(BorderFactory.createLoweredBevelBorder());
		getContentPane().add(imgPane, BorderLayout.CENTER);

		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));

		JButton btnOk = new JButton("OK");
		btnOk.setBackground(DigiTmTheme.getBgColor());
		btnOk.setActionCommand(String.valueOf(DigiTmEnum.OK.value));

		getRootPane().setDefaultButton(btnOk);

		JButton btnCancel = new JButton("Cancel");
		btnCancel.setBackground(DigiTmTheme.getBgColor());
		btnCancel.setActionCommand(String.valueOf(DigiTmEnum.CANCEL.value));

		checkImgPreview.setBackground(DigiTmTheme.getBgColor());
		buttonPane.add(checkImgPreview);
		JLabel lbl = new JLabel();
		lbl.setPreferredSize(new Dimension(500, 10));
		buttonPane.add(lbl);
		buttonPane.add(btnOk);
		buttonPane.add(btnCancel);

		JPanel dirFilePane = new JPanel(new GridLayout(2, 1, 1, 1));

		jlDir.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		jlFile.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		dirFilePane.add(new JScrollPane(jlDir));
		dirFilePane.add(new JScrollPane(jlFile));

		getContentPane().add(buttonPane, BorderLayout.SOUTH);
		getContentPane().add(dirFilePane, BorderLayout.WEST);

		dirFilePane.setBackground(DigiTmTheme.getBgColor());
		buttonPane.setBackground(DigiTmTheme.getBgColor());

		btnCancel.addActionListener(this);
		btnOk.addActionListener(this);

		jlDir.addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent lse) {
				if (!MotifLibraryDlg.this.jlDir.getSelectedValue().equals(selectedLib)) {
					refreshFileList(MotifLibraryDlg.this.jlDir.getSelectedValue());
				}
			}
		});

		jlFile.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				if (MotifLibraryDlg.this.jlFile.getSelectedValue() != null
						&& !MotifLibraryDlg.this.jlFile.getSelectedValue().equals(selectedFileName)) {
					MotifLibraryDlg.this.selectedFileName = MotifLibraryDlg.this.jlFile.getSelectedValue();
					previewImage(MotifLibraryDlg.this.jlFile.getSelectedValue());
				}
			}
		});

		this.initDirAndFileList(this.libHome);

		this.setThemeColor();
	}

	void refreshFileList(String libName) {
		this.selectedLib = libName;
		String path = this.libHome + "/" + libName;
		File lib = new File(path);
		this.listFile.clear();
		for (File motif : lib.listFiles()) {
			if (motif.isFile()) {
				this.listFile.addElement(motif.getName());
			}
		}
	}

	void previewImage(String fileName) {
		String path = this.libHome + "/" + this.jlDir.getSelectedValue() + "/" + fileName;

		selectedFile = new File(path);

		if (!checkImgPreview.isSelected()) {
			try {
				BufferedImage img = ImageIO.read(selectedFile);
				imgPane.setImage(img);
			} catch (Exception e) {
			}
		} else {
			imgPane.setImage(null);
		}
	}

	public File getSelectedFile() {
		return selectedFile;
	}

	void initDirAndFileList(String path) {
		File dir = new File(path);
		if (dir.isDirectory()) {
			File[] files = dir.listFiles(new FileFilter() {

				@Override
				public boolean accept(File pathname) {
					return pathname.isDirectory();
				}
			});

			listDir.clear();
			for (File file : files) {
				listDir.addElement(file.getName());
			}
		}

		initFileList(path);
	}

	void initFileList(String path) {
		File dir = new File(path);
		if (dir.isDirectory()) {
			File[] files = dir.listFiles(new FileFilter() {

				@Override
				public boolean accept(File pathname) {
					return !pathname.isDirectory()
							&& (pathname.getName().toUpperCase().endsWith(".BMP") || pathname.getName().toUpperCase()
									.endsWith(".JPG"));
				}
			});

			listFile.clear();
			for (File file : files) {
				listFile.addElement(file.getName());
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		DigiTmEnum action = DigiTmEnum.fromString(e.getActionCommand());

		switch (action) {
		case OK:
			okPresses = true;
			this.setVisible(false);
			break;
		case CANCEL:
			this.setVisible(false);
			break;
		default:
			break;
		}
	}

	public BufferedImage getSelectedImage() {
		if (selectedFile != null && imgPane.getImage() == null) {
			try {
				return ImageIO.read(selectedFile);
			} catch (Exception e) {
			}
		}

		return imgPane.getImage();
	}

	public boolean isOk() {
		return okPresses;
	}

	class ImgPage extends JPanel {
		/**
		 * 
		 */
		private static final long serialVersionUID = -4123591271409721179L;
		int left, top, x1, y1, x2, y2;
		BufferedImage img;

		void draggMe(int x, int y) {
			x2 = x;
			y2 = y;
			repaint();
		}

		public ImgPage() {
			this.setCursor(new Cursor(Cursor.HAND_CURSOR));
			this.addMouseMotionListener(new MouseMotionAdapter() {
				@Override
				public void mouseDragged(MouseEvent e) {
					draggMe(e.getX(), e.getY());
				}
			});

			this.addMouseListener(new MouseAdapter() {
				@Override
				public void mousePressed(MouseEvent e) {
					x1 = x2 = e.getX();
					y1 = y2 = e.getY();
				}

				@Override
				public void mouseReleased(MouseEvent e) {
					left = left + x2 - x1;
					top = top + y2 - y1;
				}
			});
		}

		public void setImage(BufferedImage img) {
			this.img = img;
			if (img != null) {
				left = (getWidth() - img.getWidth()) / 2;
				top = (getHeight() - img.getHeight()) / 2;
				x1 = y1 = x2 = y2 = 0;
			}
			repaint();
		}

		@Override
		public void paint(Graphics g) {
			super.paint(g);
			g.setColor(Color.BLACK);
			g.fillRect(0, 0, getWidth(), getHeight());
			if (img != null) {
				int x = left + x2 - x1;
				int y = top + y2 - y1;
				g.setColor(Color.WHITE);
				g.drawRect(x - 2, y - 2, img.getWidth() + 4, img.getHeight() + 4);
				g.drawImage(img, x, y, MotifLibraryDlg.this);
			}
		}
	}
}
