package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import com.tm.commons.components.button.ButtonImageToggle;
import com.tm.commons.listener.ColorChangeListener;
import com.tm.commons.listener.ColorProtectListener;

public class ColorLockDlg extends DigiTmDlg implements ColorChangeListener {
	private static final long serialVersionUID = 8845708699363700565L;
	List<ButtonImageToggle> colors = new ArrayList<ButtonImageToggle>();
	ColorProtectListener colorProtectListener;
	JButton btnColor = new JButton();

	public ColorLockDlg(JFrame parent, List<Integer> rgbs, Color drawingColor, ColorProtectListener colorProtectListener, int lockedRGBs[]) {
		super(parent);
		this.colorProtectListener = colorProtectListener;
		int cnt = rgbs.size();
		int cols = 10;
		int rows = cnt / cols + (cnt % cols > 0 ? 1 : 0);

		this.getContentPane().setLayout(new BorderLayout());

		JPanel panelColor = new JPanel(new GridLayout(rows, cols));
		int idx = 0;
		for (int r = 0; r < rows && idx < cnt; r++) {
			for (int c = 0; c < cols && idx < cnt; c++) {
				int rgb = rgbs.get(idx);
				ButtonImageToggle btn = new ButtonImageToggle(rgb, "/img/unlock.jpg", "/img/lock.jpg", isLocked(lockedRGBs, rgb));
				colors.add(btn);
				panelColor.add(btn);
				idx++;
			}
		}
		this.getContentPane().add(panelColor, BorderLayout.CENTER);

		JPanel pnlAction = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		this.btnColor.setPreferredSize(new Dimension(20, 20));
		this.btnColor.setBackground(drawingColor);
		pnlAction.add(this.btnColor);

		JButton btn = new JButton("Apply");
		pnlAction.add(btn);
		btn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				applyColorProtect();
			}
		});

		btn = new JButton("Close");
		pnlAction.add(btn);
		btn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				closeMe();
			}
		});
		
		this.getContentPane().add(pnlAction, BorderLayout.SOUTH);
		this.setSize(300, 100 + 30 * rows);
		this.setLocation(200, 200);
	}

	boolean isLocked(int[] rgbs, int rgb)
	{
		if (rgbs == null)
			return false;
		
		for (int r : rgbs)
		{
			if (r == rgb)
				return true;
		}
		
		return false;
	}
	
	void closeMe()
	{
		this.setVisible(false);
	}
	
	@Override
	public void colorChanged(Color color) {

	}

	void applyColorProtect() {
		int rgb = this.btnColor.getBackground().getRGB() | 0xff000000;
		List<Integer> list = new ArrayList<Integer>();
		for (ButtonImageToggle btn : this.colors) {
			if (!btn.isLocked()) {
				list.add(btn.getBackground().getRGB());
			}
		}
		if (list.size() > 0) {
			Integer[] rgbArr = list.toArray(new Integer[0]);
			this.colorProtectListener.protectColor(rgbArr, rgb);
		}
	}
	
	public int[] getLockedRGB()
	{
		int lcCnt=0;
		for (ButtonImageToggle btn : this.colors)
		{
			if (btn.isLocked())
			{
				lcCnt++;
			}
		}
		
		if (lcCnt > 0)
		{
			int[] rgb = new int[lcCnt];
			int i=0;
			for (ButtonImageToggle btn : this.colors)
			{
				if (btn.isLocked())
				{
					rgb[i] = btn.getBackground().getRGB() | 0xFF000000;
					i++;
				}
			}
			
			return rgb;
		}
		
		return null;
	}
	
}
