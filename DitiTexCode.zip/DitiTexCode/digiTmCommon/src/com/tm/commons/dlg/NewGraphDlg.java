package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.SwingConstants;

import com.tm.commons.theme.DigiTmTheme;

public class NewGraphDlg extends DigiTmDlg implements ActionListener {

	private final JPanel contentPanel = new JPanel();
	private JTextField txtRow = new JTextField("100");
	private JTextField txtCol = new JTextField("100");

	boolean isOk;
	int row;
	int column;

	/**
	 * Create the dialog.
	 */
	public NewGraphDlg() {
		super();

		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 400, 200);

		getContentPane().setLayout(new BorderLayout());

		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
		getContentPane().add(buttonPane, BorderLayout.SOUTH);

		JButton okButton = new JButton("OK");
		okButton.setActionCommand("OK");
		okButton.addActionListener(this);
		getRootPane().setDefaultButton(okButton);
		JButton cancelButton = new JButton("Cancel");
		cancelButton.setActionCommand("Cancel");
		cancelButton.addActionListener(this);
		cancelButton.registerKeyboardAction(this, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
				JComponent.WHEN_IN_FOCUSED_WINDOW);

		buttonPane.add(okButton);
		buttonPane.add(cancelButton);

		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		JLabel label = new JLabel("Width (in point):");
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		label.setBounds(50, 20, 100, 30);
		txtCol.setBounds(150, 20, 100, 30);
		txtCol.setPreferredSize(new Dimension(50, 25));

		contentPanel.add(label);
		contentPanel.add(txtCol);

		JLabel label_1 = new JLabel("Height (in point):");
		label_1.setHorizontalAlignment(SwingConstants.RIGHT);
		label_1.setBounds(50, 55, 100, 30);
		txtRow.setBounds(150, 55, 100, 30);
		txtRow.setPreferredSize(new Dimension(50, 25));
		contentPanel.add(label_1);
		contentPanel.add(txtRow);

		contentPanel.setBackground(DigiTmTheme.getBgColor());
		buttonPane.setBackground(DigiTmTheme.getBgColor());
		okButton.setBackground(DigiTmTheme.getBgColor());
		cancelButton.setBackground(DigiTmTheme.getBgColor());
		txtCol.setBackground(DigiTmTheme.getBgColor());
		txtRow.setBackground(DigiTmTheme.getBgColor());
	}

	public NewGraphDlg(int width, int height, boolean enabled) {
		this();
		this.txtCol.setText(String.valueOf(width));
		this.txtRow.setText(String.valueOf(height));

		if (!enabled) {
			this.txtCol.setEditable(false);
			this.txtRow.setEditable(false);
		}
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		try {
			if ("OK".equals(event.getActionCommand())) {
				isOk = true;
				if (txtRow.getText().trim().length() < 1 || txtCol.getText().trim().length() < 1) {
					return;
				}
				row = Integer.parseInt(txtRow.getText());
				column = Integer.parseInt(txtCol.getText());
			} else {
				isOk = false;
			}

			setVisible(false);
		} catch (Exception e) {
		}
	}

	public int getRow() {
		return this.row;
	}

	public int getColumn() {
		return this.column;
	}

	public boolean isOkPressed() {
		return this.isOk;
	}
}
