package com.tm.commons.dlg;

import java.awt.BorderLayout;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeSelectionModel;

import com.tm.commons.theme.DigiTmTheme;
import com.tm.commons.tool.DesignTreeCellRenderer;

public class PropBrowserDlg extends DigiTmDlg {
	private static final long serialVersionUID = 8030432355654395303L;
	JTree tree;
	ImageIcon iconDesign;
	ImageIcon iconGroup;
	ImageIcon iconMotif;

	public PropBrowserDlg(JFrame parent, DefaultMutableTreeNode root, TreeSelectionListener listener) {
		super(parent);
		this.setModal(false);
		this.setSize(200, 400);

		this.setLayout(new BorderLayout());
		this.setBackground(DigiTmTheme.getBgColor());
		this.iconDesign = new ImageIcon(this.getClass().getResource("/img/node-design.jpg"));
		this.iconGroup = new ImageIcon(this.getClass().getResource("/img/node-group.jpg"));
		this.iconMotif = new ImageIcon(this.getClass().getResource("/img/node-motif.jpg"));

		this.tree = new JTree(root);

		this.tree.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
		this.tree.addTreeSelectionListener(listener);

		this.tree.setCellRenderer(new DesignTreeCellRenderer(iconDesign, iconGroup, iconMotif));

		JPanel pnl = new JPanel();
		pnl.setOpaque(true);
		pnl.setLayout(new BorderLayout());
		pnl.setBackground(DigiTmTheme.getBgColor());
		pnl.add(new JScrollPane(this.tree), BorderLayout.CENTER);
		this.add(pnl, BorderLayout.CENTER);
	}

	public void addGroup(int motifCount) {

		DefaultTreeModel model = (DefaultTreeModel) this.tree.getModel();
		DefaultMutableTreeNode root = ((DefaultMutableTreeNode) model.getRoot());
		int groupNumber = root.getChildCount() + 1;
		DefaultMutableTreeNode group = new DefaultMutableTreeNode("Group " + groupNumber);
		root.add(group);

		for (int i = 1; i <= motifCount; i++) {
			group.add(new DefaultMutableTreeNode("Motif " + i));
		}

		model.reload();
	}

	public void addMotif(int groupIndex) {
		DefaultTreeModel model = (DefaultTreeModel) this.tree.getModel();
		DefaultMutableTreeNode root = ((DefaultMutableTreeNode) model.getRoot());
		int idx = root.getChildCount();
		DefaultMutableTreeNode group;

		if (groupIndex >= idx) {
			group = new DefaultMutableTreeNode("Group " + (groupIndex + 1));
			root.add(group);
		} else {
			group = (DefaultMutableTreeNode) root.getChildAt(groupIndex);
		}

		group.add(new DefaultMutableTreeNode("Motif " + (group.getChildCount() + 1)));

		model.reload();
	}

	public void removeGrup(int idx) {
		DefaultTreeModel model = (DefaultTreeModel) this.tree.getModel();
		DefaultMutableTreeNode root = ((DefaultMutableTreeNode) model.getRoot());

		root.remove(idx);
		model.reload();
	}

	public void removeMotif(int groupIdx) {
		DefaultTreeModel model = (DefaultTreeModel) this.tree.getModel();
		DefaultMutableTreeNode root = ((DefaultMutableTreeNode) model.getRoot());

		if (root.getChildCount() >= groupIdx)
		{
			DefaultMutableTreeNode group = (DefaultMutableTreeNode) root.getChildAt(groupIdx);
			group.remove(group.getChildCount() - 1);
		}
		model.reload();
	}

}
