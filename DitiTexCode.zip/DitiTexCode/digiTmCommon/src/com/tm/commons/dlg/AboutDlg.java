package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import com.tm.commons.components.button.ButtonMenuItem;

public class AboutDlg extends DigiTmDlg implements ActionListener {

	private final JPanel contentPanel = new JPanel();

	String user;

	public AboutDlg(JFrame parent, String user) {
		super(parent);
		this.user = user;
		init();
	}

	public AboutDlg(String user) {
		super();
		this.user = user;
		init();
	}

	void init() {
		Color bg = new Color(225, 180, 0);
		setBounds(100, 100, 710, 400);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(bg);
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		JButton btn = new ButtonMenuItem(1, null, "/img/about.jpg", null);
		btn.setPreferredSize(new Dimension(700, 190));
		btn.setBounds(0, 0, 700, 190);
		contentPanel.add(btn);

		JLabel usr = new JLabel("Dedicated to Shourya Basak");
		usr.setForeground(new Color(0, 0, 110));
		usr.setBackground(bg);
		usr.setHorizontalAlignment(SwingConstants.CENTER);
		usr.setFont(new Font("Verdana", Font.BOLD, 24));
		usr.setBounds(10, 251, 700, 30);
		contentPanel.add(usr);

		JLabel lblVersion = new JLabel("Version: FREE");
		lblVersion.setHorizontalAlignment(SwingConstants.CENTER);
		lblVersion.setForeground(new Color(0, 0, 0));
		lblVersion.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblVersion.setBounds(10, 288, 680, 30);
		contentPanel.add(lblVersion);

		JPanel buttonPane = new JPanel();
		buttonPane.setBackground(bg);
		buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER));
		getContentPane().add(buttonPane, BorderLayout.SOUTH);

		JButton okButton = new JButton("Close");

		okButton.setBackground(bg);
		okButton.setActionCommand("Close");
		buttonPane.add(okButton);
		getRootPane().setDefaultButton(okButton);

		okButton.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		this.setVisible(false);
		this.dispose();
	}
}
