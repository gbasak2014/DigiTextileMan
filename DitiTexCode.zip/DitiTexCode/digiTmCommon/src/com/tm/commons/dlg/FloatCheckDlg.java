package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.io.File;
import java.util.HashSet;
import java.util.Set;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.tm.commons.components.ColorComboRenderer;
import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.components.pane.MovableImagePane;
import com.tm.commons.image.ImageUtils;
import com.tm.commons.listener.ColorChangeListener;
import com.tm.commons.theme.DigiTmTheme;
import com.tm.commons.tool.ColorPane;
import com.tm.commons.tool.DropdownColorChooser;
import com.tm.commons.win.DigiTmWin;

public class FloatCheckDlg extends DigiTmWin implements ColorChangeListener, ActionListener {
	private static final long serialVersionUID = 143058702351786601L;
	static final int OPEN = 0;
	static final int SAVE = 1;
	static final int ZOOM_IN = 2;
	static final int ZOOM_OUT = 3;
	static final int SCAN = 4;
	static final int CHECK = 5;
	static final int REFRESH = 6;
	static final int CLOSE = 7;

	static final int LEFT_RIGHT = 0;
	static final int RIGHT_LEFT = 1;
	static final int TOP_BOTTOM = 2;
	static final int BOTTOM_TOP = 3;

	JComboBox<Integer> jcColors = new JComboBox<>();
	JComboBox<String> jcDirection = new JComboBox<>();
	JTextField jtFloat = new JTextField();
	MovableImagePane imgPane = new MovableImagePane();
	DropdownColorChooser colorChooser;

	JButton btnColor = new JButton("");

	String lastPath;

	BufferedImage backImg;

	public FloatCheckDlg() {
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(this.getToolBar(), BorderLayout.NORTH);
		this.getContentPane().add(this.imgPane, BorderLayout.CENTER);

		jcColors.setRenderer(new ColorComboRenderer());

		jcColors.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				checkColorChanged();
			}
		});

		this.jcDirection.addItem("Left To Right");
		this.jcDirection.addItem("Right To Left");
		this.jcDirection.addItem("Top To Bottom");
		this.jcDirection.addItem("Bottom To Top");

		this.setPreferredSize(new Dimension(900, 500));
		this.setSize(900, 500);
		this.pack();

	}

	@Override
	public void saveProperties() {

	}

	void checkColorChanged() {
		if (this.jcColors.getItemCount() > 0) {
			int rgb = this.jcColors.getItemAt(this.jcColors.getSelectedIndex());
			this.btnColor.setBackground(new Color(rgb));
		}
	}

	private JPanel getToolBar() {
		// JToolBar panel = new JToolBar();
		JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 2));

		this.jcColors.setPreferredSize(new Dimension(100, 20));
		this.jcDirection.setPreferredSize(new Dimension(100, 20));
		this.jtFloat.setPreferredSize(new Dimension(30, 20));
		this.colorChooser = new DropdownColorChooser(this, false);
		this.colorChooser.addColorPane(new ColorPane());
		this.colorChooser.setOpaque(false);

		panel.setBackground(DigiTmTheme.getBgColor());
		panel.setBorder(DigiTmTheme.getLineBorder());

		panel.add(new ButtonMenuItem(OPEN, this, "/img/open.jpg", "Open Image"));
		panel.add(new ButtonMenuItem(SAVE, this, "/img/save.jpg", "Save Image"));
		panel.add(new ButtonMenuItem(SCAN, this, "/img/scan.jpg", "Scan Colors"));
		panel.add(new JLabel(" Scanned Color"));
		panel.add(this.jcColors);

		this.btnColor.setPreferredSize(new Dimension(20, 20));
		panel.add(new JLabel("Check Color"));
		panel.add(this.btnColor);
		panel.add(new JLabel("Check Direction"));
		panel.add(this.jcDirection);
		panel.add(new JLabel("Highlight Color"));
		panel.add(this.colorChooser);
		panel.add(new JLabel("Float Value"));
		panel.add(this.jtFloat);
		panel.add(new ButtonMenuItem(CHECK, this, "/img/float.jpg", "Scan Colors"));

		panel.add(new ButtonMenuItem(REFRESH, this, "/img/refresh.jpg", "Refresh Image"));
		panel.add(new ButtonMenuItem(ZOOM_IN, this, "/img/z2.jpg", "Zoom-In"));
		panel.add(new ButtonMenuItem(ZOOM_OUT, this, "/img/z1.jpg", "Zoom-Out"));

		panel.add(new ButtonMenuItem(CLOSE, this, "/img/close.jpg", "Close Window"));

		return panel;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		int cmd = Integer.parseInt(e.getActionCommand());
		switch (cmd) {
		case OPEN:
			this.open();
			break;
		case SAVE:
			this.save();
			break;
		case ZOOM_IN:
			this.imgPane.zoom(1);
			break;
		case ZOOM_OUT:
			this.imgPane.zoom(-1);
			break;
		case SCAN:
			this.scanColor();
			break;
		case CHECK:
			this.floatCheck();
			break;
		case REFRESH:
			this.refresh();
			break;
		case CLOSE:
			this.close();
			break;
		}
	}

	void close() {
		this.setVisible(false);
		this.dispose();
	}

	void refresh() {
		if (this.backImg != null) {
			this.imgPane.setImage(this.backImg);
			this.backImg = ImageUtils.copyImage(this.backImg);
		}
	}

	void scanColor() {
		BufferedImage img = this.imgPane.getImage();
		if (img == null) {
			JOptionPane.showMessageDialog(this, "No Image to scan!!");
			return;
		}

		int[] data = ((DataBufferInt) img.getRaster().getDataBuffer()).getData();
		Set<Integer> set = new HashSet<Integer>();
		for (int i = 0; i < data.length; i++) {
			set.add(data[i]);
			if (set.size() > 10) {
				JOptionPane.showMessageDialog(this, "Too many colors!!");
				break;
			}
		}

		for (Integer c : set) {
			this.jcColors.addItem(c);
		}

		int idx = this.jcColors.getSelectedIndex();
		if (idx >= 0) {
			int rgb = this.jcColors.getItemAt(idx);
			this.btnColor.setBackground(new Color(rgb));
		}
	}

	void floatCheck() {
		BufferedImage img = this.imgPane.getImage();
		if (img == null) {
			JOptionPane.showMessageDialog(this, "No Image to check!!");
			return;
		}

		int floatVal = 0;
		try {
			floatVal = Integer.parseInt(this.jtFloat.getText());
			if (floatVal <= 0) {
				JOptionPane.showMessageDialog(this, "Enter valid float value!!");
				return;
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "Enter valid float value!!");
			return;
		}

		int idx = this.jcColors.getSelectedIndex();
		if (idx < 0) {
			JOptionPane.showMessageDialog(this, "No Color to scan!!");
			return;
		}

		int checkRgb = this.jcColors.getItemAt(idx); // this.btnColor.getBackground().getRGB();
		int putRgb = this.colorChooser.getSelectedColor().getRGB();

		int dir = this.jcDirection.getSelectedIndex();

		switch (dir) {
		case LEFT_RIGHT:
			this.checkLeftToRight(img, checkRgb, putRgb, floatVal);
			break;
		case RIGHT_LEFT:
			this.checkRightToLeft(img, checkRgb, putRgb, floatVal);
			break;
		case TOP_BOTTOM:
			this.checkTopToBottom(img, checkRgb, putRgb, floatVal);
			break;
		case BOTTOM_TOP:
			this.checkBottomToTop(img, checkRgb, putRgb, floatVal);
			break;
		}

		this.imgPane.repaint();
	}

	void checkLeftToRight(BufferedImage img, int checkRgb, int putRgb, int floatVal) {
		int w = img.getWidth();
		int h = img.getHeight();
		int[] data = ((DataBufferInt) img.getRaster().getDataBuffer()).getData();
		int cnt = 0;
		for (int y = 0; y < h; y++) {
			cnt = 0;
			for (int x = 0; x < w; x++) {
				if (data[(y * w) + x] == checkRgb) {
					cnt++;
				} else {
					cnt = 0;
				}

				if (cnt > floatVal) {
					data[(y * w) + x] = putRgb;
					cnt = 0;
				}
			}
		}

	}

	void checkRightToLeft(BufferedImage img, int checkRgb, int putRgb, int floatVal) {
		int w = img.getWidth();
		int h = img.getHeight();
		int[] data = ((DataBufferInt) img.getRaster().getDataBuffer()).getData();
		int cnt = 0;
		for (int y = 0; y < h; y++) {
			cnt = 0;
			for (int x = w - 1; x >= 0; x--) {
				if (data[(y * w) + x] == checkRgb) {
					cnt++;
				} else {
					cnt = 0;
				}

				if (cnt > floatVal) {
					data[(y * w) + x] = putRgb;
					cnt = 0;
				}
			}
		}

	}

	void checkTopToBottom(BufferedImage img, int checkRgb, int putRgb, int floatVal) {
		int w = img.getWidth();
		int h = img.getHeight();
		int[] data = ((DataBufferInt) img.getRaster().getDataBuffer()).getData();
		int cnt = 0;
		for (int x = 0; x < w; x++) {
			cnt = 0;
			for (int y = 0; y < h; y++) {
				if (data[(y * w) + x] == checkRgb) {
					cnt++;
				} else {
					cnt = 0;
				}

				if (cnt > floatVal) {
					data[(y * w) + x] = putRgb;
					cnt = 0;
				}
			}
		}
	}

	void checkBottomToTop(BufferedImage img, int checkRgb, int putRgb, int floatVal) {
		int w = img.getWidth();
		int h = img.getHeight();
		int[] data = ((DataBufferInt) img.getRaster().getDataBuffer()).getData();
		int cnt = 0;
		for (int x = 0; x < w; x++) {
			cnt = 0;
			for (int y = h - 1; y >= 0; y--) {
				if (data[(y * w) + x] == checkRgb) {
					cnt++;
				} else {
					cnt = 0;
				}

				if (cnt > floatVal) {
					data[(y * w) + x] = putRgb;
					cnt = 0;
				}
			}
		}
	}

	void open() {
		ImageOpenDlgTree dlg = new ImageOpenDlgTree(this, this.lastPath);
		dlg.setVisible(true);
		BufferedImage img = dlg.getSelectedImage();
		if (img != null) {
			this.imgPane.setImage(img);
			this.backImg = ImageUtils.copyImage(img);
		}
	}

	void save() {
		if (this.imgPane.getImage() == null) {
			JOptionPane.showMessageDialog(this, "No image to save!!");
			return;
		}

		JFileChooser jfc;
		if (this.lastPath != null)
			jfc = new JFileChooser(new File(this.lastPath));
		else {
			jfc = new JFileChooser();
		}

		jfc.setFileFilter(new FileNameExtensionFilter("24-bit Bitmap", "bmp"));

		if (jfc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
			File file = jfc.getSelectedFile();
			String path = file.getAbsolutePath().toLowerCase();
			if (!path.endsWith(".bmp")) {
				path = path + ".bmp";
			}
			boolean st = ImageUtils.saveImage(this.imgPane.getImage(), path, "BMP");
			if (st) {
				this.setTitle(path);
				JOptionPane.showMessageDialog(this, "Image saved");
			}
		}
	}

	@Override
	public void colorChanged(Color color) {

	}

	public static void main(String[] args) {
		FloatCheckDlg dlg = new FloatCheckDlg();
		dlg.setSize(600, 500);
		dlg.setVisible(true);
	}
}
