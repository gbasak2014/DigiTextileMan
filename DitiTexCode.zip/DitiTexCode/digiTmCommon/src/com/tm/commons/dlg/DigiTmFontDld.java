package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import com.tm.commons.theme.DigiTmTheme;

public class DigiTmFontDld extends JDialog implements ItemListener, ActionListener {

	private final JPanel contentPanel = new JPanel();
	JComboBox jcmbFontName;
	JComboBox jcmbFontStyle;
	JComboBox jcmbFontSize;
	JTextField txtrSampleSample;

	Font font;

	int[] style = { Font.PLAIN, Font.BOLD, Font.ITALIC, Font.BOLD + Font.ITALIC };
	int[] size = { 8, 9, 10, 11, 12, 14, 18, 25, 36, 48 };

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Font font = new Font("Arial", Font.BOLD, 14);

			DigiTmFontDld dialog = new DigiTmFontDld(font);
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public DigiTmFontDld(Font font) {
		this.setModal(true);
		setBounds(100, 100, 440, 294);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		JLabel lblName = new JLabel("Font");
		JLabel lblStyle = new JLabel("Style");
		JLabel lblSize = new JLabel("Size");
		lblName.setBounds(10, 17, 182, 23);
		//lblName.setBorder(DigiTmTheme.getLineBorder());
		lblName.setHorizontalAlignment(SwingConstants.CENTER);
		contentPanel.add(lblName);

		lblStyle.setBounds(198, 17, 116, 23);
		lblStyle.setHorizontalAlignment(SwingConstants.CENTER);
		contentPanel.add(lblStyle);

		lblSize.setBounds(324, 17, 91, 23);
		//lblSize.setBorder(DigiTmTheme.getLineBorder());
		lblSize.setHorizontalAlignment(SwingConstants.CENTER);
		contentPanel.add(lblSize);

		jcmbFontName = new JComboBox();
		jcmbFontName.setBounds(10, 41, 182, 23);
		contentPanel.add(jcmbFontName);

		jcmbFontStyle = new JComboBox();
		jcmbFontStyle.setBounds(198, 41, 116, 23);
		contentPanel.add(jcmbFontStyle);

		jcmbFontSize = new JComboBox();
		jcmbFontSize.setBounds(324, 41, 91, 23);
		contentPanel.add(jcmbFontSize);

		txtrSampleSample = new JTextField();
		txtrSampleSample.setText("Sample 1234");
		txtrSampleSample.setBounds(10, 81, 411, 122);
		contentPanel.add(txtrSampleSample);
		txtrSampleSample.setFont(font);
		txtrSampleSample.setHorizontalAlignment(SwingConstants.RIGHT);
		
		
		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
		getContentPane().add(buttonPane, BorderLayout.SOUTH);

		JButton okButton = new JButton("OK");
		okButton.setActionCommand("OK");
		buttonPane.add(okButton);
		getRootPane().setDefaultButton(okButton);

		JButton cancelButton = new JButton("Cancel");
		cancelButton.setActionCommand("Cancel");
		buttonPane.add(cancelButton);

		this.font = font;
		initFontList(this.font);

		this.jcmbFontName.addItemListener(this);
		this.jcmbFontSize.addItemListener(this);
		this.jcmbFontStyle.addItemListener(this);
		
		okButton.addActionListener(this);
		cancelButton.addActionListener(this);
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		String family = (String) this.jcmbFontName.getSelectedItem();
		int st = style[this.jcmbFontStyle.getSelectedIndex()];
		int sz = size[this.jcmbFontSize.getSelectedIndex()];

		if (!font.getFamily().equals(family) || st != font.getStyle() || sz != font.getSize()) {
			font = new Font(family, st, sz);
			this.txtrSampleSample.setFont(font);
		}
	}

	private void initFontList(Font font) {
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		for (String fontName : ge.getAvailableFontFamilyNames()) {
			this.jcmbFontName.addItem(fontName);
		}

		this.jcmbFontStyle.addItem("Plain");
		this.jcmbFontStyle.addItem("Bold");
		this.jcmbFontStyle.addItem("Italic");
		this.jcmbFontStyle.addItem("Bold and Italic");

		this.jcmbFontSize.addItem("8");
		this.jcmbFontSize.addItem("9");
		this.jcmbFontSize.addItem("10");
		this.jcmbFontSize.addItem("11");
		this.jcmbFontSize.addItem("12");
		this.jcmbFontSize.addItem("14");
		this.jcmbFontSize.addItem("18");
		this.jcmbFontSize.addItem("25");
		this.jcmbFontSize.addItem("36");
		this.jcmbFontSize.addItem("48");

		for (int i = 0; i < this.jcmbFontName.getItemCount(); i++) {
			if (font.getFamily().equals(this.jcmbFontName.getItemAt(i))) {
				this.jcmbFontName.setSelectedIndex(i);
				break;
			}
		}

		int st = font.getStyle();

		for (int i = 0; i < this.style.length; i++) {
			if (st == style[i]) {
				this.jcmbFontStyle.setSelectedIndex(i);
			}
		}

		int sz = font.getSize();

		for (int i = 0; i < this.jcmbFontSize.getItemCount(); i++) {
			if (sz == Integer.parseInt((String) this.jcmbFontSize.getItemAt(i))) {
				this.jcmbFontSize.setSelectedIndex(i);
				break;
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (!"OK".equalsIgnoreCase(e.getActionCommand())) {
			this.font = null;
		}

		this.setVisible(false);
	}

	public Font getFont() {
		return this.font;
	}
}
