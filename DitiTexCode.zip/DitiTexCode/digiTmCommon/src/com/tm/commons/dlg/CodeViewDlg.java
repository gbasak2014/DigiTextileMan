package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.Writer;

import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JToolBar;

import com.tm.commons.dto.PrintOption;
import com.tm.commons.win.DigiTmWin;

public class CodeViewDlg extends DigiTmWin implements ActionListener {

	private static final long serialVersionUID = 2307990589398965420L;
	JEditorPane jep;

	JButton jbPrint = new JButton("Print");
	JButton jbSave = new JButton("Save");
	PrintOption printOption;

	@Override
	public void saveProperties() {
	}

	public CodeViewDlg(String path, PrintOption printOption) {
		super();

		this.printOption = printOption;

		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setTitle("View Code");
		setBounds(100, 100, 600, 500);
		getContentPane().setLayout(new BorderLayout());
		this.jep = new JEditorPane();

		JToolBar toolbar = new JToolBar();
		jbPrint.setToolTipText("Print code");
		jbSave.setToolTipText("Save to code to file");

		jbPrint.setActionCommand("PRINT");
		jbSave.setActionCommand("SAVE");

		toolbar.add(jbPrint);
		toolbar.add(jbSave);

		this.add(new JScrollPane(this.jep), BorderLayout.CENTER);
		this.add(toolbar, BorderLayout.NORTH);

		this.jbPrint.addActionListener(this);
		this.jbSave.addActionListener(this);

		try {
			this.jep.read(new FileInputStream(path), null);
		} catch (Exception e) {
			e.printStackTrace();
		}

		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		try {
			if ("PRINT".equals(e.getActionCommand())) {
				this.printCode();
			} else {
				this.saveCode();
			}

		} catch (Exception ee) {
			ee.printStackTrace();
		}
	}

	public void printCode() throws Exception {
		this.jep.print();
	}

	public void saveCode() throws Exception {
		JFileChooser dlg = new JFileChooser();
		int status = dlg.showSaveDialog(this);
		if (status == JFileChooser.APPROVE_OPTION) {
			File file = dlg.getSelectedFile();
			Writer writer = new FileWriter(file);
			this.jep.write(writer);
			writer.close();
		}
	}
}
