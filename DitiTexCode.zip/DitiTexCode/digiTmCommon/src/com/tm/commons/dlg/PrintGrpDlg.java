package com.tm.commons.dlg;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.awt.print.Book;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;

import com.tm.commons.action.FileMenuActionEnum;
import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.dto.GridOptions;
import com.tm.commons.theme.DigiTmTheme;
import com.tm.commons.win.DigiTmWin;

public class PrintGrpDlg extends DigiTmWin {

	private static final long serialVersionUID = -3783341660431665064L;
	JPanel jpmain = new Pan();
	ButtonMenuItem btnPrint;
	ButtonMenuItem btnSetting;
	ButtonMenuItem btnClose;
	ButtonMenuItem btnNext;
	ButtonMenuItem btnPrevious;
	PrinterJob pj;
	PageFormat pf;
	BufferedImage img = null;
	BufferedImage simg = null;
	int xsft, ysft, x, y, rmax, cmax, pw, ph, dw, dh, left, top, pagew, pageh;
	JScrollBar jsh = new JScrollBar();
	JScrollBar jsv = new JScrollBar();
	JLabel jltxt = new JLabel();
	JComboBox<String> jcpage = new JComboBox<String>();
	Color c1, c2, c3;
	int cwh;
	int fw, fh;
	Font font = new Font("arial", Font.PLAIN, 10);
	int pointWidth;

	@Override
	public void saveProperties() {
		// TODO Auto-generated method stub

	}

	public PrintGrpDlg(BufferedImage bi, GridOptions gridOption) {
		super();
		this.pj = PrinterJob.getPrinterJob();

		try {
			img = bi;
			left = top = 0;
			this.cwh = gridOption.getZoom();
			this.c1 = gridOption.getColorUnit();
			this.c2 = gridOption.getColorPoint();
			this.c3 = gridOption.getColorPoint1();
			this.pointWidth = gridOption.getPoint();

			jbInit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void jbInit() throws Exception {
		pf = pj.defaultPage();
		refresh();
		ActionListener listener = new PrintHandler();
		this.getContentPane().setLayout(new BorderLayout());
		this.setSize(new Dimension(600, 700));
		this.setPreferredSize(new Dimension(600, 700));
		
		jsh.setOrientation(JScrollBar.HORIZONTAL);
		jltxt.setForeground(Color.black);
		jltxt.setPreferredSize(new Dimension(120, 20));
		jltxt.setMaximumSize(new Dimension(120, 20));
		jltxt.setMinimumSize(new Dimension(120, 20));
		jltxt.setFont(new Font("Dialog", 1, 12));
		jcpage.setPreferredSize(new Dimension(100, 20));
		jcpage.setMaximumSize(new Dimension(100, 20));
		jcpage.setBackground(new Color(245, 255, 255));
		jcpage.setMinimumSize(new Dimension(100, 20));
		jcpage.setActionCommand(String.valueOf(FileMenuActionEnum.SELECT_PAGE.value));
		jcpage.addActionListener(listener);

		btnPrint = new ButtonMenuItem(FileMenuActionEnum.PRINT_GRAPH.value, listener, "/img/print.jpg", "Print");
		btnSetting = new ButtonMenuItem(FileMenuActionEnum.PRINT_SETTING.value, listener, "/img/print_sett.jpg",
				"Print Setting");
		btnClose = new ButtonMenuItem(FileMenuActionEnum.CLOSE.value, listener, "/img/close.jpg", "Close");
		btnNext = new ButtonMenuItem(FileMenuActionEnum.NEXT.value, listener, "/img/next.jpg", "Next Page");
		btnPrevious = new ButtonMenuItem(FileMenuActionEnum.PREVIOUS.value, listener, "/img/prev.jpg", "Previous Page");

		JPanel toolPan = new JPanel(new FlowLayout(FlowLayout.CENTER, 2, 2));
		toolPan.setBackground(DigiTmTheme.getBgColor());
		toolPan.setBorder(DigiTmTheme.getLineBorder());

		toolPan.add(jltxt, null);
		toolPan.add(btnPrevious, null);
		toolPan.add(jcpage, null);
		toolPan.add(btnNext, null);
		toolPan.add(btnPrint);
		toolPan.add(btnSetting, null);
		toolPan.add(btnClose, null);
		this.getContentPane().add(jsh, BorderLayout.SOUTH);
		this.getContentPane().add(jsv, BorderLayout.EAST);
		this.getContentPane().add(toolPan, BorderLayout.NORTH);
		this.getContentPane().add(jpmain, BorderLayout.CENTER);
		jsh.addAdjustmentListener(new AdjustmentListener() {
			public void adjustmentValueChanged(AdjustmentEvent e) {
				left = jsh.getValue();
				jpmain.repaint();
			}
		});

		jsv.addAdjustmentListener(new java.awt.event.AdjustmentListener() {

			public void adjustmentValueChanged(AdjustmentEvent e) {
				top = jsv.getValue();
				jpmain.repaint();
			}
		});

	}

	public void subImg(int idx) {
		int gw, gh, r, c;
		gw = img.getWidth();
		gh = img.getHeight();
		r = idx % rmax;
		c = idx / rmax;
		dw = pw;
		dh = ph;

		if (c * pw + pw > gw)
			dw = gw - c * pw;
		if (r * ph + ph > gh)
			dh = gh - r * ph;
		jsh.setMaximum(pagew * cwh);
		jsh.setMinimum(0);
		jsh.setValue(0);
		jsv.setMaximum(pageh * cwh);
		jsv.setMinimum(0);
		jsv.setValue(0);
		simg = new BufferedImage(dw * cwh, dh * cwh, BufferedImage.TYPE_INT_RGB);
		Graphics2D g2 = (Graphics2D) simg.getGraphics();
		g2.setStroke(new BasicStroke((float) 0.05, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER));
		g2.drawImage(img.getSubimage(c * pw, r * ph, dw, dh), 0, 0, dw * cwh, dh * cwh, this);
		makeGrid(g2, c * pw, r * ph);
		g2.dispose();
	}

	void makeGrid(Graphics2D g, int c, int r) {
		int i;
		int pointWidth1 = pointWidth * 2;

		for (i = 0; i <= dw; i++) {
			if (c % pointWidth1 == 0)
				g.setColor(c3);
			else if (c % pointWidth == 0)
				g.setColor(c2);
			else
				g.setColor(c1);

			g.drawLine(i * cwh, 0, i * cwh, dh * cwh);
			c++;
		}

		for (i = 0; i <= dh; i++) {
			if (r % pointWidth1 == 0)
				g.setColor(c3);
			else if (r % pointWidth == 0)
				g.setColor(c2);
			else
				g.setColor(c1);

			g.drawLine(0, i * cwh, dw * cwh, i * cwh);
			r++;
		}
	}

	class Pan extends JPanel {

		private static final long serialVersionUID = 7330460557671004008L;

		public void paint(Graphics g) {
			g.setColor(DigiTmTheme.getBgColor());
			g.fillRect(0, 0, getWidth(), getHeight());
			g.setColor(Color.WHITE);
			g.fillRect(-left + 10, -top + 10, pagew * cwh, pageh * cwh);
			g.setColor(Color.black);
			g.drawRect(-left + 10, -top + 10, pagew * cwh, pageh * cwh);
			g.setColor(Color.lightGray);
			g.drawRect(-left + x * cwh + 10, -top + y * cwh + 10, pw * cwh + 2, ph * cwh + 2);
			g.drawImage(simg, -left + x * cwh + 11, -top + y * cwh + 11, dw * cwh, dh * cwh, this);
			if (jcpage.getSelectedIndex() % rmax == 0)
				printThreadNo(g, (jcpage.getSelectedIndex() / rmax) * pw, dw, -left + 11, -top + 11);
			if (jcpage.getSelectedIndex() / rmax == 0)
				printBoardNo(g, (jcpage.getSelectedIndex() % rmax) * ph, dh, -left + 11, -top + 11);
		}
	}

	void printGraph() {
		Book bk = new Book();
		PaintContent pc = new PaintContent(img, rmax, cmax, pw, ph);
		bk.append(pc, pf, rmax * cmax);
		pj.setPageable(bk);
		pj.setJobName("Print Graph");
		try {
			pj.print();
		} catch (Exception ee) {
		}
	}

	void showPrintSetting() {
		pf = pj.pageDialog(pf);
		refresh();
		jpmain.repaint();
	}

	void refresh() {
		Graphics2D g2d = img.createGraphics();
		g2d.setFont(font);
		Rectangle2D bound = font.getStringBounds("9999", g2d.getFontRenderContext());
		g2d.dispose();
		fw = (int) bound.getWidth(); // fm.stringWidth("9999");
		fh = (int) bound.getHeight(); // fm.getHeight() + 3;

		pf = pj.validatePage(pf);
		pagew = (int) pf.getWidth() / cwh;
		pageh = (int) pf.getHeight() / cwh;
		x = (int) (pf.getImageableX() + 1 + fw) / cwh;
		y = (int) (pf.getImageableY() + 1 + fh) / cwh;
		pw = (int) (pf.getImageableWidth() - 2 - fw) / cwh;
		ph = (int) (pf.getImageableHeight() - 2 - fh) / cwh;

		rmax = img.getHeight() / ph;
		if (img.getHeight() % ph != 0)
			rmax = rmax + 1;
		cmax = img.getWidth() / pw;
		if (img.getWidth() % pw != 0)
			cmax = cmax + 1;

		jcpage.removeAllItems();
		for (int i = 1; i <= cmax; i++)
			for (int j = 1; j <= rmax; j++)
				jcpage.addItem(j + " X " + i);
		jltxt.setText("Total Page: " + rmax + "X" + cmax);
		jcpage.setSelectedIndex(0);
		subImg(jcpage.getSelectedIndex());
	}

	public void printThreadNo(Graphics g, int start, int pwidth, int l, int t) {
		int sno;
		int sw = 10;
		if (this.pointWidth > 3) {
			sw = this.pointWidth;
		}

		sno = start % sw == 0 ? start + sw : (start / sw + 1) * sw;
		int i = start % sw == 0 ? sw : sw - (start % sw);
		for (; i <= pwidth; i += sw) {
			g.drawString(String.valueOf(sno), (x + i) * cwh - fw, y * cwh - 1 + t);
			sno += sw;
		}
	}

	public void printBoardNo(Graphics g, int start, int pheight, int l, int t) {
		int sno;
		int sw = 10;
		if (this.pointWidth > 3) {
			sw = this.pointWidth;
		}

		sno = start % sw == 0 ? start + sw : (start / sw + 1) * sw;
		int i = start % sw == 0 ? sw : sw - (start % sw);
		for (; i <= pheight; i += sw) {
			g.drawString(String.valueOf(sno), x * cwh - fw, (y + i) * cwh + t);
			sno += sw;
		}
	}

	// //////////////PaintContent//////////////////////////
	class PaintContent implements Printable {
		BufferedImage img;
		PageFormat pf;
		int row, col, pw, ph;

		public PaintContent(BufferedImage i, int row, int col, int pw, int ph) {
			img = i;
			this.row = row;
			this.col = col;
			this.pw = pw;
			this.ph = ph;
		}

		public int print(Graphics g, PageFormat pf, int pi) throws PrinterException {
			this.pf = pf;
			BufferedImage bi = getSubImg(pi);
			g.drawImage(bi, x * cwh, y * cwh, PrintGrpDlg.this);
			if (pi % rmax == 0)
				printThreadNo(g, (pi / rmax) * pw, bi.getWidth() / cwh, 0, 0);
			if (jcpage.getSelectedIndex() / rmax == 0)
				printBoardNo(g, (pi % rmax) * ph, bi.getHeight() / cwh, 0, 0);
			g.dispose();

			System.out.println(x + "," + y + "-" + cwh);
			return Printable.PAGE_EXISTS;
		}

		void printSub(BufferedImage bi, Graphics g) {
			Graphics2D g2 = (Graphics2D) g;
			g2.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
			g2.drawImage(bi, x * cwh, y * cwh, PrintGrpDlg.this);

			g2.dispose();
		}

		BufferedImage getSubImg(int idx) {
			int gw, gh, r, c;
			gw = img.getWidth();
			gh = img.getHeight();
			r = idx % rmax;
			c = idx / rmax;
			dw = pw;
			dh = ph;

			if (c * pw + pw > gw)
				dw = gw - c * pw;
			if (r * ph + ph > gh)
				dh = gh - r * ph;

			BufferedImage bi = new BufferedImage(dw * cwh, dh * cwh, BufferedImage.TYPE_INT_RGB);
			Graphics2D g2 = (Graphics2D) bi.getGraphics();
			g2.setStroke(new BasicStroke((float) 0.05, BasicStroke.CAP_SQUARE, BasicStroke.JOIN_MITER));
			g2.drawImage(img.getSubimage(c * pw, r * ph, dw, dh), 0, 0, dw * cwh, dh * cwh, PrintGrpDlg.this);
			makeGrid(g2, c * pw, r * ph);
			g2.dispose();
			return bi;
		}
	}

	// //////////////PaintContent//////////////////////////

	void showSelectedPage() {
		if (jcpage.getSelectedIndex() >= 0) {
			subImg(jcpage.getSelectedIndex());
		}

		jpmain.repaint();
	}

	void closeThis() {
		this.setVisible(false);
		this.dispose();
	}

	void movePage(int page) {
		int idx = jcpage.getSelectedIndex() + page;
		if (idx >= 0 && idx < jcpage.getItemCount()) {
			jcpage.setSelectedIndex(idx);
		}
	}

	class PrintHandler implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent e) {
			FileMenuActionEnum action = FileMenuActionEnum.fromString(e.getActionCommand());
			switch (action) {
			case PRINT_GRAPH:
				printGraph();
				break;
			case PRINT_SETTING:
				showPrintSetting();
				break;
			case SELECT_PAGE:
				showSelectedPage();
				break;
			case CLOSE:
				closeThis();
				break;
			case NEXT:
				movePage(1);
				break;
			case PREVIOUS:
				movePage(-1);
				break;
			default:
				break;
			}
		}
	}
}