package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import com.tm.commons.components.pane.PathOptionPane;
import com.tm.commons.dto.LibOptions;

public class DesignOptionsDlg extends DigiTmDlg implements ActionListener {
	private static final long serialVersionUID = -3905804023222831766L;
	PathOptionPane pathOptionPane;

	private JTabbedPane contentPanel = new JTabbedPane();
	boolean ok;

	public static void main(String[] args) {
		DesignOptionsDlg dlg = new DesignOptionsDlg(new LibOptions());
		dlg.setVisible(true);
	}

	/**
	 * Create the dialog.
	 */
	public DesignOptionsDlg(LibOptions libOptions) {
		super();
		this.setModal(true);
		this.pathOptionPane = new PathOptionPane(libOptions, true);

		setBounds(100, 100, 600, 500);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(contentPanel, BorderLayout.CENTER);

		contentPanel.add("Path Options", this.pathOptionPane);

		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
		getContentPane().add(buttonPane, BorderLayout.SOUTH);

		JButton okButton = new JButton("OK");
		okButton.setActionCommand("OK");
		buttonPane.add(okButton);
		getRootPane().setDefaultButton(okButton);

		JButton cancelButton = new JButton("Cancel");
		cancelButton.setActionCommand("Cancel");
		buttonPane.add(cancelButton);

		okButton.addActionListener(this);
		cancelButton.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if ("OK".equals(e.getActionCommand())) {
			this.pathOptionPane.saveLibPaths();
			ok = true;
		} else {
			ok = false;
		}

		this.setVisible(false);
	}

	public boolean isOk() {
		return this.ok;
	}

	public LibOptions getLibraryHome() {
		return this.pathOptionPane.getLibOptions();
	}

}
