package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

import com.tm.commons.action.EditMenuActionEnum;
import com.tm.commons.components.button.ButtonMenuItem;

public class SlidingDlg extends DigiTmDlg {
	private static final long serialVersionUID = 6866130540442931680L;

	public SlidingDlg(JFrame parent, ActionListener handler) {
		super(parent, false);
		
		this.getContentPane().setLayout(new BorderLayout());
		ButtonMenuItem btn = new ButtonMenuItem(EditMenuActionEnum.SLID_UP.value, handler, "/img/up.jpg", "Slid Up");
		btn.setPreferredSize(new Dimension(50, 50));
		this.getContentPane().add(btn, BorderLayout.NORTH);
		
		btn = new ButtonMenuItem(EditMenuActionEnum.SLID_DOWN.value, handler, "/img/down.jpg", "Slid Down");
		btn.setPreferredSize(new Dimension(50, 50));
		this.getContentPane().add(btn, BorderLayout.SOUTH);
		
		btn = new ButtonMenuItem(EditMenuActionEnum.SLID_LEFT.value, handler, "/img/left.jpg", "Slid Left");
		btn.setPreferredSize(new Dimension(50, 50));
		this.getContentPane().add(btn, BorderLayout.WEST);
		
		btn = new ButtonMenuItem(EditMenuActionEnum.SLID_RIGHT.value, handler, "/img/right.jpg", "Slid Right");
		btn.setPreferredSize(new Dimension(50, 50));
		this.getContentPane().add(btn, BorderLayout.EAST);

		btn = new ButtonMenuItem(EditMenuActionEnum.SLID_CLOSE.value, null, null, "Close");
		btn.setPreferredSize(new Dimension(50, 50));
		this.getContentPane().add(btn, BorderLayout.CENTER);
		btn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				closeMe();
			}
		});
		
		this.setPreferredSize(new Dimension(200, 200));
		this.setSize(200, 200);
		this.setLocation(200, 200);
	}
	
	void closeMe()
	{
		this.setVisible(false);
	}
}
