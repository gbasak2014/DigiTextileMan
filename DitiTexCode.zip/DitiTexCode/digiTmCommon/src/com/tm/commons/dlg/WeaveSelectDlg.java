package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.components.pane.WeavePreviewPane;
import com.tm.commons.theme.DigiTmTheme;

public class WeaveSelectDlg extends DigiTmDlg implements ActionListener, ItemListener {
	private static final long serialVersionUID = -5857474665228341462L;
	static final int ZOOM_IN = 1;
	static final int ZOOM_OUT = 2;
	static final int OK = 3;
	static final int CANCEL = 4;

	WeavePreviewPane previewPane;
	JComboBox<String> comboBoxLib;
	JComboBox<String> comboBoxWeave;
	String weaveHome;

	JLabel lblSize;

	public WeaveSelectDlg(String weaveHome) {
		super();
		setModal(true);
		this.weaveHome = weaveHome;
		Container container = this.getContentPane();
		container.setLayout(new BorderLayout());

		this.previewPane = new WeavePreviewPane();
		this.comboBoxLib = new JComboBox<String>(new DefaultComboBoxModel<String>());
		this.comboBoxWeave = new JComboBox<String>(new DefaultComboBoxModel<String>());
		this.lblSize = new JLabel();
		this.lblSize.setPreferredSize(new Dimension(100, 20));

		decorateUI(container);
		initLibrary();

		this.setSize(new Dimension(700, 600));
		this.setLocation(100, 100);
		this.setResizable(false);
		this.setModal(true);
	}

	void decorateUI(Container container) {
		JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 1, 1));
		panel.setBackground(DigiTmTheme.getBgColor());
		panel.setBorder(DigiTmTheme.getLineBorder());

		this.comboBoxLib.setPreferredSize(new Dimension(150, 20));
		this.comboBoxWeave.setPreferredSize(new Dimension(250, 20));

		panel.add(new JLabel("Select Library"));
		panel.add(this.comboBoxLib);
		panel.add(new JLabel("Select Weave"));
		panel.add(this.comboBoxWeave);
		panel.add(new JLabel("    "));

		panel.add(new ButtonMenuItem(ZOOM_IN, this, "/img/z2.jpg", "Zoom In"));
		panel.add(new ButtonMenuItem(ZOOM_OUT, this, "/img/z1.jpg", "Zoom Out"));

		container.add(panel, BorderLayout.NORTH);
		container.add(this.previewPane, BorderLayout.CENTER);
		this.previewPane.setBorder(BorderFactory.createLoweredSoftBevelBorder());

		JPanel pnlSouth = new JPanel(new FlowLayout(FlowLayout.CENTER, 5, 1));
		pnlSouth.setBackground(DigiTmTheme.getBgColor());
		pnlSouth.setBorder(DigiTmTheme.getLineBorder());

		pnlSouth.add(this.lblSize);
		this.lblSize.setBorder(DigiTmTheme.getLineBorder());

		pnlSouth.add(new JLabel("          "));

		JButton btn = new JButton("OK");
		btn.setActionCommand(String.valueOf(OK));
		btn.addActionListener(this);
		btn.setPreferredSize(new Dimension(50, 20));
		btn.setBackground(DigiTmTheme.getBgColor());
		btn.setBorder(DigiTmTheme.getLineBorder());
		pnlSouth.add(btn);

		btn = new JButton("Cancel");
		btn.setActionCommand(String.valueOf(CANCEL));
		btn.addActionListener(this);
		btn.setBackground(DigiTmTheme.getBgColor());
		btn.setBorder(DigiTmTheme.getLineBorder());
		btn.setPreferredSize(new Dimension(50, 20));
		pnlSouth.add(btn);

		container.add(pnlSouth, BorderLayout.SOUTH);

		this.comboBoxLib.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent ie) {
				if (ie.getStateChange() == ItemEvent.SELECTED) {
					refreshWeaveList();
				}

			}
		});
	}

	void initLibrary() {

		this.comboBoxLib.addItem("Select Library");
		try {
			File root = new File(this.weaveHome);
			for (File lib : root.listFiles()) {
				if (lib.isDirectory()) {
					this.comboBoxLib.addItem(lib.getName());
				}
			}
		} catch (Exception e) {
		}
		this.comboBoxLib.setSelectedIndex(0);
	}

	void refreshWeaveList() {
		this.comboBoxWeave.removeItemListener(this);
		this.comboBoxWeave.removeAllItems();
		this.comboBoxWeave.addItem("Select Weave");

		if (this.comboBoxLib.getSelectedIndex() > 0) {
			try {
				File lib = new File(this.weaveHome + "/" + this.comboBoxLib.getSelectedItem());
				for (String weave : lib.list()) {
					this.comboBoxWeave.addItem(weave);
				}
			} catch (Exception e) {
			}
		}
		this.comboBoxWeave.setSelectedIndex(0);
		this.comboBoxWeave.addItemListener(this);
	}

	void previewLib() {
		if (this.comboBoxWeave.getSelectedIndex() > 0) {
			String path = this.weaveHome + "/" + this.comboBoxLib.getSelectedItem() + "/"
					+ this.comboBoxWeave.getSelectedItem();
			try {
				BufferedImage img = ImageIO.read(new File(path));
				this.previewPane.setImgWeave(img);
				this.lblSize.setText("Size: " + img.getWidth() + "X" + img.getHeight());
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			this.previewPane.setImgWeave(null);
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		int action = Integer.parseInt(e.getActionCommand());
		switch (action) {
		case ZOOM_IN:
			this.previewPane.setZoom(1);
			break;
		case ZOOM_OUT:
			this.previewPane.setZoom(-1);
			break;
		case CANCEL:
			this.previewPane.setImgWeave(null);
		case OK:
			this.setVisible(false);
			break;
		default:
			break;
		}
	}

	@Override
	public void itemStateChanged(ItemEvent ie) {
		if (ie.getStateChange() == ItemEvent.SELECTED) {
			previewLib();
		}
	}

	public BufferedImage getWeavePattern() {
		return this.previewPane.getImgWeave();
	}

	public static void main(String[] args) {
		WeaveSelectDlg dlg = new WeaveSelectDlg("E:/TM01/pattern");
		dlg.setModal(true);
		dlg.setVisible(true);
	}
}
