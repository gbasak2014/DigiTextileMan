package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Rectangle;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;

public class AreaDlg extends DigiTmDlg implements ActionListener {

	private static final long serialVersionUID = 3090401742505902825L;
	private final JPanel contentPanel = new JPanel();
	private JTextField txtLeft;
	private JTextField txtTop;
	private JTextField txtWidth;
	private JTextField txtHeight;

	boolean ok;
	Rectangle area;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			AreaDlg dialog = new AreaDlg();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public AreaDlg() {
		setModal(true);
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		JLabel lblNewLabel = new JLabel("Left:");
		lblNewLabel.setFont(new Font("Arial Unicode MS", Font.BOLD, 12));
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setBounds(42, 77, 60, 20);
		contentPanel.add(lblNewLabel);

		txtLeft = new JTextField();
		txtLeft.setBounds(112, 78, 86, 20);
		contentPanel.add(txtLeft);
		txtLeft.setColumns(10);

		JLabel lblTop = new JLabel("Top:");
		lblTop.setHorizontalAlignment(SwingConstants.RIGHT);
		lblTop.setFont(new Font("Arial Unicode MS", Font.BOLD, 12));
		lblTop.setBounds(211, 77, 60, 20);
		contentPanel.add(lblTop);

		txtTop = new JTextField();
		txtTop.setColumns(10);
		txtTop.setBounds(281, 78, 86, 20);
		contentPanel.add(txtTop);

		JLabel lblWidth = new JLabel("Width:");
		lblWidth.setHorizontalAlignment(SwingConstants.RIGHT);
		lblWidth.setFont(new Font("Arial Unicode MS", Font.BOLD, 12));
		lblWidth.setBounds(42, 108, 60, 20);
		contentPanel.add(lblWidth);

		txtWidth = new JTextField();
		txtWidth.setColumns(10);
		txtWidth.setBounds(112, 109, 86, 20);
		contentPanel.add(txtWidth);

		JLabel lblHeight = new JLabel("Height:");
		lblHeight.setHorizontalAlignment(SwingConstants.RIGHT);
		lblHeight.setFont(new Font("Arial Unicode MS", Font.BOLD, 12));
		lblHeight.setBounds(211, 108, 60, 20);
		contentPanel.add(lblHeight);

		txtHeight = new JTextField();
		txtHeight.setColumns(10);
		txtHeight.setBounds(281, 109, 86, 20);
		contentPanel.add(txtHeight);

		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
		getContentPane().add(buttonPane, BorderLayout.SOUTH);

		JButton okButton = new JButton("OK");
		okButton.setActionCommand("OK");
		buttonPane.add(okButton);
		getRootPane().setDefaultButton(okButton);

		JButton cancelButton = new JButton("Cancel");
		cancelButton.setActionCommand("Cancel");
		buttonPane.add(cancelButton);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if ("OK".equals(e.getActionCommand())) {
			try {
				int left = Integer.parseInt(txtLeft.getText());
				int top = Integer.parseInt(txtTop.getText());
				int width = Integer.parseInt(txtWidth.getText());
				int height = Integer.parseInt(txtHeight.getText());

				area = new Rectangle(left, top, width, height);
				ok = true;
				setVisible(false);
				return;
			} catch (Exception exp) {

			}
		}

		ok = false;
		setVisible(false);
	}

	public Rectangle getArea() {
		return this.area;
	}
	
	public boolean isOk()
	{
		return this.ok;
	}
}
