package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileFilter;
import java.util.Enumeration;
import java.util.regex.Pattern;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

import com.tm.commons.action.DigiTmEnum;
import com.tm.commons.components.pane.MovableImagePane;
import com.tm.commons.image.ImageUtils;
import com.tm.commons.theme.DigiTmTheme;

public class ImageOpenDlgTree extends DigiTmDlg implements ActionListener {
	private static final long serialVersionUID = 6276648792305771983L;

	DefaultListModel<String> listFile = new DefaultListModel<String>();

	JTree tree;
	DefaultTreeModel model;
	DefaultMutableTreeNode root = new DefaultMutableTreeNode("My Computer", true);

	JList<String> jlFile = new JList<String>(listFile);

	boolean okPresses = false;

	MovableImagePane imgPane = new MovableImagePane();

	File selectedFile;
	String selectedPath;

	String EXT = ".bmp";
	String EXTRA_EXT;
	JLabel jlPath = new JLabel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			ImageOpenDlgTree dialog = new ImageOpenDlgTree(null, "F:/");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	void setThemeColor() {
		this.getContentPane().setBackground(DigiTmTheme.getBgColor());
		this.jlFile.setBackground(DigiTmTheme.getBgColor());
		this.tree.setBackground(DigiTmTheme.getBgColor());
	}

	public ImageOpenDlgTree(JFrame parent, String lastPath, String extraExt)
	{
		super(parent);
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		}

		UIManager.put("Tree.rendererFillBackground", false);
		this.EXTRA_EXT = extraExt != null ? extraExt.toLowerCase() : null;
		this.model = new DefaultTreeModel(this.root);
		// this.model.setAsksAllowsChildren(true);
		this.tree = new JTree(this.model);
		DefaultTreeCellRenderer renderer = (DefaultTreeCellRenderer) this.tree.getCellRenderer();
		renderer.setLeafIcon(renderer.getClosedIcon());

		setBounds(100, 100, 900, 600);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(imgPane, BorderLayout.CENTER);

		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));

		JButton btnOk = new JButton("OK");
		btnOk.setBackground(DigiTmTheme.getBgColor());
		btnOk.setActionCommand(String.valueOf(DigiTmEnum.OK.value));

		getRootPane().setDefaultButton(btnOk);

		JButton btnCancel = new JButton("Cancel");
		btnCancel.setBackground(DigiTmTheme.getBgColor());
		btnCancel.setActionCommand(String.valueOf(DigiTmEnum.CANCEL.value));

		this.jlPath.setBorder(BorderFactory.createLoweredBevelBorder());
		this.jlPath.setPreferredSize(new Dimension(710, 25));
		buttonPane.add(this.jlPath);
		buttonPane.add(btnOk);
		buttonPane.add(btnCancel);

		JPanel fsPane = new JPanel(new BorderLayout());

		JPanel dirFilePane = new JPanel(new GridLayout(2, 1, 1, 1));

		jlFile.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		dirFilePane.add(new JScrollPane(this.tree));
		dirFilePane.add(new JScrollPane(jlFile));

		fsPane.add(dirFilePane, BorderLayout.CENTER);
		getContentPane().add(buttonPane, BorderLayout.SOUTH);
		getContentPane().add(fsPane, BorderLayout.WEST);

		dirFilePane.setBackground(DigiTmTheme.getBgColor());
		buttonPane.setBackground(DigiTmTheme.getBgColor());
		fsPane.setBackground(DigiTmTheme.getBgColor());

		btnCancel.addActionListener(this);
		btnOk.addActionListener(this);

		jlFile.addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent e) {
				previewImage(ImageOpenDlgTree.this.jlFile.getSelectedValue());
			}
		});

		initRootDirs(lastPath);

		this.setThemeColor();

		this.tree.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				super.mouseClicked(e);
				if (e.getClickCount() > 1) {
					treeClicked();
				}
			}
		});
	}
	
	/**
	 * Create the dialog.
	 */
	public ImageOpenDlgTree(JFrame parent, String lastPath) {
		this(parent, lastPath, null);
	}

	void previewImage(String fileName) {
		if (this.selectedPath != null) {
			this.selectedFile = new File(this.selectedPath + "/" + File.separator + fileName);
			String aPath = this.selectedFile.getAbsolutePath();
			try {
				BufferedImage img = ImageUtils.getImageFromFile(aPath);
				imgPane.setImage(img);
				this.jlPath.setText(aPath);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public File getSelectedFile() {
		return selectedFile;
	}

	void initRootDirs(String selPath) {
		File[] roots = File.listRoots();
		for (File file : roots) {
			String dir;
			if (file.getAbsolutePath().startsWith("/")) {
				dir = file.getAbsolutePath();
			} else {
				dir = file.getAbsolutePath().substring(0, 2);
			}

			DefaultMutableTreeNode d = new DefaultMutableTreeNode(dir, true);
			d.setAllowsChildren(true);
			root.add(d);
		}

		Enumeration<DefaultMutableTreeNode> e = root.children();
		if (selPath != null) {
			File file = new File(selPath);
			String[] dirs = file.getAbsolutePath().split(Pattern.quote(File.separator));
			String path = null;
			for (String s : dirs) {
				if (path == null) {
					path = s;
				} else {
					path = path + "/" + s;
				}

				DefaultMutableTreeNode node = null;
				File dir = null;
				while (e.hasMoreElements()) {
					node = e.nextElement();
					//System.out.println("X:" + node);
					if (node.toString().equals(s)) {
						//System.out.println("PATH:" + path);
						dir = new File(path + "/");
						for (File child : dir.listFiles()) {
							if (child.isDirectory()) {
								node.add(new DefaultMutableTreeNode(child.getName(), true));
							}
						}
						e = node.children();
						break;
					}
				}

				if (node != null && dir != null) {
					this.model.reload(node);
					this.tree.expandPath(new TreePath(node.getPath()));
					this.listFile.clear();
					for (File f : dir.listFiles()) {
						if (f.isFile() && f.getName().toUpperCase().endsWith(EXT)) {
							this.listFile.addElement(f.getName());
						}
					}
					this.selectedPath = dir.getAbsolutePath();
				}
			}
		}
	}

	void initFileList(String path) {
		File dir = new File(path);
		if (dir.isDirectory()) {
			File[] files = dir.listFiles(new ImageFilter(EXT, ".jpg"));

			listFile.clear();
			for (File file : files) {
				listFile.addElement(file.getName());
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		DigiTmEnum action = DigiTmEnum.fromString(e.getActionCommand());

		switch (action) {
		case OK:
			if (this.selectedFile == null) {
				JOptionPane.showMessageDialog(this, "Please select file!");
				break;
			}

			okPresses = true;
			this.setVisible(false);
			break;
		case CANCEL:
			this.setVisible(false);
			break;
		case SELECT:
			// String drive = (String) jcDrive.getSelectedItem();
			// jlPath.setText(drive);
			// initDirAndFileList(drive + "/");
			break;
		default:
			break;
		}
	}

	public BufferedImage getSelectedImage() {
		if (selectedFile != null && imgPane.getImage() == null) {
			try {
				return ImageUtils.getImageFromFile(selectedFile.getAbsolutePath());
			} catch (Exception e) {
			}
		}

		return imgPane.getImage();
	}

	public boolean isOk() {
		return okPresses;
	}

	void treeClicked() {
		TreePath path = this.tree.getSelectionPath();
		if (path != null) {
			int cnt = path.getPathCount();
			String strPath = null;
			DefaultMutableTreeNode node = null;
			for (int i = 1; i < cnt; i++) {
				node = (DefaultMutableTreeNode) path.getPathComponent(i);
				if (strPath == null) {
					strPath = node.toString();
				} else {
					strPath = strPath + "/" + node.toString();
				}
			}

			if (node != null && !strPath.equals(this.selectedPath)) {
				this.selectedPath = strPath;
				boolean addChile = node.isLeaf();
				//System.out.println("Path: " + strPath);
				this.listFile.clear();
				File dir = new File(strPath + "/");
				for (File child : dir.listFiles()) {
					//System.out.println(child.getAbsolutePath());
					if (child.isFile()) {
						if (ImageFilter.isValidExt(child.getName().toLowerCase(), EXT, EXTRA_EXT)) {
							this.listFile.addElement(child.getName());
						}
					} else if (addChile) {
						node.add(new DefaultMutableTreeNode(child.getName(), true));
					}
				}

				this.model.reload(node);
				tree.expandPath(path);
			}

			//System.out.println("2:" + path.getLastPathComponent() + ">" + path.getPathCount());
		}

	}

	static class ImageFilter implements FileFilter {
		String ext;
		String extraExt;

		public ImageFilter(String ext, String extraExt) {
			this.ext = ext.toLowerCase();
			this.extraExt = extraExt != null ? extraExt.toLowerCase() : null;
		}

		static boolean isValidExt(String file, String ext, String extraExt) {
			if (file.endsWith(ext)) {
				return true;
			}

			if (extraExt != null && file.endsWith(extraExt)) {
				return true;
			}

			return false;
		}

		@Override
		public boolean accept(File file) {
			return isValidExt(file.getName().toLowerCase(), ext, extraExt);
		}
	}
}
