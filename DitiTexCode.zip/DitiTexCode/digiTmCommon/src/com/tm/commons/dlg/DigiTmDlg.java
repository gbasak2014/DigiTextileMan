package com.tm.commons.dlg;

import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.JDialog;
import javax.swing.JFrame;

import com.tm.commons.dto.DigiTmConstants;
import com.tm.commons.theme.DigiTmTheme;

public class DigiTmDlg extends JDialog {
	private static final long serialVersionUID = 5193962739508732413L;

	public DigiTmDlg(JFrame parent) {
		super(parent);
		setModal(true);
		this.setBackground(DigiTmTheme.getBgColor());
		setTitle(new String(DigiTmConstants.title));
		try {
			URL url = this.getClass().getResource(new String(DigiTmConstants.logo));
			this.setIconImage(ImageIO.read(url));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public DigiTmDlg() {
		super();
		this.setBackground(DigiTmTheme.getBgColor());
		setTitle(new String(DigiTmConstants.title));
		try {
			URL url = this.getClass().getResource(new String(DigiTmConstants.logo));
			this.setIconImage(ImageIO.read(url));
		} catch (Exception e) {
		}
	}
	
	public DigiTmDlg(JFrame parent, boolean modal) {
		super(parent);
		setModal(modal);
		this.setBackground(DigiTmTheme.getBgColor());
		setTitle(new String(DigiTmConstants.title));
		try {
			URL url = this.getClass().getResource(new String(DigiTmConstants.logo));
			this.setIconImage(ImageIO.read(url));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
