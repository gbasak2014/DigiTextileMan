package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSplitPane;

import com.tm.commons.clipboard.ClipboardUtil;
import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.theme.DigiTmTheme;
import com.tm.design.pane.MotifPane;

public class ImgMergeDlg extends DigiTmDlg implements ActionListener {

	final static int ADD_IMAGE = 1;
	final static int MERGE_IMAGE = 2;
	final static int HORIZ = 3;
	final static int VERT = 4;
	final static int SAVE = 5;
	final static int CLOSE = 6;

	JRadioButton jrHoriz = new JRadioButton("Horizontal");
	JRadioButton jrVert = new JRadioButton("Vertical");
	ImgPage imgPane = new ImgPage();
	ImgPage imgPaneMerged = new ImgPage();

	public ImgMergeDlg(JFrame parent) {
		super(parent, false);
		this.getContentPane().setLayout(new BorderLayout());
		JSplitPane jsp = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, this.imgPane, this.imgPaneMerged);
		this.getContentPane().add(this.getToolBar(), BorderLayout.NORTH);
		this.getContentPane().add(jsp, BorderLayout.CENTER);

	}

	private JPanel getToolBar() {
		JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 1, 1));
		panel.setBackground(DigiTmTheme.getBgColor());
		panel.setBorder(BorderFactory.createRaisedBevelBorder());

		panel.add(new ButtonMenuItem(ADD_IMAGE, this, "/img/add-motif.jpg", "Add Image to merge"));
		panel.add(new ButtonMenuItem(MERGE_IMAGE, this, "/img/merge.jpg", "Merge Image"));
		panel.add(this.jrHoriz);
		panel.add(this.jrVert);
		panel.add(new ButtonMenuItem(SAVE, this, "/img/save.jpg", "Save Merged Image"));
		panel.add(new ButtonMenuItem(CLOSE, this, "/img/close.jpg", "Close merge window"));

		this.jrHoriz.setBackground(DigiTmTheme.getBgColor());
		this.jrVert.setBackground(DigiTmTheme.getBgColor());

		ButtonGroup bg = new ButtonGroup();
		bg.add(jrHoriz);
		bg.add(jrVert);

		this.jrHoriz.setActionCommand("" + HORIZ);
		this.jrVert.setActionCommand("" + VERT);
		this.jrHoriz.addActionListener(this);
		this.jrVert.addActionListener(this);
		this.jrHoriz.setSelected(true);
		return panel;
	}

	static class ImgPage extends JPanel {
		MotifPane mp;

		public ImgPage() {
		}

		@Override
		public void paint(Graphics g) {
			g.setColor(Color.GRAY);
			g.fillRect(0, 0, this.getWidth(), this.getHeight());
			if (this.mp != null) {
				this.mp.paint(g);
			}
		}

		public void addImage(BufferedImage img) {
			if (this.mp == null) {
				this.mp = new MotifPane(img, true);
				this.mp.setHorizontalRepeate(1);
				this.mp.setVerticalRepeate(1);
			} else {
				this.mp.addMotif(img);
			}
			this.repaint();
		}

		public void setAlign(boolean isHoriz) {
			this.mp.setHorizontalAlign(isHoriz);
		}

		public MotifPane getMotifPane() {
			return this.mp;
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		int cmd = Integer.parseInt(e.getActionCommand());

		switch (cmd) {
		case ADD_IMAGE:
			addImage();
			break;
		case MERGE_IMAGE:
			mergeImage();
			break;
		case HORIZ:
			this.imgPane.mp.setHorizontalAlign(true);
			this.imgPane.mp.updateProperties(this.imgPane.getGraphics());
			this.imgPane.repaint();
			break;
		case VERT:
			this.imgPane.mp.setHorizontalAlign(false);
			this.imgPane.mp.updateProperties(this.imgPane.getGraphics());
			this.imgPane.repaint();
			break;
		}

	}

	void mergeImage() {
		if (this.imgPane.mp != null) {
			BufferedImage img1 = this.imgPane.mp.getMotifList().get(0).getImage();
			BufferedImage img2 = this.imgPane.mp.getMotifList().get(1).getImage();
			
			BufferedImage img = this.mergeHoriz(img1, img2);
			
			this.imgPaneMerged.addImage(img);
		}
	}

	BufferedImage mergeHoriz(BufferedImage img1, BufferedImage img2) {
		int w1 = img1.getWidth();
		int h1 = img1.getHeight();
		int w2 = img2.getWidth();
		int h2 = img2.getHeight();

		int w = w1 + w2;
		int h = h1;
		if (h < h2) {
			h = h2;
		}

		BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
		Graphics2D g = img.createGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, w, h);

		int x1=0;
		int x2=0;
		int x=0;
		for (x = 0; x < w; x++) {
			x1 = x/2;
			x2 = x/2;
			
			if (x1 < w1 && x2<w2)
			{
				if (x%2==0)
				{
					for (int y=0;y<h1;y++)
					{
						img.setRGB(x, y, img1.getRGB(x1, y));
					}
				}
				else
				{
					for (int y=0;y<h2;y++)
					{
						img.setRGB(x, y, img2.getRGB(x1, y));
					}
				}
			}
			else
			{
				break;
			}
		}

		if (x < w)
		{
			if (x1<w1)
			{
				for (x--; x<w;x++)
				{
					
				}
			}
		}
		
		return img;
	}

	BufferedImage mergVert(BufferedImage img1, BufferedImage img2) {
		int w1 = img1.getWidth();
		int h1 = img1.getHeight();
		int w2 = img2.getWidth();
		int h2 = img2.getHeight();

		int h = h1 + h2;
		int w = w1;
		if (w < w2) {
			w = w2;
		}

		BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
		Graphics2D g = img.createGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, w, h);

		
		return img;
	}

	void addImage() {
		if (this.imgPane.mp != null && this.imgPane.getMotifPane().getList().size() >= 2) {
			JOptionPane.showMessageDialog(null, "can not add more than two image!!");
			return;
		}

		if (ClipboardUtil.hasClipboardImage()) {
			BufferedImage image = ClipboardUtil.getImageFromClipboard();
			this.imgPane.addImage(image);
			this.imgPane.repaint();
		} else {
			JOptionPane.showMessageDialog(null, "No image to add, Please copy image first!!");
		}

	}
}
