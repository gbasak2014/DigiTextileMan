package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import com.tm.commons.theme.DigiTmTheme;

public class PrintDlg extends DigiTmDlg {

	private final JPanel contentPanel = new JPanel();
	private JTextField txtRanges;
	JLabel lblCurrentPage;
	JRadioButton rdbtnCurrentPage;
	JRadioButton rdbtnAllPages;
	JRadioButton rdbtnRanges;
	int currentPage;
	int totalPage;

	boolean ok;

	int[] pageInd;

	/**
	 * Create the dialog.
	 */
	public PrintDlg(int currentPage, int totalPage, JFrame parent) {
		super(parent);
		this.currentPage = currentPage;
		this.totalPage = totalPage;

		// setBounds(100, 100, 500, 400);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		lblCurrentPage = new JLabel("Current Page: " + this.currentPage + " of " + this.totalPage);
		lblCurrentPage.setHorizontalAlignment(SwingConstants.CENTER);
		lblCurrentPage.setFont(new Font("Times New Roman", Font.BOLD, 12));
		lblCurrentPage.setBounds(0, 11, 424, 27);
		contentPanel.add(lblCurrentPage);

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Print Options", TitledBorder.LEADING, TitledBorder.TOP, null,
				new Color(25, 25, 112)));
		panel.setBounds(10, 74, 414, 116);
		contentPanel.add(panel);
		panel.setLayout(null);

		rdbtnCurrentPage = new JRadioButton("Current Page");
		rdbtnCurrentPage.setHorizontalAlignment(SwingConstants.LEFT);
		rdbtnCurrentPage.setBounds(6, 26, 109, 23);
		panel.add(rdbtnCurrentPage);

		rdbtnAllPages = new JRadioButton("All Pages");
		rdbtnAllPages.setHorizontalAlignment(SwingConstants.LEFT);
		rdbtnAllPages.setBounds(6, 48, 80, 23);
		panel.add(rdbtnAllPages);

		rdbtnRanges = new JRadioButton("Ranges");
		rdbtnRanges.setHorizontalAlignment(SwingConstants.LEFT);
		rdbtnRanges.setBounds(6, 71, 68, 23);
		panel.add(rdbtnRanges);

		ButtonGroup bg = new ButtonGroup();
		bg.add(rdbtnCurrentPage);
		bg.add(rdbtnRanges);
		bg.add(rdbtnAllPages);

		txtRanges = new JTextField();
		txtRanges.setBounds(80, 71, 254, 20);
		panel.add(txtRanges);
		txtRanges.setColumns(10);

		JPanel buttonPane = new JPanel();
		getContentPane().add(buttonPane, BorderLayout.SOUTH);

		JButton okButton = new JButton("OK");
		okButton.setActionCommand("OK");
		buttonPane.add(okButton);
		getRootPane().setDefaultButton(okButton);

		JButton cancelButton = new JButton("Cancel");
		cancelButton.setActionCommand("Cancel");
		buttonPane.add(cancelButton);
		this.rdbtnCurrentPage.setSelected(true);

		okButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				pageInd = compilePages();
				if (pageInd != null) {
					ok = true;
					setVisible(false);
				}
			}
		});

		cancelButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				ok = false;
				setVisible(false);
			}
		});

		this.txtRanges.addFocusListener(new FocusListener() {

			@Override
			public void focusLost(FocusEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void focusGained(FocusEvent arg0) {
				setRangeFocus();
			}
		});

		this.contentPanel.setBackground(DigiTmTheme.getBgColor());
		panel.setBackground(DigiTmTheme.getBgColor());
		buttonPane.setBackground(DigiTmTheme.getBgColor());
		rdbtnAllPages.setBackground(DigiTmTheme.getBgColor());
		rdbtnCurrentPage.setBackground(DigiTmTheme.getBgColor());
		rdbtnRanges.setBackground(DigiTmTheme.getBgColor());

		this.setPreferredSize(new Dimension(500, 400));
		this.setSize(500, 400);
	}

	void setRangeFocus() {
		this.rdbtnRanges.setSelected(true);
	}

	public int[] getPageIndices() {
		return pageInd;
	}

	private int[] compilePages() {
		if (this.rdbtnCurrentPage.isSelected()) {
			return new int[] { this.currentPage };
		} else if (this.rdbtnAllPages.isSelected()) {
			int[] pageIndex = new int[this.totalPage];
			for (int i = 1; i <= this.totalPage; i++) {
				pageIndex[i - 1] = i;
			}

			return pageIndex;
		} else if (this.txtRanges.getText() != null && this.txtRanges.getText().trim().length() > 0) {
			Set<Integer> set = new HashSet<Integer>();

			String[] pages = this.txtRanges.getText().split(",");
			for (String pRange : pages) {
				String[] range = pRange.split("-");
				if (range.length == 1) {
					int no = new Integer(range[0].trim());
					if (no <= this.totalPage) {
						set.add(no);
					}
				} else {
					int st = Integer.parseInt(range[0].trim());
					int et = Integer.parseInt(range[1].trim());
					for (int i = st; i <= et && i <= this.totalPage; i++) {
						set.add(i);
					}
				}
			}

			int[] pageIndex = new int[set.size()];
			int idx = 0;
			for (Iterator<Integer> itr = set.iterator(); itr.hasNext();) {
				pageIndex[idx++] = itr.next().intValue();
			}

			return pageIndex;
		}

		return null;

	}
}
