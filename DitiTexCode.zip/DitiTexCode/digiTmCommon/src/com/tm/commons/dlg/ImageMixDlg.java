package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.tm.commons.action.FileMenuActionEnum;
import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.components.pane.MovableImagePane;
import com.tm.commons.components.pane.MultiImagePane;
import com.tm.commons.image.ImageUtils;
import com.tm.commons.menu.DigiTmToolBar;

public class ImageMixDlg extends DigiTmDlg implements ActionListener {
	private static final long serialVersionUID = -8054792045462548115L;
	MovableImagePane imgTrgPane = new MovableImagePane();
	MultiImagePane imgSrcPane = new MultiImagePane();
	BufferedImage img1;
	BufferedImage img2;
	String lastPath;
	JTextField jtPos = new JTextField();

	JLabel lblW1 = new JLabel(" Width: 0000");
	JLabel lblH1 = new JLabel(" Heigth: 0000");
	JLabel lblW2 = new JLabel(" Width: 0000");
	JLabel lblH2 = new JLabel(" Heigth: 0000");

	public ImageMixDlg() {
		this.setTitle("Image mixing");
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(getToolBar(), BorderLayout.NORTH);

		JScrollPane scrollSrc = new JScrollPane(this.imgSrcPane);
		JScrollPane scrollTrg = new JScrollPane(this.imgTrgPane);

		JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollSrc, scrollTrg);
		splitPane.setDividerLocation(400);
		this.getContentPane().add(splitPane, BorderLayout.CENTER);

		this.setPreferredSize(new Dimension(1000, 700));
		this.setSize(1000, 700);
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		int l = ((int)d.getWidth() - 1000)/2;
		int t = ((int)d.getHeight() - 700)/2;
		if (l<0) l=0;
		if (t<0) t=0;
		this.setLocation(l, t);
	}

	JToolBar getToolBar() {
		JToolBar tool = new DigiTmToolBar();
		tool.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
		tool.add(new ButtonMenuItem(FileMenuActionEnum.NEW.value, this, "/img/new.jpg", "New mix"));
		tool.add(new ButtonMenuItem(FileMenuActionEnum.OPEN.value, this, "/img/open.jpg", "Open Image to mix"));
		tool.add(new ButtonMenuItem(FileMenuActionEnum.SAVE.value, this, "/img/save.jpg", "Save mixed Image"));
		JRadioButton jrH = new JRadioButton("Horozontal");
		JRadioButton jrV = new JRadioButton("Vertical");
		ButtonGroup bg = new ButtonGroup();
		bg.add(jrV);
		bg.add(jrH);
		jrH.setActionCommand(String.valueOf(FileMenuActionEnum.HORIZ.value));
		jrV.setActionCommand(String.valueOf(FileMenuActionEnum.VERT.value));
		jrH.addActionListener(this);
		jrV.addActionListener(this);
		jrH.setSelected(true);
		jrH.setOpaque(false);
		jrV.setOpaque(false);
		tool.add(jrH);
		tool.add(jrV);
		tool.add(new ButtonMenuItem(FileMenuActionEnum.SWAP.value, this, "/img/swap.jpg", "Swap Image position"));
		tool.add(new JLabel("Start Position"));
		this.jtPos.setPreferredSize(new Dimension(40, 25));
		this.jtPos.setSize(30, 20);
		this.jtPos.setToolTipText("Start position of 2nd image");
		tool.add(this.jtPos);

		tool.add(new ButtonMenuItem(FileMenuActionEnum.MIX.value, this, "/img/mix.jpg", "Image Mix"));
		tool.add(new ButtonMenuItem(FileMenuActionEnum.ZOOM_IN.value, this, "/img/z2.jpg", "Zoom In"));
		tool.add(new ButtonMenuItem(FileMenuActionEnum.ZOOM_OUT.value, this, "/img/z1.jpg", "Zoom Out"));

		tool.add(new JSeparator(JSeparator.VERTICAL));

		JPanel pnl = new JPanel(new FlowLayout(FlowLayout.LEFT, 3, 0));
		pnl.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.WHITE), "Image One Size"));
		pnl.add(this.lblW1);
		pnl.add(this.lblH1);
		pnl.setOpaque(false);
		tool.add(pnl);

		pnl = new JPanel(new FlowLayout(FlowLayout.LEFT, 3, 0));
		pnl.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.WHITE), "Image Two Size"));
		pnl.add(this.lblW2);
		pnl.add(this.lblH2);
		pnl.setOpaque(false);
		tool.add(pnl);
		
		tool.add(new JSeparator(JSeparator.VERTICAL));
		tool.add(new ButtonMenuItem(FileMenuActionEnum.CLOSE.value, this, "/img/close.jpg", "Close"));

		return tool;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		FileMenuActionEnum cmd = FileMenuActionEnum.fromString(e.getActionCommand());

		switch (cmd) {
		case NEW:
			newMix();
			break;
		case OPEN:
			openImage();
			break;
		case SAVE:
			saveImage();
		case ZOOM_IN:
			this.imgSrcPane.setZoom(1);
			this.imgTrgPane.zoom(1);
			this.imgSrcPane.repaint();
			break;
		case ZOOM_OUT:
			this.imgSrcPane.setZoom(-1);
			this.imgTrgPane.zoom(-1);
			this.imgSrcPane.repaint();
			break;
		case HORIZ:
			this.imgSrcPane.setHorizontal(true);
			this.imgSrcPane.repaint();
			break;
		case VERT:
			this.imgSrcPane.setHorizontal(false);
			this.imgSrcPane.repaint();
			break;
		case SWAP:
			this.imgSrcPane.swapImage();
			this.imgSrcPane.repaint();
			this.img1 = this.imgSrcPane.getImageOne();
			this.img2 = this.imgSrcPane.getImageTwo();
			if (this.img1 != null) {
				this.lblW1.setText("Width: " + this.img1.getWidth());
				this.lblH1.setText("Height: " + this.img1.getHeight());
			}
			if (this.img2 != null) {
				this.lblW2.setText("Width: " + this.img2.getWidth());
				this.lblH2.setText("Height: " + this.img2.getHeight());
			}
			break;
		case MIX:
			mixImage();
			break;
		case CLOSE:
			this.setVisible(false);
			this.dispose();
		}

	}

	void mixImage() {
		int start = 0;
		try {
			start = Integer.parseInt(this.jtPos.getText());
		} catch (NumberFormatException e) {
		}

		BufferedImage img = this.imgSrcPane.mergeImages(start);
		this.imgTrgPane.setImage(img);
	}

	void saveImage() {
		BufferedImage img = this.imgTrgPane.getImage();
		if (img != null) {

			JFileChooser jfc;
			if (this.lastPath != null)
				jfc = new JFileChooser(new File(lastPath));
			else {
				jfc = new JFileChooser();
			}

			jfc.setFileFilter(new FileNameExtensionFilter("24-bit Bitmap", "bmp"));

			if (jfc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
				File file = jfc.getSelectedFile();
				String path = file.getAbsolutePath().toLowerCase();
				if (!path.endsWith(".bmp")) {
					path = path + ".bmp";
				}
				ImageUtils.saveImage(img, path, "BMP");
			}
		}
	}

	void openImage() {
		if (img1 != null && img2 != null) {
			JOptionPane.showMessageDialog(this, "You already have two images!!", "Image Mix", JOptionPane.ERROR_MESSAGE);
			return;
		}

		ImageOpenDlgTree dlg = new ImageOpenDlgTree(null, this.lastPath);
		dlg.setVisible(true);
		BufferedImage img = dlg.getSelectedImage();
		if (img != null) {
			this.lastPath = dlg.getSelectedFile().getParentFile().getAbsolutePath();
			if (img1 == null) {
				this.img1 = img;
				this.lblW1.setText("Width: " + this.img1.getWidth());
				this.lblH1.setText("Height: " + this.img1.getHeight());
			} else {
				this.img2 = img;
				this.lblW2.setText("Width: " + this.img2.getWidth());
				this.lblH2.setText("Height: " + this.img2.getHeight());
			}

			this.imgSrcPane.setImage(img);
			this.imgSrcPane.repaint();
		}
	}

	void newMix()
	{
		this.imgSrcPane.clearImages();
		this.img1 = null;
		this.img2 = null;
		this.lblW1.setText("Width: 000");
		this.lblH1.setText("Height: 000");
		this.lblW2.setText("Width: 000");
		this.lblH2.setText("Height: 000");
		this.imgSrcPane.repaint();
	}
	
}
