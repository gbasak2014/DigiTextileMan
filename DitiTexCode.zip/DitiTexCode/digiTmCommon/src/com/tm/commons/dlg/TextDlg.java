package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.GraphicsEnvironment;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.BevelBorder;

import com.tm.commons.theme.DigiTmTheme;

public class TextDlg extends DigiTmDlg implements ActionListener {
	JComboBox<String> jcFont = new JComboBox<>();
	JComboBox<String> jcSize = new JComboBox<>();
	JComboBox<String> jcStyle = new JComboBox<>();
	JTextArea jt = new JTextArea();

	Font font;

	Color color;

	public TextDlg(JFrame parent, Color color) {
		super(parent);
		this.color = color;
		this.jt.setForeground(this.color);

		for (String font : GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames()) {
			this.jcFont.addItem(font);
		}

		for (int s = 8; s <= 48; s = s + 2) {
			jcSize.addItem(String.valueOf(s));
		}

		jcStyle.addItem("PLAIN");
		jcStyle.addItem("BOLD");
		jcStyle.addItem("ITALIC");

		setBounds(100, 100, 650, 400);
		JPanel contentPanel = new JPanel();
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBackground(DigiTmTheme.getBgColor());
		contentPanel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout());

		JPanel jpNorth = new JPanel(new FlowLayout(FlowLayout.LEFT));
		jpNorth.add(this.jcFont);
		jpNorth.add(this.jcSize);
		jpNorth.add(this.jcStyle);
		JButton btn = new JButton("Refresh");
		btn.setActionCommand("REFRESH");
		btn.addActionListener(this);
		jpNorth.add(btn);

		JPanel jpSouth = new JPanel(new FlowLayout(FlowLayout.LEFT));
		btn = new JButton("OK");
		btn.setActionCommand("OK");
		btn.addActionListener(this);
		jpSouth.add(btn);
		btn = new JButton("CANCEL");
		btn.setActionCommand("CANCEL");
		btn.addActionListener(this);

		jpSouth.add(btn);

		jpNorth.setBackground(DigiTmTheme.getBgColor());
		jpSouth.setBackground(DigiTmTheme.getBgColor());

		contentPanel.add(jpNorth, BorderLayout.NORTH);
		contentPanel.add(jpSouth, BorderLayout.SOUTH);
		contentPanel.add(this.jt, BorderLayout.CENTER);
		this.jt.setBorder(BorderFactory.createLineBorder(Color.GRAY));
		this.font = this.jt.getFont();
		int len = this.jcFont.getItemCount();
		for (int i = 0; i < len; i++) {
			if (font.getFamily().equals(this.jcFont.getItemAt(i))) {
				this.jcFont.setSelectedIndex(i);
				break;
			}
		}

		switch (this.font.getStyle()) {
		case Font.PLAIN:
			this.jcStyle.setSelectedIndex(0);
			break;
		case Font.BOLD:
			this.jcStyle.setSelectedIndex(1);
			break;
		case Font.ITALIC:
			this.jcStyle.setSelectedIndex(2);
			break;
		}

		String sz = String.valueOf(this.font.getSize());

		len = this.jcSize.getItemCount();
		for (int i = 0; i < len; i++) {
			if (sz.equals(this.jcSize.getItemAt(i))) {
				this.jcSize.setSelectedIndex(i);
				break;
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();

		if ("REFRESH".equals(cmd)) {
			this.setFont();
			this.jt.setFont(this.font);
		} else if ("OK".equals(cmd)) {
			this.setFont();
			this.setVisible(false);
		} else {
			this.font = null;
			this.setVisible(false);
		}
	}

	public Font getSelectedFont() {
		return this.font;
	}

	public String getText() {
		return this.jt.getText();
	}

	void setFont() {
		int style = Font.PLAIN;
		if (1 == this.jcStyle.getSelectedIndex()) {
			style = Font.BOLD;
		} else if (2 == this.jcStyle.getSelectedIndex()) {
			style = Font.ITALIC;
		}
		String family = this.jcFont.getSelectedItem().toString();
		String size = this.jcSize.getSelectedItem().toString();
		this.font = new Font(family, style, Integer.parseInt(size));
	}

	public BufferedImage getTextAsImage() {
		if (this.font != null) {
			String str = this.jt.getText();
			Graphics g = this.getGraphics();
			g.setFont(this.font);
			FontMetrics fm = g.getFontMetrics();
			int w = fm.stringWidth(str);
			int h = fm.getHeight();
			int asc = fm.getAscent();
			g.dispose();

			if (w > 0 && h > 0) {
				BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
				g = img.getGraphics();
				g.setFont(this.font);
				g.setColor(Color.WHITE);
				g.fillRect(0, 0, w, h);
				g.setColor(this.color);
				g.drawString(str, 0, asc);
				g.dispose();

				return img;
			}
		}
		return null;
	}
}
