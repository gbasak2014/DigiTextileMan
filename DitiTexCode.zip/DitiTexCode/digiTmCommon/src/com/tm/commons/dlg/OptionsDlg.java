package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import com.tm.commons.components.pane.GrdOptionPane;
import com.tm.commons.components.pane.OtherOptionsPane;
import com.tm.commons.components.pane.PathOptionPane;
import com.tm.commons.components.pane.PrintOptionPane;
import com.tm.commons.dto.GridOptions;
import com.tm.commons.dto.LibOptions;
import com.tm.commons.dto.OtherOptions;
import com.tm.commons.dto.PrintOption;

public class OptionsDlg extends DigiTmDlg implements ActionListener {
	private static final long serialVersionUID = -3905804023222831766L;
	GrdOptionPane grdOptionPane;
	PathOptionPane pathOptionPane;
	OtherOptionsPane otherOptionsPane;
	PrintOptionPane printOptionPane;

	private JTabbedPane contentPanel = new JTabbedPane();
	boolean ok;

	/**
	 * Create the dialog.
	 */
	public OptionsDlg(GridOptions gridOption, LibOptions libOptions, PrintOption printOption, OtherOptions otherOptions) {
		super();
		int w = 700;
		int h = 600;
		this.setModal(true);
		this.grdOptionPane = new GrdOptionPane(gridOption);
		this.pathOptionPane = new PathOptionPane(libOptions);
		this.otherOptionsPane = new OtherOptionsPane(otherOptions);
		this.printOptionPane = new PrintOptionPane(printOption);

		this.setSize(w, h);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(contentPanel, BorderLayout.CENTER);

		contentPanel.add("Grid Options", this.grdOptionPane);
		contentPanel.add("Path Options", this.pathOptionPane);
		contentPanel.add("Others Options", this.otherOptionsPane);
		contentPanel.add("Print Options", this.printOptionPane);

		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
		getContentPane().add(buttonPane, BorderLayout.SOUTH);

		JButton okButton = new JButton("OK");
		okButton.setActionCommand("OK");
		buttonPane.add(okButton);
		getRootPane().setDefaultButton(okButton);

		JButton cancelButton = new JButton("Cancel");
		cancelButton.setActionCommand("Cancel");
		buttonPane.add(cancelButton);

		okButton.addActionListener(this);
		cancelButton.addActionListener(this);

		int l = ((int) Toolkit.getDefaultToolkit().getScreenSize().getWidth() - w) / 2;
		int t = ((int) Toolkit.getDefaultToolkit().getScreenSize().getHeight() - h) / 2;
		this.setLocation(l, t);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if ("OK".equals(e.getActionCommand())) {
			this.pathOptionPane.saveLibPaths();
			this.otherOptionsPane.saveProperties();
			this.grdOptionPane.saveProperties();
			this.printOptionPane.savePrintOption();

			ok = true;
		} else {
			ok = false;
		}

		this.setVisible(false);
	}

	public boolean isOk() {
		return this.ok;
	}

	public GridOptions getGridOptions() {
		return this.grdOptionPane.getGridOption();
	}

	public LibOptions getLibraryHome() {
		return this.pathOptionPane.getLibOptions();
	}

	public OtherOptionsPane getOtherOptions() {
		return this.otherOptionsPane;
	}

	/*
	 * public PrintOption getPrintOption() { return
	 * this.printOptionPane.getPrintOption(); }
	 */
}
