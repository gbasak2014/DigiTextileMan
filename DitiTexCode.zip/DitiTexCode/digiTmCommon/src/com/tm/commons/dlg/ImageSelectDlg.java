package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileFilter;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.tm.commons.action.DigiTmEnum;
import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.components.pane.SelectableImagePane;
import com.tm.commons.image.ImageUtils;
import com.tm.commons.theme.DigiTmTheme;

public class ImageSelectDlg extends DigiTmDlg implements ActionListener {
	private static final long serialVersionUID = 6276648792305771983L;

	JComboBox<String> jcDrive = new JComboBox<String>();
	DefaultListModel<String> listDir = new DefaultListModel<String>();
	DefaultListModel<String> listFile = new DefaultListModel<String>();

	JList<String> jlDir = new JList<String>(listDir);
	JList<String> jlFile = new JList<String>(listFile);

	JLabel jlPath = new JLabel();

	boolean okPresses = false;

	SelectableImagePane imgPane = new SelectableImagePane();
	File selectedFile;

	void setThemeColor() {
		this.getContentPane().setBackground(DigiTmTheme.getBgColor());
		this.jcDrive.setBackground(DigiTmTheme.getBgColor());
		this.jlDir.setBackground(DigiTmTheme.getBgColor());
		this.jlFile.setBackground(DigiTmTheme.getBgColor());
		this.jlPath.setBackground(DigiTmTheme.getBgColor());
	}

	/**
	 * Create the dialog.
	 */
	public ImageSelectDlg(JFrame parent, String lastPath) {
		super(parent);
		setBounds(100, 100, 1000, 700);

		getContentPane().setLayout(new BorderLayout());
		imgPane.setBorder(BorderFactory.createLoweredBevelBorder());

		JScrollPane jsp = new JScrollPane(imgPane);
		getContentPane().add(jsp, BorderLayout.CENTER);

		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));

		JButton btnOk = new JButton("OK");
		btnOk.setBackground(DigiTmTheme.getBgColor());
		btnOk.setActionCommand(String.valueOf(DigiTmEnum.OK.value));

		getRootPane().setDefaultButton(btnOk);

		JButton btnCancel = new JButton("Cancel");
		btnCancel.setBackground(DigiTmTheme.getBgColor());
		btnCancel.setActionCommand(String.valueOf(DigiTmEnum.CANCEL.value));

		JButton btnUp = new JButton("UP");
		btnUp.setBackground(DigiTmTheme.getBgColor());
		btnUp.setActionCommand(String.valueOf(DigiTmEnum.UP.value));

		buttonPane.add(new ButtonMenuItem(DigiTmEnum.ZOOM_IN.value, this, "/img/z2.jpg", "Zoom-In"));
		buttonPane.add(new ButtonMenuItem(DigiTmEnum.ZOOM_OUT.value, this, "/img/z1.jpg", "Zoom-Out"));

		JLabel lbl = new JLabel();
		lbl.setPreferredSize(new Dimension(400, 10));
		buttonPane.add(lbl);
		buttonPane.add(btnOk);
		buttonPane.add(btnCancel);

		JPanel fsPane = new JPanel(new BorderLayout());
		jcDrive.setPreferredSize(new Dimension(150, 20));
		jcDrive.setSize(150, 20);

		jlPath.setBorder(BorderFactory.createLoweredBevelBorder());
		jlPath.setPreferredSize(new Dimension(150, 20));

		JPanel jpNorth = new JPanel(new GridLayout(2, 1, 1, 1));
		jpNorth.setBackground(DigiTmTheme.getBgColor());
		JPanel jpPath = new JPanel();
		jpPath.add(jlPath);
		jpPath.add(btnUp);
		jpPath.setBackground(DigiTmTheme.getBgColor());

		JPanel pnlDrive = new JPanel(new FlowLayout(FlowLayout.CENTER));
		pnlDrive.setOpaque(false);
		pnlDrive.add(jcDrive);
		jpNorth.add(pnlDrive);
		jpNorth.add(jpPath);

		fsPane.add(jpNorth, BorderLayout.NORTH);

		JPanel dirFilePane = new JPanel(new GridLayout(2, 1, 1, 1));

		jlDir.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		jlFile.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		dirFilePane.add(new JScrollPane(jlDir));
		dirFilePane.add(new JScrollPane(jlFile));

		fsPane.add(dirFilePane, BorderLayout.CENTER);
		getContentPane().add(buttonPane, BorderLayout.SOUTH);
		getContentPane().add(fsPane, BorderLayout.WEST);

		dirFilePane.setBackground(DigiTmTheme.getBgColor());
		buttonPane.setBackground(DigiTmTheme.getBgColor());
		fsPane.setBackground(DigiTmTheme.getBgColor());

		jcDrive.addActionListener(this);
		jcDrive.setActionCommand(String.valueOf(DigiTmEnum.SELECT.value));
		btnCancel.addActionListener(this);
		btnOk.addActionListener(this);
		btnUp.addActionListener(this);

		jlDir.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() >= 2 && ImageSelectDlg.this.jlDir.getSelectedValue() != null) {
					addPath(ImageSelectDlg.this.jlDir.getSelectedValue());
				}
			}
		});

		jlFile.addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent e) {
				previewImage(ImageSelectDlg.this.jlFile.getSelectedValue());
			}
		});

		char drive;
		if (lastPath != null) {
			drive = lastPath.charAt(0);
		} else {
			drive = 'A';
		}

		initDirCombo(drive);

		if (lastPath != null) {
			lastPath = lastPath.replace("\\", "/");
			this.initDirAndFileList(lastPath);
			this.jlPath.setText(lastPath);
		}

		this.setThemeColor();
	}

	void previewImage(String fileName) {
		this.selectedFile = new File(jlPath.getText() + File.separator + fileName);
		try {
			BufferedImage img = ImageUtils.getImageFromFile(this.selectedFile.getAbsolutePath());
			imgPane.setImage(img);
		} catch (Exception e) {
		}

	}

	void addPath(String dir) {
		jlPath.setText(jlPath.getText() + "/" + dir);
		jlPath.setToolTipText(jlPath.getText());
		initDirAndFileList(jlPath.getText());
	}

	public File getSelectedFile() {
		return selectedFile;
	}

	void upDir() {
		String str = jlPath.getText();
		int idx = str.lastIndexOf("/");
		if (idx > 0 && idx + 1 < str.length()) {
			String path = str.substring(0, idx);
			jlPath.setText(path);
			initDirAndFileList(path + "/");
		}
	}

	void initDirCombo(char selDrive) {
		File[] roots = File.listRoots();
		for (File file : roots) {
			if (file.getAbsolutePath().startsWith("/")) {
				jcDrive.addItem(file.getAbsolutePath());
			} else {
				jcDrive.addItem(file.getAbsolutePath().substring(0, 2));
			}
		}

		for (int i = 0; i < jcDrive.getItemCount(); i++) {
			if (selDrive == jcDrive.getItemAt(i).charAt(0)) {
				jcDrive.setSelectedIndex(i);
				return;
			}
		}

		jcDrive.setSelectedIndex(0);
	}

	void initDirAndFileList(String path) {
		File dir = new File(path);
		if (dir.isDirectory()) {
			File[] files = dir.listFiles(new FileFilter() {

				@Override
				public boolean accept(File pathname) {
					return pathname.isDirectory();
				}
			});

			listDir.clear();
			for (File file : files) {
				listDir.addElement(file.getName());
			}
		}

		initFileList(path);
	}

	void initFileList(String path) {
		File dir = new File(path);
		if (dir.isDirectory()) {
			File[] files = dir.listFiles(new FileFilter() {

				@Override
				public boolean accept(File pathname) {
					return !pathname.isDirectory() && (pathname.getName().toUpperCase().endsWith(".BMP")
							|| pathname.getName().toUpperCase().endsWith(".JPG"));
				}
			});

			listFile.clear();
			for (File file : files) {
				listFile.addElement(file.getName());
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		DigiTmEnum action = DigiTmEnum.fromString(e.getActionCommand());

		switch (action) {
		case OK:
			if (this.getSelectedImage() == null) {
				JOptionPane.showMessageDialog(null, "Please select image!!");
				break;
			}
			okPresses = true;
			this.setVisible(false);
			break;
		case CANCEL:
			this.setVisible(false);
			break;
		case UP:
			upDir();
			break;
		case SELECT:
			String drive = (String) jcDrive.getSelectedItem();
			jlPath.setText(drive);
			initDirAndFileList(drive + "/");
			break;
		case ZOOM_IN:
			this.imgPane.zoom(1);
			break;
		case ZOOM_OUT:
			this.imgPane.zoom(-1);
			break;
		default:
			break;
		}
	}

	public BufferedImage getSelectedImage() {
		BufferedImage img = this.imgPane.getSelectedImage();
		if (img == null) {
			img = this.imgPane.getImage();
		}
		return img;
	}

	public boolean isOk() {
		return okPresses;
	}
}
