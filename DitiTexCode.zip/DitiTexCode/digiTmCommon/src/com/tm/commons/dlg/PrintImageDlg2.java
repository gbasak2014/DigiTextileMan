package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.image.BufferedImage;
import java.awt.print.Book;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;

import com.tm.commons.action.FileMenuActionEnum;
import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.win.DigiTmWin;

public class PrintImageDlg2 extends DigiTmWin implements ActionListener {
	private static final long serialVersionUID = 6307640446109828503L;
	Pan jpmain = new Pan();
	ButtonMenuItem btnPrint;
	ButtonMenuItem btnClose;
	PrinterJob pj;
	PageFormat pf;
	BufferedImage img = null;
	BufferedImage simg = null;
	int xsft, ysft, x, y, rmax, cmax, pw, ph, dw, dh, left, top, pagew, pageh;
	JScrollBar jsh = new JScrollBar();
	JScrollBar jsv = new JScrollBar();
	JLabel jltxt = new JLabel();
	JComboBox<String> jcpage = new JComboBox<String>();

	int pageR, pageC;

	int pageWidthInch;
	int pageHeightInch;
	
	int imgWidthPerPage;
	int imgHeightPerPage;
	
	@Override
	public void saveProperties() {
		// TODO Auto-generated method stub

	}

	public PrintImageDlg2(BufferedImage bi) {
		super();
		try {
			img = bi;
			left = top = 0;
			jbInit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void jbInit() throws Exception {
		pj = PrinterJob.getPrinterJob();
		pj.setJobName("Print Design");
		pf = pj.defaultPage();
		refresh();
		setIconImage(Toolkit.getDefaultToolkit().getImage("img/gm.jpg"));
		this.getContentPane().setLayout(new BorderLayout());
		this.setSize(new Dimension(400, 300));
		this.setTitle("Print Image");

		jsh.setOrientation(JScrollBar.HORIZONTAL);
		jltxt.setForeground(Color.black);
		jltxt.setPreferredSize(new Dimension(120, 20));
		jltxt.setMaximumSize(new Dimension(120, 20));
		jltxt.setMinimumSize(new Dimension(120, 20));
		jltxt.setFont(new Font("Dialog", 1, 12));
		jcpage.setPreferredSize(new Dimension(100, 20));
		jcpage.setMaximumSize(new Dimension(100, 20));
		jcpage.setBackground(new Color(245, 255, 255));
		jcpage.setMinimumSize(new Dimension(100, 20));

		JPanel toolPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 2, 2));
		btnPrint = new ButtonMenuItem(FileMenuActionEnum.PRINT_IMAGE.value, this, "/img/printdesign.jpg", "Print Design");
		btnClose = new ButtonMenuItem(FileMenuActionEnum.CLOSE.value, this, "/img/close.jpg", "Close");

		toolPanel.add(jltxt, null);
		toolPanel.add(jcpage, null);
		toolPanel.add(btnPrint);
		toolPanel.add(btnClose, null);

		this.getContentPane().add(jsh, BorderLayout.SOUTH);
		this.getContentPane().add(jsv, BorderLayout.EAST);
		this.getContentPane().add(toolPanel, BorderLayout.NORTH);
		this.getContentPane().add(jpmain, BorderLayout.CENTER);
		jcpage.setActionCommand(String.valueOf(FileMenuActionEnum.SELECT_PAGE.value));
		jcpage.addActionListener(this);

		jsh.addAdjustmentListener(new AdjustmentListener() {

			public void adjustmentValueChanged(AdjustmentEvent e) {
				left = jsh.getValue();
				jpmain.repaint();
			}
		});
		jsv.addAdjustmentListener(new AdjustmentListener() {

			public void adjustmentValueChanged(AdjustmentEvent e) {
				top = jsv.getValue();
				jpmain.repaint();
			}
		});

	}

	public void subImg(int idx) {
		int gw, gh;// r, c;
		gw = img.getWidth();
		gh = img.getHeight();
		pageR = idx % rmax;
		pageC = idx / rmax;
		xsft = ysft = 0;

		dw = pw;
		dh = ph;

		if (pageC * pw + pw > gw)
			dw = gw - pageC * pw;
		
		if (pageR * ph + ph > gh)
			dh = gh - pageR * ph;
		
		jsh.setMaximum(pagew);
		jsh.setMinimum(0);
		jsh.setValue(0);
		jsv.setMaximum(pageh);
		jsv.setMinimum(0);
		jsv.setValue(0);
		// int w, h;

		BufferedImage itmp = img.getSubimage(pageC * pw, pageR * ph, dw, dh);
		simg = new BufferedImage(dw, dh, BufferedImage.TYPE_INT_RGB);
		simg.getGraphics().drawImage(itmp, 0, 0, dw, dh, this);

		xsft = pw > dw ? (pw - dw) / 2 : 0;
		ysft = ph > dh ? (ph - dh) / 2 : 0;
	}

	class Pan extends JPanel {
		private static final long serialVersionUID = 4926401009157313940L;

		public void paint(Graphics g) {
			g.setColor(Color.white);
			g.fillRect(0, 0, getWidth(), getHeight());
			g.setColor(Color.black);
			g.drawRect(-left + 10, -top + 10, pagew, pageh);
			g.drawString((pageR + 1) + "X" + (pageC + 1), -left + 100, -top + 45);
			g.setColor(Color.lightGray);
			g.drawRect(-left + x + 10, -top + y + 10, pw + 2, ph + 2);
			g.drawImage(simg, -left + x + xsft + 11, -top + y + ysft + 11, dw, dh, this);
		}
	}

	void printDesign(int pageCount) {
		Book bk = new Book();

		PaintContent pc = new PaintContent(simg, -1, -1, pw, ph);
		bk.append(pc, pf, pageCount);

		pj.setPageable(bk);
		pj.setJobName("Print Design");
		try {
			pj.print();
		} catch (Exception ee) {
		}
	}

	void refresh() {
		pf = pj.validatePage(pf);
		pagew = (int) pf.getWidth();
		pageh = (int) pf.getHeight();
		x = (int) pf.getImageableX() + 1;
		y = (int) pf.getImageableY() + 1;
		pw = (int) pf.getImageableWidth() - 3;
		ph = (int) pf.getImageableHeight() - 3;

		pageWidthInch = pw / 72;
		pageHeightInch = ph / 72;
		
		imgWidthPerPage = pageWidthInch * 100;
		imgHeightPerPage = pageHeightInch * 100;

		if (pf.getOrientation() == PageFormat.LANDSCAPE) {
			x = pagew - pw - x;
			y = pageh - ph - y;
		}
		rmax = (int) ((double) img.getHeight() / (double) ph);

		if ((int) ((double) img.getHeight() % (double) ph) != 0) {
			rmax = rmax + 1;
		}

		cmax = (int) ((double) img.getWidth() / (double) pw);
		if ((int) ((double) img.getWidth() % (double) pw) != 0) {
			cmax = cmax + 1;
		}

		jcpage.removeAllItems();
		for (int i = 1; i <= cmax; i++) {
			for (int j = 1; j <= rmax; j++) {
				jcpage.addItem(j + " X " + i);
			}
		}

		jltxt.setText("Total Page: " + rmax + "X" + cmax);
		jcpage.setSelectedIndex(0);
		subImg(jcpage.getSelectedIndex());
	}

	// //////////////PaintContent//////////////////////////
	class PaintContent implements Printable {
		BufferedImage img;
		PageFormat pf;
		int row, col, pw, ph;

		public PaintContent(BufferedImage i, int row, int col, int pw, int ph) {
			img = i;
			this.row = row;
			this.col = col;
			this.pw = pw;
			this.ph = ph;
		}

		public int print(Graphics g, PageFormat pf, int pi) throws PrinterException {
			this.pf = pf;
			if (row < 0)
				printFull(g);
			else
				printSub(getSubImg(pi), g);
			
			return Printable.PAGE_EXISTS;
		}

		void printSub(BufferedImage bi, Graphics g) {
			Graphics2D g2 = (Graphics2D) g;
			g2.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
			g2.drawImage(bi, x + xsft, y + ysft, PrintImageDlg2.this);
			g2.setColor(Color.lightGray);
			g2.drawRect(x + xsft, y + ysft, bi.getWidth(), bi.getHeight());
			g2.dispose();
		}

		void printFull(Graphics g) {
			Graphics2D g2 = (Graphics2D) g;
			g2.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
			g2.drawImage(img, x + xsft, y + ysft, PrintImageDlg2.this);
			g2.dispose();
		}

		public BufferedImage getSubImg(int idx) {
			int gw, gh, r, c;
			gw = img.getWidth();
			gh = img.getHeight();
			r = idx % row;
			c = idx / row;

			dw = pw;
			dh = ph;

			if (c * pw + pw > gw)
				dw = gw - c * pw;
			if (r * ph + ph > gh)
				dh = gh - r * ph;

			BufferedImage itmp = new BufferedImage(dw, dh, BufferedImage.TYPE_INT_RGB);
			itmp.getGraphics().drawImage(img.getSubimage(c * pw, r * ph, dw, dh), 0, 0, dw, dh, PrintImageDlg2.this);
			return itmp;
		}
	}

	// //////////////PaintContent//////////////////////////

	void paintSelectedPage() {
		if (jcpage.getSelectedIndex() >= 0)
			subImg(jcpage.getSelectedIndex());
		jpmain.repaint();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		FileMenuActionEnum action = FileMenuActionEnum.fromString(e.getActionCommand());

		switch (action) {
		case PRINT_IMAGE:
			printDesign(jcpage.getItemCount());
			break;
		case CLOSE:
			close();
			break;
		case SELECT_PAGE:
			paintSelectedPage();
			break;
		default:
			break;
		}
	}

	void close() {
		this.setVisible(false);
		this.dispose();
	}
}