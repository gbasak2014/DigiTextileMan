package com.tm.commons.dlg;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.print.Book;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.RandomAccessFile;

import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;

import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.dto.PrintOption;
import com.tm.commons.image.ImageUtils;
import com.tm.commons.menu.DigiTmToolBar;
import com.tm.commons.win.DigiTmWin;

public class PrintCodeDlg extends DigiTmWin implements ActionListener {
	final int FIRST = 0;
	final int NEXT = 1;
	final int PREV = 2;
	final int LAST = 3;
	final int PRINT = 4;
	final int SETT = 5;
	final int REFRESH = 6;
	final int CLOSE = 7;
	final int FNT_SETT = 8;
	final int SAVE = 9;

	PrinterJob printerJob;
	PageFormat pageFormat;
	String codeFile;

	CodePane jpCode;
	JScrollBar scrollBarH = new JScrollBar(JScrollBar.HORIZONTAL);
	JScrollBar scrollBarV = new JScrollBar(JScrollBar.VERTICAL);

	JComboBox<Integer> jcmbLineSpace = new JComboBox<Integer>();

	String[] pageData;
	long[] offset;
	RandomAccessFile file;

	JComboBox<String> jcbPage = new JComboBox<String>();

	int currentPage = 0;
	int linePerPage;
	int pageCnt;
	int lineCount = 0;

	PrintOption printOption;

	Font headerFont = new Font("Arial", Font.PLAIN, 10);
	int headerHeight;

	String _user;

	public PrintCodeDlg(String user, String codeFile, PrintOption printOption) {
		this._user = user;
		this.codeFile = codeFile;
		this.printOption = printOption;

		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.printerJob = PrinterJob.getPrinterJob();
		this.printerJob.setJobName("Print Code");
		this.pageFormat = this.printerJob.defaultPage();
		this.pageFormat = this.printerJob.validatePage(this.pageFormat);

		JPanel mainPane = new JPanel();
		this.setContentPane(mainPane);
		mainPane.setLayout(new BorderLayout());

		this.jpCode = new CodePane(this.pageFormat, this.printOption);
		mainPane.add(this.jpCode, BorderLayout.CENTER);
		mainPane.add(this.scrollBarH, BorderLayout.SOUTH);
		mainPane.add(this.scrollBarV, BorderLayout.EAST);
		mainPane.add(this.getToolbar(), BorderLayout.NORTH);

		this.scrollBarH.setMaximum((int) this.pageFormat.getWidth());
		this.scrollBarV.setMaximum((int) this.pageFormat.getHeight());

		this.scrollBarH.addAdjustmentListener(new AdjustmentListener() {

			@Override
			public void adjustmentValueChanged(AdjustmentEvent ae) {

				jpCode.scroll(scrollBarH.getValue(), scrollBarV.getValue());
			}
		});

		this.scrollBarV.addAdjustmentListener(new AdjustmentListener() {

			@Override
			public void adjustmentValueChanged(AdjustmentEvent ae) {
				jpCode.scroll(scrollBarH.getValue(), scrollBarV.getValue());
			}
		});

		this.pack();

		try {
			generatePrintableText();
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Code file not exist", "Code Read Error", JOptionPane.ERROR_MESSAGE);
		}

		this.jcbPage.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent ie) {
				int p = jcbPage.getSelectedIndex();
				if (currentPage != p) {
					currentPage = p;
					try {
						refreshPage();
					} catch (Exception e) {
					}
				}

			}
		});

		this.jcmbLineSpace.addItemListener(new ItemListener() {

			@Override
			public void itemStateChanged(ItemEvent ie) {
				int ls = jcmbLineSpace.getSelectedIndex();
				if (ls != jpCode.option.getLineSpace()) {
					try {
						jpCode.option.setLineSpace(ls);
						generatePrintableText();
						jpCode.repaint();
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, "Code file not exist", "Code Read Error",
								JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		});

		this.setSize(600, 500);
		this.setVisible(true);
	}

	private void refreshPage() throws Exception {
		long currOffset = this.offset[currentPage];
		ImageUtils.loadPage(this.file, currOffset, this.pageData);
		this.jpCode.repaint();
	}

	private DigiTmToolBar getToolbar() {
		DigiTmToolBar toolBar = new DigiTmToolBar();
		toolBar.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 0));

		toolBar.add(new ButtonMenuItem(FIRST, this, "/img/first.jpg", "First Page"));
		toolBar.add(new ButtonMenuItem(PREV, this, "/img/prev.jpg", "Previous Page"));
		this.jcbPage.setPreferredSize(new Dimension(100, 20));
		toolBar.add(jcbPage);
		toolBar.add(new ButtonMenuItem(NEXT, this, "/img/next.jpg", "Next Page"));
		toolBar.add(new ButtonMenuItem(LAST, this, "/img/last.jpg", "Last Page"));

		toolBar.add(new ButtonMenuItem(SAVE, this, "/img/save.jpg", "Save Code"));

		toolBar.add(new ButtonMenuItem(PRINT, this, "/img/print.jpg", "Print"));
		toolBar.add(new ButtonMenuItem(FNT_SETT, this, "/img/font-sett.jpg", "Change Font"));
		toolBar.add(new ButtonMenuItem(SETT, this, "/img/print_sett.jpg", "Printer Settings"));

		jcmbLineSpace.setPreferredSize(new Dimension(50, 20));
		toolBar.add(this.jcmbLineSpace);
		toolBar.add(new ButtonMenuItem(REFRESH, this, "/img/refresh.jpg", "Refresh Page"));
		toolBar.add(new ButtonMenuItem(CLOSE, this, "/img/close.jpg", "Refresh Page"));

		for (int i = 0; i < 20; i++) {
			jcmbLineSpace.addItem(i);
		}

		jcmbLineSpace.setSelectedIndex(this.printOption.getLineSpace());
		return toolBar;
	}

	private void generatePrintableText() throws FileNotFoundException, IOException {
		File src = new File(this.codeFile);
		File dst = new File(src.getParent(), "_CODE_123");
		Graphics g = this.jpCode.getGraphics();

		this.headerHeight = g.getFontMetrics(headerFont).getHeight() * 2;
		this.jpCode.headerHeight = this.headerHeight;
		FontMetrics fontMetrics = g.getFontMetrics(this.printOption.getFont());
		int lineHeight = fontMetrics.getHeight();
		int printableWidth = (int) this.pageFormat.getImageableWidth();
		int printableHeight = (int) this.pageFormat.getImageableHeight() - this.headerHeight;

		try {
			this.printOption.setLineSpace(jcmbLineSpace.getSelectedIndex());
		} catch (Exception e) {

		}

		BufferedReader br = new BufferedReader(new FileReader(src));
		PrintWriter pw = new PrintWriter(dst);

		String line = null;
		StringBuffer buff = new StringBuffer();
		int lineCount = 0;
		String header = this.printOption.getHeader();
		String footer = this.printOption.getFooter();

		this.linePerPage = printableHeight / (lineHeight + this.printOption.getLineSpace());

		if (header != null && header.trim().length() > 0) {
			this.linePerPage--;
		}

		if (footer != null && footer.trim().length() > 0) {
			this.linePerPage--;
		}
		this.pageData = new String[this.linePerPage];

		while ((line = br.readLine()) != null) {
			String[] words = line.split(",");
			buff.replace(0, buff.length(), "");
			for (String word : words) {
				if ((fontMetrics.stringWidth(buff.toString()) + fontMetrics.stringWidth(word)) > printableWidth) {
					if (!buff.toString().endsWith("|")) {
						buff.append(",");
					}

					pw.println(buff.toString());
					buff.replace(0, buff.length(), "");
					lineCount++;
				}

				if (buff.length() > 0 || word.indexOf(">") > 0) {
					if (word.indexOf(">") < 0) {
						buff.append(",");
					}
				} else {
					buff.append("......");
				}

				buff.append(word);
			}

			if (buff.length() > 0) {
				pw.println(buff.toString());
				lineCount++;
			}
		}

		br.close();
		pw.close();

		pageCnt = lineCount / this.linePerPage;
		if (lineCount % this.linePerPage != 0) {
			pageCnt++;
		}

		this.offset = new long[pageCnt];
		this.file = new RandomAccessFile(dst, "r");

		file.seek(0);
		this.offset[0] = 0;
		int idx = 0;
		int i = 1;
		while ((line = this.file.readLine()) != null) {
			idx++;

			if (idx % this.linePerPage == 0) {
				this.offset[i] = this.file.getFilePointer();
				i++;
			}
		}

		this.jcbPage.removeAllItems();
		for (i = 1; i <= pageCnt; i++) {
			this.jcbPage.addItem(i + " of " + pageCnt);
		}

		this.currentPage = 0;
		ImageUtils.loadPage(file, 0, pageData);

		this.jpCode.refreshPage(pageFormat);
	}

	@Override
	public void saveProperties() {
		// TODO Auto-generated method stub

	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		int cmd = Integer.parseInt(ae.getActionCommand());
		int pg = -1;
		switch (cmd) {
		case FIRST:
			pg = 0;
			break;
		case NEXT:
			pg = this.currentPage + 1;
			if (pg >= this.pageCnt) {
				pg = this.currentPage;
			}
			break;
		case PREV:
			pg = this.currentPage - 1;
			if (pg < 0) {
				pg = 0;
			}
			break;
		case LAST:
			pg = this.pageCnt - 1;
			break;
		case SAVE:
			saveCode();
			break;
		case SETT:
			printSettings();
			break;
		case PRINT:
			print();
			break;
		case FNT_SETT:
			changeFont();
			break;
		case CLOSE:
			this.setVisible(false);
			this.dispose();
		}

		if (pg >= 0 && this.currentPage != pg) {
			try {
				this.currentPage = pg;
				this.refreshPage();
				this.jcbPage.setSelectedIndex(this.currentPage);
			} catch (Exception e) {
			}
		}

	}

	void saveCode() {
		try {
			if (this.codeFile != null) {
				JFileChooser jfc = new JFileChooser();
				if (jfc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
					File dst = jfc.getSelectedFile();
					BufferedReader br = new BufferedReader(new FileReader(this.codeFile));
					PrintWriter pw = new PrintWriter(dst);
					String line = br.readLine();
					while (line != null) {
						pw.println(line);
						line = br.readLine();
					}
					br.close();
					pw.close();
				}
			} else {
				JOptionPane.showMessageDialog(this, "Please generate code!!");
			}
		} catch (Exception e) {
		}
	}

	void changeFont() {
		DigiTmFontDld dlg = new DigiTmFontDld(this.printOption.getFont());
		dlg.setVisible(true);
		Font font = dlg.getFont();
		if (font != null) {
			this.printOption.setFont(font);
			try {
				this.generatePrintableText();
			} catch (Exception e) {

			}
		}

	}

	void printSettings() {

		this.pageFormat = this.printerJob.pageDialog(pageFormat);

		try {
			this.generatePrintableText();
		} catch (Exception e) {

		}
	}

	void print() {
		PrintDlg dlg = new PrintDlg(this.currentPage + 1, this.pageCnt, this);
		dlg.setVisible(true);
		int[] pages = dlg.getPageIndices();
		if (pages != null) {
			Book book = new Book();
			CodePaintContent pc = new CodePaintContent(this.pageFormat, this.printOption, this.file, this.offset,
					this.currentPage, this.linePerPage, pages, this.pageCnt, this.headerHeight);
			book.append(pc, this.pageFormat, pages.length);

			this.printerJob.setPageable(book);
			this.printerJob.setJobName("Print Code");

			try {
				this.printerJob.print();
			} catch (Exception e) {
			}
		}
	}

	class CodePane extends JPanel {
		int left = 0;
		int top = 0;

		int imagableX;
		int imagebleY;
		int pageWidth;
		int pageHeight;
		int imagebleWidth;
		int imagableHeight;
		PrintOption option;
		int headerHeight;

		void setPageFormat(PageFormat pageFormat) {
			this.imagableX = (int) pageFormat.getImageableX();
			this.imagebleY = (int) pageFormat.getImageableY();
			this.pageWidth = (int) pageFormat.getWidth();
			this.pageHeight = (int) pageFormat.getHeight();
			this.imagebleWidth = (int) pageFormat.getImageableWidth();
			this.imagableHeight = (int) pageFormat.getImageableHeight();
		}

		public CodePane(PageFormat pageFormat, PrintOption option) {
			this.option = option;
			setPageFormat(pageFormat);
		}

		public void refreshPage(PageFormat pageFormat) {
			setPageFormat(pageFormat);
			this.repaint();
		}

		@Override
		public void paint(Graphics g) {
			g.setFont(this.option.getFont());
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, this.getWidth(), this.getHeight());
			g.setColor(Color.GRAY);
			g.drawRect(-left, -top, this.pageWidth, this.pageHeight);

			int y = -top + imagebleY + this.headerHeight;
			int x = -left + imagableX;

			g.drawString("Page: " + (currentPage + 1) + " of " + pageCnt, x, y - (this.headerHeight / 2));
			ImageUtils.drawText(_user, pageData, g, this.option.getFont(), x, y, this.pageHeight,
					this.option.getLineSpace(), this.option);
		}

		public void scroll(int x, int y) {
			this.left = x;
			this.top = y;
			this.repaint();
		}
	}

	class CodePaintContent implements Printable {
		PrintOption option;
		int currentPage;
		long[] pageOffset;
		RandomAccessFile file;
		int linePerPage;
		int[] pages;

		String[] data;

		int imagableX;
		int imagebleY;
		int pageHeight;
		int pageCount;
		int headerHeight;

		public CodePaintContent(PageFormat pageFormat, PrintOption option, RandomAccessFile file, long[] pageOffset,
				int currentPage, int linePerPage, int[] pages, int pageCount, int headerHeight) {
			this.option = option;
			this.file = file;
			this.pageOffset = pageOffset;
			this.currentPage = currentPage;
			this.linePerPage = linePerPage;
			this.pages = pages;
			this.pageCount = pageCount;
			this.headerHeight = headerHeight;
			this.data = new String[this.linePerPage];

			imagableX = (int) pageFormat.getImageableX();
			imagebleY = (int) pageFormat.getImageableY() + this.headerHeight;
			pageHeight = (int) pageFormat.getHeight() - this.headerHeight;
		}

		@Override
		public int print(Graphics g, PageFormat pageFormat, int idx) throws PrinterException {

			try {
				int pageIdx = this.pages[idx] - 1;
				ImageUtils.loadPage(this.file, this.pageOffset[pageIdx], data);
				ImageUtils.drawText(_user, data, g, this.option.getFont(), this.imagableX, this.imagebleY,
						this.pageHeight, this.option.getLineSpace(), this.option);

				g.drawString("Page: " + (idx + 1) + " of " + pageCnt, this.imagableX,
						this.imagebleY - (this.headerHeight / 2));
			} catch (Exception e) {
				throw new PrinterException("Error printing page: " + e.getMessage());
			}

			if (idx < this.pages.length) {
				return Printable.PAGE_EXISTS;
			}

			return Printable.NO_SUCH_PAGE;
		}
	}

}
