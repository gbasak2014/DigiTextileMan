package com.tm.commons.tool;

import java.awt.Component;

import javax.swing.ImageIcon;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;

public class DesignTreeCellRenderer extends DefaultTreeCellRenderer {

	ImageIcon iconDesign;
	ImageIcon iconGroup;
	ImageIcon iconMotif;

	public DesignTreeCellRenderer(ImageIcon iconDesign, ImageIcon iconGroup, ImageIcon iconMotif) {
		this.iconDesign = iconDesign;
		this.iconGroup = iconGroup;
		this.iconMotif = iconMotif;
	}

	@Override
	public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded,
			boolean leaf, int row, boolean hasFocus) {
		super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);

		if (value.toString().startsWith("Design")) {
			setIcon(iconDesign);
		} else if (value.toString().startsWith("Group")) {
			setIcon(iconGroup);
		} else {
			setIcon(iconMotif);
		}

		return this;
	}
}
