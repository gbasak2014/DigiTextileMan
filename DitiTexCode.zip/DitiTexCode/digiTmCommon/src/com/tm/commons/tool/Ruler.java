package com.tm.commons.tool;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.AffineTransform;

import javax.swing.JPanel;

import com.tm.commons.dto.GridOptions;
import com.tm.commons.listener.RulerListener;

public class Ruler extends JPanel implements MouseListener, MouseMotionListener {
	private static final long serialVersionUID = -2292922000442173608L;
	byte type;
	Ruler rv;
	int c1, c2;
	int start = 0;
	public static final byte HORZ = 1;
	public static final byte VERTZ = 2;
	RulerListener rulerListener;

	int startIndex;
	int endIndex;

	GridOptions gridOptions;
	
	public Ruler(byte tp, RulerListener rulerListener, GridOptions gridOptions) {
		this(tp, rulerListener, null, gridOptions);
	}

	public Ruler(byte tp, RulerListener rulerListener, Ruler r, GridOptions gridOptions) {
		super();
		type = tp;
		rv = r;
		this.gridOptions = gridOptions;
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
		this.rulerListener = rulerListener;

	}

	public int getType() {
		return this.type;
	}

	public void paint(Graphics gg) {
		Graphics2D g =(Graphics2D)gg;
		int h = getHeight();
		int w = getWidth();
		g.setColor(new Color(225, 255, 255));
		g.fillRect(0, 0, w, h);
		g.setColor(Color.DARK_GRAY);
		int cw = this.gridOptions.getZoom();
		if (cw > 2)
			if (type == HORZ)
			{
				int x=start;
				for (int i = rv.getWidth(); i < w; i += cw)
				{
					if (x%10 == 0 && x>0)
					{
						g.drawLine(i, 0, i, h);
						g.setColor(Color.RED);
						g.drawString(String.valueOf(x), i, h-1);
					}
					else
					{
						g.setColor(Color.DARK_GRAY);
						g.drawLine(i, 10, i, h);
					}
					x++;
				}
			}
			else
			{
				int y=start;
				for (int i = 0; i < h; i += cw)
				{
					if (y%10 == 0 && y > 0)
					{
						g.setColor(Color.BLACK);
						g.drawLine(0, i, w, i);
					}
					else
					{
						g.setColor(Color.DARK_GRAY);
						g.drawLine(10, i, w, i);
					}
					y++;
				}
				
				y=start;
				AffineTransform at = new AffineTransform();
				at.rotate(Math.PI/2.0);
				g.setTransform(at);
				g.setColor(Color.RED);
				for (int i = 0; i < h; i += cw)
				{
					if (y%10 == 0 && y > 0)
					{
						g.drawString(String.valueOf(y), i, -2);
					}
					y++;
				}
			}
		
    g.setColor(Color.BLUE);
		g.drawRect(0, 0, w, h);
		g.dispose();
	}

	public void setStart(int s) {
		start = s;
		repaint();
	}

	@Override
	public void mouseClicked(MouseEvent me) {
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
	}

	@Override
	public void mousePressed(MouseEvent me) {
		if (this.type == HORZ) {
			this.startIndex = ((me.getX() - this.rv.getWidth()) / this.gridOptions.getZoom());
		} else {
			this.startIndex = (me.getY() / this.gridOptions.getZoom());
		}

		this.rulerListener.startIndexSet(this.type, this.startIndex, me.getButton(), me.getClickCount());
	}

	@Override
	public void mouseDragged(MouseEvent me) {
		if (this.type == HORZ) {
			this.endIndex = ((me.getX() - this.rv.getWidth()) / this.gridOptions.getZoom());
		} else {
			this.endIndex = (me.getY() / this.gridOptions.getZoom());
		}

		this.rulerListener.endIndexSet(this.type, this.endIndex, me.getButton(), me.getClickCount());
	}

	@Override
	public void mouseMoved(MouseEvent e) {
	}

}
