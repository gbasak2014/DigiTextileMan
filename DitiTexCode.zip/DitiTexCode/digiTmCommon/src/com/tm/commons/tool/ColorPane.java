package com.tm.commons.tool;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

import com.tm.commons.components.button.ButtonColor;
import com.tm.commons.theme.DigiTmTheme;

public class ColorPane extends JPopupMenu implements ActionListener, MouseListener, MouseMotionListener {
	private static final long serialVersionUID = -4021925165185087505L;
	static final int MAX_COL = 23;
	static final int MAX_ROW = 10;

	BufferedImage img = new BufferedImage(MAX_COL, MAX_ROW, BufferedImage.TYPE_INT_RGB);
	JPanel pnlImg;
	JPanel pnlRecent;
	DropdownColorChooser parent;
	List<JButton> colorList = new ArrayList<JButton>();
	int index = 0;
	JLabel lblRgb;
	
	public ColorPane() {
		addButtonToList(this);
		this.setBackground(DigiTmTheme.getBgColor());
		JPanel pnlSouth = new JPanel(new GridLayout(2, 1, 0, 0));
		pnlRecent = new JPanel(new GridLayout(1, MAX_COL, 0, 0));
		pnlRecent.setOpaque(true);

		pnlSouth.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
		pnlRecent.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
		pnlSouth.setBackground(DigiTmTheme.getBgColor());
		for (JButton btn : colorList) {
			pnlRecent.add(btn);
		}
		JPanel pnl = new JPanel(new GridLayout(1, 2, 0, 0));
		pnl.add(new JLabel("Recently Used"));
		lblRgb = new JLabel();
		pnl.add(lblRgb);
		pnlSouth.add(pnl);
		pnlSouth.add(pnlRecent);

		createPanel();

		JPanel container = new JPanel(new BorderLayout(0, 0));
		container.setBorder(BorderFactory.createLoweredBevelBorder());

		pnlImg = new ImgPane(img);
		pnlImg.setSize(MAX_COL * 20, MAX_ROW * 20);

		container.add(pnlSouth, BorderLayout.SOUTH);
		container.add(pnlImg, BorderLayout.CENTER);

		this.add(container);
		container.setPreferredSize(new Dimension((MAX_COL * 20) + 4, (MAX_ROW * 20) + 57));
		container.setSize((MAX_COL * 20) + 4, (MAX_ROW * 20) + 57);

		this.setPreferredSize(new Dimension((MAX_COL * 20) + 4, (MAX_ROW * 20) + 57));
		this.setSize((MAX_COL * 20) + 4, (MAX_ROW * 20) + 57);
		this.setVisible(false);
	}

	public void setParent(DropdownColorChooser parent) {
		this.parent = parent;
	}

	void createPanel() {
		int x = 0;
		int y = 0;

		int[] rgbs = new int[216];

		int i = 0;
		for (int r = 0; r < 255; r = r + 50)
			for (int g = 0; g < 255; g = g + 50)
				for (int b = 0; b < 255; b = b + 50) {
					rgbs[i++] = 0xFF000000 | (r << 16) | (g << 8) | b;
				}

		for (i = 0; i < rgbs.length; i = i + 3) {
			if (y >= MAX_ROW) {
				x++;
				y = 0;
			}

			img.setRGB(x, y, rgbs[i]);
			y++;
		}

		for (i = 1; i < rgbs.length; i = i + 3) {
			if (y >= MAX_ROW) {
				x++;
				y = 0;
			}
			img.setRGB(x, y, rgbs[i]);
			y++;
		}

		for (i = 2; i < rgbs.length; i = i + 3) {
			if (y >= MAX_ROW) {
				x++;
				y = 0;
			}
			img.setRGB(x, y, rgbs[i]);
			y++;
		}

		img.setRGB(x, y++, Color.WHITE.getRGB());
		if (y >= MAX_ROW) {
			x++;
			y = 0;
		}
		img.setRGB(x, y++, Color.BLACK.getRGB());
		if (y >= MAX_ROW) {
			x++;
			y = 0;
		}
		img.setRGB(x, y++, Color.BLUE.getRGB());
		if (y >= MAX_ROW) {
			x++;
			y = 0;
		}
		img.setRGB(x, y++, Color.CYAN.getRGB());
		if (y >= MAX_ROW) {
			x++;
			y = 0;
		}
		img.setRGB(x, y++, Color.DARK_GRAY.getRGB());
		if (y >= MAX_ROW) {
			x++;
			y = 0;
		}
		img.setRGB(x, y++, Color.GRAY.getRGB());
		if (y >= MAX_ROW) {
			x++;
			y = 0;
		}
		img.setRGB(x, y++, Color.GREEN.getRGB());
		if (y >= MAX_ROW) {
			x++;
			y = 0;
		}
		img.setRGB(x, y++, Color.LIGHT_GRAY.getRGB());
		if (y >= MAX_ROW) {
			x++;
			y = 0;
		}
		img.setRGB(x, y++, Color.MAGENTA.getRGB());
		if (y >= MAX_ROW) {
			x++;
			y = 0;
		}
		img.setRGB(x, y++, Color.ORANGE.getRGB());
		if (y >= MAX_ROW) {
			x++;
			y = 0;
		}
		img.setRGB(x, y++, Color.PINK.getRGB());
		if (y >= MAX_ROW) {
			x++;
			y = 0;
		}
		img.setRGB(x, y++, Color.RED.getRGB());
		if (y >= MAX_ROW) {
			x++;
			y = 0;
		}
		img.setRGB(x, y++, Color.YELLOW.getRGB());

	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		Graphics gg = this.pnlImg.getGraphics();
		gg.drawImage(img, 0, 0, img.getWidth() * 20, img.getHeight() * 20, this);
		gg.setColor(Color.GRAY);
		for (int x = 0; x < MAX_COL * 20; x = x + 20)
			for (int y = 0; y < MAX_ROW * 20; y = y + 20) {
				gg.drawRect(x, y, 20, 20);
			}
	}

	public Color getSelectedColor(int x, int y) {
		try {
			if (x >= 0 && x < this.img.getWidth() && y >= 0 && y < this.img.getHeight()) {
				Color color = new Color(this.img.getRGB(x, y));
				this.pnlRecent.setBackground(color);
				this.lblRgb.setText(color.getRed() + "," + color.getGreen() + "," + color.getBlue());
				return color;
			}
		} catch (Exception e) {
			e.printStackTrace();

		}
		return Color.BLACK;
	}

	public void setCurrentColor(Color color) {
		this.pnlRecent.setBackground(color);
	}

	void addButtonToList(ActionListener listener) {
		for (int i = 0; i < MAX_COL; i++) {
			JButton btn = new ButtonColor(listener, Color.WHITE, "Select Color");
			btn.setBackground(Color.WHITE);
			this.colorList.add(btn);
		}
	}

	public void addRecentColor(Color color) {
		if (index >= this.colorList.size()) {
			index = 0;
		}
		this.colorList.get(index).setBackground(color);
		index++;
	}

	public void addColorPaneListener() {
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
	}

	public void removeColorPaneListener() {
		this.removeMouseListener(this);
		this.removeMouseMotionListener(this);
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseDragged(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseMoved(MouseEvent e) {
		int x = e.getX() / 20;
		int y = e.getY() / 20;
		this.getSelectedColor(x, y);
	}

	@Override
	public void mousePressed(MouseEvent e) {
		int x = e.getX() / 20;
		int y = e.getY() / 20;
		Color color = this.getSelectedColor(x, y);

		if (e.getButton() == MouseEvent.BUTTON3) {
			this.setVisible(false);
			Color color1 = JColorChooser.showDialog(this, "Custom Colors", color);
			this.setVisible(true);
			if (color1 != null) {
				this.addRecentColor(color1);
			}
		} else {
			this.addRecentColor(color);
			this.parent.setSelectedColor(color);
			this.removeColorPaneListener();
			this.setVisible(false);
		}
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {

	}

	@Override
	public void actionPerformed(ActionEvent e) {

		Color color = ((JButton) e.getSource()).getBackground();
		this.parent.setSelectedColor(color);
		removeColorPaneListener();
		this.setVisible(false);
	}

	class ImgPane extends JPanel {
		private static final long serialVersionUID = 1L;
		BufferedImage img;

		public ImgPane(BufferedImage img) {
			this.img = img;
		}

		@Override
		public void paint(Graphics g) {
			g.drawImage(img, 0, 0, img.getWidth() * 20, img.getHeight() * 20, this);
			g.setColor(Color.GRAY);
			for (int x = 0; x < MAX_COL * 20; x = x + 20)
				for (int y = 0; y < MAX_ROW * 20; y = y + 20) {
					g.drawRect(x, y, 20, 20);
				}
		}
	}
}