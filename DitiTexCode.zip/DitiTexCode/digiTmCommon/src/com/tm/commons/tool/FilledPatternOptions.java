package com.tm.commons.tool;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.image.BufferedImage;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

import com.tm.commons.components.pane.ImagePane;
import com.tm.commons.theme.DigiTmTheme;

public class FilledPatternOptions extends JButton implements ActionListener {
	private static final long serialVersionUID = -9058291449556558569L;
	JPopupMenu popup = new JPopupMenu();

	public FilledPatternOptions(MouseAdapter listener) {
		super();
		this.setBackground(DigiTmTheme.getBgColor());
		this.setBorder(DigiTmTheme.getLineBorder());
		URL url = this.getClass().getResource("/img/expand-right.jpg");
		if (url != null) {
			this.setIcon(new ImageIcon(url));
		}

		this.setPreferredSize(new Dimension(11, 20));
		this.popup.setBackground(DigiTmTheme.getHighlightColor());
		this.setBorder(DigiTmTheme.getLineBorder());
		this.popup.add(addfillOption(listener));
		this.popup.setSize(60, 320);
		this.popup.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
		this.addActionListener(this);
	}

	JPanel addfillOption(MouseAdapter patternChangeHandler) {
		JPanel panel = new JPanel(new GridLayout(4, 2, 2, 2));
		panel.setPreferredSize(new Dimension(60, 120));
		panel.setOpaque(false);
		panel.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));

		panel.add(getPatternPane("/img/pattern/pat01.bmp", patternChangeHandler, true, false));
		panel.add(getPatternPane("/img/pattern/pat02.bmp", patternChangeHandler, true, false));
		panel.add(getPatternPane("/img/pattern/pat03.bmp", patternChangeHandler, true, false));
		panel.add(getPatternPane("/img/pattern/pat04.bmp", patternChangeHandler, true, false));
		panel.add(getPatternPane("/img/pattern/pat05.bmp", patternChangeHandler, true, false));
		panel.add(getPatternPane("/img/pattern/pat06.bmp", patternChangeHandler, true, false));
		panel.add(getPatternPane("/img/pattern/pat07.bmp", patternChangeHandler, true, false));
		panel.add(getPatternPane("/img/pattern/pat-cust.bmp", patternChangeHandler, false, true));
		add(panel);

		return panel;
	}

	ImagePane getPatternPane(String path, MouseAdapter patternChangeHandler, boolean pattern, boolean custom) {
		ImagePane pane = null;
		try {
			BufferedImage img = ImageIO.read(this.getClass().getResource(path));
			pane = new ImagePane(img, false, false, patternChangeHandler, true, pattern, custom);
		} catch (Exception e) {
			pane = new ImagePane(null, false, false, patternChangeHandler, true, pattern, custom);
		}

		return pane;
	}

	@Override
	protected void paintComponent(Graphics g) {
		if (getModel().isRollover()) {
			this.setBackground(DigiTmTheme.getHighlightColor());
		} else if (getModel().isPressed()) {
			setBorder(BorderFactory.createLoweredBevelBorder());
		} else {
			setBorder(BorderFactory.createEmptyBorder());
			this.setBackground(DigiTmTheme.getBgColor());
		}

		super.paintComponent(g);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton) e.getSource();
		int x = btn.getLocationOnScreen().x + btn.getWidth() - this.popup.getWidth();
		int y = btn.getLocationOnScreen().y + btn.getHeight();
		this.popup.setLocation(x, y);
		this.popup.setVisible(!this.popup.isVisible());
		if (this.popup.isVisible()) {
			this.setBackground(DigiTmTheme.getHighlightColor());
		} else {
			this.setBackground(DigiTmTheme.getBgColor());
		}
	}

	public boolean isVisiblePopup() {
		return this.popup.isVisible();
	}

	public void setVisiblePopup(boolean visible) {
		this.popup.setVisible(visible);
		if (this.popup.isVisible()) {
			this.setBackground(DigiTmTheme.getHighlightColor());
		} else {
			this.setBackground(DigiTmTheme.getBgColor());
		}
	}
}
