package com.tm.commons.tool;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

public class ColorImagePane extends JPanel implements MouseListener {
	BufferedImage img;
	Color selectedColor;
	int selX = -1;
	int selY = -1;

	public ColorImagePane(BufferedImage img) {
		this.img = img;
		this.setPreferredSize(new Dimension(img.getWidth() * 20, img.getHeight() * 20));
		this.addMouseListener(this);
	}

	@Override
	public void paint(Graphics g) {
		g.drawImage(this.img, 0, 0, img.getWidth() * 20, img.getHeight() * 20, this);
		if (selX >= 0 && selY >= 0) {
			g.setColor(Color.GRAY);
			g.drawRect(selX * 20, selY * 20, 20, 20);
		}
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		selX = e.getX() / 20;
		selY = e.getY() / 20;

		if (selX < this.img.getWidth() && selY < this.img.getHeight()) {
			this.selectedColor = new Color(this.img.getRGB(selX, selY));
			this.repaint();
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	public Color getSelectedColor() {
		return this.selectedColor;
	}
}
