package com.tm.commons.tool;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

import com.tm.commons.components.button.ButtonColor;
import com.tm.commons.listener.ColorChangeListener;

public class DropdownColorChooser extends JPanel implements ActionListener {
	private static final long serialVersionUID = 3922112817467339015L;
	JButton btnColor1;
	JButton btnColor2;
	ColorChangeListener listener;
	ColorPane colorPane;

	public DropdownColorChooser(ColorChangeListener listener) {
		super();
		this.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 0));
		this.setPreferredSize(new Dimension(36, 18));
		this.setSize(36, 18);
		this.listener = listener;
		btnColor1 = new ButtonColor(this, Color.BLACK, "Selected Color");
		btnColor2 = new ButtonColor(this, Color.WHITE, "Current Color");
		btnColor1.setBackground(Color.BLACK);
		btnColor2.setBackground(Color.WHITE);
		btnColor1.setPreferredSize(new Dimension(18, 18));
		btnColor2.setPreferredSize(new Dimension(18, 18));
		this.add(btnColor1);
		this.add(btnColor2);
	}

	public DropdownColorChooser(ColorChangeListener listener, boolean pickColor) {
		super();
		this.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 0));
		this.setPreferredSize(new Dimension(36, 18));
		this.setSize(36, 18);
		this.listener = listener;
		btnColor1 = new ButtonColor(this, Color.BLACK, "Selected Color");
		btnColor1.setBackground(Color.BLACK);
		btnColor1.setPreferredSize(new Dimension(18, 18));
		this.add(btnColor1);

		if (pickColor) {
			btnColor2 = new ButtonColor(this, Color.WHITE, "Current Color");
			btnColor2.setBackground(Color.WHITE);
			btnColor2.setPreferredSize(new Dimension(18, 18));
			this.add(btnColor2);
		}
	}

	public void addColorPane(ColorPane colorPane) {
		this.colorPane = colorPane;
	}

	public void addColorPaneListener() {
		this.colorPane.addColorPaneListener();
	}

	public void removeColorPaneListener() {
		this.colorPane.removeColorPaneListener();
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		this.showColorPane();
	}

	private void showColorPane() {
		Point p = this.getLocationOnScreen();
		int x = p.x;
		int y = p.y + this.getHeight() - 2;
		this.colorPane.setLocation(x, y);
		this.colorPane.setVisible(!this.colorPane.isVisible());
		if (this.colorPane.isVisible()) {
			this.colorPane.setParent(this);
			this.addColorPaneListener();
		} else {
			this.removeColorPaneListener();
		}
	}

	public Color getSelectedColor() {
		return this.btnColor1.getBackground();
	}

	public void setSelectedColor(Color color) {
		this.btnColor1.setBackground(color);
		this.listener.colorChanged(color);
	}

	public void pickColor(Color color) {
		if (this.btnColor2 != null) {
			this.btnColor2.setBackground(color);
		}
	}

	public void setPickColor(Color color)
	{
		this.btnColor2.setBackground(color);
	}
	
	public Color getPickColor() {
		return this.btnColor2.getBackground();
	}

	public void selectColor() {
		if (this.btnColor2 != null) {
			Color color = btnColor2.getBackground();
			this.btnColor1.setBackground(color);
			this.listener.colorChanged(color);
		}
	}
}
