package com.tm.commons.clipboard;

import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.image.BufferedImage;

public class ClipboardUtil {
	public static void copyToClipboard(BufferedImage image) {
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		TransferableImage transfer = new TransferableImage(image);
		clipboard.setContents(transfer, null);
	}

	public static BufferedImage getImageFromClipboard() {
		BufferedImage image = null;
		Transferable transfer = Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null);

		if (transfer != null && transfer.isDataFlavorSupported(DataFlavor.imageFlavor)) {
			try {
				image = (BufferedImage) transfer.getTransferData(DataFlavor.imageFlavor);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return image;
	}

	public static boolean hasClipboardImage() {
		Transferable transfer = Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null);
		return transfer != null && transfer.isDataFlavorSupported(DataFlavor.imageFlavor);
	}
}
