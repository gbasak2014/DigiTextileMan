package com.tm.commons.dto;

import java.awt.Color;
import java.util.Properties;

public class GridOptions {
	int zoom;
	Color colorUnit;
	Color colorPoint;
	Color colorPoint1;
	int point;

	public GridOptions() {
		this.zoom = 10;
		this.colorUnit = Color.GRAY;
		this.colorPoint = Color.BLACK;
	}

	public void loadProperties(Properties props) {
		try {
			this.zoom = Integer.parseInt(props.getProperty(DigiTmConstants.PROP_GRID_ZOOM));
		} catch (Exception e) {
			this.zoom = 10;
		}

		try {
			this.colorUnit = new Color(Integer.parseInt(props.getProperty(DigiTmConstants.PROP_GRID_UNIT_COLOR)));
		} catch (Exception e) {
			this.colorUnit = Color.DARK_GRAY;
		}

		try {
			this.colorPoint = new Color(Integer.parseInt(props.getProperty(DigiTmConstants.PROP_GRID_POINT_COLOR)));
		} catch (Exception e) {
			this.colorPoint = Color.BLACK;
		}

		try {
			this.colorPoint1 = new Color(Integer.parseInt(props.getProperty(DigiTmConstants.PROP_GRID_POINT_COLOR_1)));
		} catch (Exception e) {
			this.colorPoint1 = Color.BLACK;
		}
		
		try {
			this.point = Integer.parseInt(props.getProperty(DigiTmConstants.PROP_GRID_POINT));
		} catch (Exception e) {
			this.point = 10;
		}

	}

	public void updateProperties(Properties props) {
		props.put(DigiTmConstants.PROP_GRID_ZOOM, String.valueOf(this.getZoom()));
		props.put(DigiTmConstants.PROP_GRID_UNIT_COLOR, String.valueOf(this.getColorUnit().getRGB()));
		props.put(DigiTmConstants.PROP_GRID_POINT_COLOR, String.valueOf(this.getColorPoint().getRGB()));
		props.put(DigiTmConstants.PROP_GRID_POINT_COLOR_1, String.valueOf(this.getColorPoint1().getRGB()));
		props.put(DigiTmConstants.PROP_GRID_POINT, String.valueOf(this.point));
	}

	public int getZoom() {
		return zoom;
	}

	public Color getColorUnit() {
		return colorUnit;
	}

	public void setZoom(int zoom) {
		this.zoom = zoom;
	}

	public void setColorUnit(Color colorUnit) {
		this.colorUnit = colorUnit;
	}

	public Color getColorPoint() {
		return colorPoint;
	}

	public void setColorPoint(Color colorPoint) {
		this.colorPoint = colorPoint;
	}
	
	public Color getColorPoint1() {
		return colorPoint1;
	}
	
	public void setColorPoint1(Color colorPoint1) {
		this.colorPoint1 = colorPoint1;
	}

	public int getPoint() {
		return point;
	}

	public void setPoint(int point) {
		this.point = point;
	}
}
