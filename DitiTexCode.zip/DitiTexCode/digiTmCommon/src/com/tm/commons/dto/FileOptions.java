package com.tm.commons.dto;

import java.util.Properties;

public class FileOptions {
	String graphFilePath;
	String imageFilePath;
	String motifFilePath;
	String designFilePath;

	public void setProperties(Properties props) {
		this.setGraphFilePath(props.getProperty(DigiTmConstants.PROP_GRAPH_FILE_PATH));
		this.setImageFilePath(props.getProperty(DigiTmConstants.PROP_IMAGE_FILE_PATH));
		this.setMotifFilePath(props.getProperty(DigiTmConstants.PROP_MOTIF_FILE_PATH));
		this.setDesignFilePath(props.getProperty(DigiTmConstants.PROP_DESIGN_FILE_PATH));
	}

	public void updateProperties(Properties props) {
		if (getGraphFilePath() != null)
			props.put(DigiTmConstants.PROP_GRAPH_FILE_PATH, getGraphFilePath());

		if (getImageFilePath() != null)
			props.put(DigiTmConstants.PROP_IMAGE_FILE_PATH, getImageFilePath());

		if (getMotifFilePath() != null)
			props.put(DigiTmConstants.PROP_MOTIF_FILE_PATH, getMotifFilePath());

		if (getDesignFilePath() != null)
			props.put(DigiTmConstants.PROP_DESIGN_FILE_PATH, getDesignFilePath());
	}

	public String getGraphFilePath() {
		return graphFilePath;
	}

	public String getImageFilePath() {
		return imageFilePath;
	}

	public String getDesignFilePath() {
		return designFilePath;
	}

	public void setGraphFilePath(String graphFilePath) {
		this.graphFilePath = graphFilePath;
	}

	public void setImageFilePath(String imageFilePath) {
		this.imageFilePath = imageFilePath;
	}

	public void setDesignFilePath(String designFilePath) {
		this.designFilePath = designFilePath;
	}

	public String getMotifFilePath() {
		return motifFilePath;
	}

	public void setMotifFilePath(String motifFilePath) {
		this.motifFilePath = motifFilePath;
	}

}
