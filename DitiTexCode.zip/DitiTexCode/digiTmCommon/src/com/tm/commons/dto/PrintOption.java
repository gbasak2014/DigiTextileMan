package com.tm.commons.dto;

import java.awt.Font;
import java.util.Properties;

public class PrintOption {
	String header;
	String footer;
	//boolean pageNo;
	//boolean pageHeader;

	boolean printPath;

	Font font;
	int lineSpace;

	public PrintOption() {
	}

	public void setProperties(Properties props) {

		this.setPrintPath("TRUE".equalsIgnoreCase(props.getProperty(DigiTmConstants.PROP_PRINT_PATH)));
		this.setHeader(props.getProperty(DigiTmConstants.PROP_PRINT_HEADER) == null ? "" : props.getProperty(DigiTmConstants.PROP_PRINT_HEADER));
		this.setFooter(props.getProperty(DigiTmConstants.PROP_PRINT_FOOTER) == null ? "" : props.getProperty(DigiTmConstants.PROP_PRINT_FOOTER));
		//this.setPageNo("TRUE".equalsIgnoreCase(props.getProperty(DigiTmConstants.PROP_PRINT_PG_NO)));
		//this.setPageHeader("TRUE".equalsIgnoreCase(props.getProperty(DigiTmConstants.PROP_PRINT_PG_HEADER)));
		String fontFamily = props.getProperty(DigiTmConstants.PROP_PRINT_FONT);
		if (fontFamily != null) {
			String family = fontFamily.split("#")[0];
			int style = Integer.parseInt(fontFamily.split("#")[1]);
			int size = Integer.parseInt(fontFamily.split("#")[2]);
			this.font = new Font(family, style, size);
		} else {
			this.font = new Font("Arial", Font.PLAIN, 10);
		}

		try {
			this.lineSpace = Integer.parseInt(props.getProperty(DigiTmConstants.PROP_PRINT_LINE_SPACE));
		} catch (Exception e) {
		}
	}

	public void updateProperties(Properties props) {
		props.put(DigiTmConstants.PROP_PRINT_HEADER, this.getHeader());
		props.put(DigiTmConstants.PROP_PRINT_FOOTER, this.getFooter());
		//props.put(DigiTmConstants.PROP_PRINT_PG_HEADER, String.valueOf(this.isPageHeader()));
		//props.put(DigiTmConstants.PROP_PRINT_PG_NO, String.valueOf(this.isPageNo()));

		props.put(DigiTmConstants.PROP_PRINT_FONT, font.getFamily() + "#" + font.getStyle() + "#" + font.getSize());
		props.put(DigiTmConstants.PROP_PRINT_LINE_SPACE, String.valueOf(this.getLineSpace()));
		props.put(DigiTmConstants.PROP_PRINT_PATH, String.valueOf(this.isPrintPath()));
	}

	public String getHeader() {
		return header;
	}

	public String getFooter() {
		return footer;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public void setFooter(String footer) {
		this.footer = footer;
	}

	public Font getFont() {
		return font;
	}

	public int getLineSpace() {
		return lineSpace;
	}

	public void setFont(Font font) {
		this.font = font;
	}

	public void setLineSpace(int lineSpace) {
		this.lineSpace = lineSpace;
	}

	public boolean isPrintPath() {
		return printPath;
	}

	public void setPrintPath(boolean printPath) {
		this.printPath = printPath;
	}
	
/*
	public boolean isPageNo() {
	return pageNo;
}

public boolean isPageHeader() {
	return pageHeader;
}
public void setPageNo(boolean pageNo) {
	this.pageNo = pageNo;
}

public void setPageHeader(boolean pageHeader) {
	this.pageHeader = pageHeader;
}
*/

}
