package com.tm.commons.dto;

import java.io.File;

public interface DigiTmConstants {
	String PROP_MOTIF_HOME = "libOptions.motif.home";
	String PROP_CODE_HOME = "libOptions.code.home";
	String PROP_WEAVE_HOME = "libOptions.weave.home";
	String PROP_KEY_PATH = "libOptions.key.path";
	String PROP_SCANNER_PATH = "libOptions.scanner.path";
	String PROP_NEW_APP = "libOptions.newApp.path";

	String PROP_GRID_ZOOM = "gridOptions.zoom";
	String PROP_GRID_UNIT_COLOR = "gridOptions.unit.color";
	String PROP_GRID_POINT_COLOR = "gridOptions.point.color";
	String PROP_GRID_POINT_COLOR_1 = "gridOptions.point.color.1";
	String PROP_GRID_10TH_COLOR = "gridOptions.10th.color";
	String PROP_GRID_POINT = "gridOptions.point";

	String PROP_GRAPH_FILE_PATH = "graph.file.path";
	String PROP_DESIGN_FILE_PATH = "design.file.path";
	String PROP_MOTIF_FILE_PATH = "motif.file.path";
	String PROP_IMAGE_FILE_PATH = "image.file.path";

	String PROP_PRINT_PATH = "print.path";
	String PROP_PRINT_HEADER = "print.header";
	String PROP_PRINT_FOOTER = "print.footer";
	String PROP_PRINT_PG_NO = "print.pg.no";
	String PROP_PRINT_PG_HEADER = "print.pg.header";
	String PROP_PRINT_FONT = "print.font";
	String PROP_PRINT_LINE_SPACE = "print.line.space";

	String PROP_FILE_WEAVE = System.getProperty("user.home") + "/digitex/init/weave.ini";
	String PROP_FILE_MOTIF = System.getProperty("user.home") + "/digitex/init/motif.ini";
	String PROP_HIST_MOTIF = System.getProperty("user.home") + "/digitex/init/motif-hist.ini";
	String PROP_FILE_DESIGN = System.getProperty("user.home") + "/digitex/init/design.ini";

	String PROP_CUSTOM_CURSOR = "custom.cursor";

	String PROP_TEMP_DIR = "java.io.tmpdir";
	String APP_NAME = "digitm";

	byte[] x = { 84, 101, 120, 116, 105, 108, 101, 32, 77, 97, 110, 97, 103, 101, 114, 45, 32, 78, 111, 116, 32, 102,
			111, 114, 32, 83, 97, 108, 101 };
	byte[] xx = { 68, 105, 103, 105, 84, 101, 120, 32, 45, 32, 67, 111, 109, 112, 117, 116, 101, 114, 32, 65, 105, 100,
			101, 100, 32, 84, 101, 120, 116, 105, 108, 101, 32, 68, 101, 115, 105, 103, 110, 32, 83, 121, 115, 116, 101,
			109 };
	String title = new String(xx) + " - Dedicated to Shourya Basak (Free Version)";

	String logo = "/img/mc-logo.jpg";

	byte[] dev_by = { 68, 101, 115, 105, 103, 110, 101, 100, 32, 97, 110, 100, 32, 68, 101, 118, 101, 108, 111, 112,
			101, 100, 32, 98, 121, 32, 71, 111, 117, 114, 97, 110, 103, 97, 32, 66, 97, 115, 97, 107 };
	byte[] lck = { 83, 104, 111, 56, 82, 55, 97 };

	// byte[] usr = { 65, 106, 105, 116, 32, 66, 97, 115, 97, 107 };
	byte[] author = { 71, 111, 117, 114, 97, 110, 103, 97, 32, 66, 97, 115, 97, 107 };
	byte[] email = { 103, 98, 46, 116, 101, 120, 116, 105, 108, 101, 109, 97, 110, 64, 103, 109, 97, 105, 108, 46, 99,
			111, 109 };

	byte SEED = 5;

	String keyPathWin = System.getProperty(new String(new byte[] { 117, 115, 101, 114, 46, 104, 111, 109, 101 }))
			+ File.separator + new String(new byte[] { 116, 109, 45, 107, 101, 121 });

	String keyPathUnix = System.getProperty(new String(new byte[] { 117, 115, 101, 114, 46, 104, 111, 109, 101 }))
			+ File.separator + new String(new byte[] { 46, 117, 110, 105, 120, 100, 116, 107, 101, 121 });

	String digiTex = new String(new byte[] { 68, 105, 103, 105, 84, 101, 120 });

	String dHvLckAA = new String(new byte[] { 68, 111, 32, 121, 111, 117, 32, 104, 97, 118, 101, 32, 76, 111, 99, 107,
			32, 70, 105, 108, 101, 63 });

	String dHvPKey = new String(new byte[] { 68, 111, 32, 121, 111, 117, 32, 104, 97, 118, 101, 32, 112, 114, 105, 118,
			97, 116, 101, 32, 107, 101, 121, 32, 102, 105, 108, 101, 63 });
	String svLck = new String(new byte[] { 75, 105, 110, 100, 108, 121, 32, 103, 101, 110, 101, 114, 97, 116, 101, 32,
			121, 111, 117, 114, 32, 107, 101, 121, 32, 97, 110, 100, 32, 115, 101, 110, 100, 32, 102, 111, 114, 32, 112,
			114, 105, 118, 97, 116, 101, 32, 107, 101, 121, 32, 102, 105, 108, 101 });
	String msgUnAuthSel = new String(new byte[] { 79, 111, 112, 115, 32, 121, 111, 117, 32, 97, 114, 101, 32, 110, 111,
			116, 32, 97, 117, 116, 104, 111, 114, 105, 122, 101, 100, 44, 32, 83, 101, 108, 101, 99, 116, 32, 107, 101,
			121, 32, 102, 105, 108, 101, 46, 46, 46 });
	String msgUnAuth = new String(new byte[] { 79, 111, 112, 115, 32, 121, 111, 117, 32, 97, 114, 101, 32, 110, 111,
			116, 32, 97, 117, 116, 104, 111, 114, 105, 122, 101, 100, 33, 33, 33 });
	String genKey = new String(new byte[] { 71, 101, 110, 101, 114, 97, 116, 101, 32, 75, 101, 121 });

	String ERROR_FILE="digitex.log";
	
}
