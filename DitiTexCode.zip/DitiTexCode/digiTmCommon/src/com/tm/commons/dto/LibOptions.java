package com.tm.commons.dto;

import java.util.Properties;

public class LibOptions {
	String motifHome = "motifHome";
	String weaveHome = "weaveHome";
	String codeHome = "codeHome";
	String keyPath = "keyPath";
	String scannerPath;
	String newApp;

	public void setProperties(Properties props) {
		this.setMotifHome(props.getProperty(DigiTmConstants.PROP_MOTIF_HOME, "motif"));
		this.setWeaveHome(props.getProperty(DigiTmConstants.PROP_WEAVE_HOME, "weave"));
		this.setCodeHome(props.getProperty(DigiTmConstants.PROP_CODE_HOME, "code"));
		this.setKeyPath(props.getProperty(DigiTmConstants.PROP_KEY_PATH, "key"));
		this.setScannerPath(props.getProperty(DigiTmConstants.PROP_SCANNER_PATH, "NULL"));
		this.setNewApp(props.getProperty(DigiTmConstants.PROP_NEW_APP, "NULL"));
	}

	public void updateProperties(Properties props) {
		props.put(DigiTmConstants.PROP_MOTIF_HOME, this.getMotifHome());
		props.put(DigiTmConstants.PROP_WEAVE_HOME, this.getWeaveHome());
		props.put(DigiTmConstants.PROP_CODE_HOME, this.getCodeHome());
		props.put(DigiTmConstants.PROP_KEY_PATH, this.getKeyPath());
		props.put(DigiTmConstants.PROP_SCANNER_PATH, this.getScannerPath() != null ? this.getScannerPath() : "");
		props.put(DigiTmConstants.PROP_NEW_APP, this.getNewApp() == null ? "NULL" : this.getNewApp());
	}

	public String getCodeHome() {
		return codeHome;
	}

	public void setCodeHome(String codeHome) {
		this.codeHome = codeHome;
	}

	public String getKeyPath() {
		return keyPath;
	}

	public void setKeyPath(String keyPath) {
		this.keyPath = keyPath;
	}

	public String getMotifHome() {
		return motifHome;
	}

	public String getWeaveHome() {
		return weaveHome;
	}

	public void setMotifHome(String motifHome) {
		this.motifHome = motifHome;
	}

	public void setWeaveHome(String weaveHome) {
		this.weaveHome = weaveHome;
	}

	public String getScannerPath() {
		return this.scannerPath;
	}

	public void setScannerPath(String scannerPath) {
		this.scannerPath = scannerPath;
	}

	public String getNewApp() {
		return newApp;
	}

	public void setNewApp(String newApp) {
		this.newApp = newApp;
	}
	
	@Override
	public String toString() {
		
		return  "libOptions: {\n codeHome:" + this.codeHome + ",\n codeHome:" + this.codeHome + ",\n motifHome" + this.motifHome + ",\n weaveHome: " + this.weaveHome + ",\n scannerPath: " + this.scannerPath + ",\n newApp: " + this.newApp + "}";
	}
}
