package com.tm.commons.dto;

import java.util.Properties;

public class OtherOptions {
	boolean customCursor;

	public boolean isCustomCursor() {
		return customCursor;
	}

	public void setCustomCursor(boolean customCursor) {
		this.customCursor = customCursor;
	}

	public void loadProperties(Properties props) {
		try {
			this.customCursor = Boolean.parseBoolean((props.getProperty(DigiTmConstants.PROP_CUSTOM_CURSOR)));
		} catch (Exception e) {
			this.customCursor = false;
		}
	}

	public void updateProperties(Properties props) {
		props.put(DigiTmConstants.PROP_CUSTOM_CURSOR, String.valueOf(this.isCustomCursor()));
	}

}
