package com.tm.commons.undo;

import java.io.File;

import javax.imageio.ImageIO;

import com.tm.commons.image.ImageUtils;

public class Undoable {
	UndoType dataType;

	String imagePath;
	int x, y;
	int width;
	int height;
	
	int data[];

	public Undoable(String imagePath) {
		this(imagePath, -1, -1, -1, -1);
	}

	public Undoable(String imagePath, int x, int y, int width, int height) {
		this.dataType = UndoType.IMAGE;
		this.imagePath = imagePath;
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}

	public Undoable(int data[]) {
		this.dataType = UndoType.POINTS;
		this.data = data;
	}

	public UndoType getDataType() {
		return this.dataType;
	}

	public Object getObject() {
		if (this.dataType == UndoType.POINTS) {
			return this.data;
		}

		try {
			return ImageUtils.copyImage(ImageIO.read(new File(this.imagePath)));
		} catch (Exception e) {
		}

		return null;
	}

	public int getX() {
		return this.x;
	}

	public int getY() {
		return this.y;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}
}
