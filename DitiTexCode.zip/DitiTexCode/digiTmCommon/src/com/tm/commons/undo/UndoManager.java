package com.tm.commons.undo;

import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayDeque;
import java.util.Deque;

import javax.imageio.ImageIO;

import com.tm.commons.components.pane.GraphPane;

public class UndoManager {
	String resuourcePath;
	Deque<Undoable> undoLog = new ArrayDeque<Undoable>();
	Deque<Undoable> redoLog = new ArrayDeque<Undoable>();
	Deque<Undoable> undoBakLog = new ArrayDeque<Undoable>();

	GraphPane graphPane;

	int undoLimit;

	public UndoManager(String resuourcePath, GraphPane graphPane) {
		this.resuourcePath = resuourcePath;
		this.graphPane = graphPane;
		validateUniqueName();
		this.undoLimit = 20;

		try {
			File dir = new File(this.resuourcePath);
			if (!dir.exists()) {
				dir.mkdirs();
			}
		} catch (Exception e) {
		}
	}

	private void validateUniqueName() {
		int i = 1;
		File file = new File(this.resuourcePath);
		while (file.exists()) {
			this.resuourcePath = this.resuourcePath + "_" + i;
			file = new File(this.resuourcePath);
			i++;
		}

		file.mkdirs();
	}

	public void addUndoState(Undoable log) {
		this.redoLog.clear();
		this.undoBakLog.clear();
		this.undoLog.push(log);
		if (this.undoLog.size() > this.undoLimit) {
			this.undoLog.removeLast();
		}
	}

	public void addUndoState(int x, int y, BufferedImage img) {
		try {
			String path = this.resuourcePath + File.separator + System.currentTimeMillis();
			File file = new File(path);
			ImageIO.write(img, "BMP", file);
			this.addUndoState(new Undoable(path, x, y, img.getWidth(), img.getHeight()));
		} catch (Exception e) {
		}
	}

	private void addRedoState(int[] data) {
		this.addRedoState(new Undoable(data));
	}

	private void addRedoState(Undoable log) {
		this.redoLog.push(log);
	}

	private void addRedoState(int x, int y, BufferedImage img) {
		try {
			String path = this.resuourcePath + File.separator + System.currentTimeMillis();
			File file = new File(path);
			ImageIO.write(img, "BMP", file);
			this.addRedoState(new Undoable(path, x, y, img.getWidth(), img.getHeight()));
		} catch (Exception e) {
		}
	}

	public void addUndoState(int[] data) {
		this.addUndoState(new Undoable(data));
	}

	public Undoable undo() {
		Undoable state = null;
		if (this.undoLog.size() > 0) {
			state = this.undoLog.pop();
			this.undoBakLog.push(state);

			if (state.getDataType() == UndoType.IMAGE) {
				BufferedImage img = this.graphPane.getSavedImage();
				if (state.getX() >= 0 && state.getY() >= 0) {
					img = img.getSubimage(state.getX(), state.getY(), state.getWidth(), state.getHeight());
				}

				this.addRedoState(state.getX(), state.getY(), img);
			} else {
				int[] data = (int[]) state.getObject();
				int[] redoData = new int[data.length];
				int i = 0;
				while (i < data.length - 2) {
					int x = redoData[i] = data[i];
					i++;
					int y = redoData[i] = data[i];
					i++;
					redoData[i] = this.graphPane.getSavedImage().getRGB(x, y);
					i++;
				}

				this.addRedoState(redoData);
			}
		}

		return state;
	}

	public Undoable redo() {
		if (this.redoLog.size() > 0) {
			this.undoLog.push(this.undoBakLog.pop());
			return this.redoLog.pop();
		}

		return null;
	}

	public String getResuourcePath() {
		return resuourcePath;
	}

	public int getUndoLimit() {
		return undoLimit;
	}

	public void setUndoLimit(int undoLimit) {
		this.undoLimit = undoLimit;
	}
}
