package com.tm.commons.undo;

public enum UndoType {
	IMAGE(1), POINTS(2);

	int value;

	private UndoType(int value) {
		this.value = value;
	}

	public UndoType fromInt(int value) {
		switch (value) {
		case 1:
			return IMAGE;
		case 2:
			return POINTS;
		default:
			return POINTS;
		}
	}

	public UndoType fromString(String value) {
		return fromInt(Integer.parseInt(value));
	}
}
