package com.tm.commons.image;

/**
 * Utility class for file operations
 * 
 * @author Gouranga Basak
 * 
 */
public class FileUtils {

	/**
	 * Check if filepath has the extension otherwise add this and return.
	 * 
	 * @param filePath
	 * @param ext
	 * @return
	 */
	public static String checkAndAddExt(String filePath, String ext) {
		if (filePath.toUpperCase().endsWith("." + ext.toUpperCase())) {
			return filePath;
		}

		return filePath + "." + ext;
	}
}
