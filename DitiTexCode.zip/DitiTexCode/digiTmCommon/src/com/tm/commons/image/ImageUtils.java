package com.tm.commons.image;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.awt.image.FilteredImageSource;
import java.awt.image.ImageFilter;
import java.awt.image.ImageProducer;
import java.awt.image.RGBImageFilter;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.URL;
import java.util.ArrayDeque;
import java.util.Deque;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

import com.tm.commons.dto.PrintOption;

/**
 * The Image processor class responsible for transformation of images.
 * 
 * @author Gouranga Basak
 * 
 */
public class ImageUtils {
	/**
	 * Process the image and convert specified color in the image transparent.
	 * 
	 * @param img
	 * @param color
	 * @return
	 */
	public static BufferedImage getTransperantImage(BufferedImage img, final Color color) {

		ImageFilter filter = new RGBImageFilter() {
			int marker = color.getRGB() | 0xFF000000;

			@Override
			public int filterRGB(int x, int y, int rgb) {
				if ((rgb | 0xFF000000) == marker) {
					return 0x00FFFFFF & rgb;
				}

				return rgb;
			}
		};

		ImageProducer ip = new FilteredImageSource(img.getSource(), filter);

		return imageToBufferedImage(Toolkit.getDefaultToolkit().createImage(ip));
	}

	public static BufferedImage getOpaqueImage(BufferedImage img, final Color color) {
		BufferedImage tmpImg = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_RGB);
		Graphics2D g = tmpImg.createGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, img.getWidth(), img.getHeight());
		g.drawImage(img, 0, 0, null);
		g.dispose();
		return tmpImg;
	}

	/**
	 * Convert Image into BufferedImage
	 * 
	 * @param img
	 * @return
	 */
	public static BufferedImage imageToBufferedImage(Image img) {
		BufferedImage newImg = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = newImg.createGraphics();

		g.drawImage(img, 0, 0, null);
		g.dispose();

		return newImg;
	}

	/**
	 * Check if the point is valid for the image.
	 * 
	 * @param img
	 * @param x
	 * @param y
	 * @return
	 */
	public static boolean isValidPoint(BufferedImage img, int x, int y) {
		return (x >= 0 && x < img.getWidth()) && (y >= 0 && y < img.getHeight());
	}

	/**
	 * Get the copy of the image to right.
	 * 
	 * @param img
	 * @return
	 */
	public static BufferedImage arrangeRight(BufferedImage img) {
		int w = img.getWidth();
		int h = img.getHeight();

		BufferedImage newImg = new BufferedImage(2 * w, h, BufferedImage.TYPE_INT_RGB);
		Graphics g = newImg.getGraphics();
		g.drawImage(img, 0, 0, null);
		g.drawImage(img, w, 0, null);

		return newImg;
	}

	/**
	 * Get the copy of the to down.
	 * 
	 * @param img
	 * @return
	 */
	public static BufferedImage arrangeDown(BufferedImage img) {
		int w = img.getWidth();
		int h = img.getHeight();

		BufferedImage newImg = new BufferedImage(w, 2 * h, BufferedImage.TYPE_INT_RGB);
		Graphics g = newImg.getGraphics();
		g.drawImage(img, 0, 0, null);
		g.drawImage(img, 0, h, null);

		return newImg;
	}

	/**
	 * Rotate image to the specified angle end return the image after rotation.
	 * 
	 * @param image
	 * @param angle
	 * @return
	 */
	public static BufferedImage rotate(BufferedImage image, int angle) {
		try {
			double r = Math.toRadians(angle);
			double sin = Math.abs(Math.sin(r));
			double cos = Math.abs(Math.cos(r));
			int w = image.getWidth();
			int h = image.getHeight();
			int neww = (int) Math.floor(w * cos + h * sin);
			int newh = (int) Math.floor(h * cos + w * sin);
			BufferedImage newImage = new BufferedImage(neww, newh, BufferedImage.TYPE_INT_RGB);
			Graphics2D g = newImage.createGraphics();

			g.setColor(Color.WHITE);
			g.fillRect(0, 0, neww, newh);
			g.translate((neww - w) / 2, (newh - h) / 2);
			g.rotate(r, w / 2, h / 2);
			g.drawRenderedImage(image, null);
			g.dispose();
			return newImage;
		} catch (Exception e) {
		}

		return image;
	}

	/**
	 * Flip image vertically
	 * 
	 * @param image
	 * @return
	 */
	public static BufferedImage flipVertical(BufferedImage image) {
		int w = image.getWidth();
		int h = image.getHeight();
		BufferedImage newImage = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
		Graphics2D g = newImage.createGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, w, h);
		g.drawImage(image, 0, h, w, -h, null);
		g.dispose();
		return newImage;
	}

	/**
	 * Flip image Horizontally
	 * 
	 * @param image
	 * @return
	 */
	public static BufferedImage flipHorizontal(BufferedImage image) {
		int w = image.getWidth();
		int h = image.getHeight();
		BufferedImage newImage = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
		Graphics2D g = newImage.createGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, w, h);
		g.drawImage(image, w, 0, -w, h, null);
		g.dispose();
		return newImage;
	}

	/**
	 * Save image to the path in specified type
	 * 
	 * @param image
	 * @param path
	 * @param type
	 * @return
	 */
	public static boolean saveImage(BufferedImage image, String path, String type) {
/*		if (image.getWidth() > 200) {
			JOptionPane.showMessageDialog(null,
					new String(new byte[] { 73, 109, 97, 103, 101, 32, 119, 105, 100, 116, 104, 32, 99, 97, 110, 32,
							110, 111, 116, 32, 98, 101, 32, 103, 114, 101, 97, 116, 101, 114, 32, 116, 104, 97, 110, 32,
							50, 48, 48, 32, 105, 110, 32, 84, 114, 105, 97, 108, 32, 101, 100, 105, 116, 105, 111,
							110 }));
			return false;
		}
		if (image.getHeight() > 200) {
			JOptionPane.showMessageDialog(null,
					new String(new byte[] { 73, 109, 97, 103, 101, 32, 104, 101, 105, 103, 104, 116, 32, 99, 97, 110,
							32, 110, 111, 116, 32, 98, 101, 32, 103, 114, 101, 97, 116, 101, 114, 32, 116, 104, 97, 110,
							32, 50, 48, 48, 32, 105, 110, 32, 84, 114, 105, 97, 108, 32, 101, 100, 105, 116, 105, 111,
							110 }));
			return false;
		}
*/
		try {
			return ImageIO.write(image, type, new File(path));
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Error saving image: " + e.getMessage());
		}

		return false;
	}

	/**
	 * Read image from specified file path
	 * 
	 * @param path
	 * @return
	 */
	public static BufferedImage loadImage(String path) {
		try {
			return ImageIO.read(new File(path));
		} catch (IOException e) {

		}

		return null;
	}

	public static void replaceColor(BufferedImage img, int rgb) {
		int rgbWhite = Color.WHITE.getRGB();
		int w = img.getWidth();
		int h = img.getHeight();
		for (int i = 0; i < w; i++)
			for (int j = 0; j < h; j++)
				if (img.getRGB(i, j) != rgbWhite)
					img.setRGB(i, j, rgb);

	}

	public static void replaceColor1(BufferedImage img, Color oldColor, Color newColor) {
		int oldRgb = oldColor.getRGB();
		int newRgb = newColor.getRGB();

		int[] imgData = ((DataBufferInt) img.getRaster().getDataBuffer()).getData();

		int len = imgData.length;
		for (int i = 0; i < len; i++) {
			if (imgData[i] != oldRgb) {
				imgData[i] = newRgb;
			}
		}

	}

	public static BufferedImage copyImage(BufferedImage image) {
		BufferedImage newImage = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_RGB);
		Graphics2D g = newImage.createGraphics();
		g.drawImage(image, 0, 0, null);
		g.dispose();
		return newImage;
	}

	public static BufferedImage getImageFromFile(String path) throws IOException {
		return copyImage(ImageIO.read(new File(path)));
	}

	public static BufferedImage insertRows(BufferedImage image, int pos, int rows) {
		BufferedImage newImage = null;

		if (rows > 0) {
			int w = image.getWidth();
			int h = image.getHeight();
			newImage = new BufferedImage(w, h + rows, BufferedImage.TYPE_INT_RGB);
			Graphics2D g = newImage.createGraphics();
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, w, h + rows);
			if (pos <= 0) {
				g.drawImage(image, 0, rows, null);
			} else if (pos + 1 >= h) {
				g.drawImage(image, 0, 0, null);
			} else {
				BufferedImage img1 = image.getSubimage(0, 0, w, pos);
				BufferedImage img2 = image.getSubimage(0, pos, w, h - pos);
				g.drawImage(img1, 0, 0, null);
				g.drawImage(img2, 0, pos + rows, null);
			}

			g.dispose();
		}

		return newImage;
	}

	public static BufferedImage insertCols(BufferedImage image, int pos, int cols) {
		BufferedImage newImage = null;

		if (cols > 0) {
			int w = image.getWidth();
			int h = image.getHeight();
			newImage = new BufferedImage(w + cols, h, BufferedImage.TYPE_INT_RGB);
			Graphics2D g = newImage.createGraphics();
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, w + cols, h);
			if (pos <= 0) {
				g.drawImage(image, cols, 0, null);
			} else if (pos + 1 >= w) {
				g.drawImage(image, 0, 0, null);
			} else {
				BufferedImage img1 = image.getSubimage(0, 0, pos, h);
				BufferedImage img2 = image.getSubimage(pos, 0, w - pos, h);
				g.drawImage(img1, 0, 0, null);
				g.drawImage(img2, pos + cols, 0, null);
			}

			g.dispose();
		}

		return newImage;
	}

	public static BufferedImage removeRows(BufferedImage image, int startIndex, int endIndex) {
		BufferedImage newImage = null;
		BufferedImage img1 = null;
		BufferedImage img2 = null;
		int w = image.getWidth();
		int h = image.getHeight();
		int newH = 0;

		if (startIndex > 0) {
			img1 = image.getSubimage(0, 0, w, startIndex);
			newH = startIndex;
		}

		if (endIndex + 1 < h) {
			img2 = image.getSubimage(0, endIndex + 1, w, (h - endIndex - 1));
			newH = newH + (h - endIndex - 1);
		}

		newImage = new BufferedImage(w, newH, BufferedImage.TYPE_INT_RGB);
		Graphics2D g = newImage.createGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, w, newH);
		int pos2;
		if (img1 != null) {
			g.drawImage(img1, 0, 0, null);
			pos2 = img1.getHeight();
		} else {
			pos2 = 0;
		}

		if (img2 != null) {
			g.drawImage(img2, 0, pos2, null);
		}

		return newImage;
	}

	public static BufferedImage removeCols(BufferedImage image, int startIndex, int endIndex) {
		BufferedImage newImage = null;
		BufferedImage img1 = null;
		BufferedImage img2 = null;
		int w = image.getWidth();
		int h = image.getHeight();
		int newW = 0;

		if (startIndex > 0) {
			img1 = image.getSubimage(0, 0, startIndex, h);
			newW = startIndex;
		}

		if (endIndex + 1 < w) {
			img2 = image.getSubimage(endIndex + 1, 0, (w - endIndex - 1), h);
			newW = newW + (w - endIndex - 1);
		}

		newImage = new BufferedImage(newW, h, BufferedImage.TYPE_INT_RGB);
		Graphics2D g = newImage.createGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, newW, h);
		int pos2;
		if (img1 != null) {
			g.drawImage(img1, 0, 0, null);
			pos2 = img1.getWidth();
		} else {
			pos2 = 0;
		}

		if (img2 != null) {
			g.drawImage(img2, pos2, 0, null);
		}

		return newImage;
	}

	public static BufferedImage getDummyImage(BufferedImage img) {
		int x = 0;
		int y = 0;

		BufferedImage image = new BufferedImage(200, 200, BufferedImage.TYPE_INT_RGB);
		if (img.getWidth() < image.getWidth()) {
			x = (image.getWidth() - img.getWidth()) / 2;
		}

		if (img.getHeight() < image.getHeight()) {
			y = (image.getHeight() - img.getHeight()) / 2;
		}

		Graphics2D g = image.createGraphics();
		g.drawImage(img, x, y, null);

		String str1 = "Textile Manager";
		String str2 = "By Gouranga Basak";
		String str3 = "g_basak@rediffmail.com";
		String str4 = "gb.textileman@gmail.com";

		Font font = new Font("Arial", Font.BOLD, 16);
		g.setFont(font);
		g.setColor(Color.GREEN);
		g.fillArc(0, 0, 100, 100, 0, 360);

		FontMetrics fm = g.getFontMetrics(font);

		int h = fm.getHeight() + 5;

		AlphaComposite ac = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5F);
		g.setComposite(ac);
		g.setColor(Color.GRAY);
		y = 60;

		x = (200 - fm.stringWidth(str1)) / 2;
		g.drawString(str1, x, y);
		y = y + h;
		x = (200 - fm.stringWidth(str2)) / 2;
		g.drawString(str2, x, y);

		y = y + h;
		x = (200 - fm.stringWidth(str3)) / 2;
		g.drawString(str3, x, y);

		y = y + h;
		x = (200 - fm.stringWidth(str4)) / 2;
		g.drawString(str4, x, y);

		g.dispose();

		return image;
	}

	public static void floodFill(int[] drawingData, int newRgb, int imgWidth, int imgHeight, int x, int y) {

		int minX;
		int minY;
		int maxX;
		int maxY;

		minX = maxX = -1;
		minY = maxY = -1;

		// int newRgb = rgb | 0xff000000;

		Deque<Integer> queueX = new ArrayDeque<Integer>();
		Deque<Integer> queueY = new ArrayDeque<Integer>();

		queueX.push(x);
		queueY.push(y);
		minX = maxX = x;
		minY = maxY = x;
		drawingData[y * imgWidth + x] = newRgb;

		int cnt = 1;
		while (!queueX.isEmpty()) {
			cnt++;
			int px = queueX.pop();
			int py = queueY.pop();
			if (drawingData[py * imgWidth + px] != newRgb) {
				drawingData[py * imgWidth + px] = newRgb;

				if (minX > px) {
					minX = px;
				} else if (maxX < px) {
					maxX = px;
				}

				if (minY > py) {
					minY = py;
				} else if (maxY < py) {
					maxY = py;
				}

			}

			if (px - 1 >= 0 && newRgb != drawingData[py * imgWidth + (px - 1)]) {
				queueX.push(px - 1);
				queueY.push(py);
			}

			if (px + 1 < imgWidth && newRgb != drawingData[py * imgWidth + (px + 1)]) {
				queueX.push(px + 1);
				queueY.push(py);
			}

			if (py - 1 >= 0 && newRgb != drawingData[(py - 1) * imgWidth + px]) {
				queueX.push(px);
				queueY.push(py - 1);
			}

			if (py + 1 < imgHeight && newRgb != drawingData[(py + 1) * imgWidth + px]) {
				queueX.push(px);
				queueY.push(py + 1);
			}
		}
	}

	public static void drawLine(int[] data, int x1, int y1, int x2, int y2, int width, int height, int argb) {
		if (x1 == x2 && y1 == y2) {
			return;
		}

		int dx;
		int dy;

		int e = 0;
		int px = x1;
		int py = y1;
		int mx;
		int my;
		if (x1 < x2) {
			dx = x2 - x1;
			mx = 1;
		} else {
			dx = x1 - x2;
			mx = -1;
		}

		if (y1 < y2) {
			dy = y2 - y1;
			my = 1;
		} else {
			dy = y1 - y2;
			my = -1;
		}

		if (dx > dy) {
			while (px != x2) {
				if (py >= 0 && py < height && px >= 0 && px < width) {
					data[py * width + px] = argb;
				}

				if (2 * (e + dy) < dx) {
					e = e + dy;
				} else {
					py = py + my;
					e = e + dy - dx;
				}
				px = px + mx;
			}
		} else {
			while (py != y2) {

				if (py >= 0 && py < height && px >= 0 && px < width) {
					data[py * width + px] = argb;
				}

				if (2 * (e + dx) < dy) {
					e = e + dx;
				} else {
					px = px + mx;
					e = e + dx - dy;
				}
				py = py + my;
			}
		}

		if (y2 >= 0 && y2 < height && x2 >= 0 && x2 < width) {
			data[y2 * width + x2] = argb;
		}

	}

	public static int drawText(String user, String[] data, Graphics g, Font font, int x, int y, int imagableHeight,
			int lineSpace, PrintOption printOption) {

		g.setColor(new Color(240, 240, 240));
		g.setFont(new Font("Arial", Font.BOLD, 48));
		int h = g.getFontMetrics().getHeight() + 5;
		g.drawString("Designed By - ", x + 20, (y + imagableHeight / 2) - h);
		g.drawString(user, x + 20, y + imagableHeight / 2);

		g.setFont(font);
		FontMetrics fm = g.getFontMetrics();
		h = fm.getHeight() + lineSpace;
		g.setColor(Color.BLACK);

		if (printOption.getHeader() != null && printOption.getHeader().trim().length() > 0) {
			y = y + h;
			g.drawString(printOption.getHeader(), x, y);
		}

		if (data != null) {
			for (String line : data) {
				if (line == null) {
					break;
				}
				y = y + h;
				g.drawString(line, x, y);
			}
		}

		if (printOption.getFooter() != null && printOption.getFooter().trim().length() > 0) {
			y = y + h;
			g.drawString(printOption.getFooter(), x, y);
		}

		return y;
	}

	public static void loadPage(RandomAccessFile file, long seek, String[] data) throws IOException {
		int size = data.length;
		String line = null;
		int i;
		file.seek(seek);
		for (i = 0; i < size && (line = file.readLine()) != null; i++) {
			data[i] = line;
		}

		for (; i < size; i++) {
			data[i] = "";
		}
	}

	public static BufferedImage loadTransparentImage(URL url) {
		try {
			BufferedImage img = ImageIO.read(url);
			BufferedImage newImg = ImageUtils.getTransperantImage(img, Color.WHITE);

			return newImg;
		} catch (Exception e) {
		}
		return null;
	}

	public static void main(String[] a) throws Exception {

		File dir = new File("F:/apps/DigiTmWs/motifCreator/img");
		for (File f : dir.listFiles(new FilenameFilter() {

			@Override
			public boolean accept(File dir, String name) {
				return name.toLowerCase().endsWith(".bmp");
			}
		})) {
			BufferedImage img = ImageUtils.getImageFromFile(f.getAbsolutePath());
			BufferedImage img1 = ImageUtils.getTransperantImage(img, Color.WHITE);
			String p = f.getAbsolutePath().toLowerCase().replace(".bmp", ".jpg");
			ImageUtils.saveImage(img1, p, "JPG");
		}
	}

	public static void main1(String[] args) {
		System.out.println("started...................");
		int x = 0;
		int y = 0;
		int cnt = 1;

		int r = 0, g = 0, b = 0;

		int w = 147;
		for (int start = 0; start <= 20; start += 5) {
			BufferedImage img = new BufferedImage(w, 15, BufferedImage.TYPE_INT_RGB);
			Graphics2D gr = img.createGraphics();
			gr.setColor(Color.WHITE);
			gr.fillRect(0, 0, w, 15);
			x = y = 0;
			int c = 0;
			try {
				for (r = 255 - start; r >= 0; r -= 20) {
					for (g = 255 - start; g >= 0; g -= 20) {
						for (b = 255 - start; b >= 0; b -= 20) {
							if (y >= 15) {
								y = 0;
								x++;
							}
							img.setRGB(x, y, (new Color(r, g, b)).getRGB());
							y++;
							c++;
						}
					}
				}

				System.out.println(start + ">" + c + ":" + x + "-" + y);
				System.out.println(r + ":" + g + ":" + b);
				ImageIO.write(img, "BMP", new File("F:/apps/GraphMaster/colors/lib-0" + cnt + ".bmp"));
			} catch (Exception e) {

				System.out.println(c + ">" + x + " : " + y);
				e.printStackTrace();
			}
			cnt++;
		}
		System.out.println("done..........");
	}
}
