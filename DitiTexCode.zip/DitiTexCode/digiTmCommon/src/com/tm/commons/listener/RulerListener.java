package com.tm.commons.listener;

public interface RulerListener {
	void startIndexSet(byte type, int index, int button, int clickCount);
	void endIndexSet(byte type, int index, int button, int clickCount);
}
