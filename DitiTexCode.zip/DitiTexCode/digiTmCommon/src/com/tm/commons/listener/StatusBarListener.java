package com.tm.commons.listener;

import java.awt.Rectangle;

public interface StatusBarListener {
	void drawingAreaChanges(Rectangle bound);
	Rectangle getDrawingArea();
	void clearDrawingArea();
	void showGrid(boolean show);
}
