package com.tm.commons.listener;

import java.awt.Color;
import java.awt.event.MouseAdapter;

import com.tm.commons.components.pane.DigiTmStatusBar;
import com.tm.commons.components.pane.GraphPane;
import com.tm.commons.drawing.tool.FillPattern;
import com.tm.commons.drawing.tool.Pen;
import com.tm.commons.drawing.tool.PenHolder;
import com.tm.commons.tool.DropdownColorChooser;

public abstract class DrawingListener extends MouseAdapter {
	protected PenHolder penHolder;
	protected FillPattern fillPattern;

	protected DigiTmStatusBar statusBar;

	//protected DropdownColorChooser colorChooser;

	protected GraphPane graphPane;

	public DrawingListener(PenHolder penHolder, FillPattern fillPattern, DigiTmStatusBar statusBar, DropdownColorChooser colorChooser) {
		this.penHolder = penHolder;
		this.fillPattern = fillPattern;
		this.statusBar = statusBar;
		//this.colorChooser = colorChooser;
	}

	public void setGraphPane(GraphPane graphPane) {
		this.setGraphPane(graphPane, null);
	}

	public void setGraphPane(GraphPane graphPane, Color color) {
		this.graphPane = graphPane;
		Pen pen = this.penHolder.getPen();
		if (pen != null) {
			pen.setGraphPane(graphPane);
			pen.setFillPattern(fillPattern);
			if (color != null) {
				pen.setColor(color);
			}
		}
		this.statusBar.setImageSize(graphPane.getImgWidth(), graphPane.getImgHeight());
	}

	public FillPattern getFillPattern() {
		return fillPattern;
	}

	public DigiTmStatusBar getStatusBar() {
		return statusBar;
	}

	public PenHolder getPenHolder() {
		return penHolder;
	}

}
