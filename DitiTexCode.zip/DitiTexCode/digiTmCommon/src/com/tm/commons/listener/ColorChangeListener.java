package com.tm.commons.listener;

import java.awt.Color;

public interface ColorChangeListener {
	void colorChanged(Color color);
}
