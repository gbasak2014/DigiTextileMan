package com.tm.commons.listener;

public interface ColorProtectListener {
	public void protectColor(Integer[] Protectrgbs, int replaceRgb);
}
