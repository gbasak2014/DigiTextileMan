package com.tm.commons.win;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.border.EmptyBorder;

import com.tm.commons.TextUtils;
import com.tm.commons.dto.DigiTmConstants;
import com.tm.commons.secure.KeyChecker;

//com.tm.secure.LockGenWin
public class LockGenWin extends DigiTmWin {

	private static final long serialVersionUID = 4681481302728626989L;
	JTextPane txtLock;
	JTextField jtName = new JTextField();

	private JPanel contentPane;

	@Override
	public void saveProperties() {
		// TODO Auto-generated method stub

	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LockGenWin frame = new LockGenWin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LockGenWin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 594, 380);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		txtLock = new JTextPane();
		txtLock.setPreferredSize(new Dimension(200, 100));
		JScrollPane scrollPane = new JScrollPane(txtLock);
		scrollPane.setBounds(10, 78, 558, 194);
		contentPane.add(scrollPane);

		JButton btnGenerateKey = new JButton(DigiTmConstants.genKey);

		btnGenerateKey.setBounds(213, 11, 117, 23);
		contentPane.add(btnGenerateKey);

		JButton btnSaveKey = new JButton(new String(new byte[] { 83, 97, 118, 101, 32, 75, 101, 121 }));

		btnSaveKey.setBounds(333, 11, 117, 23);
		contentPane.add(btnSaveKey);

		JLabel lblUser = new JLabel("User Name");
		lblUser.setBounds(20, 37, 100, 23);
		jtName.setBounds(122, 37, 400, 23);
		contentPane.add(lblUser);
		contentPane.add(jtName);

		JLabel lblNewLabel = new JLabel(new String(new byte[] { 75, 101, 121 }));
		lblNewLabel.setBounds(20, 55, 322, 23);
		contentPane.add(lblNewLabel);

		JButton btnClose = new JButton("Close");
		btnClose.setBounds(451, 11, 117, 23);
		contentPane.add(btnClose);

		this.txtLock.setEditable(false);
		btnSaveKey.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				save();
			}
		});
		btnGenerateKey.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				generateKey();
			}
		});

		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				close();
			}
		});

	}

	void save() {
		JFileChooser dlg = new JFileChooser();
		if (dlg.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
			try {
				FileOutputStream out = new FileOutputStream(dlg.getSelectedFile());
				out.write(txtLock.getText().getBytes());
				out.close();
			} catch (Exception e) {
			}
		}
	}

	void close() {
		this.setVisible(false);
		System.exit(0);
	}

	void generateKey() {
		try {
			String user = this.jtName.getText();
			if (user.trim().length() > 0) {
				List<String> locks = KeyChecker.getLock();
				StringBuffer buff = new StringBuffer();
				buff.append(TextUtils.textToByte(this.jtName.getText()));
				buff.append("\n");

				for (String lock : locks) {
					buff.append(lock).append("\n");
				}
				txtLock.setText(buff.toString());
			} else {
				JOptionPane.showMessageDialog(this, new String(new byte[] { 80, 108, 101, 97, 115, 101, 32, 101, 110,
						116, 101, 114, 32, 85, 115, 101, 114, 32, 78, 97, 109, 101, 33, 33, 33 }));
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
