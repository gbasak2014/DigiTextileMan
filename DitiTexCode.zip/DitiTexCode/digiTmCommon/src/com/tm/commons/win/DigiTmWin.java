package com.tm.commons.win;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

import com.tm.commons.dto.DigiTmConstants;

public abstract class DigiTmWin extends JFrame implements WindowListener {
	private static final long serialVersionUID = 4041843274190286297L;

	public DigiTmWin(String logoFile) {
		this.setTitle(new String(DigiTmConstants.title));
		try {
			this.addWindowListener(this);
			URL url = this.getClass().getResource("/img/mc-logo.jpg");
			this.setIconImage(ImageIO.read(url));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public DigiTmWin() {
		this.setTitle(new String(DigiTmConstants.title));
		try {
			this.addWindowListener(this);
			URL url = this.getClass().getResource(new String(DigiTmConstants.logo));
			this.setIconImage(ImageIO.read(url));
		} catch (Exception e) {
			// e.printStackTrace();
		}
	}

	public void centerMe()
	{
		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		int left = ((int)d.getWidth() - this.getWidth())/2;
		int top = ((int)d.getHeight() - this.getHeight())/2;
		this.setLocation(left, top);
	}
	
	@Override
	public void windowActivated(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowClosed(WindowEvent arg0) {
	}

	@Override
	public void windowClosing(WindowEvent e) {
		saveProperties();
		this.dispose();
	}

	@Override
	public void windowDeactivated(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowDeiconified(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowIconified(WindowEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void windowOpened(WindowEvent arg0) {
		this.centerMe();
	}

	public abstract void saveProperties();
}
