package com.tm.commons.action;

public enum HelpMenuActionEnum {
	ABOUT(0);

	public int value;

	private HelpMenuActionEnum(int value) {
		this.value = value;
	}

	public static HelpMenuActionEnum fromString(String value) {
		return fromInt(Integer.parseInt(value));
	}

	public static HelpMenuActionEnum fromInt(int value) {
		switch (value) {
		case 0:
			return ABOUT;
		default:
			return ABOUT;
		}
	}
}
