package com.tm.commons.action;

public enum FileMenuActionEnum {
	NEW(0), OPEN(1), SAVE(2), SAVE_AS(3), SAVE_SELECT(4), SAVE_IMAGE(5), SAVE_DESIGN(6), PRINT_IMAGE(7), PRINT_GRAPH(8), PRINT_IMAGE_SELECT(
			9), PRINT_GRAPH_SELECT(10), CLOSE(11), SAVE_MOTIF(12), LOAD_MOTIF(13), EXIT(14), SELECT_PAGE(15), PRINT_SETTING(
			16), NEXT(17), PREVIOUS(18), SCANNER(19), NEW_APP(20), HORIZ(21), VERT(22), MIX(23), SWAP(24), ZOOM_IN(25), ZOOM_OUT(26), SPLIT(27),
	REFRESH(28);

	public int value;

	private FileMenuActionEnum(int value) {
		this.value = value;
	}

	public static FileMenuActionEnum fromString(String value) {
		return fromInt(Integer.parseInt(value));
	}

	public static FileMenuActionEnum fromInt(int value) {
		switch (value) {
		case 0:
			return NEW;
		case 1:
			return OPEN;
		case 2:
			return SAVE;
		case 3:
			return SAVE_AS;
		case 4:
			return SAVE_SELECT;
		case 5:
			return SAVE_IMAGE;
		case 6:
			return SAVE_DESIGN;
		case 7:
			return PRINT_IMAGE;
		case 8:
			return PRINT_GRAPH;
		case 9:
			return PRINT_IMAGE_SELECT;
		case 10:
			return PRINT_GRAPH_SELECT;
		case 11:
			return CLOSE;
		case 12:
			return SAVE_MOTIF;
		case 13:
			return LOAD_MOTIF;
		case 14:
			return EXIT;
		case 15:
			return SELECT_PAGE;
		case 16:
			return PRINT_SETTING;
		case 17:
			return NEXT;
		case 18:
			return PREVIOUS;
		case 19:
			return SCANNER;
		case 20:
			return NEW_APP;
		case 21:
			return HORIZ;
		case 22:
			return VERT;
		case 23:
			return MIX;
		case 24:
			return SWAP;
		case 25:
			return ZOOM_IN;
		case 26:
			return ZOOM_OUT;
		case 27:
			return SPLIT;
		case 28:
			return REFRESH;
		default:
			return NEW;
		}
	}
}
