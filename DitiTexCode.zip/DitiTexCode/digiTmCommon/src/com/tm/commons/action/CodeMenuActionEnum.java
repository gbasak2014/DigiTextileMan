package com.tm.commons.action;

public enum CodeMenuActionEnum {
	CREATE(0), VIEW(1), CODE_TO_IMAGE(2),

	PICK_COLOR(18), PEN(19), REPLACE_COLOR(20), MIRROR_HORIZ(21), MIRROR_VERT(22), SELECT_COLOR(23), ZOOM_IN(
			24), ZOOM_OUT(25), CODE_GENERATE(26), VIEW_CODE(27), CLOSE(28), SAVE_CODE(29);

	public int value;

	private CodeMenuActionEnum(int value) {
		this.value = value;
	}

	public static CodeMenuActionEnum fromString(String value) {
		return fromInt(Integer.parseInt(value));
	}

	public static CodeMenuActionEnum fromInt(int value) {
		switch (value) {
		case 0:
			return CREATE;
		case 1:
			return VIEW;
		case 2:
			return CODE_TO_IMAGE;
		case 18:
			return PICK_COLOR;
		case 19:
			return PEN;
		case 20:
			return REPLACE_COLOR;
		case 21:
			return MIRROR_HORIZ;
		case 22:
			return MIRROR_VERT;
		case 23:
			return SELECT_COLOR;
		case 24:
			return ZOOM_IN;
		case 25:
			return ZOOM_OUT;
		case 26:
			return CODE_GENERATE;
		case 27:
			return VIEW_CODE;
		case 28:
			return CLOSE;
		case 29:
			return SAVE_CODE;
		default:
			return CREATE;
		}
	}
}
