package com.tm.commons.action;

public enum EditMenuActionEnum {
	CUT(0), COPY(1), INSERT(2), PASTE(3), SELECT(4), ROTATE(5), FLIP_HORIZ(6), FLIP_VERT(7), DELETE_SELECT(
			8), ADD_PATTERN(9), LOAD_PATTERN(10), SET_PATTERN(11), UNDO(12), REDO(13), INSERT_ROW_COL(
					14), REMOVE_ROW_COL(15), RESIZE(16), SET_LINE_PATTERN(17), FLOAT_CHECK(18), MERGE_IMAGE(
							19), CROP_IMAGE(20), BI_COLOR(21), REVERSE_COLOR(22), SLID_UP(23), SLID_DOWN(24), SLID_LEFT(
									25), SLID_RIGHT(26), SLIDING(27), COLOR_PROTECT(28), SLID_CLOSE(29), IMAGE_MIX(
											30), IMAGE_SPLIT(31), SELECT_FROM_FILE(32), TEXT(33), DRAWING_AREA(34);

	public int value;

	private EditMenuActionEnum(int value) {
		this.value = value;
	}

	public static EditMenuActionEnum fromString(String value) {
		return fromInt(Integer.parseInt(value));
	}

	public static EditMenuActionEnum fromInt(int value) {
		switch (value) {
		case 0:
			return CUT;
		case 1:
			return COPY;
		case 2:
			return INSERT;
		case 3:
			return PASTE;
		case 4:
			return SELECT;
		case 5:
			return ROTATE;
		case 6:
			return FLIP_HORIZ;
		case 7:
			return FLIP_VERT;
		case 8:
			return DELETE_SELECT;
		case 9:
			return ADD_PATTERN;
		case 10:
			return LOAD_PATTERN;
		case 11:
			return SET_PATTERN;
		case 12:
			return UNDO;
		case 13:
			return REDO;
		case 14:
			return INSERT_ROW_COL;
		case 15:
			return REMOVE_ROW_COL;
		case 16:
			return RESIZE;
		case 17:
			return SET_LINE_PATTERN;
		case 18:
			return FLOAT_CHECK;
		case 19:
			return MERGE_IMAGE;
		case 20:
			return CROP_IMAGE;
		case 21:
			return BI_COLOR;
		case 22:
			return REVERSE_COLOR;
		case 23:
			return SLID_UP;
		case 24:
			return SLID_DOWN;
		case 25:
			return SLID_LEFT;
		case 26:
			return SLID_RIGHT;
		case 27:
			return SLIDING;
		case 28:
			return COLOR_PROTECT;
		case 29:
			return SLID_CLOSE;
		case 30:
			return IMAGE_MIX;
		case 31:
			return IMAGE_SPLIT;
		case 32:
			return SELECT_FROM_FILE;
		case 33:
			return TEXT;
		case 34:
			return DRAWING_AREA;
		default:
			return COPY;
		}
	}
}
