package com.tm.commons.action;

public enum DigiTmEnum {
	OK(0), CANCEL(1), UP(2), SELECT(3), ZOOM_IN(4), ZOOM_OUT(5);

	public int value;

	private DigiTmEnum(int value) {
		this.value = value;
	}

	public static DigiTmEnum fromString(String value) {
		return fromInt(Integer.parseInt(value));
	}

	public static DigiTmEnum fromInt(int value) {
		switch (value) {
		case 0:
			return OK;
		case 1:
			return CANCEL;
		case 2:
			return UP;
		case 3:
			return SELECT;
		case 4:
			return ZOOM_IN;
		case 5:
			return ZOOM_OUT;
		default:
			return CANCEL;
		}
	}
}
