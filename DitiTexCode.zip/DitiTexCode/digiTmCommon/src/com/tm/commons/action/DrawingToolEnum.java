package com.tm.commons.action;

public enum DrawingToolEnum {
	PEN(1), LINE(2), CIRCLE(3), RECT(4), FILL_RECT(5), PICK(6), COLOR(7), MOUSE(8), BEZ(9), SELECT(10), FILL(
			11), SCALE_H(
					12), SCALE_V(13), PASTE_CP(14), PASTE_XOR(15), FILL_PATTERN(16), FILL_SOLID(17), FILL_EMPTY(18),

	CIRCLE_LEFT(21), CIRCLE_RIGHT(22), CIRCLE_TOP(23), CIRCLE_BOTTOM(24), CIRCLE_TOP_LEFT(25), CIRCLE_BOTTOM_LEFT(
			26), CIRCLE_TOP_RIGHT(27), CIRCLE_BOTTOM_RIGHT(28), CIRCLE_FULL(29), REPLACE_COLOR(
					30), PASTE(31), CLEAR(32), ARRANGE(33), SELECT_RAND(34), MOVE(35), COLOR_SELECT(36), ADD_BORDER(37);

	public int value;

	private DrawingToolEnum(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}

	public static DrawingToolEnum fromString(String val) {
		return fromInt(Integer.parseInt(val));
	}

	public static DrawingToolEnum fromInt(int val) {
		switch (val) {
		case 1:
			return PEN;
		case 2:
			return LINE;
		case 3:
			return CIRCLE;
		case 4:
			return RECT;
		case 5:
			return FILL_RECT;
		case 6:
			return PICK;
		case 7:
			return COLOR;
		case 8:
			return MOUSE;
		case 9:
			return BEZ;
		case 10:
			return SELECT;
		case 11:
			return FILL;
		case 12:
			return SCALE_H;
		case 13:
			return SCALE_V;
		case 14:
			return PASTE_CP;
		case 15:
			return PASTE_XOR;
		case 16:
			return FILL_PATTERN;
		case 17:
			return FILL_SOLID;
		case 18:
			return FILL_EMPTY;
		case 21:
			return CIRCLE_LEFT;
		case 22:
			return CIRCLE_RIGHT;
		case 23:
			return CIRCLE_TOP;
		case 24:
			return CIRCLE_BOTTOM;
		case 25:
			return CIRCLE_TOP_LEFT;
		case 26:
			return CIRCLE_BOTTOM_LEFT;
		case 27:
			return CIRCLE_TOP_RIGHT;
		case 28:
			return CIRCLE_BOTTOM_RIGHT;
		case 29:
			return CIRCLE_FULL;
		case 30:
			return REPLACE_COLOR;
		case 31:
			return PASTE;
		case 32:
			return CLEAR;
		case 33:
			return ARRANGE;
		case 34:
			return SELECT_RAND;
		case 35:
			return MOVE;
		case 36:
			return COLOR_SELECT;
		case 37:
			return ADD_BORDER;
		default:
			return PEN;
		}
	}
}
