package com.tm.commons.action;

public enum MergeImageEnume {
	OPEN(0), PASTE(1), LEFT(2), RIGHT(3), MERGE(4), SAVE(5), DELETE(6), EXIT(7);

	public int value;

	private MergeImageEnume(int value) {
		this.value = value;
	}

	public static MergeImageEnume fromString(String value) {
		return fromInt(Integer.parseInt(value));
	}

	public static MergeImageEnume fromInt(int value) {
		switch (value) {
		case 0:
			return OPEN;
		case 1:
			return PASTE;
		case 2:
			return LEFT;
		case 3:
			return RIGHT;
		case 4:
			return MERGE;
		case 5:
			return SAVE;
		case 6:
			return DELETE;
		case 7:
			return EXIT;
		default:
			return OPEN;
		}
	}
}
