package com.tm.commons.action;

public enum ViewMenuActionEnum {
	DRAWING_TOOL(0), MENU_TOOL(1), ZOOM_IN(2), ZOOM_OUT(3);

	public int value;

	private ViewMenuActionEnum(int value) {
		this.value = value;
	}

	public static ViewMenuActionEnum fromString(String value) {
		return fromInt(Integer.parseInt(value));
	}

	public static ViewMenuActionEnum fromInt(int value) {
		switch (value) {
		case 0:
			return DRAWING_TOOL;
		case 1:
			return MENU_TOOL;
		case 2:
			return ZOOM_IN;
		case 3:
			return ZOOM_OUT;
		default:
			return ZOOM_IN;
		}
	}
}
