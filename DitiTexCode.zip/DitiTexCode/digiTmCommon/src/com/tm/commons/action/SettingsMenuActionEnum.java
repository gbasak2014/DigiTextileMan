package com.tm.commons.action;

public enum SettingsMenuActionEnum {
	OPTIONS(0), PRINT_OPTIONS(1);

	public int value;

	private SettingsMenuActionEnum(int value) {
		this.value = value;
	}

	public static SettingsMenuActionEnum fromString(String value) {
		return fromInt(Integer.parseInt(value));
	}

	public static SettingsMenuActionEnum fromInt(int value) {
		switch (value) {
		case 0:
			return OPTIONS;
		case 1:
			return PRINT_OPTIONS;
		default:
			return OPTIONS;
		}
	}
}
