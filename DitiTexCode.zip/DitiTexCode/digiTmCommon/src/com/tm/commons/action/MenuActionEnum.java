package com.tm.commons.action;

public enum MenuActionEnum {
	FILE(0), EDIT(1), CODE(2), SETTING(3), VIEW(4), HELP(5);

	int value;

	private MenuActionEnum(int value) {
		this.value = value;
	}

	public static MenuActionEnum fromString(String value) {
		return fromInt(Integer.parseInt(value));
	}

	public static MenuActionEnum fromInt(int value) {
		switch (value) {
		case 0:
			return FILE;
		case 1:
			return EDIT;
		case 2:
			return CODE;
		case 3:
			return SETTING;
		case 4:
			return VIEW;
		case 5:
			return HELP;
		default:
			return FILE;
		}
	}
}
