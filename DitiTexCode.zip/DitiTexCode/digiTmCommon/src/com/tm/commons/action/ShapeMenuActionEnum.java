package com.tm.commons.action;

public enum ShapeMenuActionEnum {
	UP(0), DOWN(1), LEFT(2), RIGHT(3), COMMIT(4), CANCEL(5);

	public int value;

	private ShapeMenuActionEnum(int value) {
		this.value = value;
	}

	public static ShapeMenuActionEnum fromString(String value) {
		return fromInt(Integer.parseInt(value));
	}

	public static ShapeMenuActionEnum fromInt(int value) {
		switch (value) {
		case 0:
			return UP;
		case 1:
			return DOWN;
		case 2:
			return LEFT;
		case 3:
			return RIGHT;
		case 4:
			return COMMIT;
		case 5:
			return CANCEL;
		default:
			return UP;
		}
	}
}
