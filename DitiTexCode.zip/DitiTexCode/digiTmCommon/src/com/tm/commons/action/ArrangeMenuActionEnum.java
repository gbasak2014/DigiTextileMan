package com.tm.commons.action;

public enum ArrangeMenuActionEnum {
	LEFT(0), RIGHT(1), UP(2), DOWN(3), LEFT_UP(4), LEFT_DOWN(5), RIGHT_UP(6), RIGHT_DOWN(7);

	public int value;

	private ArrangeMenuActionEnum(int value) {
		this.value = value;
	}

	public static ArrangeMenuActionEnum fromString(String value) {
		return fromInt(Integer.parseInt(value));
	}

	public static ArrangeMenuActionEnum fromInt(int value) {
		switch (value) {
		case 0:
			return LEFT;
		case 1:
			return RIGHT;
		case 2:
			return UP;
		case 3:
			return DOWN;
		case 4:
			return LEFT_UP;
		case 5:
			return LEFT_DOWN;
		case 6:
			return RIGHT_UP;
		case 7:
			return RIGHT_DOWN;
		default:
			return RIGHT;
		}
	}
}
