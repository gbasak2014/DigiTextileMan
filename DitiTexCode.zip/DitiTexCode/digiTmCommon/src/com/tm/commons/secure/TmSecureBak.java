package com.tm.commons.secure;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import com.tm.commons.TextUtils;
import com.tm.commons.dto.DigiTmConstants;
import com.tm.commons.win.LockGenWin;

public class TmSecureBak {
	private static String getKey(String k) {
		System.out.println("==========================================");
		String str = k.replaceAll("-", new String(DigiTmConstants.lck));
		byte[] b = str.getBytes();
		System.out.println(str.length() + ":::" + b.length);
		for (int i=0; i<str.length();i++)
		{
			System.out.print(b[i]);
		}
		System.out.println("\n==========================================");
		return k.replaceAll("-", new String(DigiTmConstants.lck));
	}

	public static String getKeys(String locks) throws Exception {
		StringBuffer buff = new StringBuffer();
		for (String lock : locks.split("\n")) {
			System.out.println(lock);
			String str = getKey(lock);
			System.out.println(str);
			buff.append(KeyChecker.getMd5(str)).append("\n");
		}

		return buff.toString();
	}

	public static boolean isValidKey(File path) {

		try {
			BufferedReader br = new BufferedReader(new FileReader(path));
			String line;

			List<String> keys = new ArrayList<String>();
			br.readLine();
			while ((line = br.readLine()) != null) {
				keys.add(line);
			}
			br.close();

			List<String> locks = KeyChecker.getLock();

			for (String lock : locks) {
				String md5 = KeyChecker.getMd5(getKey(lock));
				for (String key : keys) {
					if (key.equals(md5)) {
						return true;
					}
				}
			}

		} catch (Exception e) {
		}
		return false;
	}

	public static String getUserName(File path) {
		try {
			BufferedReader br = new BufferedReader(new FileReader(path));
			String line = br.readLine();
			br.close();
			return line;
		} catch (Exception e) {
		}

		return null;
	}

	public static void validateKeyBAK() {

	}

	public static String validateKey() {
		try {
			String keyPath = System.getProperty("user.home") + File.separator + "tm-key";
			File file = new File(keyPath);

			if (!file.exists()) {
				int status = JOptionPane.showConfirmDialog(null, "Do you have Lock File?", "DigiTm",
						JOptionPane.YES_NO_OPTION);
				if (status == JOptionPane.YES_OPTION) {
					JFileChooser dlg = new JFileChooser();
					if (dlg.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
						file = dlg.getSelectedFile();
					} else {
						System.exit(1);
					}
				} else {
					JOptionPane.showMessageDialog(null, "Kindly save lock file and send for key");
					LockGenWin frame = new LockGenWin();
					frame.setVisible(true);
					return null;
				}
			}

			if (!TmSecureBak.isValidKey(file)) {
				JOptionPane.showMessageDialog(null, "Oops you are not authorisez, Select key file...");
				JFileChooser dlg = new JFileChooser();
				if (dlg.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
					file = dlg.getSelectedFile();
				} else {
					System.exit(1);
				}
			}

			if (!TmSecureBak.isValidKey(file)) {
				JOptionPane.showMessageDialog(null, "Oops you are not authorisez!!!!");
				System.exit(1);
			}

			if (!keyPath.equals(file.getAbsolutePath())) {
				OutputStream out = new FileOutputStream(keyPath);
				InputStream in = new FileInputStream(file);
				byte[] buff = new byte[1024];
				int len = 0;
				while ((len = in.read(buff)) > 0) {
					out.write(buff, 0, len);
				}

				out.close();
				in.close();
			}

			return getUserName(file);

		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Oops you are not authorisez :(");
			System.exit(1);
		}

		return null;
	}

	public static void main(String[] args) throws Exception{
		Random r = new Random(5);
		
		for (int i=0;i<20;i++)
			System.out.println(r.nextInt(5));
		
	}
}
