package com.tm.commons.secure;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import com.tm.commons.DigiTmUtils;
import com.tm.commons.dto.DigiTmConstants;
import com.tm.commons.win.LockGenWin;

public class TmSecure {
	static String KEY_PATH;
	static {
		if (System.getProperty("os.name").toLowerCase().startsWith("window")) {
			KEY_PATH = DigiTmConstants.keyPathWin;
		} else {
			KEY_PATH = DigiTmConstants.keyPathUnix;
		}
	}

	private static String getKey(String k) {
		byte[] b = k.replaceAll("-", new String(DigiTmConstants.lck)).getBytes();
		Random r = new Random();
		byte seed = (byte) r.nextInt(DigiTmConstants.SEED);
		for (int i = 0; i < b.length; i++) {
			b[i] = (byte) (b[i] + seed);
		}
		return new String(b);
	}

	private static String getKey(String k, byte seed) {
		byte[] b = k.replaceAll("-", new String(DigiTmConstants.lck)).getBytes();
		for (int i = 0; i < b.length; i++) {
			b[i] = (byte) (b[i] + seed);
		}
		return new String(b);
	}

	public static String getKeys(String locks) throws Exception {
		StringBuffer buff = new StringBuffer();
		for (String lock : locks.split("\n")) {
			String str = getKey(lock);
			buff.append(KeyChecker.getMd5(str)).append("\n");
		}

		return buff.toString();
	}

	public static boolean isValidKey(File path) {

		try {
			BufferedReader br = new BufferedReader(new FileReader(path));
			String line;

			List<String> keys = new ArrayList<String>();
			br.readLine();
			while ((line = br.readLine()) != null) {
				keys.add(line);
			}
			br.close();

			List<String> locks = KeyChecker.getLock();
			if (locks.size() <= 0) {
				JOptionPane.showMessageDialog(null, "Error getting hardware address!!, Please restart your computer");
				System.exit(1);
			}
			int lockSize = locks.size();

			for (int i = 0; i <= DigiTmConstants.SEED; i++) {

				for (int idx = 0; idx < lockSize; idx++) {
					String lock = locks.get(idx);
					String md5 = KeyChecker.getMd5(getKey(lock, (byte) i));
					for (String key : keys) {
						if (key.equals(md5)) {
							return true;
						}
					}
				}

			}
		} catch (Exception e) {
			String errPath = DigiTmUtils.WriteLog(e);
			if (errPath != null) {
				JOptionPane.showMessageDialog(null, "Error authenticating Key, please verify log at: " + errPath);
			} else {
				JOptionPane.showMessageDialog(null, "Error authenticating Key: " + e.getMessage());
			}
		}
		return false;
	}

	public static String getUserName(String un) {
		StringBuffer sb = new StringBuffer();
		for (byte ch : un.getBytes()) {
			sb.append(ch);
		}

		return sb.toString();
	}

	public static String getUserName(File path) {
		try {
			BufferedReader br = new BufferedReader(new FileReader(path));
			String line = br.readLine();
			br.close();
			return line;
		} catch (Exception e) {
			String errPath = DigiTmUtils.WriteLog(e);
			if (errPath != null) {
				JOptionPane.showMessageDialog(null, "ERROR, please verify log at: " + errPath);
			} else {
				JOptionPane.showMessageDialog(null, "ERROR: " + e.getMessage());
			}
		}

		return null;
	}

	public static String validateKey() {
		return "Dedicated to Shourya Basak";
	}

	public static String validateKeyBAK() {
		try {
			File file = new File(KEY_PATH);
			System.out.println("KEY_PATH:" + KEY_PATH);

			File newFile = null;

			if (!file.exists()) {
				int status = JOptionPane.showConfirmDialog(null, DigiTmConstants.dHvPKey, DigiTmConstants.digiTex,
						JOptionPane.YES_NO_OPTION);
				if (status == JOptionPane.YES_OPTION) {
					JFileChooser dlg = new JFileChooser();
					if (dlg.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
						newFile = dlg.getSelectedFile();
						file = newFile;
					} else {
						System.exit(1);
					}
				} else {
					JOptionPane.showMessageDialog(null, DigiTmConstants.svLck);
					LockGenWin frame = new LockGenWin();
					frame.setVisible(true);
					return null;
				}
			}

			if (!TmSecure.isValidKey(file)) {
				JOptionPane.showMessageDialog(null, DigiTmConstants.msgUnAuthSel);
				JFileChooser dlg = new JFileChooser();
				if (dlg.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
					newFile = dlg.getSelectedFile();
					file = newFile;
				} else {
					System.exit(1);
				}
			}

			if (!TmSecure.isValidKey(file)) {
				JOptionPane.showMessageDialog(null, DigiTmConstants.msgUnAuth);
				System.exit(1);
			}

			if (newFile != null) {
				OutputStream out = new FileOutputStream(KEY_PATH);
				InputStream in = new FileInputStream(file);
				byte[] buff = new byte[1024];
				int len = 0;
				while ((len = in.read(buff)) > 0) {
					out.write(buff, 0, len);
				}

				out.close();
				in.close();
			}

			return getUserName(file);

		} catch (Exception e) {
			String errPath = DigiTmUtils.WriteLog(e);
			if (errPath != null) {
				JOptionPane.showMessageDialog(null, "ERROR, please verify log at: " + errPath);
			} else {
				JOptionPane.showMessageDialog(null, "ERROR: " + e.getMessage());
			}

			System.exit(1);
		}

		return null;
	}
}
