package d.i.g.i.t.m;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.UIManager;

import com.tm.commons.TextUtils;
import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.dto.DigiTmConstants;
import com.tm.commons.secure.TmSecure;
import com.tm.commons.win.DigiTmWin;
import com.tm.design.win.TmDesignWin;
import com.tm.image.trace.TraceImageWindow;
import com.tm.motif.win.MotifCreatorWin;
import com.tm.weave.pattern.WeaveCreateWin;

public class X extends DigiTmWin implements ActionListener {
	// d.i.g.i.t.m.X
	private static final long serialVersionUID = 5594056897251860737L;
	static final int MOTIF = 0;
	static final int DESIGN = 1;
	static final int WEAVE = 2;
	static final int IMAGE = 3;
	static final int EXIT = 4;

	static {
		try {
			UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public X() {
		super();
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setLayout(new BorderLayout(0, 0));

		JButton btn;

		JLabel lbl = new JLabel(new String(DigiTmConstants.title));
		lbl.setForeground(new Color(255, 255, 0));
		lbl.setOpaque(true);
		lbl.setBackground(new Color(0, 0, 50));
		lbl.setFont(new Font("Arial", Font.BOLD, 32));

		this.add(lbl, BorderLayout.NORTH);

		btn = new ButtonMenuItem(1, null, "/img/digitex.jpg", null);
		btn.setPreferredSize(new Dimension(400, 110));
		this.add(btn, BorderLayout.NORTH);

		JPanel pnl = new JPanel(new FlowLayout(FlowLayout.CENTER));
		pnl.setBorder(BorderFactory.createRaisedSoftBevelBorder());
		pnl.setBackground(new Color(0, 0, 50));
		pnl.setOpaque(true);
		lbl = new JLabel("");
		lbl.setForeground(Color.RED);
		lbl.setOpaque(true);
		lbl.setBackground(new Color(0, 0, 50));
		lbl.setFont(new Font("Arial", Font.BOLD, 24));
		pnl.add(lbl);
		this.add(pnl, BorderLayout.SOUTH);

		pnl = new JPanel(new GridLayout(4, 1, 1, 1));
		// pnl.setBackground(new Color(225, 192, 0));
		pnl.setBackground(new Color(0, 0, 70));
		pnl.setOpaque(true);

		btn = new ButtonMenuItem(1, null, null, "Create Motif");
		btn.setForeground(new Color(225, 192, 0));
		btn.setFont(new Font("Arial", Font.BOLD, 48));
		btn.setBorder(BorderFactory.createLineBorder(Color.WHITE));
		btn.setOpaque(false);
		btn.setActionCommand(String.valueOf(MOTIF));
		btn.addActionListener(this);
		pnl.add(btn);

		btn = new ButtonMenuItem(1, null, null, "Create Design");
		btn.setForeground(new Color(225, 192, 0));
		btn.setFont(new Font("Arial", Font.BOLD, 48));
		btn.setBorder(BorderFactory.createLineBorder(Color.WHITE));
		btn.setOpaque(false);
		btn.setActionCommand(String.valueOf(DESIGN));
		btn.addActionListener(this);
		pnl.add(btn);

		btn = new ButtonMenuItem(1, null, null, "Create Pattern");
		btn.setForeground(new Color(225, 192, 0));
		btn.setFont(new Font("Arial", Font.BOLD, 48));
		btn.setBorder(BorderFactory.createLineBorder(Color.WHITE));
		btn.setOpaque(false);
		btn.setActionCommand(String.valueOf(WEAVE));
		btn.addActionListener(this);
		pnl.add(btn);

		btn = new ButtonMenuItem(1, null, null, "Process Scanned Image");
		btn.setForeground(new Color(225, 192, 0));
		btn.setFont(new Font("Arial", Font.BOLD, 48));
		btn.setBorder(BorderFactory.createLineBorder(Color.WHITE));
		btn.setOpaque(false);
		btn.setActionCommand(String.valueOf(IMAGE));
		btn.addActionListener(this);
		pnl.add(btn);

		this.getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW)
				.put(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), "cancel");

		this.getRootPane().getActionMap().put("cancel", new AbstractAction() {

			@Override
			public void actionPerformed(ActionEvent e) {
				cancelMe();
			}
		});

		this.add(pnl, BorderLayout.CENTER);

		this.setPreferredSize(new Dimension(900, 570));
		this.setSize(900, 570);

		Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
		int x = ((int) d.getWidth() - 900) / 2;
		int y = ((int) d.getHeight() - 570) / 2;
		this.setLocation(x, y);
		this.setResizable(false);
		this.pack();
		this.setVisible(true);
	}

	@Override
	public void saveProperties() {
	}

	void cancelMe() {
		this.setVisible(false);
		System.exit(0);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		int cmd = Integer.parseInt(e.getActionCommand());
		this.setVisible(false);
		String userName = TmSecure.validateKey();

		if (userName != null) {
			try {
				userName = TextUtils.byteToText(userName);
			} catch (Exception ex) {

			}

			switch (cmd) {
			case MOTIF:
				new MotifCreatorWin(userName);
				break;
			case DESIGN:
				new TmDesignWin(userName);
				break;
			case WEAVE:
				new WeaveCreateWin(userName);
				break;
			case IMAGE:
				new TraceImageWindow(userName);
				break;
			}
		}
	}

	public static void main(String[] args) {
		System.out.println(DigiTmConstants.PROP_FILE_WEAVE);
		new X();
	}

	static class StartPanel extends JPanel {
		BufferedImage img;

		public StartPanel(BufferedImage img) {
			this.img = img;
		}

		@Override
		protected void paintComponent(Graphics g) {
			super.paintComponent(g);
			g.drawImage(this.img, 0, 0, this);
			g.dispose();
		}
	}
}
