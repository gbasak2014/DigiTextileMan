package com.tm.image.trace;

import java.awt.FlowLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JToolBar;

import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.theme.DigiTmTheme;
import com.tm.commons.tool.ColorPane;
import com.tm.commons.tool.DropdownColorChooser;

public class TraceToolBar extends JToolBar {
	private static final long serialVersionUID = -6540733201330111474L;
	DropdownColorChooser colorTool;
	TraceStatusBar statusBar;

	public TraceToolBar(TraceImageWindow traceWin) {
		this.setBackground(DigiTmTheme.getBgColor());
		this.setBorder(DigiTmTheme.getLineBorder());

		this.setLayout(new FlowLayout(FlowLayout.LEFT, 1, 1));
		this.add(new ButtonMenuItem(TraceEnum.OPEN.value, traceWin, "/img/open.jpg", "Open Image"));
		this.add(new ButtonMenuItem(TraceEnum.OPEN_SEL.value, traceWin, "/img/open-sel.jpg", "Open Selected Image in new window"));
		this.add(new ButtonMenuItem(TraceEnum.SAVE.value, traceWin, "/img/save.jpg", "Save Image"));
		this.add(new ButtonMenuItem(TraceEnum.SAVE_AS.value, traceWin, "/img/saveas.jpg", "Save Image As"));

		this.add(new ButtonMenuItem(TraceEnum.CLOSE.value, traceWin, "/img/close.jpg", "Close"));
		add(new JLabel("      "));
		this.add(new ButtonMenuItem(TraceEnum.CUT.value, traceWin, "/img/cut.jpg", "Get selected area..."));
		this.add(new ButtonMenuItem(TraceEnum.RESIZE.value, traceWin, "/img/resize.jpg", "Resize Image"));
		this.add(new ButtonMenuItem(TraceEnum.ROTATE.value, traceWin, "/img/rotate.jpg", "Rotate"));
		this.add(new ButtonMenuItem(TraceEnum.COLOR_REDUCE.value, traceWin, "/img/trc-reducecl.jpg", "Reduce Color"));
		this.add(new ButtonMenuItem(TraceEnum.ZOOM_IN.value, traceWin, "/img/z2.jpg", "Zoom In"));
		this.add(new ButtonMenuItem(TraceEnum.ZOOM_OUT.value, traceWin, "/img/z1.jpg", "Zoom Out"));
		add(new JLabel("      "));
		JPanel pnl = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
		pnl.setBorder(DigiTmTheme.getLineBorder());

		pnl.add(new ButtonMenuItem(TraceEnum.PEN.value, traceWin, "/img/trc-pen.jpg", "Select Pen"));
		pnl.add(new ButtonMenuItem(TraceEnum.LINE.value, traceWin, "/img/trc-line.jpg", "Select Line"));
		pnl.add(new ButtonMenuItem(TraceEnum.RECT.value, traceWin, "/img/trc-rect.jpg", "Select Rectangle"));
		pnl.add(new ButtonMenuItem(TraceEnum.CIRCLE.value, traceWin, "/img/trc-circle.jpg", "Select Circle"));
		pnl.add(new ButtonMenuItem(TraceEnum.SELECT.value, traceWin, "/img/trc-select.jpg", "Select Area"));
		pnl.add(new ButtonMenuItem(TraceEnum.REPLACE_COLOR.value, traceWin, "/img/trc-replcolor.jpg", "Repalce with selected color"));
		pnl.add(new ButtonMenuItem(TraceEnum.MOVE_COLOR.value, traceWin, "/img/move-color.jpg", "Move Color"));
		pnl.add(new ButtonMenuItem(TraceEnum.PICK_COLOR.value, traceWin, "/img/trc-pickcolor.jpg", "Pick Color"));
		this.add(pnl);
		add(new JLabel("      "));
		this.colorTool = new DropdownColorChooser(traceWin);
		this.colorTool.addColorPane(new ColorPane());
		this.add(colorTool);
		add(new JLabel("     "));
		this.statusBar = new TraceStatusBar();
		this.add(this.statusBar);

		pnl = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));
		pnl.setBorder(DigiTmTheme.getLineBorder());
		pnl.add(new ButtonMenuItem(TraceEnum.CLOSE.value, traceWin, "/img/close.jpg", "Close"));
		this.add(pnl);

	}

	public DropdownColorChooser getColorTool() {
		return this.colorTool;
	}

	public TraceStatusBar getStatusBar() {
		return this.statusBar;
	}
}
