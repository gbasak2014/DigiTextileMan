package com.tm.image.trace;

public class PickColor implements Pen{
	ImagePane pane;
	
	public void setImagePane(ImagePane pane) {
		this.pane = pane;
		this.pane.isReplaceColor = true;
	}

	@Override
	public void draw() {
		this.pane.pickColor();
	}
	
	@Override
	public void save() {
		this.pane.saveColor();
		this.pane.isReplaceColor = false;
	}
}
