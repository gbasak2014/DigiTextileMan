package com.tm.image.trace;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.tm.commons.dlg.ImageOpenDlgTree;
import com.tm.commons.dlg.ImageRotateDlg;
import com.tm.commons.listener.ColorChangeListener;
import com.tm.commons.secure.TmSecure;
import com.tm.commons.theme.DigiTmTheme;
import com.tm.commons.win.DigiTmWin;

public class TraceImageWindow extends DigiTmWin implements ActionListener, ColorChangeListener {
	// com.tm.image.trace.TraceImageWindow
	private static final long serialVersionUID = -8512874242642887517L;
	TraceDrawingPane activeDrawingPane;
	TraceToolBar toolbar;

	Rectangle winBound = new Rectangle(100, 100, 500, 500);
	File file;
	File fileFiltered;

	String lastOpenPath;

	JDesktopPane desktopPane;

	Pen currentPen;

	JButton prevButton;

	String user;

	@Override
	public void saveProperties() {
		// TODO Auto-generated method stub

	}

	void setTheme() {
		this.getContentPane().setBackground(DigiTmTheme.getBgColor());
		this.toolbar.setBackground(DigiTmTheme.getBgColor());
		this.getJMenuBar().setOpaque(true);
		this.getJMenuBar().setBackground(DigiTmTheme.getBgColor());
		this.desktopPane.setBackground(Color.LIGHT_GRAY);
		this.desktopPane.setBorder(BorderFactory.createLoweredBevelBorder());
	}

	public TraceImageWindow(String user) {
		super();
		this.user = user;
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(winBound);

		this.toolbar = new TraceToolBar(this);
		this.desktopPane = new JDesktopPane();
		this.desktopPane.setDragMode(JDesktopPane.OUTLINE_DRAG_MODE);
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(toolbar, BorderLayout.NORTH);
		this.getContentPane().add(this.desktopPane, BorderLayout.CENTER);

		this.setExtendedState(JFrame.MAXIMIZED_BOTH);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		this.setJMenuBar(new TraceMenuBar(this));

		this.pack();
		// this.setBounds(winBound);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setTheme();
		this.setVisible(true);

	}

	public void open() {
		ImageOpenDlgTree dlg = new ImageOpenDlgTree(this, this.lastOpenPath, ".jpg");
		dlg.setModal(true);
		dlg.setVisible(true);

		if (dlg.isOk()) {
			BufferedImage img = dlg.getSelectedImage();
			if (img != null) {
				this.file = dlg.getSelectedFile();
				this.lastOpenPath = dlg.getSelectedFile().getParent().replace("\\", "/");

				open(img, this.file.getName(), this.lastOpenPath);
			}
		}
	}

	public void open(BufferedImage img, String fileName, String filePath) {
		if (img != null) {
			setActiveDrawingPane(new TraceDrawingPane(img, this.toolbar.getColorTool(), this.toolbar.getStatusBar(),
					this, fileName, filePath));
			this.desktopPane.add(this.activeDrawingPane);
			this.activeDrawingPane.setVisible(true);
		}
	}

	void openSelected() {
		BufferedImage img = this.activeDrawingPane.imagePane.getSelectedImage();
		if (img != null) {
			String fileName = "New " + (this.desktopPane.getComponentCount() + 1);
			this.open(img, fileName, null);
		}
	}

	public void save() {
		TmSecure.validateKey();
		try {
			if (this.activeDrawingPane.getFilePath() != null) {
				this.file = new File(this.activeDrawingPane.getFilePath() + "/" + this.activeDrawingPane.getFileName());
				save(this.file);
			} else {
				saveAs();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void saveNew() {
		TmSecure.validateKey();
		File tmp = getSaveFile();
		if (tmp != null) {
			try {
				ImageIO.write(this.activeDrawingPane.getNewImage(), "BMP", tmp);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private void save(File imageFile) {
		try {
			ImageIO.write(this.activeDrawingPane.getImage(), "BMP", imageFile);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void saveAs() {
		TmSecure.validateKey();
		File tmp = getSaveFile();
		if (tmp != null) {
			this.file = tmp;
			this.save(this.file);
		}
	}

	private File getSaveFile() {
		String parent = this.activeDrawingPane.getFilePath() != null ? this.activeDrawingPane.getFilePath()
				: this.file.getParent();
		JFileChooser saveDlg = new JFileChooser(parent);
		saveDlg.setFileFilter(new FileNameExtensionFilter("24-bit Bitmap", "BMP"));
		int ret = saveDlg.showSaveDialog(this);

		if (ret == JFileChooser.APPROVE_OPTION) {
			file = saveDlg.getSelectedFile();
			if (!file.getName().endsWith(".bmp")) {
				return new File(file.getAbsolutePath() + ".bmp");
			}
		}

		return null;
	}

	public void close() {
		validateSave();
		this.setVisible(false);
		System.exit(0);
	}

	public void selectColor(Color color) {
		if (this.activeDrawingPane != null) {
			this.activeDrawingPane.setColor(color);
		}
	}

	void validateSave() {

	}

	public void reduceColor() {
		this.activeDrawingPane.reduceImageColor();
	}

	public void resizeImage() {
		int w = activeDrawingPane.getImage().getWidth();
		int h = activeDrawingPane.getImage().getHeight();
		ImageResizeDlg dlg = new ImageResizeDlg(w, h);
		dlg.setModal(true);
		dlg.setVisible(true);

		if (dlg.isOK()) {
			activeDrawingPane.scaleImage(dlg.getNewWidth(), dlg.getNewHeight());
		}
	}

	public void rotateImage() {
		ImageRotateDlg dlg = new ImageRotateDlg(activeDrawingPane.getImage());
		dlg.setModal(true);
		dlg.setVisible(true);
		if (dlg.isOk()) {
			activeDrawingPane.setImage(dlg.getImage());
			activeDrawingPane.repaint();
		}
	}

	public void selectPen(TraceEnum action, Object source) {
		if (this.prevButton != null) {
			this.prevButton.setBorder(BorderFactory.createEmptyBorder());
		}

		this.prevButton = (JButton) source;
		this.prevButton.setBorder(BorderFactory.createLoweredBevelBorder());

		switch (action) {
		case PEN:
			this.activeDrawingPane.setPen(new Point());
			break;
		case LINE:
			this.activeDrawingPane.setPen(new Line());
			break;
		case RECT:
			this.activeDrawingPane.setPen(new Rect());
			break;
		case CIRCLE:
			this.activeDrawingPane.setPen(new Circle());
			break;
		case FILL:
			break;
		case SELECT:
			this.activeDrawingPane.setPen(new Select());
			break;
		case CUT:
			this.activeDrawingPane.cut();
			break;
		case REPLACE_COLOR:
			this.activeDrawingPane.setPen(new ReplaceColor());
			break;
		case PICK_COLOR:
			this.activeDrawingPane.setPen(new PickColor());
			break;
		case FILTER:
			this.activeDrawingPane.setPen(new FilterColor());
			break;
		case MOVE_COLOR:
			this.activeDrawingPane.setPen(new MoveColor(this.activeDrawingPane));
			break;
		default:
			break;
		}

		this.currentPen = this.activeDrawingPane.getPen();
	}

	public void zoom(int zoom) {
		this.activeDrawingPane.zoom(zoom);
	}

	@Override
	public void actionPerformed(ActionEvent event) {

		TraceEnum action = TraceEnum.fromString(event.getActionCommand());
		switch (action) {
		case OPEN:
			this.open();
			break;
		case OPEN_SEL:
			this.openSelected();
			break;
		case SAVE:
			this.save();
			break;
		case SAVE_NEW:
			this.saveNew();
			break;
		case SAVE_AS:
			this.saveAs();
			break;
		case COLOR_REDUCE:
			this.reduceColor();
			break;
		case CLOSE:
			this.close();
			break;
		case ZOOM_IN:
			this.zoom(1);
			break;
		case ZOOM_OUT:
			this.zoom(-1);
			break;
		case RESIZE:
			this.resizeImage();
			break;
		case ROTATE:
			this.rotateImage();
		case REPLACE_COLOR:
		case PEN:
		case LINE:
		case RECT:
		case CIRCLE:
		case FILL:
		case SELECT:
		case PICK_COLOR:
		case FILTER:
		case MOVE_COLOR:
			this.selectPen(action, event.getSource());
			break;
		case CUT:
			this.activeDrawingPane.cut();
			break;
		case ARRANGE_TILE:
			arrangeTile();
			break;
		case ARRANGE_CASCADE:
			arrangeCascade();
			break;
		case EXIT:
			this.setVisible(false);
			System.exit(0);
		}
	}

	void arrangeTile() {
		Component[] cmps = this.desktopPane.getComponents();

		int w = this.desktopPane.getWidth();
		int h = this.desktopPane.getHeight();
		int fw;
		int fh;
		int c = cmps.length;
		if (c > 1 && c < 4) {
			fh = h / c;
			int i = 0;
			for (Component cmp : cmps) {
				JInternalFrame jif = (JInternalFrame) cmp;
				jif.setSize(w, fh);
				jif.setLocation(0, i * fh);
				i++;
			}
		} else if (c == 4) {
			int x = 0;
			int y = 0;
			fw = w / 2;
			fh = h / 2;
			for (Component cmp : cmps) {
				JInternalFrame jif = (JInternalFrame) cmp;
				jif.setSize(fw, fh);
				jif.setLocation(x, y);
				x = x + fw;
				if (x > w - 2) {
					x = 0;
					y = y + fh;
				}
			}
		} else if (c <= 9) {
			int x = 0;
			int y = 0;
			fw = w / 3;
			fh = h / 3;
			for (Component cmp : cmps) {
				JInternalFrame jif = (JInternalFrame) cmp;
				jif.setSize(fw, fh);
				jif.setLocation(x, y);
				x = x + fw;
				if (x > w - 5) {
					x = 0;
					y = y + fh;
				}
			}
		} else if (c <= 16) {
			int x = 0;
			int y = 0;
			fw = w / 4;
			fh = h / 4;
			for (Component cmp : cmps) {
				JInternalFrame jif = (JInternalFrame) cmp;
				jif.setSize(fw, fh);
				jif.setLocation(x, y);
				x = x + fw;
				if (x > w - 5) {
					x = 0;
					y = y + fh;
				}
			}
		}

	}

	void arrangeCascade() {
		Component[] cmps = this.desktopPane.getComponents();

		int w = this.desktopPane.getWidth();
		int h = this.desktopPane.getHeight();
		int x = 0;
		int y = 0;

		int i = 0;
		for (Component cmp : cmps) {
			cmp.setSize(w - 10, h - 10);
			cmp.setLocation(x + i, y + i);
			cmp.setVisible(true);
			i = i + 50;
			if (y + i > h) {
				x = x + 50;
				y = y + 50;
			}
		}
	}

	public void setActiveDrawingPane(TraceDrawingPane activeDrawingPane) {
		if (this.activeDrawingPane != activeDrawingPane) {
			int x = 10;
			int y = 10;
			if (this.activeDrawingPane != null) {
				x = this.activeDrawingPane.getLocation().x + 50;
				y = this.activeDrawingPane.getLocation().y + 50;
				if (x > (this.desktopPane.getWidth() - 20) || y > (this.desktopPane.getHeight() - 20)) {
					x = 20;
					y = 20;
				}
				this.activeDrawingPane.removeDrawingListener();
			}

			this.activeDrawingPane = activeDrawingPane;
			this.activeDrawingPane.setLocation(x, y);
			this.toolbar.statusBar.SetWidth(this.activeDrawingPane.getImage().getWidth());
			this.toolbar.statusBar.SetHeight(this.activeDrawingPane.getImage().getHeight());

			this.activeDrawingPane.addDrawingListener();
		}
	}

	public Pen getCurrentPen() {
		return this.currentPen;
	}

	@Override
	public void colorChanged(Color color) {
		if (this.activeDrawingPane != null) {
			this.activeDrawingPane.setColor(color);
		}
	}
}
