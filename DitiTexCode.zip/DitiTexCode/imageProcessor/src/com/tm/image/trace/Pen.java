package com.tm.image.trace;

public interface Pen {
	byte LEFT=0;
	byte RIGHT=1;
	byte TOP=2;
	byte BOTTOM=3;
	byte FULL=4;
	
	void draw();
	void save();
	void setImagePane(ImagePane pane);
}
