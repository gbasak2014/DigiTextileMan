package com.tm.image.trace;

import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import com.tm.commons.theme.DigiTmTheme;

public class TraceStatusBar extends JPanel {
	private static final long serialVersionUID = 4771802194987944475L;
	private JLabel lblW;
	private JLabel lblH;
	JLabel lblX;
	JLabel lblY;

	/**
	 * Create the panel.
	 */
	public TraceStatusBar() {
		this.setOpaque(false);
		FlowLayout flowLayout = new FlowLayout(FlowLayout.LEFT, 0, 0);
		flowLayout.setAlignOnBaseline(true);
		setLayout(flowLayout);

		Dimension d = new Dimension(60, 20);
		lblX = new JLabel("X:");
		lblX.setPreferredSize(d);
		lblX.setBorder(DigiTmTheme.getLineBorder());
		add(lblX);

		lblY = new JLabel("Y:");
		lblY.setPreferredSize(d);
		lblY.setBorder(DigiTmTheme.getLineBorder());
		add(lblY);

		lblW = new JLabel("W:");
		lblW.setPreferredSize(d);
		lblW.setBorder(DigiTmTheme.getLineBorder());
		add(lblW);

		lblH = new JLabel("H:");
		lblH.setPreferredSize(d);
		lblH.setBorder(DigiTmTheme.getLineBorder());
		add(lblH);
	}

	public void SetX(int x) {
		this.lblX.setText("X:" + x);
	}

	public void SetY(int y) {
		this.lblY.setText("Y:" + y);
	}

	public void SetWidth(int w) {
		this.lblW.setText("W:" + w);
	}

	public void SetHeight(int h) {
		this.lblH.setText("H:" + h);
	}
}
