package com.tm.image.trace;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.util.HashSet;
import java.util.Set;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.event.InternalFrameEvent;
import javax.swing.event.InternalFrameListener;

import com.tm.commons.components.ColorComboRenderer;
import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.listener.ColorChangeListener;
import com.tm.commons.theme.DigiTmTheme;
import com.tm.commons.tool.DropdownColorChooser;

public class TraceDrawingPane extends JInternalFrame
		implements InternalFrameListener, ActionListener, ColorChangeListener {
	private static final long serialVersionUID = -1638762529939626314L;
	DropdownColorChooser colorTool;
	TraceStatusBar statusBar;
	TraceImageWindow traceImageWindow;
	ImagePane imagePane;

	JScrollPane scrollPane;

	String fileName;
	String filePath;

	static final int SCAN = 0;
	static final int CLEAR = 1;

	static final int NEW_IMAGE = 2;

	JComboBox<Integer> jcColors = new JComboBox<>();
	JLabel btnColor = new JLabel("  ");

	JSplitPane splitPane;
	TrcImgPane trcImage;

	public TraceDrawingPane(BufferedImage img, DropdownColorChooser colorTool, TraceStatusBar statusBar,
			TraceImageWindow traceImageWindow, String fileName, String filePath) {
		super(fileName, true, true, true, true);
		this.fileName = fileName;
		this.filePath = filePath;
		this.setTitle((filePath != null ? filePath + "/" : "") + fileName);
		this.imagePane = new ImagePane(img, colorTool, statusBar);
		this.colorTool = colorTool;
		this.statusBar = statusBar;
		this.traceImageWindow = traceImageWindow;
		this.scrollPane = new JScrollPane(this.imagePane, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		this.getContentPane().setLayout(new BorderLayout());
		// this.getContentPane().add(this.scrollPane, BorderLayout.CENTER);

		this.trcImage = new TrcImgPane();
		this.splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, this.scrollPane, this.trcImage);
		this.splitPane.setDividerLocation(300);
		this.getContentPane().add(this.splitPane, BorderLayout.CENTER);

		this.getContentPane().add(this.getToolBar(), BorderLayout.NORTH);

		this.setSize(300, 600);
		this.setPreferredSize(new Dimension(300, 300));
		this.addInternalFrameListener(this);
		this.pack();
		this.scrollPane.setViewportView(this.imagePane);
		this.scrollPane.revalidate();

		jcColors.setRenderer(new ColorComboRenderer());

		jcColors.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				checkColorChanged();
			}
		});

	}

	@Override
	public void colorChanged(Color color) {
		// TODO Auto-generated method stub

	}

	void checkColorChanged() {
		int idx = this.jcColors.getSelectedIndex();
		if (idx >= 0) {
			Color color = new Color(this.jcColors.getItemAt(idx).intValue());
			this.btnColor.setBackground(color);
			this.btnColor.setForeground(color);
		}
	}

	JPanel getToolBar() {
		JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 2, 2));

		panel.setBackground(DigiTmTheme.getBgColor());
		panel.setBorder(DigiTmTheme.getLineBorder());

		panel.add(new ButtonMenuItem(SCAN, this, "/img/scan.jpg", "Scan Colors"));
		panel.add(new JLabel("Scanned Color"));
		panel.add(this.jcColors);
		this.btnColor.setPreferredSize(new Dimension(30, 20));
		this.btnColor.setOpaque(true);
		panel.add(this.btnColor);
		panel.add(new ButtonMenuItem(CLEAR, this, "/img/trc-replcolor.jpg", "Clear Colors"));

		panel.add(new ButtonMenuItem(NEW_IMAGE, this, "/img/new.jpg", "Create New Image"));

		return panel;
	}

	public BufferedImage getImage() {
		return this.imagePane.getImage();
	}

	public void setPen(Pen pen) {
		this.imagePane.setPen(pen);
	}

	public Pen getPen() {
		return this.imagePane.pen;
	}

	public void zoom(int val) {
		this.imagePane.zoom(val);
		this.scrollPane.setViewportView(this.imagePane);
		this.scrollPane.revalidate();

		this.trcImage.zoom(val);
	}

	public void setColor(Color color) {
		this.imagePane.setColor(color);
	}

	public Color getColor() {
		return this.imagePane.getColor();
	}

	public void reduceImageColor() {
		this.imagePane.reduceImageColor();
	}

	public void scaleImage(int newWidth, int newHeight) {
		this.imagePane.scaleImage(newWidth, newHeight);
	}

	public void cut() {
		this.imagePane.cut();
	}

	public void setImage(BufferedImage img) {
		this.imagePane.setImage(img);
	}

	public void replaceColor() {
		int newRgb = this.colorTool.getSelectedColor().getRGB();
		int oldRgb = this.colorTool.getPickColor().getRGB();
		BufferedImage image = this.getImage();
		int w = image.getWidth();
		int h = image.getHeight();

		for (int c = 0; c < w; c++) {
			for (int r = 0; r < h; r++) {
				if (image.getRGB(c, r) == oldRgb) {
					image.setRGB(c, r, newRgb);
				}
			}
		}

		Graphics g = this.imagePane.drawImage.getGraphics();
		g.setColor(Color.DARK_GRAY);
		g.fillRect(0, 0, this.imagePane.drawImage.getWidth(), this.imagePane.drawImage.getHeight());
		g.drawImage(image, 0, 0, this);

		this.imagePane.repaint();
	}

	public void removeColor(Color color) {
		int rgb = color.getRGB();
		int newRgb = Color.WHITE.getRGB();
		BufferedImage image = this.getImage();
		int w = image.getWidth();
		int h = image.getHeight();

		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				if (rgb == image.getRGB(x, y)) {
					image.setRGB(x, y, newRgb);
				}
			}
		}

		this.imagePane.repaint();
	}

	@Override
	public void internalFrameActivated(InternalFrameEvent e) {
		this.traceImageWindow.setActiveDrawingPane(this);
	}

	@Override
	public void internalFrameClosed(InternalFrameEvent arg0) {
	}

	@Override
	public void internalFrameClosing(InternalFrameEvent arg0) {
	}

	@Override
	public void internalFrameDeactivated(InternalFrameEvent arg0) {
	}

	@Override
	public void internalFrameDeiconified(InternalFrameEvent arg0) {
	}

	@Override
	public void internalFrameIconified(InternalFrameEvent arg0) {
	}

	@Override
	public void internalFrameOpened(InternalFrameEvent arg0) {
	}

	public void addDrawingListener() {
		this.imagePane.addEventListener();
	}

	public void removeDrawingListener() {
		this.imagePane.removeEventListener();
	}

	public String getFileName() {
		return fileName;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		int cmd = Integer.parseInt(e.getActionCommand());
		switch (cmd) {
		case SCAN:
			scanColor();
			break;
		case CLEAR:
			clearColor();
			break;
		case NEW_IMAGE:
			createNewImage();
			break;
		}
	}

	void moveColor() {
		int newRgb = this.colorTool.getSelectedColor().getRGB();
		int oldRgb = this.colorTool.getPickColor().getRGB();

		BufferedImage img = this.getImage();
		BufferedImage imgTrc = this.trcImage.getImage();

		int w = img.getWidth();
		int h = img.getHeight();

		double wf = (double) imgTrc.getWidth() / (double) w;
		double hf = (double) imgTrc.getHeight() / (double) h;

		for (int r = 0; r < h; r++) {
			for (int c = 0; c < w; c++) {
				if (oldRgb == img.getRGB(c, r)) {
					int x = (int) (c * wf);
					int y = (int) (r * hf);
					imgTrc.setRGB(x, y, newRgb);
				}
			}
		}

		this.trcImage.repaint();
	}

	void createNewImage() {
		BufferedImage img = this.imagePane.getImage();

		ImageResizeDlg dlg = new ImageResizeDlg(img.getWidth(), img.getHeight());
		dlg.setModal(true);
		dlg.setVisible(true);

		if (dlg.isOK()) {
			img = null;
			img = new BufferedImage(dlg.getNewWidth(), dlg.getNewHeight(), BufferedImage.TYPE_INT_RGB);
			Graphics2D g = img.createGraphics();
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, dlg.getNewWidth(), dlg.getNewHeight());
			g.dispose();
			this.trcImage.setImage(img);
		}
	}

	void scanColor11() {
		int[] data = ((DataBufferInt) this.imagePane.getImage().getRaster().getDataBuffer()).getData();
		Set<Integer> set = new HashSet<Integer>();

		this.jcColors.removeAllItems();
		for (Integer rgb : data) {
			if (!set.contains(rgb)) {
				set.add(rgb);
				this.jcColors.addItem(rgb);
			}
			// if (set.size() > 100) {
			// JOptionPane.showMessageDialog(this, "Too many colors!!");
			// break;
			// }
		}

		System.out.println(data.length + ":" + set.size());
	}

	void scanColor() {
		Set<Integer> set = new HashSet<Integer>();
		this.jcColors.removeAllItems();

		BufferedImage img = this.imagePane.getImage();
		int w = img.getWidth();
		int h = img.getHeight();
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int rgb = img.getRGB(x, y);
				if (!set.contains(rgb)) {
					set.add(rgb);
					this.jcColors.addItem(rgb);
				}
			}
		}

		System.out.println(set.size());
	}

	void clearColor() {
		int idx = this.jcColors.getSelectedIndex();
		if (idx < 0) {
			JOptionPane.showMessageDialog(this, "No Color to clear!!");
			return;
		}

		int rgb = this.jcColors.getItemAt(idx);
		this.imagePane.clearRGB(rgb);
		this.jcColors.removeItemAt(idx);
	}

	public BufferedImage getNewImage() {
		return this.trcImage.getImage();
	}

	class TrcImgPane extends JPanel {
		BufferedImage img;
		int zm = 1;
		int MAX_ZOOM = 10;

		public void setImage(BufferedImage img) {
			this.img = img;
			this.repaint();
		}

		BufferedImage getImage() {
			return this.img;
		}

		public void zoom(int val) {
			this.zm = this.zm + val;
			if (this.zm < 1) {
				this.zm = 1;

			} else if (this.zm > MAX_ZOOM) {
				this.zm = MAX_ZOOM;
			}
			repaint();
		}

		@Override
		public void paint(Graphics g) {
			g.setColor(Color.WHITE);
			int w = this.getWidth();
			int h = this.getHeight();
			g.fillRect(0, 0, w, h);
			if (this.img != null) {
				w = img.getWidth() * this.zm;
				h = img.getHeight() * this.zm;

				g.drawImage(this.img, 10, 10, w, h, this);
				g.setColor(Color.gray);
				g.drawRect(8, 8, w + 3, h + 3);
			}
			g.dispose();
		}
	}

}
