package com.tm.image.trace;

public class Point implements Pen{
	ImagePane pane;
	
	public Point(ImagePane pane) {
		this.pane = pane;
	}
	
	public Point() {
		this(null);
	}
	public void setImagePane(ImagePane pane) {
		this.pane = pane;
	}

	@Override
	public void draw() {
		this.pane.setPoint();
	}
	
	@Override
	public void save() {
		//this.pane.saveLine();
	}
}
