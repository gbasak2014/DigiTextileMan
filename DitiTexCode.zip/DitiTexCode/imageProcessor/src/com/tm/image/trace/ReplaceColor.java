package com.tm.image.trace;

public class ReplaceColor implements Pen
{
	ImagePane pane;

	public void setImagePane(ImagePane pane)
	{
		this.pane = pane;
		this.pane.isReplaceColor = true;
	}

	@Override
	public void draw()
	{
		this.pane.pickColor(this.pane.moveX, this.pane.moveY);
	}

	@Override
	public void save()
	{
		this.pane.replaceColor();
		this.pane.isReplaceColor = false;
	}
}
