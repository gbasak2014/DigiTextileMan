package com.tm.image.trace;

import java.awt.event.KeyEvent;

import javax.swing.JMenu;
import javax.swing.JMenuBar;

import com.tm.commons.menu.DigiTmMenu;
import com.tm.commons.menu.DigiTmMenuItem;
import com.tm.commons.theme.DigiTmTheme;

public class TraceMenuBar extends JMenuBar {

	private static final long serialVersionUID = -1687730907633324575L;

	public TraceMenuBar(TraceImageWindow traceImageWindow) {
		super();
		this.setBackground(DigiTmTheme.getBgColor());
		this.add(this.createFileMenu(traceImageWindow));
		this.add(this.createEditMenu(traceImageWindow));
		this.add(this.createViewMenu(traceImageWindow));
		this.add(this.createWindowMenu(traceImageWindow));
	}

	JMenu createFileMenu(TraceImageWindow traceImageWindow) {
		DigiTmMenu menu = new DigiTmMenu("File");
		menu.setMnemonic(KeyEvent.VK_F);

		menu.add(new DigiTmMenuItem("Open", TraceEnum.OPEN.value, traceImageWindow));
		menu.add(new DigiTmMenuItem("Save", TraceEnum.SAVE.value, traceImageWindow));
		menu.add(new DigiTmMenuItem("Save New Image", TraceEnum.SAVE_NEW.value, traceImageWindow));
		
		menu.add(new DigiTmMenuItem("Save As", TraceEnum.SAVE_AS.value, traceImageWindow));

		menu.add(new DigiTmMenuItem("Exit", TraceEnum.EXIT.value, traceImageWindow));
		return menu;
	}

	JMenu createEditMenu(TraceImageWindow traceImageWindow) {
		DigiTmMenu menu = new DigiTmMenu("Edit");
		menu.setMnemonic(KeyEvent.VK_E);

		menu.add(new DigiTmMenuItem("Make Gray scale", TraceEnum.COLOR_REDUCE.value, traceImageWindow));
		menu.add(new DigiTmMenuItem("Resize Image", TraceEnum.RESIZE.value, traceImageWindow));

		return menu;
	}

	JMenu createViewMenu(TraceImageWindow traceImageWindow) {
		DigiTmMenu menu = new DigiTmMenu("View");
		menu.setMnemonic(KeyEvent.VK_V);

		menu.add(new DigiTmMenuItem("Zoom In", TraceEnum.ZOOM_IN.value, traceImageWindow));
		menu.add(new DigiTmMenuItem("Zoom Out", TraceEnum.ZOOM_OUT.value, traceImageWindow));
		return menu;
	}

	JMenu createWindowMenu(TraceImageWindow traceImageWindow) {
		DigiTmMenu menu = new DigiTmMenu("Window");
		menu.setMnemonic(KeyEvent.VK_W);

		menu.add(new DigiTmMenuItem("Arrange Tile", TraceEnum.ARRANGE_TILE.value, traceImageWindow));
		menu.add(new DigiTmMenuItem("Arrange cascade", TraceEnum.ARRANGE_CASCADE.value, traceImageWindow));
		return menu;
	}
}
