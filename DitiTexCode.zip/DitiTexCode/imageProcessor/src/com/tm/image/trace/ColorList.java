package com.tm.image.trace;

import java.awt.Color;
import java.awt.Component;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

public class ColorList extends JList<Integer>
{
	DefaultListModel model = new DefaultListModel();
	//JScrollPane sp;
	ColorListCellRenderer clcr = new ColorListCellRenderer();

	public ColorList()
	{
		super();
		try
		{
			//sp = new JScrollPane(this, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
			setCellRenderer(clcr);
			setModel(model);
			this.setFixedCellHeight(20);
			this.setFixedCellWidth(40);
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public void addItem(Integer rgb)
	{
		if (model.indexOf(rgb) < 0)
			model.add(model.size(), rgb);
	}

	public int getItemCount()
	{
		return model.size();
	}

	public Integer getItem(int i)
	{
		return (Integer) model.getElementAt(i);
	}

	public boolean isExist(Integer rgb)
	{
		return model.indexOf(rgb) < 0 ? false : true;
	}

	public void removeAll()
	{
		model.removeAllElements();
	}

	public void removeAt(int i)
	{
		model.removeElementAt(i);
	}

/*	public JScrollPane getScrollPane()
	{
		return sp;
	}
*/
	public boolean isEmpty()
	{
		return model.isEmpty();
	}
}

class ColorListCellRenderer extends JLabel implements ListCellRenderer<Integer>
{
	public ColorListCellRenderer()
	{
		setOpaque(true);
	}

	@Override
	public Component getListCellRendererComponent(JList<? extends Integer> list, Integer rgb, int index, boolean isSelected,
			boolean cellHasFocus)
	{
		try
		{
			Color color = new Color(rgb);
			setBackground(color);
			setForeground(color);
			setBorder(isSelected ? BorderFactory.createLoweredBevelBorder() : BorderFactory.createRaisedBevelBorder());
		} catch (Exception e)
		{
		}
		return this;
	}
}
