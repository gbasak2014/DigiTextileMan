package com.tm.image.trace;

public class FilterColor implements Pen{
	ImagePane pane;
	
	public void setImagePane(ImagePane pane) {
		this.pane = pane;
		this.pane.isReplaceColor = true;
	}

	@Override
	public void draw() {
		this.pane.pickColor();
	}
	
	@Override
	public void save() {
		//this.pane.filterColor();
		this.pane.isReplaceColor = false;
	}
}
