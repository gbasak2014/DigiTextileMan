package com.tm.image.trace;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.UIManager;

public class ImageResizeDlg extends JDialog implements ActionListener, FocusListener {

	private final JPanel contentPanel = new JPanel();
	private JTextField txtOldWidth;
	private JTextField txtOldHeight;
	private JTextField txtNewWidth;
	private JTextField txtNewHeight;

	boolean okPressed;

	int newWidth;
	int newHeight;

	/**
	 * Create the dialog.
	 */
	public ImageResizeDlg(int imageWidth, int imageHeight) {
		setBounds(100, 100, 536, 308);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		JPanel panelOldAttr = new JPanel();
		panelOldAttr.setBorder(new TitledBorder(null, "Old Properties", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		panelOldAttr.setBounds(71, 11, 393, 109);
		contentPanel.add(panelOldAttr);
		panelOldAttr.setLayout(null);

		JLabel lblOldWidth = new JLabel("Width:");
		lblOldWidth.setBounds(127, 31, 46, 14);
		panelOldAttr.add(lblOldWidth);

		txtOldWidth = new JTextField();
		txtOldWidth.setBounds(183, 28, 86, 20);
		panelOldAttr.add(txtOldWidth);
		txtOldWidth.setColumns(10);

		JLabel lblOldHeight = new JLabel("Height:");
		lblOldHeight.setBounds(127, 59, 46, 14);
		panelOldAttr.add(lblOldHeight);

		txtOldHeight = new JTextField();
		txtOldHeight.setColumns(10);
		txtOldHeight.setBounds(183, 56, 86, 20);
		panelOldAttr.add(txtOldHeight);

		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "New Properties", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		panel.setBounds(71, 117, 393, 109);
		contentPanel.add(panel);

		JLabel lblNewWidth = new JLabel("Width:");
		lblNewWidth.setBounds(127, 31, 46, 14);
		panel.add(lblNewWidth);

		txtNewWidth = new JTextField();
		txtNewWidth.setColumns(10);
		txtNewWidth.setBounds(183, 28, 86, 20);
		panel.add(txtNewWidth);

		JLabel lblnewHeight = new JLabel("Height:");
		lblnewHeight.setBounds(127, 59, 46, 14);
		panel.add(lblnewHeight);

		txtNewHeight = new JTextField();
		txtNewHeight.setColumns(10);
		txtNewHeight.setBounds(183, 56, 86, 20);
		panel.add(txtNewHeight);

		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
		getContentPane().add(buttonPane, BorderLayout.SOUTH);

		JButton okButton = new JButton("OK");
		okButton.setActionCommand("OK");
		buttonPane.add(okButton);
		getRootPane().setDefaultButton(okButton);

		JButton cancelButton = new JButton("Cancel");
		cancelButton.setActionCommand("Cancel");
		buttonPane.add(cancelButton);

		okButton.addActionListener(this);
		cancelButton.addActionListener(this);

		txtOldWidth.setText(String.valueOf(imageWidth));
		txtOldHeight.setText(String.valueOf(imageHeight));
		txtOldWidth.setEditable(false);
		txtOldHeight.setEditable(false);

		txtNewWidth.addFocusListener(this);
	}

	public boolean isOK() {
		return okPressed;
	}

	public int getNewWidth() {
		return this.newWidth;
	}

	public int getNewHeight() {
		return this.newHeight;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if ("OK".equals(e.getActionCommand())) {
			try {
				this.newWidth = Integer.parseInt(txtNewWidth.getText());
				this.newHeight = Integer.parseInt(txtNewHeight.getText());

				this.okPressed = true;
				this.setVisible(false);
			} catch (Exception ex) {
				JOptionPane.showMessageDialog(this, "Invalid Width/Height!!");
			}
		} else {
			this.okPressed = false;
			this.setVisible(false);
		}
	}

	@Override
	public void focusGained(FocusEvent arg0) {

	}

	@Override
	public void focusLost(FocusEvent e) {
		int w = Integer.parseInt(this.txtOldWidth.getText());
		int h = Integer.parseInt(this.txtOldHeight.getText());

		int nw = Integer.parseInt(this.txtNewWidth.getText());

		int nh = (h * nw) / w;
		this.txtNewHeight.setText(String.valueOf(nh));
	}
}
