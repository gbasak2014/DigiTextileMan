package com.tm.image.trace;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import com.tm.commons.dlg.DigiTmDlg;

public class TraceColorDlg extends DigiTmDlg implements ActionListener {

	private static final long serialVersionUID = -1239550145632235873L;

	private final JPanel contentPanel = new JPanel();

	TraceDrawingPane drawingPane;

	static final String CLOSE = "close";
	static final String REMOVE = "remove";
	static final String REPLACE = "replace";
	static final String COLOR = "color";

	ColorList colorList = new ColorList();

	static final int MAX = 500;

	/**
	 * Create the dialog.
	 */
	public TraceColorDlg(TraceDrawingPane drawingPane) {
		this.drawingPane = drawingPane;

		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		JScrollPane scrollPane = new JScrollPane(colorList, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(10, 11, 100, 207);
		contentPanel.add(scrollPane);

		colorList.addItem(Color.RED.getRGB());
		colorList.addItem(Color.GREEN.getRGB());

		JButton btnRemove = new JButton("Remove Color");
		btnRemove.setToolTipText("Remove Selected Color(s) from image");
		btnRemove.setBounds(147, 150, 124, 23);
		contentPanel.add(btnRemove);

		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
		getContentPane().add(buttonPane, BorderLayout.SOUTH);

		JButton btnClose = new JButton("Close");
		btnClose.setActionCommand("OK");
		buttonPane.add(btnClose);
		getRootPane().setDefaultButton(btnClose);

		JButton btnReplaceColor = new JButton("Replace Color with");
		btnReplaceColor.setToolTipText("Remove Selected Color(s) from image");
		btnReplaceColor.setBounds(147, 97, 124, 23);
		contentPanel.add(btnReplaceColor);

		JButton btnSelectColor = new JButton(" ");
		btnSelectColor.setToolTipText("Get Color to replace with");
		btnSelectColor.setBounds(273, 97, 38, 23);
		btnSelectColor.setBackground(Color.WHITE);
		contentPanel.add(btnSelectColor);

		JLabel lblColorCount = new JLabel("Color Count:");
		lblColorCount.setBounds(120, 10, 244, 23);
		contentPanel.add(lblColorCount);

		btnClose.setActionCommand(CLOSE);
		btnRemove.setActionCommand(REMOVE);
		btnSelectColor.setActionCommand(COLOR);
		btnReplaceColor.setActionCommand(REPLACE);

		btnClose.addActionListener(this);
		btnRemove.addActionListener(this);
		btnSelectColor.addActionListener(this);
		btnReplaceColor.addActionListener(this);

		initColor(true);

		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();

		if (REMOVE.equals(cmd)) {
			this.removeColor();
		} else if (CLOSE.equals(cmd)) {
			this.close();
		} else if (REPLACE.equals(cmd)) {
			replaceColor();
		} else if (COLOR.equals(cmd)) {
			getColor(e.getSource());
		}
	}

	private void getColor(Object src) {
		JButton btn = (JButton) src;
		JColorChooser jcc = new JColorChooser(btn.getBackground());
		Color color = jcc.showDialog(this, "Select Color", null);
		if (color != null) {
			btn.setBackground(color);
		}
	}

	private void close() {
		this.setVisible(false);
	}

	private void removeColor() {
		System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
	}

	private void replaceColor() {

	}

	private void initColor(boolean force) {
		BufferedImage img = this.drawingPane.getImage();
		int w = img.getWidth();
		int h = img.getHeight();
		for (int c = 0; c < w; c++) {
			for (int r = 0; r < h; r++) {
				int rgb = img.getRGB(c, r);
				this.colorList.addItem(rgb);
			}
		}
	}

}
