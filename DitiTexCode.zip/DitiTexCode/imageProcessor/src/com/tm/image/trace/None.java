package com.tm.image.trace;

public class None implements Pen{
	ImagePane pane;
	
	public void setImagePane(ImagePane pane) {
		this.pane = pane;
	}

	@Override
	public void draw() {
	}
	
	@Override
	public void save() {
	}
}
