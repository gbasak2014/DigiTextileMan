package com.tm.image.trace;

public class Line implements Pen{
	ImagePane pane;
	
	public Line(ImagePane pane) {
		this.pane = pane;
	}
	
	public Line() {
		this(null);
	}
	public void setImagePane(ImagePane pane) {
		this.pane = pane;
	}

	@Override
	public void draw() {
		this.pane.drawLine();
	}
	
	@Override
	public void save() {
		this.pane.saveLine();
	}
}
