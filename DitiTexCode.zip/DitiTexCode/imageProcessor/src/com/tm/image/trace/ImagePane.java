package com.tm.image.trace;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;

import javax.swing.JPanel;

import com.tm.commons.tool.DropdownColorChooser;

public class ImagePane extends JPanel implements MouseMotionListener, MouseListener {
	static final int MAX_ZOOM = 5;

	BufferedImage image;
	BufferedImage drawImage;

	int zoom = 1;

	Pen nonePen = new None();

	int x1, y1, x2, y2;
	boolean isSelected;
	boolean isReplaceColor;
	byte selectMode;
	Pen pen;

	Color color;
	DropdownColorChooser colorTool;
	// TraceToolColor colorTool;
	TraceStatusBar statusBar;

	int moveX;
	int moveY;

	public ImagePane(BufferedImage image, DropdownColorChooser colorTool, TraceStatusBar statusBar) {
		this.colorTool = colorTool;
		this.statusBar = statusBar;
		pen = new Line(this);
		this.image = image;
		this.drawImage = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_RGB);
		Graphics g = drawImage.getGraphics();
		g.setColor(Color.DARK_GRAY);
		g.fillRect(0, 0, this.drawImage.getWidth(), this.drawImage.getHeight());
		g.drawImage(image, 0, 0, this);
		this.setSize(image.getWidth() * zoom, image.getHeight() * zoom);

		this.statusBar.SetWidth(this.image.getWidth());
		this.statusBar.SetHeight(this.image.getHeight());
		this.statusBar.SetX(0);
		this.statusBar.SetY(0);
		addEventListener();
	}

	public void addEventListener() {
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
	}

	public void removeEventListener() {
		this.removeMouseListener(this);
		this.removeMouseMotionListener(this);
	}

	public void refreshSize() {
		this.setSize(image.getWidth() * zoom, image.getHeight() * zoom);
	}

	/*
	 * @Override public void paint(Graphics g) { super.paint(g); int w =
	 * this.getWidth(); int h = this.getHeight(); g.setColor(Color.DARK_GRAY);
	 * g.fillRect(0, 0, w, h);
	 * 
	 * if (this.img != null) { g.drawImage(this.img, 0, 0, this); } }
	 */
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		if (drawImage != null) {
			Graphics2D g2d = (Graphics2D) g;
			g2d.scale(zoom, zoom);
			g2d.setColor(Color.DARK_GRAY);
			g2d.fillRect(0, 0, this.getWidth(), this.getHeight());
			g2d.drawImage(drawImage, 0, 0, this);
		}
	}

	public void zoom(int val) {
		this.zoom = this.zoom + val;
		if (this.zoom < 1) {
			this.zoom = 1;

		} else if (this.zoom > MAX_ZOOM) {
			this.zoom = MAX_ZOOM;
		}
		repaint();

		int w = this.image.getWidth() * zoom;
		int h = this.image.getHeight() * zoom;

		Dimension d = new Dimension(w, h);
		this.setPreferredSize(d);
		this.setSize(d);
	}

	public BufferedImage getImage() {
		return this.image;
	}

	@Override
	public void mousePressed(MouseEvent e) {
		int x = e.getX() / zoom;
		int y = e.getY() / zoom;

		if (this.isSelected) {
			if ((x >= x1 - 1 && x <= x1 + 1) && y > y1 && y < y2) {
				this.selectMode = Pen.LEFT;

			} else if ((x >= x2 - 1 && x <= x2 + 1) && y > y1 && y < y2) {
				this.selectMode = Pen.RIGHT;
			} else if ((y >= y1 - 1 && y <= y1 + 1) && x > x1 && x < x2) {
				this.selectMode = Pen.TOP;
			} else if ((y >= y2 - 1 && y <= y2 + 1) && x > x1 && x < x2) {
				this.selectMode = Pen.BOTTOM;
			} else {
				this.selectMode = Pen.FULL;
				this.isSelected = false;
				x1 = x;
				y1 = y;
			}
		} else {
			x1 = x;
			y1 = y;
			this.isSelected = false;
		}

		// this.statusBar.SetX(x);
		// this.statusBar.SetY(y);
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// this.x2 = e.getX() / zoom;
		// this.y2 = e.getY() / zoom;

		this.pen.save();
		// this.statusBar.SetX(x2);
		// this.statusBar.SetY(y2);
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		int x = e.getX() / zoom;
		int y = e.getY() / zoom;
		this.moveX = x;
		this.moveY = y;
		this.statusBar.SetX(x2);
		this.statusBar.SetY(y2);
		if (isReplaceColor) {
			this.pen.draw();
		} else if (this.isSelected) {
			if ((x >= x1 - 1 && x <= x1 + 1) && y > y1 && y < y2) {
				this.setCursor(new Cursor(Cursor.E_RESIZE_CURSOR));
			} else if ((x >= x2 - 1 && x <= x2 + 1) && y > y1 && y < y2) {
				this.setCursor(new Cursor(Cursor.W_RESIZE_CURSOR));
			} else if ((y >= y1 - 1 && y <= y1 + 1) && x > x1 && x < x2) {
				this.setCursor(new Cursor(Cursor.N_RESIZE_CURSOR));
			} else if ((y >= y2 - 1 && y <= y2 + 1) && x > x1 && x < x2) {
				this.setCursor(new Cursor(Cursor.S_RESIZE_CURSOR));
			} else {
				this.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}
		}
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		int x = e.getX() / zoom;
		int y = e.getY() / zoom;

		if (this.isSelected) {
			switch (this.selectMode) {
			case Pen.LEFT:
				x1 = x;
				break;
			case Pen.RIGHT:
				x2 = x;
				break;
			case Pen.TOP:
				y1 = y;
				break;
			case Pen.BOTTOM:
				y2 = y;
				break;
			default:
				x2 = x;
				y2 = y;
				break;
			}
		} else {
			x2 = x;
			y2 = y;
		}

		this.pen.draw();
		this.statusBar.SetX(x);
		this.statusBar.SetY(y);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	void paintOld(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(Color.DARK_GRAY);
		g2d.fillRect(0, 0, this.drawImage.getWidth(), this.drawImage.getHeight());
		g2d.drawImage(image, 0, 0, this);
	}

	public void drawLine() {
		Graphics2D g = this.drawImage.createGraphics();
		paintOld(g);
		g.setColor(color);
		g.drawLine(x1, y1, x2, y2);
		repaint();
		isSelected = false;
		isReplaceColor = false;
	}

	public void saveLine() {
		Graphics g = image.getGraphics();
		g.setColor(color);
		g.drawLine(x1, y1, x2, y2);
		this.drawImage.getGraphics().drawImage(image, 0, 0, this);
		repaint();
	}

	public void drawRect() {
		int x = x1 > x2 ? x2 : x1;
		int y = y1 > y2 ? y2 : y1;
		int w = Math.abs(x2 - x1);
		int h = Math.abs(y2 - y1);

		Graphics2D g = this.drawImage.createGraphics();
		paintOld(g);
		g.setColor(color);
		g.drawRect(x, y, w, h);
		repaint();
		isSelected = false;
		isReplaceColor = false;
	}

	public void drawSelect() {
		int x = x1 > x2 ? x2 : x1;
		int y = y1 > y2 ? y2 : y1;
		int w = Math.abs(x2 - x1);
		int h = Math.abs(y2 - y1);

		Graphics2D g = this.drawImage.createGraphics();
		paintOld(g);
		g.setXORMode(Color.WHITE);
		g.setColor(Color.GREEN);
		g.drawRect(x, y, w, h);
		repaint();
	}

	public void saveRect() {
		int tmp;
		if (x1 > x2) {
			tmp = x1;
			x1 = x2;
			x2 = tmp;
		}
		if (y1 > y2) {
			tmp = y1;
			y1 = y2;
			y2 = tmp;
		}

		int w = x2 - x1;
		int h = y2 - y1;

		Graphics g = image.getGraphics();
		g.setColor(color);
		g.drawRect(x1, y1, w, h);
		this.drawImage.getGraphics().drawImage(image, 0, 0, this);
		repaint();
	}

	public void saveSelect() {
		int tmp;
		if (x1 > x2) {
			tmp = x1;
			x1 = x2;
			x2 = tmp;
		}
		if (y1 > y2) {
			tmp = y1;
			y1 = y2;
			y2 = tmp;
		}
		isSelected = true;
		isReplaceColor = false;
	}

	public void drawCircle() {
		int x = x1 > x2 ? x2 : x1;
		int y = y1 > y2 ? y2 : y1;
		int w = Math.abs(x2 - x1);
		int h = Math.abs(y2 - y1);

		Graphics2D g = this.drawImage.createGraphics();
		paintOld(g);
		g.setColor(color);
		g.drawOval(x, y, w, h);
		repaint();
		isSelected = false;
		isReplaceColor = false;
	}

	public void saveCircle() {
		int x = x1 > x2 ? x2 : x1;
		int y = y1 > y2 ? y2 : y1;
		int w = Math.abs(x2 - x1);
		int h = Math.abs(y2 - y1);

		Graphics g = image.getGraphics();
		g.setColor(color);
		g.drawOval(x, y, w, h);
		this.drawImage.getGraphics().drawImage(image, 0, 0, this);

		repaint();
	}

	public void setPoint() {
		try {
			/*
			 * this.drawImage.setRGB(x2, y2, color.getRGB());
			 * this.image.setRGB(x2, y2, color.getRGB());
			 */

			Graphics g = image.getGraphics();
			g.setColor(color);
			g.drawLine(x1, y1, x2, y2);
			this.drawImage.getGraphics().drawImage(image, 0, 0, this);
			repaint();
			x1 = x2;
			y1 = y2;

		} catch (Exception e) {
		}
	}

	public void reduceImageColor() {
		int w = image.getWidth();
		int h = image.getHeight();

		for (int i = 0; i < w; i++) {
			for (int j = 0; j < h; j++) {
				int rgb = image.getRGB(i, j);
				int a = (rgb & 0xFF000000) >> 24;
				int r = (rgb & 0x00FF0000) >> 16;
				int g = (rgb & 0x0000FF00) >> 8;
				int b = (rgb & 0x000000FF);
				r = r > 200 ? 255 : (r > 100 ? 200 : 0);
				g = g > 200 ? 255 : (g > 100 ? 200 : 0);
				b = b > 200 ? 255 : (b > 100 ? 200 : 0);
				// image.setRGB(i, j, ((a << 24) | (r << 16) | (g << 8) | b));
				image.setRGB(i, j, (0 | (r << 16) | (g << 8) | b));
			}
		}
		this.drawImage.getGraphics().drawImage(image, 0, 0, this);
		repaint();
	}

	public void setPen(Pen pen) {
		this.pen = pen;
		this.pen.setImagePane(this);
	}

	public void scaleImage(int newWidth, int newHeight) {
		BufferedImage img = new BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_RGB);
		Graphics2D g = img.createGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, img.getWidth(), img.getHeight());
		double sw = (double) newWidth / (double) image.getWidth();
		double sh = (double) newHeight / (double) image.getHeight();
		g.scale(sw, sh);
		g.drawImage(image, 0, 0, this);
		// image.getGraphics().drawImage(img, 0, 0, this);
		image = img;

		Graphics g2 = drawImage.getGraphics();
		g2.setColor(Color.DARK_GRAY);
		g2.fillRect(0, 0, drawImage.getWidth(), drawImage.getHeight());
		g2.drawImage(image, 0, 0, this);
		repaint();
	}

	public void cut() {
		if (isSelected) {
			int x = x1 > x2 ? x2 : x1;
			int y = y1 > y2 ? y2 : y1;
			int w = Math.abs(x2 - x1);
			int h = Math.abs(y2 - y1);
			BufferedImage img = image.getSubimage(x, y, w, h);
			if (img != null) {
				this.image = img;
			}

			Graphics g = this.drawImage.getGraphics();
			g.setColor(Color.DARK_GRAY);
			g.fillRect(0, 0, this.drawImage.getWidth(), this.drawImage.getHeight());
			g.drawImage(image, 0, 0, this);

			repaint();

		}

		isSelected = false;
		// this.setStatus();
	}

	public BufferedImage getSelectedImage() {
		if (isSelected) {
			int x = x1 > x2 ? x2 : x1;
			int y = y1 > y2 ? y2 : y1;
			int w = Math.abs(x2 - x1 + 1);
			int h = Math.abs(y2 - y1 + 1);
			BufferedImage img = image.getSubimage(x, y, w, h);
			if (img != null) {
				BufferedImage tmp = new BufferedImage(img.getWidth(), img.getHeight(), BufferedImage.TYPE_INT_RGB);
				Graphics g = tmp.getGraphics();
				g.setColor(Color.WHITE);
				g.fillRect(0, 0, tmp.getWidth(), tmp.getHeight());
				g.drawImage(img, 0, 0, this);
				return tmp;
			}
		}

		return null;
	}

	public void setImage(BufferedImage img) {
		this.image = img;
		int w = img.getWidth() * MAX_ZOOM;
		int h = img.getHeight() * MAX_ZOOM;
		if (this.drawImage.getWidth() < w || this.drawImage.getHeight() < h) {
			this.drawImage = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
		}
		repaint();
	}

	public void pickColor() {
		if (x2 < this.image.getWidth() && y2 < this.image.getHeight()) {
			this.colorTool.pickColor(new Color(this.image.getRGB(x2, y2)));
		}
	}

	public void pickColor(int x, int y) {
		if (x < this.image.getWidth() && y < this.image.getHeight()) {
			this.colorTool.pickColor(new Color(this.image.getRGB(x, y)));
		}
	}

	public void replaceColor() {
		int newRgb = this.colorTool.getSelectedColor().getRGB();
		int oldRgb = this.colorTool.getPickColor().getRGB();
		int w = this.image.getWidth();
		int h = this.image.getHeight();

		for (int c = 0; c < w; c++) {
			for (int r = 0; r < h; r++) {
				if (this.image.getRGB(c, r) == oldRgb) {
					this.image.setRGB(c, r, newRgb);
				}
			}
		}

		Graphics g = this.drawImage.getGraphics();
		g.setColor(Color.DARK_GRAY);
		g.fillRect(0, 0, this.drawImage.getWidth(), this.drawImage.getHeight());
		g.drawImage(this.image, 0, 0, this);

		this.repaint();
	}

	public void clearRGB(int rgb) {
		int rgbWhite = Color.WHITE.getRGB() & 0x00FFFFFF;// this.colorTool.getSelectedColor().getRGB();
		int[] data = ((DataBufferInt) this.getImage().getRaster().getDataBuffer()).getData();
		int len = data.length;
		for (int i = 0; i < len; i++) {
			if ((rgb & 0x00FFFFFF) == (data[i] & 0x00FFFFFF)) {
				data[i] = rgbWhite;
			}
		}

		Graphics g = this.drawImage.getGraphics();
		g.setColor(Color.DARK_GRAY);
		g.fillRect(0, 0, this.drawImage.getWidth(), this.drawImage.getHeight());
		g.drawImage(this.image, 0, 0, this);

		this.repaint();
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public Color getColor() {
		return this.color;
	}

	public void saveColor() {
		this.colorTool.setSelectedColor(this.colorTool.getPickColor());
		this.setColor(this.colorTool.getSelectedColor());
		this.setPen(nonePen);
	}
}
