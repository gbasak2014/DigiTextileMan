package com.tm.image.trace;

public enum TraceEnum {
	NEW(1), OPEN(2), SAVE(3), CLOSE(4), PEN(5), LINE(6), RECT(7), CIRCLE(8), BEZ(9), FILL(10), COLOR(11), ZOOM_IN(12), ZOOM_OUT(13), COLOR_REDUCE(14), EXIT(15), RESIZE(
			16), ROTATE(17), SELECT(18), CUT(19), REPLACE_COLOR(20), SAVE_AS(
					21), LIST_COLOR(22), PICK_COLOR(23), FILTER(24), SAVE_FILTER(25), OPEN_SEL(26), ARRANGE_TILE(27), ARRANGE_CASCADE(28), MOVE_COLOR(29), SAVE_NEW(30);

	public int value;

	private TraceEnum(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}

	public static TraceEnum fromString(String val) {
		return fromInt(Integer.parseInt(val));
	}

	public static TraceEnum fromInt(int val) {
		switch (val) {
		case 1:
			return NEW;
		case 2:
			return OPEN;
		case 3:
			return SAVE;
		case 4:
			return CLOSE;
		case 5:
			return PEN;
		case 6:
			return LINE;
		case 7:
			return RECT;
		case 8:
			return CIRCLE;
		case 9:
			return BEZ;
		case 10:
			return FILL;
		case 11:
			return COLOR;
		case 12:
			return ZOOM_IN;
		case 13:
			return ZOOM_OUT;
		case 14:
			return COLOR_REDUCE;
		case 15:
			return EXIT;
		case 16:
			return RESIZE;
		case 17:
			return ROTATE;
		case 18:
			return SELECT;
		case 19:
			return CUT;
		case 20:
			return REPLACE_COLOR;
		case 21:
			return SAVE_AS;
		case 22:
			return LIST_COLOR;
		case 23:
			return PICK_COLOR;
		case 24:
			return FILTER;
		case 25:
			return SAVE_FILTER;
		case 26:
			return OPEN_SEL;
		case 27:
			return ARRANGE_TILE;
		case 28:
			return ARRANGE_CASCADE;
		case 29:
			return MOVE_COLOR;
		case 30:
			return SAVE_NEW;
		default:
			return NEW;
		}
	}
}
