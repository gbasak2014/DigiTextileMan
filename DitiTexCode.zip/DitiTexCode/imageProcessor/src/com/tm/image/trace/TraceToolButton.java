package com.tm.image.trace;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class TraceToolButton extends JButton {

	private static final long serialVersionUID = -5043605258594885101L;

	public TraceToolButton(int action, ActionListener listener, String imagePath, String title) {
		super("     ");
		this.setActionCommand(String.valueOf(action));
		this.setPreferredSize(new Dimension(35, 25));
		this.setBorder(BorderFactory.createEtchedBorder());
		URL url = this.getClass().getResource(imagePath);
		if (url != null) {
			this.setIcon(new ImageIcon(url));
		}
		this.setToolTipText(title);
		this.addActionListener(listener);
	}

	public TraceToolButton(int action, ActionListener listener, String title) {
		super("     ");
		this.setActionCommand(String.valueOf(action));
		this.setPreferredSize(new Dimension(35, 25));
		this.setBorder(BorderFactory.createRaisedBevelBorder());

		this.setToolTipText(title);
		this.addActionListener(listener);
	}

	public void selectMe() {
		this.setBorder(BorderFactory.createEtchedBorder(Color.BLACK, Color.RED));
	}

	public void deselectMe() {
		this.setBorder(BorderFactory.createEtchedBorder());
	}

}
