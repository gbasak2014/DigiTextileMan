package com.tm.image.trace;

public class MoveColor implements Pen {
	ImagePane pane;
	TraceDrawingPane drawingPane;

	public MoveColor(TraceDrawingPane drawingPane) {
		this.drawingPane = drawingPane;
	}

	public void setImagePane(ImagePane pane) {
		this.pane = pane;
		this.pane.isReplaceColor = true;
	}

	@Override
	public void draw() {
		this.pane.pickColor(this.pane.moveX, this.pane.moveY);
	}

	@Override
	public void save() {
		this.drawingPane.moveColor();
		this.pane.isReplaceColor = false;
	}
}
