package com.tm.motif.win;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.components.pane.MovableImagePane;
import com.tm.commons.listener.ColorChangeListener;
import com.tm.commons.theme.DigiTmTheme;
import com.tm.commons.tool.ColorPane;
import com.tm.commons.tool.DropdownColorChooser;
import com.tm.commons.win.DigiTmWin;

public class CodeToDesignWin extends DigiTmWin implements ActionListener, ColorChangeListener {

	static final int NEW = 0;
	static final int OPEN = 1;
	static final int SAVE = 2;
	static final int GET_SIZE = 3;
	static final int PROCESS = 4;
	static final int CLOSE = 5;
	static final int ZOOM_IN = 6;
	static final int ZOOM_OUT = 7;
	
	private static final long serialVersionUID = -8432008305188698619L;

	JTextField jtWidth = new JTextField();
	JTextField jtHeight = new JTextField();
	JTextField jtFilePath = new JTextField();

	JProgressBar progressBar = new JProgressBar(JProgressBar.HORIZONTAL);

	MovableImagePane imagePane = new MovableImagePane();

	DropdownColorChooser colorChooser;

	@Override
	public void saveProperties() {
		// TODO Auto-generated method stub

	}

	public CodeToDesignWin() {
		JPanel contentPane = new JPanel(new BorderLayout());
		this.setContentPane(contentPane);
		contentPane.add(getToolBar(), BorderLayout.NORTH);
		contentPane.add(getStatusBar(), BorderLayout.SOUTH);
		contentPane.add(this.imagePane, BorderLayout.CENTER);

		this.setPreferredSize(new Dimension(800, 700));
		this.setSize(800, 700);
		
		this.pack();
		this.setVisible(true);
	}

	JPanel getToolBar() {
		JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));

		panel.setBackground(DigiTmTheme.getBgColor());
		panel.add(new ButtonMenuItem(OPEN, this, "/img/open.jpg", "Open Code File"));
		panel.add(new ButtonMenuItem(GET_SIZE, this, "/img/get-size.jpg", "Get Design Size"));
		panel.add(new ButtonMenuItem(NEW, this, "/img/create-design.jpg", "Create Design Image"));

		this.colorChooser = new DropdownColorChooser(this, false);
		this.colorChooser.addColorPane(new ColorPane());
		this.colorChooser.setOpaque(false);
		panel.add(this.colorChooser);
		
		panel.add(new ButtonMenuItem(PROCESS, this, "/img/compile-code.jpg", "Compile Code"));
		panel.add(new ButtonMenuItem(SAVE, this, "/img/save.jpg", "Save Design"));

		panel.add(new ButtonMenuItem(ZOOM_IN, this, "/img/z2.jpg", "Zoom In"));
		panel.add(new ButtonMenuItem(ZOOM_OUT, this, "/img/z1.jpg", "Zoom Out"));

		panel.add(new ButtonMenuItem(CLOSE, this, "/img/close.jpg", "Zoom Out"));
		
		return panel;
	}

	JPanel getStatusBar() {
		JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 1));
		this.jtWidth.setPreferredSize(new Dimension(50, 20));
		this.jtHeight.setPreferredSize(new Dimension(50, 20));
		this.jtFilePath.setPreferredSize(new Dimension(250, 20));
		this.jtFilePath.setEditable(false);

		panel.setBackground(DigiTmTheme.getBgColor());
		panel.add(new JLabel("Width"));
		panel.add(this.jtWidth);
		panel.add(new JLabel("Height"));
		panel.add(this.jtHeight);
		panel.add(this.jtFilePath);

		panel.add(this.progressBar);

		return panel;
	}

	@Override
	public void actionPerformed(ActionEvent ae) {
		int cmd = Integer.parseInt(ae.getActionCommand());

		switch (cmd) {
		case NEW:
			createImage();
			break;
		case OPEN:
			openFile();
			break;
		case GET_SIZE:
			getImageSize();
			break;
		case PROCESS:
			compileCode();
			break;
		case SAVE:
			saveImage();
			break;
		case ZOOM_IN:
			this.imagePane.zoom(1);
			break;
		case ZOOM_OUT:
			this.imagePane.zoom(-1);
			break;
		case CLOSE:
			this.setVisible(false);
			this.dispose();
		default:
			break;
		}

	}

	void createImage() {
		try {
			this.getImageSize();
			int w = Integer.parseInt(this.jtWidth.getText());
			int h = Integer.parseInt(this.jtHeight.getText());
			BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
			Graphics g = img.getGraphics();
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, w, h);
			g.dispose();
			this.imagePane.setImage(img);
			this.imagePane.repaint();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "Error creating design Image!!");
		}
	}

	void openFile() {
		JFileChooser jfc = new JFileChooser();
		if (jfc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
			this.jtFilePath.setText(jfc.getSelectedFile().getAbsolutePath());
			System.out.println(jfc.getSelectedFile().getAbsolutePath());
		}
	}

	void getImageSize() {
		int width = 0;
		int height = 0;

		try {
			BufferedReader br = new BufferedReader(new FileReader(this.jtFilePath.getText()));
			String line;
			while ((line = br.readLine()) != null) {
				line = line.replace("|", "");
				int idx = line.indexOf(':');
				int no = Integer.parseInt(line.substring(0, idx).trim());
				if (no > height) {
					height = no;
				}

				idx = line.lastIndexOf(',') + 1;
				int idx1 = line.lastIndexOf('-') + 1;
				if (idx1 > idx) {
					idx = idx1;
				}

				no = Integer.parseInt(line.substring(idx).trim());
				if (no > width) {
					width = no;
				}

			}

			this.jtWidth.setText(String.valueOf(width));
			this.jtHeight.setText(String.valueOf(height));
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	void compileCode() {
		try {
			BufferedImage img = imagePane.getImage();
			if (img == null)
			{
				this.createImage();
				img = imagePane.getImage();
			}
			
			this.progressBar.setMaximum(Integer.parseInt(jtHeight.getText()));

			BufferedReader br = new BufferedReader(new FileReader(this.jtFilePath.getText()));
			String line;
			int x;
			int y;
			int rgb = this.colorChooser.getSelectedColor().getRGB();
			
			while ((line = br.readLine()) != null) {
				line = line.replace("|", "");
				int idx = line.indexOf(':');
				y = Integer.parseInt(line.substring(0, idx).trim()) - 1;
				line = line.substring(line.indexOf('>') + 1);

				String[] pts = line.split(",");
				for (String pt : pts) {
					String[] xPts = pt.split("--");
					if (xPts.length == 1) {
						img.setRGB((Integer.parseInt(xPts[0].trim()) - 1), y, rgb);
					} else {
						for (x = (Integer.parseInt(xPts[0].trim()) - 1); x <= (Integer.parseInt(xPts[1].trim()) - 1); x++) {
							img.setRGB(x, y, rgb);
						}
					}
				}

				this.progressBar.setValue(y);
			}

			imagePane.repaint();
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	void saveImage() {
		JFileChooser jfc = new JFileChooser();
		jfc.setFileFilter(new FileNameExtensionFilter("24-bit Bitmap", "bmp"));
		if (jfc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
			String path = jfc.getSelectedFile().getAbsolutePath();
			if (!path.toLowerCase().endsWith(".bmp")) {
				path = path + ".bmp";
			}

			try {
				ImageIO.write(imagePane.getImage(), "BMP", new File(path));
			} catch (Exception e) {

			}
		}
	}

	@Override
	public void colorChanged(Color color) {

	}

	public static void main(String[] args) {
		//new CodeToDesignWin();
		
		System.out.println(System.getProperty("java.home"));
		System.out.println(System.getProperty("java.class.path"));
		System.out.println(File.pathSeparator);
		System.out.println(File.separator);
		
	}
}
