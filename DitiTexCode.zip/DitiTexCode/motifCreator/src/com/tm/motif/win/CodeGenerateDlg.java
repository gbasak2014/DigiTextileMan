package com.tm.motif.win;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;

import com.tm.commons.action.CodeMenuActionEnum;
import com.tm.commons.dlg.ImageRotateDlg;
import com.tm.commons.dlg.PrintCodeDlg;
import com.tm.commons.dto.GridOptions;
import com.tm.commons.dto.PrintOption;
import com.tm.commons.listener.ColorChangeListener;
import com.tm.commons.pane.CodeImagePane;
import com.tm.commons.theme.DigiTmTheme;
import com.tm.commons.win.DigiTmWin;
import com.tm.motif.tool.ToolBarCodeGenerate;

public class CodeGenerateDlg extends DigiTmWin
		implements AdjustmentListener, MouseListener, MouseMotionListener, ActionListener, ColorChangeListener {

	private static final long serialVersionUID = 8994578844259190807L;
	static int PICK_COLOR = 0;
	static int REPLACE_COLOR = 1;
	static int PEN = 2;

	public static final String CODE_FILE_NAME = "tm-code.txt";

	JScrollBar scrollHoriz = new JScrollBar(JScrollBar.HORIZONTAL);
	JScrollBar scrollVert = new JScrollBar(JScrollBar.VERTICAL);
	ToolBarCodeGenerate toolBar;
	CodeImagePane imgPane;

	JPanel contentPane = new JPanel(new BorderLayout());
	int cellWidth;
	int imageLeft = 0;
	int imageTop = 0;

	int pen;
	BufferedImage img;
	String codeFilePath;
	PrintOption printOption;

	String path;

	String user;

	@Override
	public void saveProperties() {
	}

	@Override
	public void colorChanged(Color color) {
	}

	public CodeGenerateDlg(String user, String path, BufferedImage img, GridOptions gridOption, String codeFilePath,
			PrintOption printOption) {
		super();
		this.user = user;
		this.path = path;
		this.img = img;
		this.codeFilePath = codeFilePath;
		this.printOption = printOption;

		this.imgPane = new CodeImagePane(img, gridOption, this);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		setContentPane(contentPane);

		toolBar = new ToolBarCodeGenerate(this);
		this.contentPane.add(toolBar, BorderLayout.NORTH);
		this.contentPane.add(scrollHoriz, BorderLayout.SOUTH);
		this.contentPane.add(scrollVert, BorderLayout.EAST);
		this.contentPane.add(imgPane, BorderLayout.CENTER);

		this.scrollHoriz.setMinimum(0);
		this.scrollHoriz.setMaximum(img.getWidth());
		this.scrollVert.setMinimum(0);
		this.scrollVert.setMaximum(img.getHeight());

		this.scrollHoriz.addAdjustmentListener(this);
		this.scrollVert.addAdjustmentListener(this);

		this.imgPane.addMouseListener(this);
		this.imgPane.addMouseMotionListener(this);

		setBackground();

		pack();
		setSize(500, 450);
		setVisible(true);
	}

	void setBackground() {
		this.contentPane.setBackground(DigiTmTheme.getBgColor());
		this.contentPane.setBorder(DigiTmTheme.getLineBorder());

		this.toolBar.setBackground(DigiTmTheme.getBgColor());
		this.toolBar.setBorder(DigiTmTheme.getLineBorder());
	}

	public void rotate() {
		ImageRotateDlg dlg = new ImageRotateDlg(this.img);
		dlg.setModal(true);
		dlg.setVisible(true);

		if (dlg.isOk()) {
			BufferedImage tmp = dlg.getImage();
			if (tmp != null) {
				this.img = tmp;
				this.imgPane.setImage(this.img);
			}
		}

		dlg.dispose();
	}

	public void mirrorHorizontal() {
		this.imgPane.mirrorHorizontal();
	}

	public void mirrorVertical() {
		this.imgPane.mirrorVertical();
	}

	public void zoom(int zoom) {
		this.imgPane.zoom(zoom);
	}

	public void pickColor() {
		this.pen = PICK_COLOR;
	}

	public void replaceColor() {
		this.pen = REPLACE_COLOR;
	}

	public void selectPen() {
		this.pen = PEN;
	}

	public void viewCode() {
		// CodeViewDlg dlg = new CodeViewDlg(this.codeFilePath + File.separator
		// + CodeGenerateDlg.CODE_FILE_NAME, this.printOption);
		// dlg.setVisible(true);
		String codeFile = this.codeFilePath + File.separator + CodeGenerateDlg.CODE_FILE_NAME;
		PrintCodeDlg codeDlg = new PrintCodeDlg(this.user, codeFile, this.printOption);
		codeDlg.setVisible(true);

	}

	public void codeGenerate() {
		int status = JOptionPane.showConfirmDialog(this, "Append To existing code?");
		if (JOptionPane.CANCEL_OPTION == status) {
			return;
		}

		File file = new File(this.codeFilePath, CODE_FILE_NAME);
		boolean append = false;
		if (JOptionPane.YES_OPTION == status) {
			append = true;
		}

		try {
			PrintWriter pw;
			if (append) {
				pw = new PrintWriter(new FileWriter(file, true));
			} else {
				pw = new PrintWriter(file);
			}

			this.codeGenerate(pw, append);
			pw.close();
			JOptionPane.showMessageDialog(this, "Code generated!!");
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this,
					"Not able to create code file, please specify proper code path from library setting");
		}
	}

	public void codeGenerate(PrintWriter pw, boolean append) {

		if (append) {
			pw.println("\n");
		}

		pw.println("Board: " + this.img.getHeight() + ", Thread: " + this.img.getWidth());
		if (this.printOption.isPrintPath()) {
			pw.println("File: " + this.path);
		}
		pw.println("Designer:" + this.user);
		pw.println("--------------------------------------------------------------------------------");

		int rgb = this.toolBar.getSelectedColorButton().getRGB();

		StringBuffer line = new StringBuffer();
		try {
			int h = this.img.getHeight();
			int w = this.img.getWidth();

			for (int y = 0; y < h; y++) {
				line.delete(0, line.length());
				// line.append(String.format("%03d", (y + 1)) + ":>");
				int startX;

				for (int x = 0; x < w; x++) {
					if (this.img.getRGB(x, y) == rgb) {
						x++;
						startX = x;

						if (line.length() > 0) {
							line.append(", ");
						}

						line.append(startX);

						for (; x < w && this.img.getRGB(x, y) == rgb; x++)
							;

						if (startX < x) {
							if ((startX + 1) == x) {
								line.append(", ").append(x);

							} else {
								line.append("--").append(x);
							}
						}
					}
				}

				if (line.length() > 0) {
					line.append("||");
					pw.println((y + 1) + ":>" + line.toString());
				}

			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	public void selectColor() {
		// TODO
	}

	@Override
	public void adjustmentValueChanged(AdjustmentEvent e) {
		int x = scrollHoriz.getValue();
		int y = scrollVert.getValue();

		this.imgPane.scroll(x, y);
	}

	public CodeImagePane getImagePane() {
		return this.imgPane;
	}

	@Override
	public void mousePressed(MouseEvent e) {
		int x = e.getX();
		int y = e.getY();
		int rgb = imgPane.getRGB(x, y);

		if (PEN == this.pen) {
			this.imgPane.setRGB(x, y, toolBar.getSelectedColorButton().getRGB());
		} else if (PICK_COLOR == pen) {
			toolBar.setSelectedColor(rgb);
		} else if (REPLACE_COLOR == pen) {
			this.imgPane.replaceColor(rgb, toolBar.getSelectedColorButton().getRGB());
		}

	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		if (PEN == this.pen) {
			this.imgPane.setRGB(e.getX(), e.getY(), toolBar.getSelectedColorButton().getRGB());
		}
	}

	@Override
	public void mouseMoved(MouseEvent e) {

		if (this.pen == PICK_COLOR || this.pen == REPLACE_COLOR) {
			this.toolBar.setNewColor(new Color(this.imgPane.getRGB(e.getX(), e.getY())));
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		CodeMenuActionEnum action = CodeMenuActionEnum.fromString(e.getActionCommand());

		switch (action) {
		case PICK_COLOR:
			this.pickColor();
			break;
		case REPLACE_COLOR:
			this.replaceColor();
			this.img = this.imgPane.getImage();
			break;
		case PEN:
			this.selectPen();
			break;
		/*
		 * case ROTATE: this.rotate(); break;
		 */
		case MIRROR_HORIZ:
			this.mirrorHorizontal();
			break;
		case MIRROR_VERT:
			this.mirrorVertical();
			break;
		case ZOOM_IN:
			this.zoom(1);
			break;
		case ZOOM_OUT:
			this.zoom(-1);
			break;
		case CODE_GENERATE:
			this.codeGenerate();
			break;
		case SELECT_COLOR:
			this.selectColor();
			break;
		case VIEW_CODE:
			this.viewCode();
			break;
		case CLOSE:
			this.setVisible(false);
			this.dispose();
			break;
		}
	}
}
