package com.tm.motif.win;

import java.awt.Font;

import com.tm.commons.dlg.ImageMixDlg;
import com.tm.commons.dlg.ImageSplitDlg;
import com.tm.commons.dlg.PrintCodeDlg;
import com.tm.commons.dto.PrintOption;

public class A {

	public static void main(String[] args) {
		openImgSplitDlg();
		//openImgMixDlg();
	}

	static void openPrintDlg()
	{
		PrintOption option = new PrintOption();
		option.setFont(new Font("Arial", Font.ITALIC, 14));
		new PrintCodeDlg("AAAA", "E:/TM01/code-001.txt", option);		
	}
	
	static void openImgMixDlg()
	{
		ImageMixDlg dlg = new ImageMixDlg();
		dlg.setVisible(true);
	}
	
	static void openImgSplitDlg()
	{
		ImageSplitDlg dlg = new ImageSplitDlg();
		dlg.setVisible(true);
	}
	
	
}
