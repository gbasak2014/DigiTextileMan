package com.tm.motif.win;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.filechooser.FileFilter;

import com.tm.commons.action.MergeImageEnume;
import com.tm.commons.clipboard.ClipboardUtil;
import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.image.ImageUtils;
import com.tm.commons.menu.DigiTmToolBar;
import com.tm.commons.win.DigiTmWin;
import com.tm.design.motif.Motif;
import com.tm.design.pane.MotifPane;

public class ImageMergeWin extends DigiTmWin implements ActionListener,
		MouseListener {
	MotifPane motifPane;
	MainPane jpMain;
	MergeImgPane mergeImgPane;

	JSplitPane jsp;

	File currentDir;

	public ImageMergeWin() {
		/*
		 * this.motifPane = new MotifPane(Color.white);
		 * this.motifPane.setHorizontalAlign(true);
		 * this.motifPane.setHorizontalRepeate(0);
		 */
		this.jpMain = new MainPane();
		this.mergeImgPane = new MergeImgPane();

		this.jsp = new JSplitPane(JSplitPane.VERTICAL_SPLIT, jpMain,
				this.mergeImgPane);

		this.getContentPane().setLayout(new BorderLayout());
		DigiTmToolBar jpButton = new DigiTmToolBar();

		this.getContentPane().add(jsp, BorderLayout.CENTER);
		// jsp.add(jpMain);

		// this.getContentPane().add(jpMain, BorderLayout.CENTER);

		jpButton.setLayout(new FlowLayout(FlowLayout.LEADING, 0, 0));
		jpButton.add(new ButtonMenuItem(MergeImageEnume.OPEN.value, this,
				"/img/open.jpg", "Open Image"));
		jpButton.add(new ButtonMenuItem(MergeImageEnume.PASTE.value, this,
				"/img/paste.jpg", "Paste Image"));
		jpButton.add(new ButtonMenuItem(MergeImageEnume.LEFT.value, this,
				"/img/mv-l.jpg", "Move Left"));
		jpButton.add(new ButtonMenuItem(MergeImageEnume.RIGHT.value, this,
				"/img/mv-r.jpg", "Move Right"));
		jpButton.add(new ButtonMenuItem(MergeImageEnume.DELETE.value, this,
				"/img/delete-sel.jpg", "Delete Image"));
		jpButton.add(new ButtonMenuItem(MergeImageEnume.MERGE.value, this,
				"/img/merge.jpg", "Merge Image"));
		jpButton.add(new ButtonMenuItem(MergeImageEnume.SAVE.value, this,
				"/img/save.jpg", "Save"));
		JLabel lbl = new JLabel();
		lbl.setPreferredSize(new Dimension(40, 20));
		jpButton.add(lbl);
		jpButton.add(new ButtonMenuItem(MergeImageEnume.EXIT.value, this,
				"/img/close.jpg", "Exit"));

		this.getContentPane().add(jpButton, BorderLayout.NORTH);

		this.setPreferredSize(new Dimension(500, 400));
		// this.addMouseListener(this);

		this.jpMain.addMouseListener(this);
		this.pack();
	}

	@Override
	public void saveProperties() {

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		MergeImageEnume cmd = MergeImageEnume.fromString(e.getActionCommand());

		switch (cmd) {
		case OPEN:
			openImage();
			break;
		case PASTE:
			pasteImage();
			break;
		case LEFT:
		case RIGHT:
			this.jpMain.move(cmd);
			break;
		case DELETE:
			this.motifPane.removeSelectedMotif(this.jpMain.getGraphics());
			this.jpMain.repaint();
			break;
		case SAVE:
			save();
			break;
		case MERGE:
			mergeImages();
			break;
		case EXIT:
			this.setVisible(false);
			this.dispose();
			System.exit(0);
			break;
		}
	}

	void mergeImages() {
		int width = 0;
		int height = 0;
		List<BufferedImage> imgList = new ArrayList<BufferedImage>();

		for (Motif m : this.motifPane.getList()) {
			BufferedImage img = m.getImage();
			imgList.add(img);
			if (height < img.getHeight()) {
				height = img.getHeight();
			}
			width = width + img.getWidth();
		}

		BufferedImage newImg = new BufferedImage(width, height,
				BufferedImage.TYPE_INT_RGB);
		Graphics g = newImg.getGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, width, height);
		g.dispose();

		for (int x = 0; x < width; x++) {
			for (int y = 0; y < height; y++) {
				
			}
		}
	}

	void save() {

	}

	void openImage() {
		JFileChooser jfc = new JFileChooser(this.currentDir);
		jfc.setFileFilter(new FileFilter() {

			@Override
			public String getDescription() {
				// TODO Auto-generated method stub
				return null;
			}

			@Override
			public boolean accept(File f) {
				// TODO Auto-generated method stub
				return f.isDirectory()
						|| f.getName().toLowerCase().endsWith(".bmp");
			}
		});

		if (jfc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
			File imgFine = jfc.getSelectedFile();
			this.currentDir = imgFine.getParentFile();
			System.out.println("File:" + imgFine);

			try {
				BufferedImage img = ImageUtils.getImageFromFile(imgFine
						.getAbsolutePath());
				if (img != null) {
					addImage(img);
				}
			} catch (Exception e) {
			}

		}
	}

	void addImage(BufferedImage img) {
		if (this.motifPane == null) {
			this.motifPane = new MotifPane(img, true);
			this.motifPane.setHorizontalRepeate(0);
			this.jpMain.setMotifPane(this.motifPane);
		} else {
			this.motifPane.addMotif(img);
		}
		this.jpMain.repaint();
	}

	void pasteImage() {
		if (ClipboardUtil.hasClipboardImage()) {
			BufferedImage img = ClipboardUtil.getImageFromClipboard();
			if (img != null) {
				addImage(img);
			}
		}
	}

	static class MainPane extends JPanel {
		MotifPane mp;

		public MainPane() {
			// TODO Auto-generated constructor stub
		}

		void setMotifPane(MotifPane mp) {
			this.mp = mp;
		}

		void move(MergeImageEnume dir) {
			if (dir == MergeImageEnume.LEFT) {
				mp.moveUp(this.getGraphics());
			} else {
				mp.moveDown(this.getGraphics());
			}
		}

		@Override
		public void paint(Graphics g) {
			super.paint(g);
			int w = this.getWidth();
			int h = this.getHeight();
			g.setColor(this.getBackground());
			g.fillRect(0, 0, w, h);

			if (this.mp != null) {
				this.mp.paint(g);
			}
		}
	}

	static class MergeImgPane extends JPanel {
		BufferedImage img;

		void setImage(BufferedImage img) {
			this.img = img;
		}

		@Override
		public void paint(Graphics g) {
			g.setColor(Color.BLACK);
			g.fillRect(0, 0, this.getWidth(), this.getHeight());
			if (img != null) {
				int w = img.getWidth();
				int h = img.getHeight();
				g.setColor(Color.WHITE);
				g.drawImage(img, 1, 1, this);
				g.drawRect(0, 0, w + 2, h + 2);
			}
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		int x = e.getX();
		int y = e.getY();

		System.out.println("RELEASED:" + e.getX() + "," + e.getY());

		if (this.motifPane.isIntersect(x, y)) {
			this.motifPane.selecteMotif(x, y);
			this.jpMain.repaint();
		}
	}

	public static void main(String[] args) {
		ImageMergeWin imw = new ImageMergeWin();
		imw.setVisible(true);
	}
}
