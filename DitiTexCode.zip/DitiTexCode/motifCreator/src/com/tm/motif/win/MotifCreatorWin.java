package com.tm.motif.win;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.KeyStroke;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.DrawingImage;
import com.tm.commons.components.GridImage;
import com.tm.commons.components.pane.DigiTmStatusBar;
import com.tm.commons.drawing.tool.FillPattern;
import com.tm.commons.drawing.tool.PenHolder;
import com.tm.commons.dto.DigiTmConstants;
import com.tm.commons.dto.FileOptions;
import com.tm.commons.dto.GridOptions;
import com.tm.commons.dto.LibOptions;
import com.tm.commons.dto.OtherOptions;
import com.tm.commons.dto.PrintOption;
import com.tm.commons.theme.DigiTmTheme;
import com.tm.commons.tool.DropdownColorChooser;
import com.tm.commons.win.DigiTmWin;
import com.tm.motif.action.handler.DrawingHandler;
import com.tm.motif.action.handler.MotifCreatorActionHandler;
import com.tm.motif.action.handler.PenSelectHandler;
import com.tm.motif.menu.MotifCreatorToolBar;
import com.tm.motif.menu.MotifMenuBar;
import com.tm.motif.pane.DrawingPane;
import com.tm.motif.tool.DrawingTool;
import com.tm.motif.tool.ToolBarDrawingHoriz;

public class MotifCreatorWin extends DigiTmWin {
	// com.tm.motif.win.MotifCreatorWin
	private static final long serialVersionUID = -1696822790403338547L;

	MotifCreatorActionHandler actionHandler;
	JPanel container;
	JTabbedPane designContainer = new JTabbedPane();
	DigiTmStatusBar statusBar;
	DrawingTool toolBarDrawing;
	MotifCreatorToolBar motifCreatorToolBar;

	DrawingPane currentDrawingPane;

	GridImage gridImage;
	DrawingImage drawingImage;

	DrawingHandler drawingHandler;

	PenHolder penHolder;
	FillPattern fillPattern;
	Color currentColor = Color.BLACK;
	Color currentFillColor = Color.BLACK;

	GridOptions gridOptions;
	LibOptions libOptions;
	PrintOption printOption;
	FileOptions fileOptions;
	OtherOptions otherOptions;

	String lastGrapgPath;

	PenSelectHandler penSelectHandler;

	Map<Long, String> history;

	DropdownColorChooser colorChooser;

	String user;

	public MotifCreatorWin(String user) {
		super("/img/mc-logo.jpg");
		this.user = user;
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);
		loadProperties();
		createComponent();
		setTheme();
		registerKeyHandler();
		this.colorChooser = this.motifCreatorToolBar.getColorChooser();
		this.pack();
		this.setVisible(true);
	}

	void registerKeyHandler() {
		this.getRootPane().registerKeyboardAction(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent ae) {
				cancel();
			}
		}, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

		this.getRootPane().registerKeyboardAction(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent ae) {
				commit();
			}
		}, KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

		this.getRootPane().registerKeyboardAction(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent ae) {
				clearSelection();
			}
		}, KeyStroke.getKeyStroke(KeyEvent.VK_DELETE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

	}

	void cancel() {
		if (this.currentDrawingPane != null) {
			this.currentDrawingPane.cancel();
		}
	}

	void commit() {
		if (this.currentDrawingPane != null) {
			this.currentDrawingPane.commit();
		}
	}

	void clearSelection() {
		if (this.currentDrawingPane != null) {
			this.currentDrawingPane.clearSelectedArea();
		}
	}

	private void loadProperties() {
		this.gridOptions = new GridOptions();
		this.libOptions = new LibOptions();
		this.printOption = new PrintOption();
		this.fileOptions = new FileOptions();
		this.otherOptions = new OtherOptions();

		Properties properties = new Properties();
		String path = "";
		try {
			File file = new File(DigiTmConstants.PROP_FILE_MOTIF);
			path = file.getAbsolutePath();
			properties.load(new FileInputStream(file));
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Properties Load ERROR: " + path);
		}
		this.gridOptions.loadProperties(properties);
		this.libOptions.setProperties(properties);
		this.printOption.setProperties(properties);
		this.fileOptions.setProperties(properties);
		this.otherOptions.loadProperties(properties);

		this.history = this.getHistory();

		File file = new File(this.libOptions.getCodeHome());
		if (!file.exists()) {
			file.mkdirs();
		}

		file = new File(this.libOptions.getMotifHome());
		if (!file.exists()) {
			file.mkdirs();
		}

		file = new File(this.libOptions.getWeaveHome());
		if (!file.exists()) {
			file.mkdirs();
		}
	}

	Map<Long, String> getHistory() {
		Map<Long, String> map = new TreeMap<Long, String>(new Comparator<Long>() {
			@Override
			public int compare(Long o1, Long o2) {
				return o2.compareTo(o1);
			}
		});

		Properties properties = new Properties();
		try {
			File file = new File(DigiTmConstants.PROP_HIST_MOTIF);
			properties.load(new FileInputStream(file));

			for (Object key : properties.keySet()) {
				map.put(Long.valueOf((String) key), properties.getProperty((String) key));
			}

		} catch (Exception e) {
		}

		return map;
	}

	void saveHistory() {
		Set<String> set = new HashSet<String>();
		Properties props = new Properties();
		for (Long key : this.history.keySet()) {
			String filePath = this.history.get(key);
			if (!set.contains(filePath)) {
				props.put(String.valueOf(key), filePath);
				set.add(filePath);
			}

			if (props.size() >= 10) {
				break;
			}
		}

		try {
			File file = new File(DigiTmConstants.PROP_HIST_MOTIF);
			System.out.println(file.getAbsolutePath());
			props.store(new FileOutputStream(file), "Generated by system, please do not delete or update.");
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this, "History save ERROR: " + e.getMessage());
		}
	}

	@Override
	public void saveProperties() {
		System.out.println("Entered saveProperties");
		this.saveLibrary();
		this.saveHistory();
		this.cleanup();
		System.out.println("Exiting saveProperties");
	}

	public void saveLibrary() {
		try {
			File file = new File(DigiTmConstants.PROP_FILE_MOTIF);
			System.out.println(file.getAbsolutePath());
			File dir = file.getParentFile();
			if (!dir.exists()) {
				dir.mkdirs();
			}

			Properties props = new Properties();
			this.libOptions.updateProperties(props);
			this.gridOptions.updateProperties(props);
			this.fileOptions.updateProperties(props);
			this.printOption.updateProperties(props);
			this.otherOptions.updateProperties(props);

			props.store(new FileOutputStream(file),
					"Properties generated by the system. Do not delete or update properties.");
		} catch (Exception e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Library save ERROR: " + e.getMessage());
		}
	}

	private void cleanup() {
		int cnt = this.designContainer.getComponentCount();
		for (int i = 0; i < cnt; i++) {
			DrawingPane dp = (DrawingPane) this.designContainer.getComponentAt(i);
			dp.cleanup();
		}
	}

	void createComponent() {
		this.container = new JPanel(new BorderLayout());
		this.setContentPane(this.container);
		this.actionHandler = new MotifCreatorActionHandler(this);
		this.drawingImage = new DrawingImage(100, 100);
		this.penHolder = new PenHolder();
		this.fillPattern = new FillPattern();
		this.motifCreatorToolBar = new MotifCreatorToolBar(actionHandler);
		this.toolBarDrawing = new ToolBarDrawingHoriz(this, this.motifCreatorToolBar.getColorChooser());

		this.statusBar = new DigiTmStatusBar(this.actionHandler.getStatusBarHandler());
		// this.history = getHistory();
		this.setJMenuBar(new MotifMenuBar(this.actionHandler, this.history, this.libOptions.getNewApp()));
		JPanel jpTool = new JPanel(new GridLayout(2, 1));
		jpTool.add(this.motifCreatorToolBar);
		jpTool.add(this.toolBarDrawing);

		this.container.add(jpTool, BorderLayout.NORTH);
		this.container.add(this.designContainer, BorderLayout.CENTER);
		this.container.add(this.statusBar, BorderLayout.SOUTH);

		// this.container.add(this.toolBarDrawing, BorderLayout.WEST);

		this.drawingHandler = new DrawingHandler(this);
		this.gridImage = new GridImage(this.gridOptions);

		this.designContainer.addChangeListener(new ChangeListener() {

			@Override
			public void stateChanged(ChangeEvent e) {
				selectDrawingPane();
			}
		});

		this.penSelectHandler.setCustomCursor(this.otherOptions.isCustomCursor());
	}

	@Override
	public void windowClosing(WindowEvent e) {
		System.out.println("Entered windowClosing");
		int status = JOptionPane.showConfirmDialog(this,
				"Save your work before closing, are you sure to close application", "Confirmation",
				JOptionPane.YES_NO_OPTION);

		if (status == JOptionPane.YES_OPTION) {
			super.windowClosing(e);
			System.exit(0);
		} else {
			this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		}
		System.out.println("Exiting windowClosing");
	}

	void setTheme() {
		// this.designContainer.setBackground(DigiTmTheme.getBgColor());
		this.statusBar.setBackground(DigiTmTheme.getBgColor());
		this.statusBar.setBackground(DigiTmTheme.getBgColor());
		this.getContentPane().setBackground(Color.WHITE);
	}

	public DrawingPane getCurrentDrawingPane() {
		return this.currentDrawingPane;
	}

	public void setDrawingTool(DrawingToolEnum tool) {

	}

	public void insertRowsOrColumns() {

	}

	public JTabbedPane getDesignContainer() {
		return designContainer;
	}

	public DrawingImage getDrawingImage() {
		return drawingImage;
	}

	public void setCurrentDrawingPane(DrawingPane currentDrawingPane) {
		this.currentDrawingPane = currentDrawingPane;
	}

	public void setDrawingImage(BufferedImage img) {
		this.drawingImage.copyImage(img);
	}

	public DrawingHandler getDrawingHandler() {
		return drawingHandler;
	}

	public PenHolder getPenHolder() {
		return penHolder;
	}

	public FillPattern getFillPattern() {
		return fillPattern;
	}

	public Color getCurrentColor() {
		return currentColor;
	}

	public void setCurrentColor(Color currentColor) {
		this.currentColor = currentColor;
	}

	public MotifCreatorToolBar getMotifCreatorToolBar() {
		return motifCreatorToolBar;
	}

	public DrawingTool getToolBarDrawing() {
		return toolBarDrawing;
	}

	public GridOptions getGridOptions() {
		return gridOptions;
	}

	public void setGridOptions(GridOptions gridOptions) {
		this.gridOptions = gridOptions;
	}

	public GridImage getGridImage() {
		return gridImage;
	}

	public DigiTmStatusBar getStatusBar() {
		return statusBar;
	}

	public String getLastGrapgPath() {
		return lastGrapgPath;
	}

	public void setLastGrapgPath(String lastGrapgPath) {
		this.lastGrapgPath = lastGrapgPath;
	}

	void selectDrawingPane() {
		if (this.currentDrawingPane != null) {
			this.currentDrawingPane.removeDrawingHandler(this.drawingHandler);
		}

		this.currentDrawingPane = (DrawingPane) this.designContainer.getSelectedComponent();
		this.drawingImage.copyImage(this.currentDrawingPane.getSavedImage());

		this.currentDrawingPane.setDrawingHandler(this.drawingHandler);

		/*
		 * if (this.penHolder.getPen() != null) {
		 * this.penHolder.getPen().setGraphPane(this.currentDrawingPane.
		 * getGraphPan( )); }
		 */
		this.gridImage.createGrid(this.currentDrawingPane.getImgLeft(), this.currentDrawingPane.getImgTop(),
				this.currentDrawingPane.getImgWidth(), this.currentDrawingPane.getImgHeight());

	}

	public void addToHistory(Long time, String filePath) {
		this.history.put(time, filePath);
	}

	public PenSelectHandler getPenSelectHandler() {
		return penSelectHandler;
	}

	public void setPenSelectHandler(PenSelectHandler penSelectHandler) {
		this.penSelectHandler = penSelectHandler;
	}

	public LibOptions getLibOptions() {
		return libOptions;
	}

	public PrintOption getPrintOption() {
		return printOption;
	}

	public FileOptions getFileOptions() {
		return fileOptions;
	}

	public OtherOptions getOtherOptions() {
		return this.otherOptions;
	}

	public Color getCurrentFillColor() {
		return currentFillColor;
	}

	public void setCurrentFillColor(Color currentFillColor) {
		this.currentFillColor = currentFillColor;
		if (this.penHolder.getPen() != null) {
			this.penHolder.getPen().setFillColor(currentFillColor);
		}
	}

	public void openScanner() {
		String scannerPath = this.libOptions.getScannerPath();
		if (scannerPath != null && !"NULL".equalsIgnoreCase(scannerPath)) {
			try {
				if (JOptionPane.showConfirmDialog(this, "Open Scanner?", "Open Scanner",
						JOptionPane.OK_CANCEL_OPTION) == JOptionPane.YES_OPTION) {
					Runtime.getRuntime().exec(scannerPath);
				}
			} catch (Exception e) {
				JOptionPane.showMessageDialog(this, "Scanner Open Error for path: " + scannerPath);
				e.printStackTrace();
			}
		}
	}

	public void openNewApp() {
		String newApp = this.libOptions.getNewApp();
		String[] app;
		if (newApp != null) {
			app = newApp.split("@");
			if (app.length == 2) {
				try {
					if (JOptionPane.showConfirmDialog(this, "Open " + app[0] + "?", "Open App",
							JOptionPane.OK_CANCEL_OPTION) == JOptionPane.YES_OPTION) {
						Runtime.getRuntime().exec(app[1]);
					}
				} catch (Exception e) {
					JOptionPane.showMessageDialog(this, "Application opening Error for path: " + app[1]);
				}
			}
		}
	}

	public void setCustomCursor(Cursor cursor) {
		if (this.getCurrentDrawingPane() != null) {
			this.currentDrawingPane.getGraphPane().setCustomCurson(cursor);
		}
	}

	public void setCustomCorser(boolean custom) {
		this.penSelectHandler.setCustomCursor(custom);
	}

	public void selectColorChooser(boolean isFillColor) {
		if (isFillColor) {
			this.colorChooser = this.toolBarDrawing.getColorChooser();
		} else {
			this.colorChooser = this.motifCreatorToolBar.getColorChooser();
		}
	}

	public void pickColor(Color color) {
		this.colorChooser.pickColor(color);
	}

	public void selectColor(Color color) {
		this.colorChooser.setSelectedColor(color);
	}

	public DropdownColorChooser getSelectedColorChooser() {
		return this.colorChooser;
	}

	public String getUser() {
		return this.user;
	}

	public void setDrawingArea() {
		this.statusBar.setDrawingArea();
	}
}
