package com.tm.motif.menu;

import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.util.Map;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JSeparator;

import com.tm.commons.action.ArrangeMenuActionEnum;
import com.tm.commons.action.CodeMenuActionEnum;
import com.tm.commons.action.EditMenuActionEnum;
import com.tm.commons.action.FileMenuActionEnum;
import com.tm.commons.action.HelpMenuActionEnum;
import com.tm.commons.action.SettingsMenuActionEnum;
import com.tm.commons.action.ShapeMenuActionEnum;
import com.tm.commons.action.ViewMenuActionEnum;
import com.tm.commons.menu.DigiTmMenu;
import com.tm.commons.menu.DigiTmMenuBar;
import com.tm.commons.menu.DigiTmMenuItem;
import com.tm.motif.action.handler.MotifCreatorActionHandler;

/**
 * Menubar for motifCreator windows
 * 
 * @author Gouranga Basak
 * 
 */
public class MotifMenuBar extends DigiTmMenuBar {
	private static final long serialVersionUID = -9140263375986957347L;

	public MotifMenuBar(MotifCreatorActionHandler actionHandler, Map<Long, String> history, String newApp) {

		this.add(this.getFileMenu(actionHandler.getFileMenuActionHandler(), newApp));
		this.add(this.getEditMenu(actionHandler.getEditMenuActionHandler()));
		this.add(this.getArrangeMenu(actionHandler.getArrangeMenuActionHandler()));
		this.add(this.getMoveMenu(actionHandler.getMoveMenuHandler()));
		this.add(this.getCodeMenu(actionHandler.getCodeMenuActionHandler()));
		this.add(this.getViewMenu(actionHandler.getViewMenuActionHandler()));
		this.add(getToolsMenu(actionHandler.getEditMenuActionHandler()));
		this.add(this.getSettingsMenu(actionHandler.getSettingsMenuActionHandler()));
		this.add(this.getHelpMenu(actionHandler.getHelpMenuActionHandler()));
		this.add(this.getHistoryMenu(actionHandler.getHistoryMenuHandler(), history));
	}

	JMenu getFileMenu(ActionListener handler, String newApp) {
		JMenu menu = new DigiTmMenu("File", KeyEvent.VK_F);

		menu.add(new DigiTmMenuItem("New", FileMenuActionEnum.NEW.value, handler, KeyEvent.VK_N));
		menu.add(new DigiTmMenuItem("Open", FileMenuActionEnum.OPEN.value, handler, KeyEvent.VK_O));
		menu.add(new DigiTmMenuItem("Save", FileMenuActionEnum.SAVE.value, handler, KeyEvent.VK_S));
		menu.add(new DigiTmMenuItem("Save As", FileMenuActionEnum.SAVE_AS.value, handler));
		menu.add(new DigiTmMenuItem("Save Selected", FileMenuActionEnum.SAVE_SELECT.value, handler));

		menu.add(new JSeparator());
		menu.add(new DigiTmMenuItem("Print As Image", FileMenuActionEnum.PRINT_IMAGE.value, handler, KeyEvent.VK_P));
		menu.add(new DigiTmMenuItem("Print As Graph", FileMenuActionEnum.PRINT_GRAPH.value, handler, KeyEvent.VK_P,
				KeyEvent.CTRL_MASK + KeyEvent.SHIFT_MASK));
		menu.add(new DigiTmMenuItem("Print Selected As Image", FileMenuActionEnum.PRINT_IMAGE_SELECT.value, handler));
		menu.add(new DigiTmMenuItem("Print Selected As Graph", FileMenuActionEnum.PRINT_GRAPH_SELECT.value, handler));

		menu.add(new JSeparator());
		menu.add(new DigiTmMenuItem("Save Motif to Library", FileMenuActionEnum.SAVE_MOTIF.value, handler));
		menu.add(new DigiTmMenuItem("Load Motif from Library", FileMenuActionEnum.LOAD_MOTIF.value, handler));
		menu.add(new JSeparator());
		menu.add(new DigiTmMenuItem("Open Scanner", FileMenuActionEnum.SCANNER.value, handler));
		if (newApp != null) {
			String[] app = newApp.split("@");
			if (app.length == 2) {
				menu.add(new DigiTmMenuItem(app[0], FileMenuActionEnum.NEW_APP.value, handler));
			}
		}

		menu.add(new JSeparator());
		menu.add(new DigiTmMenuItem("Close", FileMenuActionEnum.CLOSE.value, handler));
		menu.add(new DigiTmMenuItem("Exit", FileMenuActionEnum.EXIT.value, handler));

		return menu;
	}

	JMenu getEditMenu(ActionListener handler) {
		JMenu menu = new DigiTmMenu("Edit", KeyEvent.VK_E);

		menu.add(new DigiTmMenuItem("Cut", EditMenuActionEnum.CUT.value, handler, KeyEvent.VK_X));
		menu.add(new DigiTmMenuItem("Copy", EditMenuActionEnum.COPY.value, handler, KeyEvent.VK_C));
		menu.add(new DigiTmMenuItem("Paste", EditMenuActionEnum.PASTE.value, handler, KeyEvent.VK_V));
		// menu.add(new DigiTmMenuItem("Copy From File",
		// EditMenuActionEnum.INSERT.value, handler));
		// menu.add(new DigiTmMenuItem("Select Area",
		// EditMenuActionEnum.SELECT.value, handler));
		menu.add(new DigiTmMenuItem("Copy From File", EditMenuActionEnum.SELECT_FROM_FILE.value, handler));
		menu.add(new DigiTmMenuItem("Delete selected", EditMenuActionEnum.DELETE_SELECT.value, handler));

		menu.add(new DigiTmMenuItem("Undo", EditMenuActionEnum.UNDO.value, handler, KeyEvent.VK_Z));
		menu.add(new DigiTmMenuItem("Redo", EditMenuActionEnum.REDO.value, handler, KeyEvent.VK_Y));

		return menu;
	}

	JMenu getToolsMenu(ActionListener handler) {
		JMenu menu = new DigiTmMenu("Tools", KeyEvent.VK_T);
		menu.add(new DigiTmMenuItem("Add As Pattern to Library", EditMenuActionEnum.ADD_PATTERN.value, handler));
		menu.add(new DigiTmMenuItem("Get Pattern From Library", EditMenuActionEnum.LOAD_PATTERN.value, handler));
		menu.add(new DigiTmMenuItem("Set Selection As Pattern", EditMenuActionEnum.SET_PATTERN.value, handler));
		menu.addSeparator();

		menu.add(new DigiTmMenuItem("Rotate", EditMenuActionEnum.ROTATE.value, handler));
		menu.add(new DigiTmMenuItem("Flip Horizontal", EditMenuActionEnum.FLIP_HORIZ.value, handler));
		menu.add(new DigiTmMenuItem("Flip Vertical", EditMenuActionEnum.FLIP_VERT.value, handler));
		menu.addSeparator();
		menu.add(new DigiTmMenuItem("Make Black & White", EditMenuActionEnum.BI_COLOR.value, handler));
		menu.add(new DigiTmMenuItem("Reverse Color", EditMenuActionEnum.REVERSE_COLOR.value, handler));
		menu.addSeparator();
		menu.add(new DigiTmMenuItem("Slid Image", EditMenuActionEnum.SLIDING.value, handler));
		menu.add(new DigiTmMenuItem("Protect Colors", EditMenuActionEnum.COLOR_PROTECT.value, handler));
		menu.add(new DigiTmMenuItem("Crop Image", EditMenuActionEnum.CROP_IMAGE.value, handler));
		menu.addSeparator();
		menu.add(new DigiTmMenuItem("Mix Image", EditMenuActionEnum.IMAGE_MIX.value, handler));
		menu.add(new DigiTmMenuItem("Split Image", EditMenuActionEnum.IMAGE_SPLIT.value, handler));
		JCheckBoxMenuItem chkMi = new JCheckBoxMenuItem("Set Drawing Area");
		chkMi.setActionCommand(String.valueOf(EditMenuActionEnum.DRAWING_AREA.value));
		chkMi.addActionListener(handler);
		menu.add(chkMi);

		return menu;
	}

	JMenu getCodeMenu(ActionListener handler) {
		JMenu menu = new DigiTmMenu("Code", KeyEvent.VK_C);

		menu.add(new DigiTmMenuItem("Generate", CodeMenuActionEnum.CREATE.value, handler));
		menu.add(new DigiTmMenuItem("View", CodeMenuActionEnum.VIEW.value, handler));
		menu.add(new DigiTmMenuItem("Convert Code To Motif", CodeMenuActionEnum.CODE_TO_IMAGE.value, handler));

		return menu;
	}

	JMenu getArrangeMenu(ActionListener handler) {
		JMenu menu = new DigiTmMenu("Arrange", KeyEvent.VK_A);
		menu.add(new DigiTmMenuItem("Left", ArrangeMenuActionEnum.LEFT.value, handler, KeyEvent.VK_L,
				KeyEvent.CTRL_MASK + KeyEvent.SHIFT_MASK));
		menu.add(new DigiTmMenuItem("Right", ArrangeMenuActionEnum.RIGHT.value, handler, KeyEvent.VK_R,
				KeyEvent.CTRL_MASK + KeyEvent.SHIFT_MASK));
		menu.add(new DigiTmMenuItem("Up", ArrangeMenuActionEnum.UP.value, handler, KeyEvent.VK_U,
				KeyEvent.CTRL_MASK + KeyEvent.SHIFT_MASK));
		menu.add(new DigiTmMenuItem("Down", ArrangeMenuActionEnum.DOWN.value, handler, KeyEvent.VK_D,
				KeyEvent.CTRL_MASK + KeyEvent.SHIFT_MASK));

		menu.add(new DigiTmMenuItem("Left-Top", ArrangeMenuActionEnum.LEFT_UP.value, handler));
		menu.add(new DigiTmMenuItem("Left-Down", ArrangeMenuActionEnum.LEFT_DOWN.value, handler));
		menu.add(new DigiTmMenuItem("Right-Top", ArrangeMenuActionEnum.RIGHT_UP.value, handler));
		menu.add(new DigiTmMenuItem("Right-Down", ArrangeMenuActionEnum.RIGHT_DOWN.value, handler));

		return menu;
	}

	JMenu getViewMenu(ActionListener handler) {
		JMenu menu = new DigiTmMenu("View", KeyEvent.VK_V);

		menu.add(new DigiTmMenuItem("View/Hide Drawing Tools", ViewMenuActionEnum.DRAWING_TOOL.value, handler));
		menu.add(new DigiTmMenuItem("View/Hide Menu Tools", ViewMenuActionEnum.MENU_TOOL.value, handler));
		menu.add(new DigiTmMenuItem("Zoom-In", ViewMenuActionEnum.ZOOM_IN.value, handler, KeyEvent.VK_PAGE_UP,
				KeyEvent.CTRL_MASK));
		menu.add(new DigiTmMenuItem("Zoom-out", ViewMenuActionEnum.ZOOM_OUT.value, handler, KeyEvent.VK_PAGE_DOWN,
				KeyEvent.CTRL_MASK));

		return menu;
	}

	JMenu getSettingsMenu(ActionListener handler) {
		JMenu menu = new DigiTmMenu("Settings", KeyEvent.VK_S);

		menu.add(new DigiTmMenuItem("Options", SettingsMenuActionEnum.OPTIONS.value, handler));
		// menu.add(new DigiTmMenuItem("Print Options",
		// SettingsMenuActionEnum.PRINT_OPTIONS.value, handler));

		return menu;
	}

	public JMenu getHelpMenu(ActionListener handler) {
		JMenu menu = new DigiTmMenu("Help", KeyEvent.VK_H);
		menu.add(new DigiTmMenuItem("About", HelpMenuActionEnum.ABOUT.value, handler));
		return menu;
	}

	public JMenu getMoveMenu(ActionListener listener) {
		JMenu menu = new DigiTmMenu("Shape", KeyEvent.VK_P);
		menu.add(new DigiTmMenuItem("Up", ShapeMenuActionEnum.UP.value, listener, KeyEvent.VK_UP, KeyEvent.ALT_MASK));
		menu.add(new DigiTmMenuItem("Down", ShapeMenuActionEnum.DOWN.value, listener, KeyEvent.VK_DOWN,
				KeyEvent.ALT_MASK));
		menu.add(new DigiTmMenuItem("Left", ShapeMenuActionEnum.LEFT.value, listener, KeyEvent.VK_LEFT,
				KeyEvent.ALT_MASK));
		menu.add(new DigiTmMenuItem("Right", ShapeMenuActionEnum.RIGHT.value, listener, KeyEvent.VK_RIGHT,
				KeyEvent.ALT_MASK));

		menu.add(new DigiTmMenuItem("Commit", ShapeMenuActionEnum.COMMIT.value, listener, KeyEvent.VK_ENTER, -1));
		menu.add(new DigiTmMenuItem("Cancel", ShapeMenuActionEnum.CANCEL.value, listener, KeyEvent.VK_ESCAPE, -1));
		return menu;
	}

	public JMenu getHistoryMenu(ActionListener handler, Map<Long, String> history) {
		JMenu menu = new DigiTmMenu("History");
		int count = 1;
		for (Long key : history.keySet()) {
			File file = new File(history.get(key));
			DigiTmMenuItem mi = new DigiTmMenuItem(count + ". " + file.getName(), 0, handler);
			mi.setToolTipText(file.getAbsolutePath());
			menu.add(mi);
			count++;
		}

		return menu;
	}

}
