package com.tm.motif.menu;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;

import javax.swing.JSeparator;

import com.tm.commons.action.ArrangeMenuActionEnum;
import com.tm.commons.action.CodeMenuActionEnum;
import com.tm.commons.action.EditMenuActionEnum;
import com.tm.commons.action.FileMenuActionEnum;
import com.tm.commons.action.SettingsMenuActionEnum;
import com.tm.commons.action.ShapeMenuActionEnum;
import com.tm.commons.action.ViewMenuActionEnum;
import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.listener.ColorChangeListener;
import com.tm.commons.menu.DigiTmToolBar;
import com.tm.commons.tool.ColorPane;
import com.tm.commons.tool.DropdownColorChooser;
import com.tm.motif.action.handler.MotifCreatorActionHandler;

public class MotifCreatorToolBar extends DigiTmToolBar {

	private static final long serialVersionUID = -4264962908646779930L;
	DropdownColorChooser colorChooser;
	MotifCreatorActionHandler actionHandler;
	
	public MotifCreatorToolBar(MotifCreatorActionHandler actionHandler) {
		this.actionHandler = actionHandler;
		this.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));

		constructFileMenuTools(actionHandler.getFileMenuActionHandler());
		this.addColorTools(actionHandler.getColorChangeListener());
		JSeparator sep = new JSeparator(JSeparator.VERTICAL);
		sep.setPreferredSize(new Dimension(4, 16));
		this.add(sep);
		this.constructEditMenuTools(actionHandler.getEditMenuActionHandler());
		sep = new JSeparator(JSeparator.VERTICAL);
		sep.setPreferredSize(new Dimension(4, 16));
		this.add(sep);
		this.constructArrangeTools(actionHandler.getArrangeMenuActionHandler());
		sep = new JSeparator(JSeparator.VERTICAL);
		sep.setPreferredSize(new Dimension(4, 16));
		this.add(sep);
		this.constructMoveTools(actionHandler.getMoveMenuHandler());
		sep = new JSeparator(JSeparator.VERTICAL);
		sep.setPreferredSize(new Dimension(4, 16));
		this.add(sep);
		this.constructViewTools(actionHandler.getViewMenuActionHandler());
		sep = new JSeparator(JSeparator.VERTICAL);
		sep.setPreferredSize(new Dimension(4, 16));
		this.add(sep);
		this.constructCodeTools(actionHandler.getCodeMenuActionHandler());
		sep = new JSeparator(JSeparator.VERTICAL);
		sep.setPreferredSize(new Dimension(4, 16));
		this.add(sep);
		this.constructSettingsTools(actionHandler.getSettingsMenuActionHandler());
		sep = new JSeparator(JSeparator.VERTICAL);
		sep.setPreferredSize(new Dimension(4, 16));
		this.add(sep);
		ButtonMenuItem btn = new ButtonMenuItem(FileMenuActionEnum.EXIT.value, actionHandler.getFileMenuActionHandler(), "/img/exit.jpg", "Exit Application");
		btn.setPreferredSize(new Dimension(34, 20));
		add(btn);
	}

	void constructFileMenuTools(ActionListener handler) {

		add(new ButtonMenuItem(FileMenuActionEnum.NEW.value, handler, "/img/new.jpg", "New"));
		add(new ButtonMenuItem(FileMenuActionEnum.OPEN.value, handler, "/img/open.jpg", "Open"));
		add(new ButtonMenuItem(FileMenuActionEnum.SAVE.value, handler, "/img/save.jpg", "Save"));
		add(new ButtonMenuItem(FileMenuActionEnum.PRINT_GRAPH.value, handler, "/img/print.jpg", "Print Graph"));
		//add(new ButtonMenuItem(FileMenuActionEnum.PRINT_IMAGE.value, handler, "/img/printdesign.jpg", "Print Image"));
		this.add(new ButtonMenuItem(FileMenuActionEnum.SAVE_MOTIF.value, handler, "/img/add-motif-lib.jpg",
				"Add motif to library"));
		this.add(new ButtonMenuItem(FileMenuActionEnum.LOAD_MOTIF.value, handler, "/img/get-motif-lib.jpg",
				"Get motif from library"));
		add(new ButtonMenuItem(FileMenuActionEnum.CLOSE.value, handler, "/img/close.jpg", "Close"));
	}

	void constructEditMenuTools(ActionListener handler) {

		add(new ButtonMenuItem(EditMenuActionEnum.INSERT_ROW_COL.value, handler, "/img/insertcell.jpg",
				"Insert row(s) or Column(s)"));
		add(new ButtonMenuItem(EditMenuActionEnum.REMOVE_ROW_COL.value, handler, "/img/removecell.jpg",
				"Remove row(s) or Column(s)"));
		JSeparator sep;
		sep = new JSeparator(JSeparator.VERTICAL);
		sep.setPreferredSize(new Dimension(2, 16));
		this.add(sep);
		add(new ButtonMenuItem(EditMenuActionEnum.COPY.value, handler, "/img/copy.jpg", "Copy selection"));
		add(new ButtonMenuItem(EditMenuActionEnum.CUT.value, handler, "/img/cut.jpg", "Cut Selection"));
		add(new ButtonMenuItem(EditMenuActionEnum.PASTE.value, handler, "/img/paste.jpg", "Paste from clipboard"));
		add(new ButtonMenuItem(EditMenuActionEnum.DELETE_SELECT.value, handler, "/img/delete-sel.jpg", "Clear Selection"));
		sep = new JSeparator(JSeparator.VERTICAL);
		sep.setPreferredSize(new Dimension(2, 16));
		this.add(sep);
		add(new ButtonMenuItem(EditMenuActionEnum.FLIP_HORIZ.value, handler, "/img/flip-h.jpg", "Mirro selected image"));
		add(new ButtonMenuItem(EditMenuActionEnum.FLIP_VERT.value, handler, "/img/flip-v.jpg", "Mirro selected image"));
		add(new ButtonMenuItem(EditMenuActionEnum.ROTATE.value, handler, "/img/rotate.jpg", "Rotate Selected image"));
		add(new ButtonMenuItem(EditMenuActionEnum.RESIZE.value, handler, "/img/resize.jpg", "Resize selected image"));
		add(new ButtonMenuItem(EditMenuActionEnum.CROP_IMAGE.value, handler, "/img/crop.jpg", "Crop - Get only current selection"));
		sep = new JSeparator(JSeparator.VERTICAL);
		sep.setPreferredSize(new Dimension(2, 16));
		this.add(sep);

		this.add(new ButtonMenuItem(EditMenuActionEnum.ADD_PATTERN.value, handler, "/img/add-pattern-lib.jpg",
				"Add pattern to library"));
		this.add(new ButtonMenuItem(EditMenuActionEnum.LOAD_PATTERN.value, handler, "/img/get-pattern-lib.jpg",
				"Get pattern from library"));
		this.add(new ButtonMenuItem(EditMenuActionEnum.SET_PATTERN.value, handler, "/img/set-pattern.jpg",
				"Set selection as fill pattern"));
		this.add(new ButtonMenuItem(EditMenuActionEnum.SET_LINE_PATTERN.value, handler, "/img/line-pat.jpg",
				"Set selection as line pattern"));
		sep = new JSeparator(JSeparator.VERTICAL);
		sep.setPreferredSize(new Dimension(2, 16));
		this.add(sep);
		add(new ButtonMenuItem(EditMenuActionEnum.UNDO.value, handler, "/img/undo.jpg", "Undo drawing"));
		add(new ButtonMenuItem(EditMenuActionEnum.REDO.value, handler, "/img/redo.jpg", "Redo drawing"));
		sep = new JSeparator(JSeparator.VERTICAL);
		sep.setPreferredSize(new Dimension(2, 16));
		this.add(sep);
		add(new ButtonMenuItem(EditMenuActionEnum.FLOAT_CHECK.value, handler, "/img/float.jpg", "Float Check..."));
		add(new ButtonMenuItem(EditMenuActionEnum.TEXT.value, handler, "/img/text.jpg", "Create Text"));
		//TODO - uncomment
		//add(new ButtonMenuItem(EditMenuActionEnum.MERGE_IMAGE.value, handler, "/img/merge.jpg", "Merge Image..."));
		
	}

	void constructArrangeTools(ActionListener handler) {
		add(new ButtonMenuItem(ArrangeMenuActionEnum.LEFT.value, handler, "/img/arrangeleft.jpg", "Copy to Left"));
		add(new ButtonMenuItem(ArrangeMenuActionEnum.RIGHT.value, handler, "/img/arrangeright.jpg", "Right to Right"));
		add(new ButtonMenuItem(ArrangeMenuActionEnum.UP.value, handler, "/img/arrangeup.jpg", "Copy to Up"));
		add(new ButtonMenuItem(ArrangeMenuActionEnum.DOWN.value, handler, "/img/arrangedown.jpg", "Copy to Down"));
		
		add(new ButtonMenuItem(ArrangeMenuActionEnum.LEFT_UP.value, handler, "/img/arrangeleftup.jpg",
				"Copy to Left-Up"));
		add(new ButtonMenuItem(ArrangeMenuActionEnum.RIGHT_UP.value, handler, "/img/arrangerightup.jpg",
				"Copy to Right-Up"));
		add(new ButtonMenuItem(ArrangeMenuActionEnum.RIGHT_DOWN.value, handler, "/img/arrangerightdown.jpg",
				"Right to Right-Down"));
		add(new ButtonMenuItem(ArrangeMenuActionEnum.LEFT_DOWN.value, handler, "/img/arrangeleftdown.jpg",
				"Copy to Left-Down"));
	}

	void constructViewTools(ActionListener handler) {
		add(new ButtonMenuItem(ViewMenuActionEnum.ZOOM_IN.value, handler, "/img/z2.jpg", "Zoom-In"));
		add(new ButtonMenuItem(ViewMenuActionEnum.ZOOM_OUT.value, handler, "/img/z1.jpg", "Zoom-Out"));
	}

	void constructSettingsTools(ActionListener handler) {
		add(new ButtonMenuItem(SettingsMenuActionEnum.OPTIONS.value, handler, "/img/options.jpg", "Set Options"));
		//add(new ButtonMenuItem(SettingsMenuActionEnum.PRINT_OPTIONS.value, handler, "/img/print_sett.jpg", "Set Print Options"));
	}
	
	void constructCodeTools(ActionListener handler)
	{
		add(new ButtonMenuItem(CodeMenuActionEnum.CREATE.value, handler, "/img/mkcode.jpg", "Generate Code"));
		add(new ButtonMenuItem(CodeMenuActionEnum.SAVE_CODE.value, handler, "/img/savecode.jpg", "Save Code to File"));
		add(new ButtonMenuItem(CodeMenuActionEnum.VIEW_CODE.value, handler, "/img/viewcode.jpg", "View Code"));
		add(new ButtonMenuItem(CodeMenuActionEnum.CODE_TO_IMAGE.value, handler, "/img/cdtogrp.jpg", "Convert Code to Graph"));
	}
	
	void addColorTools(ColorChangeListener listener) {
		colorChooser = new DropdownColorChooser(listener);
		colorChooser.addColorPane(new ColorPane());
		this.add(colorChooser);
	}

	void constructMoveTools(ActionListener handler) {
		add(new ButtonMenuItem(ShapeMenuActionEnum.UP.value, handler, "/img/mv-u.jpg", "Move Up the shape"));
		add(new ButtonMenuItem(ShapeMenuActionEnum.DOWN.value, handler, "/img/mv-d.jpg", "Move Down the shape"));
		add(new ButtonMenuItem(ShapeMenuActionEnum.LEFT.value, handler, "/img/mv-l.jpg", "Move Left the shape"));
		add(new ButtonMenuItem(ShapeMenuActionEnum.RIGHT.value, handler, "/img/mv-r.jpg", "Move Right the shape"));
		add(new ButtonMenuItem(ShapeMenuActionEnum.COMMIT.value, handler, "/img/commit.jpg", "Commit current drawing"));
		add(new ButtonMenuItem(ShapeMenuActionEnum.CANCEL.value, handler, "/img/cancel.jpg", "Cancel current drawing"));
	}

	public DropdownColorChooser getColorChooser() {
		return this.colorChooser;
	}
}
