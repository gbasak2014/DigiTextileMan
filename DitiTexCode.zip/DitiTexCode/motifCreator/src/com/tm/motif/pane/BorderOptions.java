package com.tm.motif.pane;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.button.ButtonDrawingTool;
import com.tm.commons.drawing.tool.AddBorder;
import com.tm.commons.drawing.tool.PenHolder;
import com.tm.commons.theme.DigiTmTheme;
import com.tm.motif.action.handler.PenSelectHandler;
import com.tm.motif.tool.DrawingTool;

public class BorderOptions extends JButton implements ActionListener {
	private static final long serialVersionUID = -6400111922481462327L;
	JPopupMenu popup = new JPopupMenu();
	PenHolder penHolder;
	ButtonDrawingTool btnSelected;
	DrawingTool toolBarDrawing;
	ButtonDrawingTool btnToolBorder;
	PenSelectHandler penSelectHandler;

	public BorderOptions(ButtonDrawingTool btnToolBorder, PenHolder penHolder, DrawingTool toolBarDrawing,
			PenSelectHandler penSelectHandler) {
		super();
		this.btnToolBorder = btnToolBorder;
		this.penHolder = penHolder;
		this.toolBarDrawing = toolBarDrawing;
		this.penSelectHandler = penSelectHandler;
		this.setBackground(DigiTmTheme.getBgColor());
		URL url = this.getClass().getResource("/img/expand-right.jpg");
		if (url != null) {
			this.setIcon(new ImageIcon(url));
		}

		this.setPreferredSize(new Dimension(11, 20));
		this.popup.setBackground(DigiTmTheme.getHighlightColor());
		// this.setBorder(DigiTmTheme.getLineBorder());
		this.popup.add(addBorderOption());
		this.popup.setSize(30, 60);
		this.popup.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
		this.addActionListener(this);
	}

	JPanel addBorderOption() {
		ActionListener popupListener = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (penHolder.getPen() != null) {
					if (btnSelected != null) {
						btnSelected.setBorder(BorderFactory.createEmptyBorder());
					}

					penSelectHandler.selectPenTool(btnToolBorder, DrawingToolEnum.ADD_BORDER);
					btnSelected = (ButtonDrawingTool) e.getSource();
					btnSelected.setBorder(BorderFactory.createLoweredBevelBorder());
					toolBarDrawing.setSelectedCirclePattern(btnSelected.getImage());
					((AddBorder) penHolder.getPen()).setOption(Integer.parseInt(e.getActionCommand()));
					popup.setVisible(false);
				}
			}
		};

		JPanel panel = new JPanel(new GridLayout(2, 1, 1, 1));
		panel.setPreferredSize(new Dimension(30, 60));
		panel.setOpaque(false);

		panel.add(new ButtonDrawingTool(AddBorder.INNER, popupListener, "/img/pattern/border-inner.jpg", "Inner Border",
				true, true));
		panel.add(new ButtonDrawingTool(AddBorder.OUTER, popupListener, "/img/pattern/border-outer.jpg", "Outer Border",
				true, true));
		add(panel);

		return panel;
	}

	@Override
	protected void paintComponent(Graphics g) {
		if (getModel().isRollover()) {
			this.setBackground(DigiTmTheme.getHighlightColor());
		} else if (getModel().isPressed()) {
			setBorder(BorderFactory.createLoweredBevelBorder());
		} else {
			setBorder(BorderFactory.createEmptyBorder());
			this.setBackground(DigiTmTheme.getBgColor());
		}

		super.paintComponent(g);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton) e.getSource();
		int x = btn.getLocationOnScreen().x - this.popup.getWidth() + btn.getWidth();
		int y = btn.getLocationOnScreen().y + btn.getHeight();
		this.popup.setLocation(x, y);
		this.popup.setVisible(!this.popup.isVisible());
		if (this.popup.isVisible()) {
			this.setBackground(DigiTmTheme.getHighlightColor());
		} else {
			this.setBackground(DigiTmTheme.getBgColor());
		}
	}

	public boolean isvisiblePopup() {
		return this.popup.isVisible();
	}

	public void setVisiblePopup(boolean visible) {
		this.popup.setVisible(visible);
		if (this.popup.isVisible()) {
			this.setBackground(DigiTmTheme.getHighlightColor());
		} else {
			this.setBackground(DigiTmTheme.getBgColor());
		}
	}
}
