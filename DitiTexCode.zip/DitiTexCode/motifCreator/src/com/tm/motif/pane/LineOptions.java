package com.tm.motif.pane;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.button.ButtonDrawingTool;
import com.tm.commons.drawing.tool.Pen;
import com.tm.commons.drawing.tool.PenHolder;
import com.tm.commons.theme.DigiTmTheme;
import com.tm.motif.action.handler.PenSelectHandler;
import com.tm.motif.tool.DrawingTool;
import com.tm.motif.tool.ToolBarDrawing;

public class LineOptions extends JButton implements ActionListener {

	private static final long serialVersionUID = 2916035289855418977L;
	JPopupMenu popup = new JPopupMenu();
	PenHolder penHolder;
	ButtonDrawingTool btnSelected;
	DrawingTool toolBarDrawing;
	ButtonDrawingTool btnToolLine;
	PenSelectHandler penSelectHandler;

	public LineOptions(ButtonDrawingTool btnToolLine, PenHolder penHolder, DrawingTool toolBarDrawing,
			PenSelectHandler penSelectHandler) {
		super();
		this.btnToolLine = btnToolLine;
		this.penHolder = penHolder;
		this.toolBarDrawing = toolBarDrawing;
		this.penSelectHandler = penSelectHandler;
		this.setBackground(DigiTmTheme.getBgColor());
		URL url = this.getClass().getResource("/img/expand-right.jpg");
		if (url != null) {
			this.setIcon(new ImageIcon(url));
		}

		this.setPreferredSize(new Dimension(11, 20));
		this.popup.setBackground(DigiTmTheme.getHighlightColor());
		// this.setBorder(DigiTmTheme.getLineBorder());
		this.popup.add(addCircleOption());
		this.popup.setSize(105, 60);
		this.popup.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
		this.addActionListener(this);
	}

	JPanel addCircleOption() {
		ActionListener popupListener = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (penHolder.getPen() != null) {
					if (btnSelected != null) {
						btnSelected.setBorder(BorderFactory.createEmptyBorder());
					}

					penSelectHandler.selectPenTool(btnToolLine, DrawingToolEnum.LINE);
					btnSelected = (ButtonDrawingTool) e.getSource();
					btnSelected.setBorder(BorderFactory.createLoweredBevelBorder());
					toolBarDrawing.setSelectedCirclePattern(btnSelected.getImage());
					addLinePattern(penHolder.getPen(), Integer.parseInt(e.getActionCommand()));
					popup.setVisible(false);
				}
			}
		};

		JPanel panel = new JPanel(new GridLayout(5, 2, 1, 1));
		panel.setPreferredSize(new Dimension(60, 150));
		panel.setOpaque(false);

		panel.add(new ButtonDrawingTool(1, popupListener, "/img/pattern/line-1.jpg", "Solid Line", true, true));
		panel.add(new ButtonDrawingTool(11, popupListener, "/img/pattern/line-11.jpg", "Line 1:1", true, true));
		panel.add(new ButtonDrawingTool(12, popupListener, "/img/pattern/line-12.jpg", "Line 1:2", true, true));
		panel.add(new ButtonDrawingTool(13, popupListener, "/img/pattern/line-13.jpg", "Line 1:3", true, true));

		panel.add(new ButtonDrawingTool(21, popupListener, "/img/pattern/line-11.jpg", "Line 2:1", true, true));
		panel.add(new ButtonDrawingTool(22, popupListener, "/img/pattern/line-12.jpg", "Line 2:2", true, true));
		panel.add(new ButtonDrawingTool(23, popupListener, "/img/pattern/line-13.jpg", "Line 2:3", true, true));

		panel.add(new ButtonDrawingTool(31, popupListener, "/img/pattern/line-11.jpg", "Line 3:1", true, true));
		panel.add(new ButtonDrawingTool(32, popupListener, "/img/pattern/line-12.jpg", "Line 3:2", true, true));
		panel.add(new ButtonDrawingTool(33, popupListener, "/img/pattern/line-13.jpg", "Line 3:3", true, true));

		add(panel);

		return panel;
	}

	private void addLinePattern(Pen pen, int pat) {
		switch (pat) {
		case 1:
			pen.setLinePattern(new int[] { 1 });
			break;
		case 11:
			pen.setLinePattern(new int[] { 1, 0 });
			break;
		case 12:
			pen.setLinePattern(new int[] { 1, 0, 0 });
			break;
		case 13:
			pen.setLinePattern(new int[] { 1, 0, 0, 0 });
			break;
		case 21:
			pen.setLinePattern(new int[] { 1, 1, 0 });
			break;
		case 22:
			pen.setLinePattern(new int[] { 1, 1, 0, 0 });
			break;
		case 23:
			pen.setLinePattern(new int[] { 1, 1, 0, 0, 0 });
			break;
		case 31:
			pen.setLinePattern(new int[] { 1, 1, 1, 0 });
			break;
		case 32:
			pen.setLinePattern(new int[] { 1, 1, 1, 0, 0 });
			break;
		case 33:
			pen.setLinePattern(new int[] { 1, 1, 1, 0, 0, 0 });
			break;
		default:
			pen.setLinePattern(new int[] { 1 });
		}
	}

	@Override
	protected void paintComponent(Graphics g) {
		if (getModel().isRollover()) {
			this.setBackground(DigiTmTheme.getHighlightColor());
		} else if (getModel().isPressed()) {
			setBorder(BorderFactory.createLoweredBevelBorder());
		} else {
			setBorder(BorderFactory.createEmptyBorder());
			this.setBackground(DigiTmTheme.getBgColor());
		}

		super.paintComponent(g);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton) e.getSource();
		int x = btn.getLocationOnScreen().x + btn.getWidth() - this.popup.getWidth();
		int y = btn.getLocationOnScreen().y + btn.getHeight();
		this.popup.setLocation(x, y);
		this.popup.setVisible(!this.popup.isVisible());
		if (this.popup.isVisible()) {
			this.setBackground(DigiTmTheme.getHighlightColor());
		} else {
			this.setBackground(DigiTmTheme.getBgColor());
		}
	}

	public boolean isvisiblePopup() {
		return this.popup.isVisible();
	}

	public void setVisiblePopup(boolean visible) {
		this.popup.setVisible(visible);
		if (this.popup.isVisible()) {
			this.setBackground(DigiTmTheme.getHighlightColor());
		} else {
			this.setBackground(DigiTmTheme.getBgColor());
		}
	}
}
