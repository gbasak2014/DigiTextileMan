package com.tm.motif.pane;

import java.awt.BorderLayout;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.image.BufferedImage;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollBar;

import com.tm.commons.components.DrawingImage;
import com.tm.commons.components.GridImage;
import com.tm.commons.components.pane.GraphPane;
import com.tm.commons.drawing.tool.Mouse;
import com.tm.commons.drawing.tool.PenHolder;
import com.tm.commons.listener.DrawingListener;
import com.tm.commons.theme.DigiTmTheme;
import com.tm.commons.tool.Ruler;
import com.tm.motif.win.MotifCreatorWin;

public class DrawingPane extends JPanel {

	private static final long serialVersionUID = -8348668649506813701L;
	Ruler rulerVertical;
	Ruler rulerHorizontal;
	JScrollBar scrollVertical;
	JScrollBar scrollHorizontal;

	GraphPane graphPane;

	String path;

	MotifCreatorWin motifCreatorWin;

	public DrawingPane(String path, BufferedImage graphImage, DrawingImage drawingImage, GridImage gridImage, MotifCreatorWin motifCreatorWin, String filePath) {
		this.path = path;
		this.motifCreatorWin = motifCreatorWin;
		scrollVertical = new JScrollBar(JScrollBar.VERTICAL);
		scrollHorizontal = new JScrollBar(JScrollBar.HORIZONTAL);

		PenHolder penHolder = motifCreatorWin.getPenHolder();

		graphPane = new GraphPane(graphImage, drawingImage, gridImage, motifCreatorWin.getDrawingHandler(), penHolder, filePath);

		penHolder.setPen(new Mouse(graphPane, this.motifCreatorWin.getCurrentColor(), this.motifCreatorWin.getFillPattern()));
		motifCreatorWin.getDrawingHandler().setGraphPane(graphPane, motifCreatorWin.getCurrentColor());

		rulerVertical = new Ruler(Ruler.VERTZ, graphPane, gridImage.getGridOptions());
		rulerHorizontal = new Ruler(Ruler.HORZ, graphPane, rulerVertical, gridImage.getGridOptions());
		this.setLayout(new BorderLayout(0, 0));

		this.add(rulerVertical, BorderLayout.WEST);
		this.add(rulerHorizontal, BorderLayout.NORTH);
		this.add(scrollVertical, BorderLayout.EAST);
		this.add(scrollHorizontal, BorderLayout.SOUTH);
		this.add(graphPane, BorderLayout.CENTER);

		rulerVertical.setBorder(BorderFactory.createRaisedBevelBorder());
		rulerHorizontal.setBorder(BorderFactory.createRaisedBevelBorder());

		addScrollBarListener();
		scrollHorizontal.setMaximum(graphImage.getWidth());
		scrollHorizontal.setMinimum(0);

		scrollVertical.setMaximum(graphImage.getHeight());
		scrollVertical.setMinimum(0);

		scrollVertical.setBackground(DigiTmTheme.getBgColor());
		scrollHorizontal.setBackground(DigiTmTheme.getBgColor());
	}

	public GraphPane getGraphPane() {
		return this.graphPane;
	}

	void addScrollBarListener() {
		scrollHorizontal.addAdjustmentListener(new AdjustmentListener() {

			@Override
			public void adjustmentValueChanged(AdjustmentEvent e) {
				scroll();
			}
		});

		scrollVertical.addAdjustmentListener(new AdjustmentListener() {

			@Override
			public void adjustmentValueChanged(AdjustmentEvent e) {
				scroll();
			}
		});

		scrollVertical.addMouseWheelListener(new MouseWheelListener() {

			@Override
			public void mouseWheelMoved(MouseWheelEvent e) {
				scrollVertical.setValue(scrollVertical.getValue() + e.getWheelRotation());
			}
		});

		this.addMouseWheelListener(new MouseWheelListener() {

			@Override
			public void mouseWheelMoved(MouseWheelEvent e) {
				scrollVertical.setValue(scrollVertical.getValue() + e.getWheelRotation());

			}
		});
	}

	public void scroll() {
		graphPane.scroll(scrollHorizontal.getValue(), scrollVertical.getValue());
		graphPane.repaint();
		this.motifCreatorWin.getStatusBar().setImagePos(scrollHorizontal.getValue(), scrollVertical.getValue());

		this.rulerHorizontal.setStart(graphPane.getImgLeft());
		this.rulerVertical.setStart(graphPane.getImgTop());
		rulerHorizontal.repaint();
		rulerVertical.repaint();
	}

	public void zoom(int width) {
		this.graphPane.setZoom(width);
		rulerHorizontal.repaint();
		rulerVertical.repaint();
	}

	public void setScrollbarMaxValue(int maxX, int maxY) {
		this.scrollHorizontal.setMaximum(maxX);
		this.scrollVertical.setMaximum(maxY);
	}

	public void setScrollvalue(int x, int y) {
		this.scrollHorizontal.setValue(x);
		this.scrollVertical.setValue(y);
	}

	public BufferedImage getSavedImage() {
		return this.graphPane.getSavedImage();
	}

	public DrawingImage getDrawingImage() {
		return this.graphPane.getDrawingImage();
	}

	public void setFilePath(String path) {
		this.graphPane.setFilePath(path);
	}

	@Override
	protected void finalize() throws Throwable {
		super.finalize();
	}

	public void cleanup() {
		this.graphPane.cleanup();
	}

	public void cancel() {
		this.graphPane.cancel();
	}

	public void commit() {
		this.graphPane.commit();
	}

	public void clearSelectedArea() {
		this.graphPane.clearSelectedArea();
		this.graphPane.repaint();
	}

	public void removeDrawingHandler(DrawingListener drawingHandler) {
		this.graphPane.removeDrawingHandler(drawingHandler);
	}

	public void setDrawingHandler(DrawingListener drawingHandler) {
		this.graphPane.setDrawingHandler(drawingHandler);
	}

	public int getImgLeft() {
		return this.graphPane.getImgLeft();
	}

	public int getImgTop() {
		return this.graphPane.getImgTop();
	}

	public int getImgWidth() {
		return this.graphPane.getSavedImage().getWidth();
	}

	public int getImgHeight() {
		return this.graphPane.getSavedImage().getHeight();
	}

	public BufferedImage getSelectedImage() {
		return this.graphPane.getSelectedImage();
	}

	public String getFilePath() {
		return this.graphPane.getFilePath();
	}
}
