package com.tm.motif.pane;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.button.ButtonDrawingTool;
import com.tm.commons.drawing.tool.PenHolder;
import com.tm.commons.theme.DigiTmTheme;
import com.tm.motif.action.handler.PenSelectHandler;
import com.tm.motif.tool.DrawingTool;
import com.tm.motif.tool.ToolBarDrawing;

public class CircleOptions extends JButton implements ActionListener {

	private static final long serialVersionUID = -6083519697303329062L;
	JPopupMenu popup = new JPopupMenu();
	PenHolder penHolder;
	ButtonDrawingTool btnSelected;
	DrawingTool toolBarDrawing;
	ButtonDrawingTool btnToolCircle;
	PenSelectHandler penSelectHandler;

	public CircleOptions(ButtonDrawingTool btnToolCircle, PenHolder penHolder, DrawingTool toolBarDrawing,
			PenSelectHandler penSelectHandler) {
		super();
		this.btnToolCircle = btnToolCircle;
		this.penHolder = penHolder;
		this.toolBarDrawing = toolBarDrawing;
		this.penSelectHandler = penSelectHandler;
		this.setBackground(DigiTmTheme.getBgColor());
		URL url = this.getClass().getResource("/img/expand-right.jpg");
		if (url != null) {
			this.setIcon(new ImageIcon(url));
		}

		this.setPreferredSize(new Dimension(11, 20));
		this.popup.setBackground(DigiTmTheme.getHighlightColor());
		this.setBorder(DigiTmTheme.getLineBorder());
		this.popup.add(addCircleOption());
		this.popup.setSize(105, 60);
		this.popup.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
		this.addActionListener(this);
	}

	JPanel addCircleOption() {
		ActionListener rectPatternListener = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (penHolder.getPen() != null) {
					if (btnSelected != null) {
						btnSelected.setBorder(BorderFactory.createEmptyBorder());
					}

					penSelectHandler.selectPenTool(btnToolCircle, DrawingToolEnum.CIRCLE);
					btnSelected = (ButtonDrawingTool) e.getSource();
					btnSelected.setBorder(BorderFactory.createLoweredBevelBorder());
					toolBarDrawing.setSelectedCirclePattern(btnSelected.getImage());
					penHolder.getPen().setPattern(DrawingToolEnum.fromString(e.getActionCommand()));
					popup.setVisible(false);
				}
			}
		};

		JPanel panel = new JPanel(new GridLayout(3, 3, 1, 1));
		panel.setPreferredSize(new Dimension(105, 60));
		panel.setOpaque(false);

		panel.add(new ButtonDrawingTool(DrawingToolEnum.CIRCLE_FULL.value, rectPatternListener, "/img/circle-full.jpg",
				"Full Circle", true, true));
		panel.add(new ButtonDrawingTool(DrawingToolEnum.CIRCLE_LEFT.value, rectPatternListener, "/img/circle-l.jpg",
				"Left half Circle", true, true));
		panel.add(new ButtonDrawingTool(DrawingToolEnum.CIRCLE_RIGHT.value, rectPatternListener, "/img/circle-r.jpg",
				"Right half Circle", true, true));
		panel.add(new ButtonDrawingTool(DrawingToolEnum.CIRCLE_TOP.value, rectPatternListener, "/img/circle-t.jpg",
				"Top half Circle", true, true));
		panel.add(new ButtonDrawingTool(DrawingToolEnum.CIRCLE_BOTTOM.value, rectPatternListener, "/img/circle-b.jpg",
				"Bottom half Circle", true, true));

		panel.add(new ButtonDrawingTool(DrawingToolEnum.CIRCLE_TOP_LEFT.value, rectPatternListener,
				"/img/circle-tl.jpg", "Left-to Circle", true, true));
		panel.add(new ButtonDrawingTool(DrawingToolEnum.CIRCLE_TOP_RIGHT.value, rectPatternListener,
				"/img/circle-tr.jpg", "Right-top Circle", true, true));
		panel.add(new ButtonDrawingTool(DrawingToolEnum.CIRCLE_BOTTOM_LEFT.value, rectPatternListener,
				"/img/circle-bl.jpg", "Left-bottom Circle", true, true));
		panel.add(new ButtonDrawingTool(DrawingToolEnum.CIRCLE_BOTTOM_RIGHT.value, rectPatternListener,
				"/img/circle-br.jpg", "Right-bottom Circle", true, true));
		add(panel);

		return panel;
	}

	@Override
	protected void paintComponent(Graphics g) {
		if (getModel().isRollover()) {
			this.setBackground(DigiTmTheme.getHighlightColor());
		} else if (getModel().isPressed()) {
			setBorder(BorderFactory.createLoweredBevelBorder());
		} else {
			setBorder(BorderFactory.createEmptyBorder());
			this.setBackground(DigiTmTheme.getBgColor());
		}

		super.paintComponent(g);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton) e.getSource();
		int x = btn.getLocationOnScreen().x + btn.getWidth() - this.popup.getWidth();
		int y = btn.getLocationOnScreen().y + btn.getHeight();
		this.popup.setLocation(x, y);
		this.popup.setVisible(!this.popup.isVisible());
		if (this.popup.isVisible()) {
			this.setBackground(DigiTmTheme.getHighlightColor());
		} else {
			this.setBackground(DigiTmTheme.getBgColor());
		}
	}

	public boolean isvisiblePopup() {
		return this.popup.isVisible();
	}

	public void setVisiblePopup(boolean visible) {
		this.popup.setVisible(visible);
		if (this.popup.isVisible()) {
			this.setBackground(DigiTmTheme.getHighlightColor());
		} else {
			this.setBackground(DigiTmTheme.getBgColor());
		}
	}
}
