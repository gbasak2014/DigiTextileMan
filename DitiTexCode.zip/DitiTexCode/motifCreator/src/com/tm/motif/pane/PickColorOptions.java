package com.tm.motif.pane;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButton;

import com.tm.commons.components.button.ButtonDrawingTool;
import com.tm.commons.drawing.tool.PenHolder;
import com.tm.commons.theme.DigiTmTheme;
import com.tm.motif.action.handler.PenSelectHandler;
import com.tm.motif.tool.DrawingTool;
import com.tm.motif.tool.ToolBarDrawing;

public class PickColorOptions extends JButton implements ActionListener {
	private static final long serialVersionUID = -6400111922481462327L;
	JPopupMenu popup = new JPopupMenu();
	PenHolder penHolder;
	ButtonDrawingTool btnSelected;
	DrawingTool toolBarDrawing;
	ButtonDrawingTool btnToolBorder;
	PenSelectHandler penSelectHandler;

	public PickColorOptions(ButtonDrawingTool btnToolBorder, PenHolder penHolder, DrawingTool toolBarDrawing,
			PenSelectHandler penSelectHandler) {
		super();
		this.btnToolBorder = btnToolBorder;
		this.penHolder = penHolder;
		this.toolBarDrawing = toolBarDrawing;
		this.penSelectHandler = penSelectHandler;
		this.setBackground(DigiTmTheme.getBgColor());
		URL url = this.getClass().getResource("/img/expand-right.jpg");
		if (url != null) {
			this.setIcon(new ImageIcon(url));
		}

		this.setPreferredSize(new Dimension(11, 20));
		this.popup.setBackground(DigiTmTheme.getBgColor());
		// this.setBorder(DigiTmTheme.getLineBorder());
		this.popup.add(addBorderOption());
		this.popup.setSize(60, 30);
		this.popup.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
		this.addActionListener(this);
	}

	JPanel addBorderOption() {
		ActionListener popupListener = new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if (penHolder.getPen() != null) {
					penSelectHandler.selectColorChooser("FILL".equals(e.getActionCommand()));
					popup.setVisible(false);
				}
			}
		};

		JPanel panel = new JPanel(new GridLayout(2, 1, 1, 1));
		panel.setPreferredSize(new Dimension(120, 60));
		panel.setOpaque(false);

		JRadioButton jrLine = new JRadioButton("Pick Line Color");
		JRadioButton jrFill = new JRadioButton("Pick Fill Color");
		jrLine.setOpaque(false);
		jrFill.setOpaque(false);
		
		panel.add(jrLine);
		panel.add(jrFill);

		jrLine.setActionCommand("LINE");
		jrFill.setActionCommand("FILL");

		ButtonGroup bg = new ButtonGroup();
		bg.add(jrFill);
		bg.add(jrLine);
		jrLine.setSelected(true);
		jrLine.addActionListener(popupListener);
		jrFill.addActionListener(popupListener);

		add(panel);

		return panel;
	}

	@Override
	protected void paintComponent(Graphics g) {
		if (getModel().isRollover()) {
			this.setBackground(DigiTmTheme.getHighlightColor());
		} else if (getModel().isPressed()) {
			setBorder(BorderFactory.createLoweredBevelBorder());
		} else {
			setBorder(BorderFactory.createEmptyBorder());
			this.setBackground(DigiTmTheme.getBgColor());
		}

		super.paintComponent(g);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton) e.getSource();
		int x = btn.getLocationOnScreen().x + btn.getWidth() - this.popup.getWidth();
		int y = btn.getLocationOnScreen().y + btn.getHeight();
		this.popup.setLocation(x, y);
		this.popup.setVisible(!this.popup.isVisible());
		if (this.popup.isVisible()) {
			this.setBackground(DigiTmTheme.getHighlightColor());
		} else {
			this.setBackground(DigiTmTheme.getBgColor());
		}
	}

	public boolean isvisiblePopup() {
		return this.popup.isVisible();
	}

	public void setVisiblePopup(boolean visible) {
		this.popup.setVisible(visible);
		if (this.popup.isVisible()) {
			this.setBackground(DigiTmTheme.getHighlightColor());
		} else {
			this.setBackground(DigiTmTheme.getBgColor());
		}
	}
}
