package com.tm.motif.action.handler;

import com.tm.commons.listener.ColorChangeListener;
import com.tm.motif.win.MotifCreatorWin;

/**
 * Action handler for Motif Creator actions events
 * 
 * @author Gouranga Basak
 * 
 */
public class MotifCreatorActionHandler {
	FileMenuHandler fileMenuAction;
	EditMenuHandler editMenuAction;
	CodeMenuHandler codeMenuAction;
	ArrangeMenuHandler arrangeMenuAction;
	ViewMenuHandler viewMenuAction;
	SettingsMenuHandler settingsMenuAction;
	HelpMenuHandler helpMenuAction;
	ColorChangeListener colorChangeListener;
	ShapeMenuHandler shapeMenuHandler;
	StatusBarHandler statusBarHandler;
	HistoryMenuHandler historyMenuHandler;
	
	MotifCreatorWin motifCreatorWin;
	
	
	public MotifCreatorActionHandler(MotifCreatorWin motifCreatorWin) {
		this.motifCreatorWin = motifCreatorWin;
		this.fileMenuAction = new FileMenuHandler(motifCreatorWin);
		this.editMenuAction = new EditMenuHandler(motifCreatorWin);
		this.codeMenuAction = new CodeMenuHandler(motifCreatorWin);
		this.arrangeMenuAction = new ArrangeMenuHandler(motifCreatorWin);
		this.viewMenuAction = new ViewMenuHandler(motifCreatorWin);
		this.settingsMenuAction = new SettingsMenuHandler(motifCreatorWin);
		this.helpMenuAction = new HelpMenuHandler(motifCreatorWin);
		this.colorChangeListener = new ColorChangeHandler(motifCreatorWin);
		this.shapeMenuHandler = new ShapeMenuHandler(motifCreatorWin);
		this.statusBarHandler = new StatusBarHandler(motifCreatorWin);
		this.historyMenuHandler = new HistoryMenuHandler(this.fileMenuAction);
	}

	public FileMenuHandler getFileMenuActionHandler() {
		return fileMenuAction;
	}

	public EditMenuHandler getEditMenuActionHandler() {
		return editMenuAction;
	}

	public CodeMenuHandler getCodeMenuActionHandler() {
		return codeMenuAction;
	}

	public ArrangeMenuHandler getArrangeMenuActionHandler() {
		return arrangeMenuAction;
	}

	public ViewMenuHandler getViewMenuActionHandler() {
		return viewMenuAction;
	}

	public SettingsMenuHandler getSettingsMenuActionHandler() {
		return settingsMenuAction;
	}

	public HelpMenuHandler getHelpMenuActionHandler() {
		return helpMenuAction;
	}

	public ColorChangeListener getColorChangeListener() {
		return colorChangeListener;
	}

	public ShapeMenuHandler getMoveMenuHandler() {
		return shapeMenuHandler;
	}

	public StatusBarHandler getStatusBarHandler() {
		return statusBarHandler;
	}

	public MotifCreatorWin getMotifCreatorWin() {
		return motifCreatorWin;
	}

	public HistoryMenuHandler getHistoryMenuHandler() {
		return historyMenuHandler;
	}

}
