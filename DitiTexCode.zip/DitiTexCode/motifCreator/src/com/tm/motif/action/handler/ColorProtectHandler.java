package com.tm.motif.action.handler;

import com.tm.commons.listener.ColorProtectListener;
import com.tm.motif.win.MotifCreatorWin;

public class ColorProtectHandler implements ColorProtectListener {
	MotifCreatorWin motifCreatorWin;

	public ColorProtectHandler(MotifCreatorWin motifCreatorWin) {
		this.motifCreatorWin = motifCreatorWin;
	}

	@Override
	public void protectColor(Integer[] replaceRgbs, int newRgb) {
		int[] rgbs = new int[replaceRgbs.length];
		int i = 0;
		for (int c : replaceRgbs) {
			rgbs[i] = c | 0xff000000;
			i++;
		}

		this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().replaceColors(rgbs, newRgb);
		this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().repaint();
	}
}
