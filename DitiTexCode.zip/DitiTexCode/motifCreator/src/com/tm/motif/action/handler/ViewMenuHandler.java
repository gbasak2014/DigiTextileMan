package com.tm.motif.action.handler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.tm.commons.action.ViewMenuActionEnum;
import com.tm.motif.win.MotifCreatorWin;

public class ViewMenuHandler implements ActionListener {
	MotifCreatorWin motifCreatorWin;

	public ViewMenuHandler(MotifCreatorWin motifCreatorWin) {
		this.motifCreatorWin = motifCreatorWin;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		ViewMenuActionEnum action = ViewMenuActionEnum.fromString(e.getActionCommand());

		switch (action) {
		case ZOOM_IN:
			zoom(1);
			break;
		case ZOOM_OUT:
			zoom(-1);
		default:
			break;
		}
	}

	void zoom(int val) {
		int zoom = this.motifCreatorWin.getGridOptions().getZoom() + val;

		if (zoom > 0) {
			this.motifCreatorWin.getCurrentDrawingPane().zoom(zoom);
		}

	}
}
