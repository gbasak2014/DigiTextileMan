package com.tm.motif.action.handler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.swing.JMenuItem;

import com.tm.commons.image.ImageUtils;

public class HistoryMenuHandler implements ActionListener {
	FileMenuHandler fileMenuHandler;

	public HistoryMenuHandler(FileMenuHandler fileMenuHandler) {
		this.fileMenuHandler = fileMenuHandler;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JMenuItem mi = (JMenuItem) e.getSource();
		File file = new File(mi.getToolTipText());
		if (file.exists()) {
			try {
				BufferedImage img = ImageUtils.getImageFromFile(file.getAbsolutePath());
				if (img != null) {

					this.fileMenuHandler.addGraphPane(file.getName(), img, file.getAbsolutePath());
				}
			} catch (Exception ex) {
			}
		}

	}
}
