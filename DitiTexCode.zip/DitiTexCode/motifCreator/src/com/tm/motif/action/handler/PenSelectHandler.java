package com.tm.motif.action.handler;

import java.awt.Cursor;
import java.awt.Image;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.button.ButtonDrawingTool;
import com.tm.commons.components.pane.GraphPane;
import com.tm.commons.drawing.tool.AddBorder;
import com.tm.commons.drawing.tool.Arc;
import com.tm.commons.drawing.tool.Bezier;
import com.tm.commons.drawing.tool.ColorSelect;
import com.tm.commons.drawing.tool.Fill;
import com.tm.commons.drawing.tool.Line;
import com.tm.commons.drawing.tool.Mouse;
import com.tm.commons.drawing.tool.Move;
import com.tm.commons.drawing.tool.Paste;
import com.tm.commons.drawing.tool.Pen;
import com.tm.commons.drawing.tool.PenHolder;
import com.tm.commons.drawing.tool.Pencil;
import com.tm.commons.drawing.tool.PickColor;
import com.tm.commons.drawing.tool.Rect;
import com.tm.commons.drawing.tool.ReplaceColor;
import com.tm.commons.drawing.tool.Scale;
import com.tm.commons.drawing.tool.Select;
import com.tm.commons.drawing.tool.SelectFreeHand;
import com.tm.commons.image.ImageUtils;
import com.tm.motif.win.MotifCreatorWin;

public class PenSelectHandler implements ActionListener {
	private ButtonDrawingTool selectedButton;
	MotifCreatorWin motifCreatorWin;

	Line line = new Line();
	Rect rect = new Rect();
	Pencil pencil = new Pencil();
	Bezier bezier = new Bezier();
	Mouse mouse = new Mouse();
	Select select = new Select();
	Arc arc = new Arc();
	Paste paste = new Paste();
	ReplaceColor replaceColor = new ReplaceColor();
	PickColor pickColor = new PickColor();
	Scale scaleH = new Scale(DrawingToolEnum.SCALE_H);
	Scale scaleV = new Scale(DrawingToolEnum.SCALE_V);
	Fill fill = new Fill();
	Move move = new Move();
	ColorSelect colorSelect = new ColorSelect();
	AddBorder addBorder = new AddBorder();
	SelectFreeHand selectFreeHand = new SelectFreeHand();

	Pen currentPen;

	boolean isCustomCursor = false;

	public PenSelectHandler(MotifCreatorWin motifCreatorWin) {
		this.motifCreatorWin = motifCreatorWin;
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		DrawingToolEnum tool = DrawingToolEnum.fromString(event.getActionCommand());
		selectPenTool((ButtonDrawingTool) event.getSource(), tool);
	}

	public void selectPenTool(ButtonDrawingTool button, DrawingToolEnum tool) {
		setDrawingTool(tool);

		if (selectedButton != null) {
			selectedButton.deselectMe();
		}
		selectedButton = button;
		selectedButton.selectMe();
	}

	public void setDrawingTool(DrawingToolEnum tool) {
		if (motifCreatorWin.getCurrentDrawingPane() == null) {
			return;
		}

		PenHolder penHolder = motifCreatorWin.getPenHolder();
		if (penHolder.getPen() != null && penHolder.getPen().getType() != DrawingToolEnum.PEN
				&& penHolder.getPen().getType() != DrawingToolEnum.REPLACE_COLOR) {
			penHolder.getPen().save();
		}

		GraphPane graphPane = motifCreatorWin.getCurrentDrawingPane().getGraphPane();
		Cursor cursor;
		switch (tool) {
		case LINE:
			currentPen = line;
			cursor = this.getCursor("/cursor/cursor-line.bmp");
			break;
		case RECT:
			currentPen = rect;
			cursor = this.getCursor("/cursor/cursor-rect.bmp");
			break;
		case CIRCLE:
			currentPen = arc;
			cursor = this.getCursor("/cursor/cursor-curve.bmp");
			break;
		case BEZ:
			currentPen = bezier;
			cursor = this.getCursor("/cursor/cursor-bez.bmp");
			break;
		case PEN:
			currentPen = pencil;
			cursor = this.getCursor("/cursor/cursor-pencil.bmp");
			break;
		case SELECT:
			currentPen = select;
			cursor = this.getCursor("/cursor/cursor-select.bmp");
			break;
		case PASTE:
			currentPen = paste;
			cursor = new Cursor(Cursor.DEFAULT_CURSOR);
			break;
		case REPLACE_COLOR:
			currentPen = replaceColor;
			cursor = this.getCursor("/cursor/cursor-replace-col.bmp");
			break;
		case PICK:
			currentPen = pickColor;
			cursor = this.getCursor("/cursor/cursor-color-pick.bmp");
			break;
		case SCALE_H:
			currentPen = scaleH;
			cursor = this.getCursor("/cursor/cursor-scaleh.bmp");
			break;
		case SCALE_V:
			currentPen = scaleV;
			cursor = this.getCursor("/cursor/cursor-scalev.bmp");
			break;
		case FILL:
			currentPen = fill;
			cursor = this.getCursor("/cursor/cursor-fill.bmp");
			break;
		case SELECT_RAND:
			currentPen = selectFreeHand;
			cursor = this.getCursor("/cursor/cursor-sel-irreg.bmp");
			break;
		case MOVE:
			currentPen = move;
			cursor = new Cursor(Cursor.MOVE_CURSOR);
			break;
		case COLOR_SELECT:
			currentPen = colorSelect;
			cursor = this.getCursor("/cursor/cursor-color-sel.bmp");
			break;
		case ADD_BORDER:
			currentPen = addBorder;
			cursor = this.getCursor("/cursor/cursor-border-add.bmp");
			break;
		default:
			currentPen = mouse;
			cursor = new Cursor(Cursor.DEFAULT_CURSOR);
			break;
		}

		graphPane.setCustomCurson(cursor);
		currentPen.setGraphPane(graphPane);
		currentPen.setColor(motifCreatorWin.getCurrentColor());
		currentPen.setFillColor(motifCreatorWin.getCurrentFillColor());
		currentPen.setFillPattern(motifCreatorWin.getFillPattern());
		currentPen.setStartPoint(-1, -1);
		penHolder.setPen(currentPen);
	}

	public ButtonDrawingTool getSelectedButton() {
		return this.selectedButton;
	}

	public Line getLine() {
		return line;
	}

	public Rect getRect() {
		return rect;
	}

	public Pencil getPencil() {
		return pencil;
	}

	public Bezier getBezier() {
		return bezier;
	}

	public Mouse getMouse() {
		return mouse;
	}

	public Select getSelect() {
		return select;
	}

	public Arc getArc() {
		return arc;
	}

	public Paste getPaste() {
		return paste;
	}

	public Pen getCurrentPen() {
		return currentPen;
	}

	public void setCustomCursor(boolean custom) {
		this.isCustomCursor = custom;
	}

	Cursor getCursor(String imgPath) {
		if (this.isCustomCursor) {
			try {
				return Toolkit.getDefaultToolkit().createCustomCursor(
						ImageUtils.loadTransparentImage(this.getClass().getResource(imgPath)), new Point(0, 0),
						"DigiTm");
			} catch (Exception e) {
				e.printStackTrace();
				return new Cursor(Cursor.DEFAULT_CURSOR);
			}
		}

		System.out.println("DEFAULT.......................");
		return new Cursor(Cursor.DEFAULT_CURSOR);
	}

	public void selectColorChooser(boolean isFillColor) {
		this.motifCreatorWin.selectColorChooser(isFillColor);
	}

}
