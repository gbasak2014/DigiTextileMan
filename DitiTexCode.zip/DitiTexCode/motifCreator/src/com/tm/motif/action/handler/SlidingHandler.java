package com.tm.motif.action.handler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.tm.commons.action.EditMenuActionEnum;
import com.tm.commons.components.pane.GraphPane;
import com.tm.motif.win.MotifCreatorWin;

public class SlidingHandler implements ActionListener {
	MotifCreatorWin motifCreatorWin;

	public SlidingHandler(MotifCreatorWin motifCreatorWin) {
		this.motifCreatorWin = motifCreatorWin;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		EditMenuActionEnum cmd = EditMenuActionEnum.fromString(e.getActionCommand());
		GraphPane gp = this.motifCreatorWin.getCurrentDrawingPane().getGraphPane();
		switch (cmd) {
		case SLID_UP:
			gp.addUndoState();
			gp.slidUp();
			break;
		case SLID_DOWN:
			gp.addUndoState();
			gp.slidDown();
			break;
		case SLID_LEFT:
			gp.addUndoState();
			gp.slidLeft();
			break;
		case SLID_RIGHT:
			gp.addUndoState();
			gp.slidRight();
			break;
		}

		gp.repaint();
	}
}
