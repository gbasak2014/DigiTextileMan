package com.tm.motif.action.handler;

import java.awt.Rectangle;

import com.tm.commons.listener.StatusBarListener;
import com.tm.motif.win.MotifCreatorWin;

public class StatusBarHandler implements StatusBarListener {
	MotifCreatorWin motifCreatorWin;

	public StatusBarHandler(MotifCreatorWin motifCreatorWin) {
		this.motifCreatorWin = motifCreatorWin;
	}

	@Override
	public void drawingAreaChanges(Rectangle bound) {
		this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().setDrawingArea(bound);
	}

	@Override
	public Rectangle getDrawingArea() {
		Rectangle rect = this.motifCreatorWin.getPenHolder().getPen().getBound();
		this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().setDrawingArea(rect);
		return rect;
	}

	@Override
	public void clearDrawingArea() {
		this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().setDrawingArea(null);
	}

	@Override
	public void showGrid(boolean show) {
		this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().setShowGrid(show);
		this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().repaint();
	}
}
