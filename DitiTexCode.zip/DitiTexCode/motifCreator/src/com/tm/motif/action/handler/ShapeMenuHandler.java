package com.tm.motif.action.handler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.tm.commons.action.ShapeMenuActionEnum;
import com.tm.commons.components.pane.GraphPane;
import com.tm.motif.win.MotifCreatorWin;

public class ShapeMenuHandler implements ActionListener {
	MotifCreatorWin motifCreatorWin;

	public ShapeMenuHandler(MotifCreatorWin motifCreatorWin) {
		this.motifCreatorWin = motifCreatorWin;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		ShapeMenuActionEnum action = ShapeMenuActionEnum.fromString(e.getActionCommand());
		GraphPane graphPane = this.motifCreatorWin.getCurrentDrawingPane().getGraphPane();

		switch (action) {
		case UP:
			graphPane.moveShape(0, -1);
			break;
		case DOWN:
			graphPane.moveShape(0, 1);
			break;
		case LEFT:
			graphPane.moveShape(-1, 0);
			break;
		case RIGHT:
			graphPane.moveShape(1, 0);
			break;
		case COMMIT:
			graphPane.commit();
			break;
		case CANCEL:
			graphPane.cancel();
			break;
		}
	}
}
