package com.tm.motif.action.handler;

import java.awt.Color;

import com.tm.commons.listener.ColorChangeListener;
import com.tm.motif.win.MotifCreatorWin;

public class ColorChangeHandler implements ColorChangeListener {
	MotifCreatorWin motifCreatorWin;

	public ColorChangeHandler(MotifCreatorWin motifCreatorWin) {
		this.motifCreatorWin = motifCreatorWin;
	}

	@Override
	public void colorChanged(Color color) {
		if (this.motifCreatorWin.getPenHolder().getPen() != null) {
			this.motifCreatorWin.getPenHolder().getPen().setColor(color);
		}
		this.motifCreatorWin.setCurrentColor(color);
	}
}
