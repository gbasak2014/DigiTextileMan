package com.tm.motif.action.handler;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

import javax.swing.BorderFactory;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.button.ButtonDrawingTool;
import com.tm.commons.components.pane.ImagePane;
import com.tm.commons.dlg.WeaveSelectDlg;
import com.tm.commons.drawing.tool.Pen;
import com.tm.commons.image.ImageUtils;
import com.tm.motif.tool.DrawingTool;
import com.tm.motif.win.MotifCreatorWin;

public class PatternSelectHandler extends MouseAdapter implements ActionListener {

	MotifCreatorWin motifCreatorWin;
	DrawingTool toolBarDrawing;

	BufferedImage imgFillEmpty;
	BufferedImage imgFillSolid;
	ButtonDrawingTool btnSelPattern;

	public PatternSelectHandler(MotifCreatorWin motifCreatorWin, DrawingTool toolBarDrawing) {
		this.motifCreatorWin = motifCreatorWin;
		this.toolBarDrawing = toolBarDrawing;

		imgFillEmpty = new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB);
		Graphics2D g = imgFillEmpty.createGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, 20, 20);
		g.setColor(Color.BLACK);
		g.drawRect(5, 5, 10, 10);
		g.dispose();

		imgFillSolid = new BufferedImage(20, 20, BufferedImage.TYPE_INT_RGB);
		g = imgFillSolid.createGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, 20, 20);
		g.setColor(Color.BLACK);
		g.fillRect(5, 5, 10, 10);
		g.dispose();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		setTool(DrawingToolEnum.fromString(e.getActionCommand()), (ButtonDrawingTool) e.getSource());
	}

	public void setTool(DrawingToolEnum action, ButtonDrawingTool currentTool) {

		if (btnSelPattern != null) {
			btnSelPattern.setBorder(BorderFactory.createEmptyBorder());
		}
		btnSelPattern = currentTool;
		btnSelPattern.setBorder(BorderFactory.createLoweredBevelBorder());

		if (this.motifCreatorWin.getPenHolder().getPen() != null) {
			switch (action) {
			case FILL_SOLID:
				this.toolBarDrawing.setSelectedFillPattern(this.imgFillSolid);
				this.motifCreatorWin.getPenHolder().getPen().getFillPattern().setSolid(true);
				break;
			case FILL_EMPTY:
				this.toolBarDrawing.setSelectedFillPattern(this.imgFillEmpty);
				this.motifCreatorWin.getPenHolder().getPen().getFillPattern().setPattern(null);
			case FILL_PATTERN:
				this.motifCreatorWin.getPenHolder().getPen().getFillPattern().setSolid(false);
				break;
			case PASTE_CP:
				setPasteOption(false);
				break;
			case PASTE_XOR:
				setPasteOption(true);
				break;
			}
		}
	}

	void setPasteOption(boolean xor) {
		this.motifCreatorWin.getPenSelectHandler().getPaste().setPasteXor(xor);
	}

	@Override
	public void mousePressed(MouseEvent e) {
		Pen pen = this.motifCreatorWin.getPenHolder().getPen();
		if (pen != null) {
			ImagePane imagePane = (ImagePane) e.getSource();
			BufferedImage img = null;
			if (imagePane.isPattern()) {
				img = ImageUtils.copyImage(imagePane.getImage());
			} else if (imagePane.isCustomePattern()) {
				WeaveSelectDlg dlg = new WeaveSelectDlg(this.motifCreatorWin.getLibOptions().getWeaveHome());
				dlg.setVisible(true);
				img = dlg.getWeavePattern();
				dlg.dispose();
			}

			if (img != null) {
				ImageUtils.replaceColor(img, this.motifCreatorWin.getCurrentFillColor().getRGB());
				this.toolBarDrawing.setSelectedFillPattern(img);
				pen.getFillPattern().setPattern(img);

				if (btnSelPattern != null) {
					btnSelPattern.setBorder(BorderFactory.createEmptyBorder());
				}

				btnSelPattern = (ButtonDrawingTool) this.toolBarDrawing.getBtnFillPattern();
				btnSelPattern.setBorder(BorderFactory.createLoweredBevelBorder());
			}

			this.toolBarDrawing.getFilledPatternOptions().setVisiblePopup(false);
		}
	}

}