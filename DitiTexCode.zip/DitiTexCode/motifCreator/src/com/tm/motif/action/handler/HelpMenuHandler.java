package com.tm.motif.action.handler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.tm.commons.action.HelpMenuActionEnum;
import com.tm.commons.dlg.AboutDlg;
import com.tm.motif.win.MotifCreatorWin;

public class HelpMenuHandler implements ActionListener {
	MotifCreatorWin motifCreatorWin;

	public HelpMenuHandler(MotifCreatorWin motifCreatorWin) {
		this.motifCreatorWin = motifCreatorWin;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		HelpMenuActionEnum action = HelpMenuActionEnum.fromString(e.getActionCommand());

		switch (action) {
		case ABOUT:
			this.showAbout();
			break;
		default:
			this.showAbout();
			break;
		}
	}

	void showAbout() {
		AboutDlg dlg = new AboutDlg(this.motifCreatorWin, this.motifCreatorWin.getUser());
		dlg.setVisible(true);
	}
}
