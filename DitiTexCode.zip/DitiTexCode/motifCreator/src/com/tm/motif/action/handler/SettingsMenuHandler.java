package com.tm.motif.action.handler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.tm.commons.action.SettingsMenuActionEnum;
import com.tm.commons.components.pane.GraphPane;
import com.tm.commons.dlg.OptionsDlg;
import com.tm.motif.win.MotifCreatorWin;

public class SettingsMenuHandler implements ActionListener {
	MotifCreatorWin motifCreatorWin;

	public SettingsMenuHandler(MotifCreatorWin motifCreatorWin) {
		this.motifCreatorWin = motifCreatorWin;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		SettingsMenuActionEnum action = SettingsMenuActionEnum.fromString(e.getActionCommand());

		switch (action) {
		case OPTIONS:
			showOptions();
			break;
		case PRINT_OPTIONS:
			break;

		default:
			break;
		}
	}

	void showOptions() {
		OptionsDlg dlg = new OptionsDlg(this.motifCreatorWin.getGridOptions(), this.motifCreatorWin.getLibOptions(),
				this.motifCreatorWin.getPrintOption(), this.motifCreatorWin.getOtherOptions());
		dlg.setVisible(true);
		if (dlg.isOk() && this.motifCreatorWin.getCurrentDrawingPane() != null) {
			GraphPane graphPane = this.motifCreatorWin.getCurrentDrawingPane().getGraphPane();
			this.motifCreatorWin.getGridImage().createGrid(graphPane.getImgLeft(), graphPane.getImgTop(),
					graphPane.getImgWidth(), graphPane.getImgHeight());
			graphPane.repaint();

			this.motifCreatorWin.setCustomCorser(dlg.getOtherOptions().isCustomCursor());
			this.motifCreatorWin.saveLibrary();

		}
	}
}
