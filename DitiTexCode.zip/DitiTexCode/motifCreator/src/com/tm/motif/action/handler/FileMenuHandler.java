package com.tm.motif.action.handler;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.swing.filechooser.FileNameExtensionFilter;

import com.tm.commons.action.FileMenuActionEnum;
import com.tm.commons.clipboard.ClipboardUtil;
import com.tm.commons.components.DrawingImage;
import com.tm.commons.dlg.ImageOpenDlgTree;
import com.tm.commons.dlg.MotifLibraryDlg;
import com.tm.commons.dlg.PrintGrpDlg;
import com.tm.commons.dlg.PrintImageDlg;
import com.tm.commons.dlg.SaveLibDlg;
import com.tm.commons.image.ImageUtils;
import com.tm.commons.secure.TmSecure;
import com.tm.commons.theme.DigiTmTheme;
import com.tm.motif.pane.DrawingPane;
import com.tm.motif.win.MotifCreatorWin;

public class FileMenuHandler implements ActionListener {
	static final String NEW_GRAPH = "New Graph ";
	static int NEW_GRAPH_COUNT = 0;

	MotifCreatorWin motifCreatorWin;

	public FileMenuHandler(MotifCreatorWin motifCreatorWin) {
		this.motifCreatorWin = motifCreatorWin;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		FileMenuActionEnum action = FileMenuActionEnum.fromString(e.getActionCommand());
		try {
			switch (action) {
			case NEW:
				newGraph();
				break;
			case OPEN:
				openGraph();
				break;
			case SAVE:
				saveGraph();
				break;
			case SAVE_AS:
				if (this.motifCreatorWin.getCurrentDrawingPane() != null) {
					String path = this.motifCreatorWin.getCurrentDrawingPane().getFilePath();
					saveAsGraph(path);
				}
				break;
			case SAVE_SELECT:
				if (this.motifCreatorWin.getCurrentDrawingPane() != null) {
					BufferedImage img = this.motifCreatorWin.getCurrentDrawingPane().getSelectedImage();
					if (img != null) {
						String path = this.motifCreatorWin.getCurrentDrawingPane().getFilePath();
						saveAsGraph(img, path);
					}
				}
				break;
			case LOAD_MOTIF:
				loadMotifFromLibrary();
				break;
			case SAVE_MOTIF:
				saveMotif();
				break;
			case PRINT_IMAGE:
				if (this.motifCreatorWin.getCurrentDrawingPane() != null) {
					this.printImage(this.motifCreatorWin.getCurrentDrawingPane().getSavedImage());
				}
				break;
			case PRINT_IMAGE_SELECT:
				if (this.motifCreatorWin.getCurrentDrawingPane() != null) {
					BufferedImage img = this.motifCreatorWin.getCurrentDrawingPane().getSelectedImage();
					if (img != null) {
						this.printImage(img);
					}
				}
				break;
			case PRINT_GRAPH:
				if (this.motifCreatorWin.getCurrentDrawingPane() != null) {
					this.printGraph(this.motifCreatorWin.getCurrentDrawingPane().getSavedImage());
				}
				break;
			case PRINT_GRAPH_SELECT:
				if (this.motifCreatorWin.getCurrentDrawingPane() != null) {
					BufferedImage img = this.motifCreatorWin.getCurrentDrawingPane().getSelectedImage();
					if (img != null) {
						this.printGraph(img);
					}
				}
				break;
			case CLOSE:
				closeGraph();
				break;
			case EXIT:
				this.motifCreatorWin.dispatchEvent(new WindowEvent(this.motifCreatorWin, WindowEvent.WINDOW_CLOSING));
				break;
			case SCANNER:
				openScanner();
				break;
			case NEW_APP:
				openNewApp();
				break;
			default:
				break;
			}
		} catch (Exception ex) {
			JOptionPane.showMessageDialog(this.motifCreatorWin, ex.getMessage(), "ERROR", JOptionPane.ERROR_MESSAGE);
		}
	}

	void openScanner() {
		this.motifCreatorWin.openScanner();
	}

	void openNewApp() {
		this.motifCreatorWin.openNewApp();
	}

	public void closeGraph() {
		if (this.motifCreatorWin.getDesignContainer().getComponentCount() <= 1) {
			int status = JOptionPane.showConfirmDialog(this.motifCreatorWin, "Close TextileMan?");
			if (status == JOptionPane.YES_OPTION) {
				this.motifCreatorWin.setVisible(false);
			}

			return;
		}

		int idx = this.motifCreatorWin.getDesignContainer().getSelectedIndex();
		if (idx >= 0) {
			DrawingPane drawingPane = (DrawingPane) this.motifCreatorWin.getDesignContainer().getSelectedComponent();
			drawingPane.cleanup();

			this.motifCreatorWin.getDesignContainer().remove(idx);
		}
	}

	void saveGraph() {
		TmSecure.validateKey();
		if (this.motifCreatorWin.getCurrentDrawingPane() != null) {
			String path = this.motifCreatorWin.getCurrentDrawingPane().getFilePath();
			if (path == null || path.startsWith(NEW_GRAPH)) {
				saveAsGraph(this.motifCreatorWin.getFileOptions().getGraphFilePath());
			} else {
				saveGraph(path);
			}
		}
	}

	void saveAsGraph(String parentPath) {
		TmSecure.validateKey();
		JFileChooser jfc;
		if (parentPath != null)
			jfc = new JFileChooser(new File(parentPath));
		else {
			jfc = new JFileChooser();
		}

		jfc.setFileFilter(new FileNameExtensionFilter("24-bit Bitmap", "bmp"));

		if (jfc.showSaveDialog(this.motifCreatorWin) == JFileChooser.APPROVE_OPTION) {
			File file = jfc.getSelectedFile();
			String path = file.getAbsolutePath().toLowerCase();
			if (!path.endsWith(".bmp")) {
				path = path + ".bmp";
			}

			File f = new File(path);
			if (f.exists()) {
				int status = JOptionPane.showConfirmDialog(this.motifCreatorWin, "File already exist, want to replace?",
						"Confirmation", JOptionPane.YES_NO_OPTION);

				if (status != JOptionPane.YES_OPTION) {
					return;
				}
			}

			saveGraph(path);
			this.motifCreatorWin.getFileOptions().setGraphFilePath(file.getParent());
		}
	}

	void saveAsGraph(BufferedImage image, String parentPath) {
		TmSecure.validateKey();
		JFileChooser jfc;
		if (parentPath != null)
			jfc = new JFileChooser(new File(parentPath));
		else {
			jfc = new JFileChooser();
		}

		jfc.setFileFilter(new FileNameExtensionFilter("24-bit Bitmap", "bmp"));

		if (jfc.showSaveDialog(this.motifCreatorWin) == JFileChooser.APPROVE_OPTION) {
			File file = jfc.getSelectedFile();
			String path = file.getAbsolutePath().toLowerCase();
			if (!path.endsWith(".bmp")) {
				path = path + ".bmp";
			}
			saveGraph(image, path);
			this.motifCreatorWin.getFileOptions().setGraphFilePath(file.getParent());
		}
	}

	void saveGraph(String path) {
		try {
			File file = new File(path);
			BufferedImage image = this.motifCreatorWin.getCurrentDrawingPane().getSavedImage();
			if (ImageUtils.saveImage(image, path, "BMP")) {
				this.motifCreatorWin.getCurrentDrawingPane().setFilePath(path);
				JTabbedPane tabbedPane = this.motifCreatorWin.getDesignContainer();
				int idx = tabbedPane.getSelectedIndex();
				tabbedPane.setTitleAt(idx, file.getName());
				tabbedPane.setToolTipTextAt(idx, path);
				this.motifCreatorWin.addToHistory(System.currentTimeMillis(), path);
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this.motifCreatorWin, "File saving ERROR: " + e.getMessage(), "Graph Save",
					JOptionPane.ERROR_MESSAGE);
		}
	}

	void saveGraph(BufferedImage image, String path) {
		try {
			if (ImageUtils.saveImage(image, path, "BMP")) {
				this.openGraph(path);
			}
		} catch (Exception e) {
		}
	}

	void printGraph(BufferedImage img) {

		PrintGrpDlg dlg = new PrintGrpDlg(img, this.motifCreatorWin.getGridOptions());
		dlg.setVisible(true);
	}

	void printImage(BufferedImage img) {

		PrintImageDlg dlg = new PrintImageDlg(img);
		dlg.setVisible(true);
	}

	void loadMotifFromLibrary() {
		MotifLibraryDlg dlg = new MotifLibraryDlg(this.motifCreatorWin,
				this.motifCreatorWin.getLibOptions().getMotifHome());
		dlg.setVisible(true);
		if (dlg.isOk()) {
			BufferedImage img = dlg.getSelectedImage();
			if (img != null) {
				ClipboardUtil.copyToClipboard(img);
			}
		}
	}

	void saveMotif() {
		BufferedImage tmpImg = this.motifCreatorWin.getCurrentDrawingPane().getSelectedImage();

		if (tmpImg != null) {
			SaveLibDlg dlg = new SaveLibDlg(this.motifCreatorWin.getLibOptions().getMotifHome());
			dlg.setModal(true);
			dlg.setVisible(true);
			dlg.setTitle("Save Motif");
			if (dlg.isOk()) {
				String path = this.motifCreatorWin.getLibOptions().getMotifHome() + "/" + dlg.getSelectedLibrary()
						+ "/ptrn_" + System.currentTimeMillis();

				System.out.println(path);
				try {
					ImageIO.write(tmpImg, "BMP", new File(path));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			dlg.dispose();
		}
	}

	void newGraph() {
		BufferedImage graphImage = new BufferedImage(100, 100, BufferedImage.TYPE_INT_RGB);
		Graphics2D g = graphImage.createGraphics();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, 100, 100);
		g.dispose();
		addGraphPane(NEW_GRAPH + (++NEW_GRAPH_COUNT), graphImage, null);
		this.motifCreatorWin.getContentPane().setBackground(DigiTmTheme.getTitleColor());
	}

	void openGraph() throws Exception {
		ImageOpenDlgTree dlg = new ImageOpenDlgTree(this.motifCreatorWin,
				this.motifCreatorWin.getFileOptions().getGraphFilePath());
		dlg.setVisible(true);
		BufferedImage img = dlg.getSelectedImage();
		if (img != null) {
			File file = dlg.getSelectedFile();
			addGraphPane(file.getName(), img, file.getAbsolutePath());
			this.motifCreatorWin.getFileOptions().setGraphFilePath(file.getParent());
			this.motifCreatorWin.addToHistory(System.currentTimeMillis(), file.getAbsolutePath());
			this.motifCreatorWin.getContentPane().setBackground(DigiTmTheme.getTitleColor());
		} else {
			throw new Exception("10001 - ERROR Opening Graph");
		}
	}

	void openGraph(String path) throws Exception {

		try {
			BufferedImage img = ImageUtils.getImageFromFile(path);
			if (img != null) {
				File file = new File(path);
				addGraphPane(file.getName(), img, file.getAbsolutePath());
				this.motifCreatorWin.getFileOptions().setGraphFilePath(file.getParent());
				this.motifCreatorWin.addToHistory(System.currentTimeMillis(), file.getAbsolutePath());
				this.motifCreatorWin.getContentPane().setBackground(DigiTmTheme.getTitleColor());
			}
		} catch (Exception e) {
			throw new Exception("10001 - ERROR Opening Graph");
		}
	}

	public void addGraphPane(String title, BufferedImage graphImage, String path) {
		if (this.motifCreatorWin.getCurrentDrawingPane() != null) {
			this.motifCreatorWin.getCurrentDrawingPane().removeDrawingHandler(this.motifCreatorWin.getDrawingHandler());
		}

		DrawingImage drawingImg = this.motifCreatorWin.getDrawingImage();
		drawingImg.copyImage(graphImage);
		DrawingPane drawingPane = new DrawingPane(title, graphImage, drawingImg, this.motifCreatorWin.getGridImage(),
				this.motifCreatorWin, path);

		this.motifCreatorWin.setCurrentDrawingPane(drawingPane);

		this.motifCreatorWin.getCurrentDrawingPane().setBorder(BorderFactory.createLoweredBevelBorder());
		JTabbedPane pane = this.motifCreatorWin.getDesignContainer();
		pane.add(title, drawingPane);

		this.motifCreatorWin.getDrawingHandler().setGraphPane(drawingPane.getGraphPane(),
				this.motifCreatorWin.getCurrentColor());

		int idx = pane.getComponentCount() - 1;
		pane.setToolTipTextAt(idx, path != null ? path : title);
		pane.setSelectedIndex(idx);
		pane.setBackgroundAt(idx, DigiTmTheme.getBgColor());
	}
}
