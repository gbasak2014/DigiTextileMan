package com.tm.motif.action.handler;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import com.tm.commons.action.ArrangeMenuActionEnum;
import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.pane.GraphPane;
import com.tm.motif.win.MotifCreatorWin;

public class ArrangeMenuHandler implements ActionListener {
	MotifCreatorWin motifCreatorWin;

	public ArrangeMenuHandler(MotifCreatorWin motifCreatorWin) {
		this.motifCreatorWin = motifCreatorWin;
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (this.motifCreatorWin.getCurrentDrawingPane() != null && this.motifCreatorWin.getPenHolder() != null
				&& this.motifCreatorWin.getPenHolder().getPen().getType() == DrawingToolEnum.SELECT) {
			ArrangeMenuActionEnum action = ArrangeMenuActionEnum.fromString(e.getActionCommand());
			GraphPane graphPane = this.motifCreatorWin.getCurrentDrawingPane().getGraphPane();
			BufferedImage img = graphPane.getSelectedImage();
			if (img == null) {
				return;
			}

			Rectangle area = graphPane.getArrangeArea();

			if (area == null) {
				Rectangle rect = this.motifCreatorWin.getPenHolder().getPen().getBound();
				area = new Rectangle(rect.x, rect.y, rect.width, rect.height);
			}

			int w = img.getWidth();
			int h = img.getHeight();

			switch (action) {
			case LEFT:
				area.x = area.x - w;
				break;
			case RIGHT:
				area.x = area.x + w;
				break;
			case UP:
				area.y = area.y - h;
				break;
			case DOWN:
				area.y = area.y + h;
				break;
			case LEFT_UP:
				area.x = area.x - w;
				area.y = area.y - h;
				break;
			case LEFT_DOWN:
				area.x = area.x - w;
				area.y = area.y + h;
				break;
			case RIGHT_UP:
				area.x = area.x + w;
				area.y = area.y - h;
				break;
			case RIGHT_DOWN:
				area.x = area.x + w;
				area.y = area.y + h;
				break;
			default:
				break;
			}

			if (area.x + img.getWidth() > 0 && area.y + img.getHeight() > 0 && area.x < graphPane.getImgWidth() && area.y < graphPane.getImgHeight()) {

				Rectangle size = new Rectangle(0, 0, graphPane.getImgWidth(), graphPane.getImgHeight());
				Rectangle subSize = size.intersection(area);

				BufferedImage bakImg = graphPane.getSavedImage().getSubimage(subSize.x, subSize.y, subSize.width, subSize.height);
				graphPane.addUndoState(subSize.x, subSize.y, bakImg);

				graphPane.getSavedImage().getGraphics().drawImage(img, area.x, area.y, graphPane);
				Graphics2D g = graphPane.getDrawingImage().getImage().createGraphics();
				g.drawImage(graphPane.getSavedImage(), 0, 0, graphPane);
				g.dispose();
				graphPane.setArrangeArea(area);
				graphPane.repaint();
			}
		}
	}

	public static void main(String[] args) {
		Rectangle a1 = new Rectangle(0, 0, 100, 100);
		Rectangle a2 = new Rectangle(10, 0, 10, 10);
		System.out.println(a1.intersection(a2));
	}
}
