package com.tm.motif.action.handler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

import com.tm.commons.action.CodeMenuActionEnum;
import com.tm.commons.dlg.PrintCodeDlg;
import com.tm.commons.image.ImageUtils;
import com.tm.motif.win.CodeGenerateDlg;
import com.tm.motif.win.CodeToDesignWin;
import com.tm.motif.win.MotifCreatorWin;

public class CodeMenuHandler implements ActionListener {
	MotifCreatorWin motifCreatorWin;

	public CodeMenuHandler(MotifCreatorWin motifCreatorWin) {
		this.motifCreatorWin = motifCreatorWin;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		CodeMenuActionEnum action = CodeMenuActionEnum.fromString(e.getActionCommand());

		switch (action) {
		case CREATE:
			BufferedImage img = null;
			if (this.motifCreatorWin.getCurrentColor() != null
					&& this.motifCreatorWin.getCurrentDrawingPane() != null) {
				img = this.motifCreatorWin.getCurrentDrawingPane().getSelectedImage();

				if (img == null) {
					img = this.motifCreatorWin.getCurrentDrawingPane().getSavedImage();
				}
			}

			if (img != null) {
				this.showCodeWindow(ImageUtils.copyImage(img));
			} else {
				JOptionPane.showMessageDialog(this.motifCreatorWin,
						"No motif to generate code,\nPlease create or open Motif!!");
			}
			break;
		case VIEW_CODE:
			viewCode();
			break;
		case SAVE_CODE:
			saveCode();
			break;
		case CODE_TO_IMAGE:
			// openCodeToImageWin();
			new CodeToDesignWin();
			break;
		default:
			break;
		}
	}

	void openCodeToImageWin() {
		System.out.println("Starting.......");

		try {
			File dir = new File((new File(".")).getCanonicalPath() + File.separator + "plugin");
			StringBuffer cp = new StringBuffer();
			for (File f : dir.listFiles()) {
				cp.append(f.getAbsolutePath()).append(File.pathSeparator);
			}

			String javaBin = System.getProperty("java.home") + File.separator + "bin" + File.separator + "java";
			// String classPath = System.getProperty("java.class.path") +
			// File.pathSeparator + (new File(".")).getCanonicalPath() +
			// File.separator + "plugin";

			String classPath = cp.toString();
			String className = CodeToDesignWin.class.getCanonicalName();
			String cmd = "-cp";

			ProcessBuilder builder = new ProcessBuilder(javaBin, cmd, classPath, className);
			Process p = builder.start();
			System.out.println("Started...");
			System.out.println(javaBin + " " + cmd + " " + classPath + " " + className);
			// System.out.println(p.exitValue());
			// System.out.println(p.);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	void viewCode() {
		String codeFile = this.motifCreatorWin.getLibOptions().getCodeHome() + File.separator
				+ CodeGenerateDlg.CODE_FILE_NAME;
		PrintCodeDlg codeDlg = new PrintCodeDlg(this.motifCreatorWin.getUser(), codeFile,
				this.motifCreatorWin.getPrintOption());
		codeDlg.setVisible(true);
	}

	void saveCode() {
		String codeFile = this.motifCreatorWin.getLibOptions().getCodeHome() + File.separator
				+ CodeGenerateDlg.CODE_FILE_NAME;
		try {
			File file = new File(codeFile);
			if (file.exists()) {
				JFileChooser jfc = new JFileChooser();
				if (jfc.showSaveDialog(this.motifCreatorWin) == JFileChooser.APPROVE_OPTION) {
					PrintWriter pw = new PrintWriter(jfc.getSelectedFile());
					BufferedReader br = new BufferedReader(new FileReader(file));

					String line = br.readLine();
					while (line != null) {
						pw.println(line);
						line = br.readLine();
					}

					pw.close();
					br.close();
				}
			} else {
				JOptionPane.showMessageDialog(this.motifCreatorWin, "Please generate code!!");
			}
		} catch (Exception e) {
			JOptionPane.showMessageDialog(this.motifCreatorWin, e.getMessage());
		}
	}

	void showCodeWindow(BufferedImage image) {

		CodeGenerateDlg dlg = new CodeGenerateDlg(this.motifCreatorWin.getUser(),
				this.motifCreatorWin.getCurrentDrawingPane().getFilePath(), image,
				this.motifCreatorWin.getGridOptions(), this.motifCreatorWin.getLibOptions().getCodeHome(),
				this.motifCreatorWin.getPrintOption());
		dlg.setVisible(true);
	}
}
