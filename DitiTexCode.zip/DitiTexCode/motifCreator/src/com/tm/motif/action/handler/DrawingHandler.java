package com.tm.motif.action.handler;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.drawing.tool.Bezier;
import com.tm.commons.drawing.tool.Pen;
import com.tm.commons.listener.DrawingListener;
import com.tm.motif.tool.DrawingTool;
import com.tm.motif.win.MotifCreatorWin;

public class DrawingHandler extends DrawingListener {

	MotifCreatorWin motifCreatorWin;

	DrawingTool toolBarDrawing;
	boolean isMove = false;
	int px;
	int py;

	int prevX = -1;
	int prevY = -1;

	public DrawingHandler(MotifCreatorWin motifCreatorWin) {
		super(motifCreatorWin.getPenHolder(), motifCreatorWin.getFillPattern(), motifCreatorWin.getStatusBar(),
				motifCreatorWin.getMotifCreatorToolBar().getColorChooser());
		this.toolBarDrawing = motifCreatorWin.getToolBarDrawing();
		this.motifCreatorWin = motifCreatorWin;
	}

	@Override
	public void mousePressed(MouseEvent e) {
		Pen pen = this.penHolder.getPen();
		if (pen != null) {
			int x = e.getX() / graphPane.getZoom() + graphPane.getImgLeft();
			int y = e.getY() / graphPane.getZoom() + graphPane.getImgTop();
			this.isMove = false;

			if (DrawingToolEnum.FILL == pen.getType() || DrawingToolEnum.REPLACE_COLOR == pen.getType()
					|| DrawingToolEnum.ADD_BORDER == pen.getType()) {
				pen.draw(x, y);
				graphPane.repaint();
				// this.toolBarDrawing.selectMouse();
			} else if (DrawingToolEnum.PICK == pen.getType()) {
				int rgb = this.graphPane.getSavedImage().getRGB(x, y);
				this.motifCreatorWin.selectColor(new Color(rgb));
				// this.colorChooser.setSelectedColor(new Color(rgb));
			} else if (DrawingToolEnum.BEZ == pen.getType() && ((Bezier) pen).isControlPoint(x, y)) {
				pen.setStartPoint(x, y);
			} else if (x == pen.getStartX() && y == pen.getStartY()) {
				pen.setMode(Pen.STARTX_STARTY);
			} else if (x == pen.getStartX() && y == pen.getCurrentY()) {
				pen.setMode(Pen.STARTX_CURRENTY);
			} else if (x == pen.getCurrentX() && y == pen.getStartY()) {
				pen.setMode(Pen.CURRENTX_STARTY);
			} else if (x == pen.getCurrentX() && y == pen.getCurrentY()) {
				pen.setMode(Pen.CURRENTX_CURRENTY);
			} else if (x == pen.getStartX()) {
				pen.setMode(Pen.START_X);
			} else if (x == pen.getCurrentX()) {
				pen.setMode(Pen.CURRENT_X);
			} else if (y == pen.getStartY()) {
				pen.setMode(Pen.START_Y);
			} else if (y == pen.getCurrentY()) {
				pen.setMode(Pen.CURRENT_Y);
			} else if (pen.inside(x, y)) {
				this.isMove = true;
				this.px = x;
				this.py = y;
			} else {

				if (pen.getType() != DrawingToolEnum.BEZ) {
					if (DrawingToolEnum.COLOR_SELECT == pen.getType()) {
						pen.draw(x, y);
					} else {
						pen.save();
						if (e.getButton() != MouseEvent.BUTTON1) {
							pen.setClearColor();
						}
						pen.setStartPoint(x, y);
					}
					this.graphPane.clearRulerIndex();
					this.statusBar.setCurrentPos(x, y);
				} else {
					if (e.getButton() != MouseEvent.BUTTON1) {
						pen.save();
					} else {
						pen.setStartPoint(x, y);
					}
				}

			}

			this.graphPane.setArrangeArea(null);
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		Pen pen = this.penHolder.getPen();
		if (pen != null) {
			pen.setMode(Pen.ALL);
			if (pen.getType() == DrawingToolEnum.PEN || pen.getType() == DrawingToolEnum.SELECT_RAND) {
				pen.save();
			} else if (pen.getType() == DrawingToolEnum.BEZ) {
				((Bezier) pen).setControlPoint();
			}
		}

		graphPane.repaint();
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		Pen pen = this.penHolder.getPen();
		int sx;
		int sy;
		int x;
		int y;
		if (pen != null) {
			sx = x = e.getX() / graphPane.getZoom() + graphPane.getImgLeft();
			sy = y = e.getY() / graphPane.getZoom() + graphPane.getImgTop();

			if (prevX == x && prevY == y) {
				return;
			}

			prevX = x;
			prevY = y;

			if (this.isMove) {
				int dx = x - this.px;
				int dy = y - this.py;
				pen.move(dx, dy);
				this.px = x;
				this.py = y;
			} else {
				pen.draw(x, y);
			}

			if (e.getX() < 0) {
				sx = this.graphPane.getImgLeft() - 5;
				if (sx < 0) {
					sx = 0;
				}
			} else if (e.getX() > this.graphPane.getWidth()) {
				sx = this.graphPane.getImgLeft() + 5;
				if (this.graphPane.getImgWidth() - sx < 5) {
					sx = this.graphPane.getImgWidth() - 5;
				}
			} else {
				sx = this.graphPane.getImgLeft();
			}

			if (e.getY() < 0) {
				sy = this.graphPane.getImgTop() - 5;
				if (sy < 0) {
					sy = 0;
				}
			} else if (e.getY() > this.graphPane.getHeight()) {
				sy = this.graphPane.getImgTop() + 5;
				if (this.graphPane.getImgHeight() - sy < 5) {
					sy = this.graphPane.getImgHeight() - 5;
				}
			} else {
				sy = this.graphPane.getImgTop();
			}

			if (x != sx || y != sy) {
				this.graphPane.scroll(sx, sy);
				this.motifCreatorWin.getCurrentDrawingPane().setScrollvalue(sx, sy);
			}

			this.graphPane.repaint();

			this.statusBar.setCurrentPos(x+1, y+1);
			this.statusBar.setShapeSize(pen.getBound().width, pen.getBound().height);
		}
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		Pen pen = this.penHolder.getPen();
		if (pen != null) {
			int x = e.getX() / graphPane.getZoom() + graphPane.getImgLeft();
			int y = e.getY() / graphPane.getZoom() + graphPane.getImgTop();
			this.statusBar.setCurrentPos(x+1, y+1);

			Rectangle bound = pen.getBound();

			if (DrawingToolEnum.REPLACE_COLOR == pen.getType() || DrawingToolEnum.PICK == pen.getType()) {
				// pen.draw(x, y);
				// pen.setCurrentPoint(x, y);
				if (x >= 0 && x < this.graphPane.getSavedImage().getWidth() && y >= 0
						&& y < this.graphPane.getSavedImage().getHeight()) {
					int rgb = this.graphPane.getSavedImage().getRGB(x, y);
					// this.colorChooser.pickColor(new Color(rgb));
					this.motifCreatorWin.pickColor(new Color(rgb));
				}
			} else if ((pen.getType() != DrawingToolEnum.BEZ || !((Bezier) pen).isControlPoint(x, y))
					&& (bound.width > 0 || bound.height > 0)) {
				if (x == bound.x && y == bound.y) {
					this.graphPane.setCursor(new Cursor(Cursor.NW_RESIZE_CURSOR));
				} else if (x == bound.x && y == (bound.y + bound.height - 1)) {
					this.graphPane.setCursor(new Cursor(Cursor.SW_RESIZE_CURSOR));
				} else if (x == (bound.x + bound.width - 1) && y == bound.y) {
					this.graphPane.setCursor(new Cursor(Cursor.NE_RESIZE_CURSOR));
				} else if (x == (bound.x + bound.width - 1) && y == (bound.y + bound.height - 1)) {
					this.graphPane.setCursor(new Cursor(Cursor.SE_RESIZE_CURSOR));
				} else if (x == bound.x) {
					this.graphPane.setCursor(new Cursor(Cursor.W_RESIZE_CURSOR));
				} else if (x == (bound.x + bound.width - 1)) {
					this.graphPane.setCursor(new Cursor(Cursor.E_RESIZE_CURSOR));
				} else if (y == bound.y) {
					this.graphPane.setCursor(new Cursor(Cursor.N_RESIZE_CURSOR));
				} else if (y == (bound.y + bound.height - 1)) {
					this.graphPane.setCursor(new Cursor(Cursor.S_RESIZE_CURSOR));
				} else if (this.penHolder.getPen().inside(x, y)) {
					this.graphPane.setCursor(new Cursor(Cursor.MOVE_CURSOR));
				} else {
					this.graphPane.resetCursor();
					// this.graphPane.setCursor(new
					// Cursor(Cursor.DEFAULT_CURSOR));
				}
			} else {
				this.graphPane.resetCursor();
				// setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}
		}
	}
}
