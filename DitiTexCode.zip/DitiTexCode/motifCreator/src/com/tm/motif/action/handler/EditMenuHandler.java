package com.tm.motif.action.handler;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.action.EditMenuActionEnum;
import com.tm.commons.clipboard.ClipboardUtil;
import com.tm.commons.components.pane.GraphPane;
import com.tm.commons.dlg.ColorLockDlg;
import com.tm.commons.dlg.FloatCheckDlg;
import com.tm.commons.dlg.ImageMixDlg;
import com.tm.commons.dlg.ImageResizeDlg;
import com.tm.commons.dlg.ImageRotateDlg;
import com.tm.commons.dlg.ImageSelectDlg;
import com.tm.commons.dlg.ImageSplitDlg;
import com.tm.commons.dlg.ImgMergeDlg;
import com.tm.commons.dlg.SaveLibDlg;
import com.tm.commons.dlg.SlidingDlg;
import com.tm.commons.dlg.TextDlg;
import com.tm.commons.dlg.WeaveSelectDlg;
import com.tm.commons.drawing.tool.Paste;
import com.tm.commons.drawing.tool.Pen;
import com.tm.commons.image.ImageUtils;
import com.tm.commons.tool.Ruler;
import com.tm.motif.win.MotifCreatorWin;

public class EditMenuHandler implements ActionListener {
	MotifCreatorWin motifCreatorWin;

	public EditMenuHandler(MotifCreatorWin motifCreatorWin) {
		this.motifCreatorWin = motifCreatorWin;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		EditMenuActionEnum action = EditMenuActionEnum.fromString(e.getActionCommand());

		switch (action) {
		case COPY:
			this.copy();
			break;
		case CUT:
			this.cut();
			break;
		case PASTE:
			this.paste();
			break;
		case INSERT_ROW_COL:
			this.insertRowsCols();
			break;
		case REMOVE_ROW_COL:
			this.removeRowsCols();
			break;
		case DELETE_SELECT:
			this.deleteSelect();
			break;
		case FLIP_HORIZ:
			this.flipImage(true);
			break;
		case FLIP_VERT:
			this.flipImage(false);
			break;
		case ROTATE:
			this.rotateImage();
			break;
		case RESIZE:
			this.resizeSelectedImage();
			break;
		case UNDO:
			if (this.motifCreatorWin.getCurrentDrawingPane() != null) {
				this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().undo();
				this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().repaint();
			}
			break;
		case REDO:
			if (this.motifCreatorWin.getCurrentDrawingPane() != null) {
				this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().redo();
				this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().repaint();
			}
			break;
		case SET_LINE_PATTERN:
			setLinePattern();
			break;
		case SET_PATTERN:
			setFillPattern();
			break;
		case ADD_PATTERN:
			savePattern();
			break;
		case LOAD_PATTERN:
			loadPatternFromLibrary();
			break;
		case FLOAT_CHECK:
			openFloadCheckWin();
			break;
		case MERGE_IMAGE:
			openMergeImageDlg();
			break;
		case CROP_IMAGE:
			cropImage();
			break;
		case BI_COLOR:
			makeBlackWhite();
			break;
		case REVERSE_COLOR:
			reverseColor();
			break;
		case SLIDING:
			openSlidDlg();
			break;
		case COLOR_PROTECT:
			openColorProtectDlg();
			break;
		case IMAGE_MIX:
			ImageMixDlg mixDlg = new ImageMixDlg();
			mixDlg.setVisible(true);
			break;
		case IMAGE_SPLIT:
			ImageSplitDlg splitDlg = new ImageSplitDlg();
			splitDlg.setVisible(true);
			break;
		case SELECT_FROM_FILE:
			selectFromFile();
			break;
		case TEXT:
			getTextDlg();
			break;
		case DRAWING_AREA:
			setDrawingArea((JCheckBoxMenuItem) e.getSource());
			break;
		default:
			break;
		}
	}

	void setDrawingArea(JCheckBoxMenuItem jmi) {
		if (jmi.isSelected()) {
			this.motifCreatorWin.setDrawingArea();
		}
	}

	void selectFromFile() {
		ImageSelectDlg dlg = new ImageSelectDlg(this.motifCreatorWin, null);
		dlg.setVisible(true);

		if (dlg.isOk()) {
			BufferedImage img = dlg.getSelectedImage();
			if (img != null) {
				ClipboardUtil.copyToClipboard(img);
			}
		}

		dlg.dispose();
	}

	void openColorProtectDlg() {
		List<Integer> rgbs = this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().getUsedColors();
		int rgb[] = this.motifCreatorWin.getPenHolder().getLockedRGBs();
		ColorLockDlg dlg = new ColorLockDlg(this.motifCreatorWin, rgbs, this.motifCreatorWin.getCurrentColor(),
				new ColorProtectHandler(motifCreatorWin), rgb);

		dlg.setVisible(true);
		this.motifCreatorWin.getPenHolder().setLockedColor(dlg.getLockedRGB());
	}

	void openSlidDlg() {
		SlidingDlg dlg = new SlidingDlg(motifCreatorWin, new SlidingHandler(motifCreatorWin));
		dlg.setVisible(true);
	}

	void getTextDlg() {

		TextDlg dlg = new TextDlg(this.motifCreatorWin,
				this.motifCreatorWin.getSelectedColorChooser().getSelectedColor());
		dlg.setVisible(true);
		BufferedImage img = dlg.getTextAsImage();
		if (img != null) {
			ClipboardUtil.copyToClipboard(img);
		}
	}

	public void savePattern() {
		BufferedImage tmpImg = this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().getSelectedImage();

		if (tmpImg != null) {
			SaveLibDlg dlg = new SaveLibDlg(this.motifCreatorWin.getLibOptions().getWeaveHome());
			dlg.setModal(true);
			dlg.setVisible(true);
			dlg.setTitle("Save Pattern");
			if (dlg.isOk()) {
				String path = this.motifCreatorWin.getLibOptions().getWeaveHome() + "/" + dlg.getSelectedLibrary()
						+ "/ptrn_" + System.currentTimeMillis();

				try {
					ImageIO.write(tmpImg, "BMP", new File(path));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			dlg.dispose();
		}
	}

	private void rotateImage() {
		BufferedImage img = this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().getSelectedImage();
		if (img != null) {
			ImageRotateDlg dlg = new ImageRotateDlg(img);
			dlg.setVisible(true);
			if (dlg.isOk()) {

				BufferedImage tmpImg = dlg.getImage();
				if (tmpImg != null) {
					ClipboardUtil.copyToClipboard(tmpImg);
				}
			}
		}
	}

	private void resizeSelectedImage() {
		BufferedImage img = this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().getSelectedImage();
		if (img != null) {
			ImageResizeDlg dlg = new ImageResizeDlg(img.getWidth(), img.getHeight());
			dlg.setVisible(true);
			if (dlg.isOK()) {
				int w = dlg.getNewWidth();
				int h = dlg.getNewHeight();
				if (w > 0 && h > 0) {
					BufferedImage tmpImg = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
					Graphics2D g = tmpImg.createGraphics();
					g.drawImage(img, 0, 0, w, h, null);
					g.dispose();
					ClipboardUtil.copyToClipboard(tmpImg);
				}
			}
		}
	}

	private void deleteSelect() {
		GraphPane graphPane = this.motifCreatorWin.getCurrentDrawingPane().getGraphPane();
		graphPane.clearSelectedArea();
		graphPane.repaint();
	}

	private void insertRowsCols() {
		GraphPane graphPane = this.motifCreatorWin.getCurrentDrawingPane().getGraphPane();
		int index = graphPane.getRulerStartIndex();
		if (index >= 0) {
			try {
				if (Ruler.VERTZ == graphPane.getRulerType()) {
					int rows = Integer.parseInt(JOptionPane.showInputDialog("Enter Number of Rows"));
					if (rows > 0) {
						graphPane.insertRows(index, rows);
					}
				} else {
					int cols = Integer.parseInt(JOptionPane.showInputDialog("Enter Number of Columns"));
					if (cols > 0) {
						graphPane.insertColumns(index, cols);
					}
				}
				graphPane.repaint();
			} catch (Exception e) {
				e.printStackTrace();
			}

			this.motifCreatorWin.getCurrentDrawingPane().setScrollbarMaxValue(graphPane.getImgWidth(),
					graphPane.getImgHeight());
			this.motifCreatorWin.getStatusBar().setImageSize(graphPane.getImgWidth(), graphPane.getImgHeight());
			this.motifCreatorWin.getPenHolder().getPen().setGraphPane(graphPane);
		}
	}

	private void removeRowsCols() {
		GraphPane graphPane = this.motifCreatorWin.getCurrentDrawingPane().getGraphPane();
		int index1 = graphPane.getRulerStartIndex();
		int index2 = graphPane.getRulerEndIndex();
		if (index1 >= 0 && index1 < index2) {
			try {
				if (Ruler.VERTZ == graphPane.getRulerType()) {
					graphPane.removeRows(index1 + graphPane.getImgTop(), index2 + graphPane.getImgTop());
				} else {
					graphPane.removeCols(index1 + graphPane.getImgLeft(), index2 + graphPane.getImgLeft());
				}
				graphPane.repaint();
			} catch (Exception e) {
				e.printStackTrace();
			}

			this.motifCreatorWin.getCurrentDrawingPane().setScrollbarMaxValue(graphPane.getImgWidth(),
					graphPane.getImgHeight());
			this.motifCreatorWin.getStatusBar().setImageSize(graphPane.getImgWidth(), graphPane.getImgHeight());
			this.motifCreatorWin.getPenHolder().getPen().setGraphPane(graphPane);
		}
	}

	void makeBlackWhite() {
		this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().makeBlackColored();
		this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().repaint();
	}

	private void flipImage(boolean horiz) {
		BufferedImage selImage = this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().getSelectedImage();

		if (selImage != null) {
			if (horiz) {
				this.paste(ImageUtils.flipHorizontal(selImage));
			} else {
				this.paste(ImageUtils.flipVertical(selImage));
			}
		}

	}

	void reverseColor() {
		this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().reverseColor();
		this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().repaint();
	}

	private BufferedImage copy() {
		BufferedImage image = this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().getSelectedImage();
		if (image != null) {
			ClipboardUtil.copyToClipboard(image);
		}

		return image;
	}

	private BufferedImage cut() {
		BufferedImage image = this.copy();
		if (image != null) {
			this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().clearSelectedArea();
			this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().repaint();

			Rectangle bound = this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().getPenHolder().getPen()
					.getBound();
			this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().addUndoState(bound.x, bound.y, image);
		}

		return image;
	}

	private void paste() {
		if (ClipboardUtil.hasClipboardImage()) {
			BufferedImage image = ClipboardUtil.getImageFromClipboard();
			paste(image);
		}
	}

	void cropImage() {
		BufferedImage image = this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().getSelectedImage();
		if (image != null) {
			BufferedImage newImage = ImageUtils.copyImage(image);
			this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().cropImage(newImage);
			this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().repaint();
		}
	}

	private void paste(BufferedImage image) {
		Pen pen = this.motifCreatorWin.getPenSelectHandler().getCurrentPen();
		this.motifCreatorWin.getPenSelectHandler().setDrawingTool(DrawingToolEnum.PASTE);
		Paste paste = this.motifCreatorWin.getPenSelectHandler().getPaste();
		paste.setImage(image);
		paste.setPreviousPen(pen);
		this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().repaint();
	}

	private void setLinePattern() {
		if (this.motifCreatorWin.getCurrentDrawingPane() != null
				&& this.motifCreatorWin.getPenHolder().getPen() != null) {
			Rectangle bound = this.motifCreatorWin.getPenHolder().getPen().getBound();
			if (bound.height == 1) {
				BufferedImage img = this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().getSavedImage();
				int[] pattern = new int[bound.width];
				int rgb = Color.WHITE.getRGB();
				int i = 0;
				for (int x = bound.x; x < bound.x + bound.width; x++) {
					if (rgb == img.getRGB(x, bound.y)) {
						pattern[i++] = 0;
					} else {
						pattern[i++] = 1;
					}
				}

				this.motifCreatorWin.getPenSelectHandler().getLine().setLinePattern(pattern);
			}
		}
	}

	private void setFillPattern() {
		if (this.motifCreatorWin.getCurrentDrawingPane() != null
				&& this.motifCreatorWin.getPenHolder().getPen() != null) {
			Rectangle bound = this.motifCreatorWin.getPenHolder().getPen().getBound();
			if (bound.height > 0 && bound.width > 0) {
				BufferedImage patImg = this.motifCreatorWin.getCurrentDrawingPane().getGraphPane().getSavedImage()
						.getSubimage(bound.x, bound.y, bound.width, bound.height);
				if (patImg != null) {
					ImageUtils.replaceColor(patImg, this.motifCreatorWin.getCurrentFillColor().getRGB());
					this.motifCreatorWin.getToolBarDrawing().setSelectedFillPattern(patImg);
					this.motifCreatorWin.getPenHolder().getPen().getFillPattern().setPattern(patImg);
				}
			}
		}
	}

	void loadPatternFromLibrary() {
		WeaveSelectDlg dlg = new WeaveSelectDlg(this.motifCreatorWin.getLibOptions().getWeaveHome());
		dlg.setVisible(true);
		BufferedImage pattern = dlg.getWeavePattern();
		if (pattern != null) {
			ImageUtils.replaceColor(pattern, this.motifCreatorWin.getCurrentFillColor().getRGB());
			this.motifCreatorWin.getToolBarDrawing().setSelectedFillPattern(pattern);
			this.motifCreatorWin.getPenHolder().getPen().getFillPattern().setPattern(pattern);
		}
	}

	void openFloadCheckWin() {

		FloatCheckDlg dlg = new FloatCheckDlg();
		dlg.setVisible(true);
	}

	void openMergeImageDlg() {
		ImgMergeDlg dlg = new ImgMergeDlg(this.motifCreatorWin);
		dlg.setSize(500, 500);
		dlg.setVisible(true);
	}
}
