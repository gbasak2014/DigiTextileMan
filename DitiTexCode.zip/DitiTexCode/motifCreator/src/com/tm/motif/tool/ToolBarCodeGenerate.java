package com.tm.motif.tool;

import java.awt.Color;
import java.awt.FlowLayout;

import com.tm.commons.action.CodeMenuActionEnum;
import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.listener.ColorChangeListener;
import com.tm.commons.menu.DigiTmToolBar;
import com.tm.commons.tool.ColorPane;
import com.tm.commons.tool.DropdownColorChooser;
import com.tm.motif.win.CodeGenerateDlg;

public class ToolBarCodeGenerate extends DigiTmToolBar {
	private static final long serialVersionUID = -1722888686342670752L;
	DropdownColorChooser colorChooser;

	public ToolBarCodeGenerate(CodeGenerateDlg codeGenerateDlg) {
		super();
		this.setLayout(new FlowLayout(FlowLayout.LEADING, 0, 0));
		add(new ButtonMenuItem(CodeMenuActionEnum.PICK_COLOR.value, codeGenerateDlg, "/img/pick_color.jpg",
				"Pick Color"));
		this.addColorTools(codeGenerateDlg);
		add(new ButtonMenuItem(CodeMenuActionEnum.PEN.value, codeGenerateDlg, "/img/pen.jpg",
				"Pen - Freehand drawing with selected color"));
		String title = "Replace Color - Pick Color and then mouse press on image to replace the color";
		add(new ButtonMenuItem(CodeMenuActionEnum.REPLACE_COLOR.value, codeGenerateDlg, "/img/replcolor.jpg", title));
		add(new ButtonMenuItem(CodeMenuActionEnum.MIRROR_HORIZ.value, codeGenerateDlg, "/img/flip-h.jpg",
				"Flip Horizontal"));
		add(new ButtonMenuItem(CodeMenuActionEnum.MIRROR_VERT.value, codeGenerateDlg, "/img/flip-v.jpg",
				"Flip Vertical"));
		add(new ButtonMenuItem(CodeMenuActionEnum.ZOOM_IN.value, codeGenerateDlg, "/img/z2.jpg", "Zoom In"));
		add(new ButtonMenuItem(CodeMenuActionEnum.ZOOM_OUT.value, codeGenerateDlg, "/img/z1.jpg", "Zoom Out"));
		add(new ButtonMenuItem(CodeMenuActionEnum.CODE_GENERATE.value, codeGenerateDlg, "/img/mkcode.jpg",
				"Code Generate - Generate code for selected color"));

		add(new ButtonMenuItem(CodeMenuActionEnum.VIEW_CODE.value, codeGenerateDlg, "/img/viewcode.jpg", "View Code"));

		add(new ButtonMenuItem(CodeMenuActionEnum.CLOSE.value, codeGenerateDlg, "/img/close.jpg", "Close window"));

	}

	void addColorTools(ColorChangeListener listener) {
		colorChooser = new DropdownColorChooser(listener);
		colorChooser.addColorPane(new ColorPane());
		this.add(colorChooser);
	}

	public void setSelectedColor(int rgb) {
		this.colorChooser.setSelectedColor(new Color(rgb));
	}

	public Color getSelectedColorButton() {
		return this.colorChooser.getSelectedColor();
	}

	public void setNewColor(Color color) {
		this.colorChooser.pickColor(color);
	}
}
