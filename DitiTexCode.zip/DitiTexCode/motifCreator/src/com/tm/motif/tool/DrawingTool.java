package com.tm.motif.tool;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.image.BufferedImage;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JSpinner;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.button.ButtonDrawingTool;
import com.tm.commons.components.pane.SimpleImagePane;
import com.tm.commons.image.ImageUtils;
import com.tm.commons.listener.ColorChangeListener;
import com.tm.commons.tool.DropdownColorChooser;
import com.tm.commons.tool.FilledPatternOptions;
import com.tm.motif.action.handler.PatternSelectHandler;
import com.tm.motif.action.handler.PenSelectHandler;
import com.tm.motif.pane.BorderOptions;
import com.tm.motif.pane.CircleOptions;
import com.tm.motif.pane.LineOptions;
import com.tm.motif.pane.PickColorOptions;
import com.tm.motif.win.MotifCreatorWin;

public abstract class DrawingTool extends JPanel implements ColorChangeListener {
	DropdownColorChooser colorChooser;
	MotifCreatorWin parent;
	PenSelectHandler drawingAction;
	PatternSelectHandler patternSelectHandler;
	PatternSelectHandler pasteOptionsHandler;
	SimpleImagePane selectedFillPatternPane;
	SimpleImagePane selectedCirclePatternPane;

	FilledPatternOptions filledPatternOptions;
	CircleOptions circleOptions;
	// LineOptions lineOptions;

	JButton btnFillPattern;
	ButtonDrawingTool btnMouse;
	JSpinner spinner;

	public DropdownColorChooser getColorChooser() {
		return this.colorChooser;
	}

	public BufferedImage getSelectedPatternImage() {
		return this.selectedFillPatternPane.getImage();
	}

	public void refeshSelectedPattern() {
		this.selectedFillPatternPane.repaint();
	}

	public void setSelectedCirclePattern(BufferedImage pattern) {
		this.selectedCirclePatternPane.setImage(pattern);
		this.selectedCirclePatternPane.repaint();
	}

	void setBrush() {
		int v = Integer.parseInt(this.spinner.getModel().getValue().toString());
		this.parent.getPenHolder().setBrush(v);
	}

	void addLineButton(JPanel panel) {
		ButtonDrawingTool btn = new ButtonDrawingTool(DrawingToolEnum.LINE.value, drawingAction, "/img/line.jpg",
				"Line", false);
		btn.setPreferredSize(new Dimension(28, 20));
		JPanel pnlOption = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
		pnlOption.add(btn);
		LineOptions lineOptions = new LineOptions(btn, this.parent.getPenHolder(), this,
				(PenSelectHandler) drawingAction);
		pnlOption.add(lineOptions);
		panel.add(pnlOption);
	}

	void addSetBorder(JPanel panel) {
		ButtonDrawingTool btn = new ButtonDrawingTool(DrawingToolEnum.ADD_BORDER.value, drawingAction,
				"/img/set-border.jpg", "Set Border", false);
		btn.setPreferredSize(new Dimension(28, 20));
		JPanel pnlOption = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
		pnlOption.add(btn);
		BorderOptions borderOptions = new BorderOptions(btn, this.parent.getPenHolder(), this,
				(PenSelectHandler) drawingAction);
		pnlOption.add(borderOptions);

		panel.add(pnlOption);
	}

	void addPickColor(JPanel panel) {
		ButtonDrawingTool btn = new ButtonDrawingTool(DrawingToolEnum.PICK.value, drawingAction, "/img/pick_color.jpg",
				"Pick Color", false);
		btn.setPreferredSize(new Dimension(28, 20));
		JPanel pnlOption = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
		pnlOption.add(btn);
		PickColorOptions pickColorOptions = new PickColorOptions(btn, this.parent.getPenHolder(), this,
				(PenSelectHandler) drawingAction);

		pnlOption.add(pickColorOptions);

		panel.add(pnlOption);
	}

	public DrawingToolEnum getSelectedPen() {
		if (drawingAction.getSelectedButton() != null) {
			int action = Integer.parseInt(drawingAction.getSelectedButton().getActionCommand());
			return DrawingToolEnum.fromInt(action);
		}

		return null;
	}

	public void setSelectedFillPattern(BufferedImage pattern) {
		this.selectedFillPatternPane.setImage(pattern);
		this.selectedFillPatternPane.repaint();
	}

	public FilledPatternOptions getFilledPatternOptions() {
		return filledPatternOptions;
	}

	public CircleOptions getCircleOptions() {
		return circleOptions;
	}

	public void setFilledPatternOptions(FilledPatternOptions filledPatternOptions) {
		this.filledPatternOptions = filledPatternOptions;
	}

	public void setCircleOptions(CircleOptions circleOptions) {
		this.circleOptions = circleOptions;
	}

	public void selectMouse() {
		this.drawingAction.selectPenTool(this.btnMouse, DrawingToolEnum.MOUSE);
	}

	public JButton getBtnFillPattern() {
		return btnFillPattern;
	}

	@Override
	public void colorChanged(Color color) {

		BufferedImage img = this.parent.getToolBarDrawing().getSelectedPatternImage();
		this.parent.setCurrentFillColor(color);

		if (img != null) {
			ImageUtils.replaceColor(img, color.getRGB());
			this.parent.getToolBarDrawing().refeshSelectedPattern();
			if (this.parent.getFillPattern().getPattern() != null) {
				this.parent.getFillPattern().setPattern(img);
			}
		}
	}
}
