package com.tm.motif.tool;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.tm.commons.action.DrawingToolEnum;
import com.tm.commons.components.button.ButtonDrawingTool;
import com.tm.commons.components.pane.SimpleImagePane;
import com.tm.commons.listener.ColorChangeListener;
import com.tm.commons.theme.DigiTmTheme;
import com.tm.commons.tool.ColorPane;
import com.tm.commons.tool.DropdownColorChooser;
import com.tm.commons.tool.FilledPatternOptions;
import com.tm.motif.action.handler.PatternSelectHandler;
import com.tm.motif.action.handler.PenSelectHandler;
import com.tm.motif.pane.CircleOptions;
import com.tm.motif.win.MotifCreatorWin;

public class ToolBarDrawingHoriz extends DrawingTool {
	private static final long serialVersionUID = -1418944053221622423L;

	DropdownColorChooser colorChooserLine;

	public ToolBarDrawingHoriz(MotifCreatorWin parent, DropdownColorChooser colorChooserLine) {
		super();
		this.parent = parent;
		this.colorChooserLine = colorChooserLine;
		this.setPreferredSize(new Dimension(1400, 25));
		this.setBackground(DigiTmTheme.getBgColor());
		constructToolBar();
		this.setBorder(BorderFactory.createLineBorder(Color.WHITE));
	}

	void constructToolBar() {
		this.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
		addCurrentPatternPane();
		addCirclePatternPane();
		this.add(this.colorChooserLine);
		addDrawingButtons();
		addFillPattern();
		addPasteOptions();
	}

	void addColorToolsLine(ColorChangeListener listener) {
		colorChooser = new DropdownColorChooser(listener);
		colorChooser.addColorPane(new ColorPane());
		this.add(colorChooser);
	}

	void addPasteOptions() {
		pasteOptionsHandler = new PatternSelectHandler(parent, this);
		JPanel panel = new JPanel();
		// panel.setBorder(DigiTmTheme.getLineBorder());
		panel.setBorder(BorderFactory.createLineBorder(Color.WHITE));
		panel.setLayout(new FlowLayout(FlowLayout.LEADING, 1, 1));
		panel.setPreferredSize(new Dimension(92, 25)); // 38
		panel.setOpaque(false);

		ButtonDrawingTool btn = new ButtonDrawingTool(DrawingToolEnum.PASTE_CP.value, pasteOptionsHandler,
				"/img/paste-cp.jpg", "Paste Copy", false);
		panel.add(btn);
		btn = new ButtonDrawingTool(DrawingToolEnum.PASTE_XOR.value, pasteOptionsHandler, "/img/paste-xor.jpg",
				"Paste Transparent", false);
		panel.add(btn);
		this.add(panel);
		pasteOptionsHandler.setTool(DrawingToolEnum.PASTE_XOR, btn);
	}

	void addFillPattern() {
		patternSelectHandler = new PatternSelectHandler(parent, this);
		JPanel panel = new JPanel();
		// panel.setBorder(DigiTmTheme.getLineBorder());
		panel.setBorder(BorderFactory.createLineBorder(Color.WHITE));
		panel.setLayout(new FlowLayout(FlowLayout.LEADING, 1, 1));
		panel.setPreferredSize(new Dimension(114, 25)); // 38
		panel.setOpaque(false);
		ButtonDrawingTool btn = new ButtonDrawingTool(DrawingToolEnum.FILL_EMPTY.value, patternSelectHandler,
				"/img/nofill.jpg", "No Fill", false);
		panel.add(btn);
		panel.add(new ButtonDrawingTool(DrawingToolEnum.FILL_SOLID.value, patternSelectHandler, "/img/solidfill.jpg",
				"Solid Fill", false));

		JPanel pnl = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
		btnFillPattern = new ButtonDrawingTool(DrawingToolEnum.FILL_PATTERN.value, patternSelectHandler,
				"/img/fillpattern.jpg", "Pattern Fill", false);
		btnFillPattern.setPreferredSize(new Dimension(20, 24));
		pnl.add(btnFillPattern);
		filledPatternOptions = new FilledPatternOptions(patternSelectHandler);
		pnl.add(filledPatternOptions);
		panel.add(pnl);
		this.add(panel);
		patternSelectHandler.setTool(DrawingToolEnum.FILL_EMPTY, btn);

		colorChooser = new DropdownColorChooser(this, false);
		colorChooser.setToolTipText("Select Fill color");
		colorChooser.addColorPane(new ColorPane());
		this.add(colorChooser);

	}

	void addDrawingButtons() {
		drawingAction = new PenSelectHandler(this.parent);
		this.parent.setPenSelectHandler(drawingAction);

		// JToolBar panel = new JToolBar();
		JPanel panel = new JPanel();
		panel.setBorder(BorderFactory.createEmptyBorder());
		panel.setLayout(new FlowLayout(FlowLayout.LEADING, 1, 1));
		// panel.setPreferredSize(new Dimension(800, 38)); // 38
		panel.setOpaque(false);
		this.btnMouse = new ButtonDrawingTool(DrawingToolEnum.MOUSE.value, drawingAction, "/img/mouse.jpg",
				"Mouse Pointer / No drawing tool", false);
		panel.add(btnMouse);
		panel.add(new ButtonDrawingTool(DrawingToolEnum.MOVE.value, drawingAction, "/img/move.jpg", "Move Pan", false));
		panel.add(
				new ButtonDrawingTool(DrawingToolEnum.SELECT.value, drawingAction, "/img/select.jpg", "Select", false));
		panel.add(new ButtonDrawingTool(DrawingToolEnum.SELECT_RAND.value, drawingAction, "/img/select-rand.jpg",
				"Free-form Select", false));
		panel.add(new ButtonDrawingTool(DrawingToolEnum.COLOR_SELECT.value, drawingAction, "/img/color-select.jpg",
				"Select Color", false));
		addSetBorder(panel);

		// Add brush start
		SpinnerNumberModel m = new SpinnerNumberModel(1, 1, 10, 1);
		this.spinner = new JSpinner(m);
		this.spinner.setBackground(DigiTmTheme.getBgColor());
		this.spinner.setPreferredSize(new Dimension(35, 20));
		panel.add(spinner);
		this.spinner.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				setBrush();
			}
		});
		this.add(panel);
		// Add brush end

		// panel.add(new ButtonDrawingTool(DrawingToolEnum.PICK.value,
		// drawingAction, "/img/pick_color.jpg", "Pick Color", false));
		addPickColor(panel);
		panel.add(new ButtonDrawingTool(DrawingToolEnum.PEN.value, drawingAction, "/img/pen.jpg", "Pen", false));

		addLineButton(panel);

		ButtonDrawingTool btn = new ButtonDrawingTool(DrawingToolEnum.CIRCLE.value, drawingAction, "/img/circle.jpg",
				"Circle", false);
		btn.setPreferredSize(new Dimension(28, 20));
		JPanel pnlOption = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
		pnlOption.add(btn);
		circleOptions = new CircleOptions(btn, this.parent.getPenHolder(), this, (PenSelectHandler) drawingAction);
		pnlOption.add(circleOptions);
		panel.add(pnlOption);

		panel.add(
				new ButtonDrawingTool(DrawingToolEnum.BEZ.value, drawingAction, "/img/bez.jpg", "Bazier Curve", false));
		panel.add(
				new ButtonDrawingTool(DrawingToolEnum.RECT.value, drawingAction, "/img/rect.jpg", "Rectangle", false));

		panel.add(new ButtonDrawingTool(DrawingToolEnum.FILL.value, drawingAction, "/img/fill.jpg", "Fill Region",
				false));

		panel.add(new ButtonDrawingTool(DrawingToolEnum.REPLACE_COLOR.value, drawingAction, "/img/replcolor.jpg",
				"Replace Color - Click on drawing to replace the color with selected color", false));
		panel.add(new ButtonDrawingTool(DrawingToolEnum.CLEAR.value, drawingAction, "/img/clear.jpg", "Clear", false));

		panel.add(new ButtonDrawingTool(DrawingToolEnum.SCALE_H.value, drawingAction, "/img/scaleh.jpg",
				"Horizontal Scale", false));
		panel.add(new ButtonDrawingTool(DrawingToolEnum.SCALE_V.value, drawingAction, "/img/scalev.jpg",
				"Vertical Scale", false));
		add(panel);
	}

	SimpleImagePane addCirclePatternPane() {
		selectedCirclePatternPane = new SimpleImagePane();
		selectedCirclePatternPane.setPreferredSize(new Dimension(25, 25));
		selectedCirclePatternPane.setSize(25, 25);
		selectedCirclePatternPane.setOpaque(false);
		selectedCirclePatternPane.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
		this.add(selectedCirclePatternPane);
		return selectedCirclePatternPane;
	}

	SimpleImagePane addCurrentPatternPane() {
		selectedFillPatternPane = new SimpleImagePane();
		selectedFillPatternPane.setPreferredSize(new Dimension(25, 25));
		selectedFillPatternPane.setSize(25, 25);
		selectedFillPatternPane.setOpaque(false);
		selectedFillPatternPane.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
		this.add(selectedFillPatternPane);
		return selectedFillPatternPane;
	}

}
