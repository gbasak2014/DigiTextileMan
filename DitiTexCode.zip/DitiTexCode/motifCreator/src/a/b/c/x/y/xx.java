package a.b.c.x.y;

import com.tm.commons.secure.TmSecure;
import com.tm.motif.win.MotifCreatorWin;

public class xx {

	public static void main(String[] args) {
		String user = TmSecure.validateKey();
		new MotifCreatorWin(user);
	}

}
