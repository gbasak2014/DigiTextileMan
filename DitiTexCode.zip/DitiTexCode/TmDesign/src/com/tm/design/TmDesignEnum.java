package com.tm.design;

public enum TmDesignEnum {

	FILE(0), OPEN(1), SAVE(2), SAVE_AS_IMAGE(3), EXIT(4), SAVE_AS(5), NEW(6), CREATE_GROUP(7), ADD_BLOCK(8), EDIT_GRP(9), SHOW_PROP(
			10), EDIT_BLOCK(11), ADD_BORDER(12), ROTATE(13), FLIP_VERT(14), FLIP_HORZ(15), MIRROR_VERT(16), MIRROR_HORZ(
			17), FILL(18), REPLACE_COLOR(19), OK(20), CANCEL(21), BORDER(22), MOTIF(23), ZOOM_IN(24), ZOOM_OUT(25), SELECT_COLOR(
			26), UNDO(27), REDO(28), UPDATE_PROP(29), REMOVE_MOTIF(30), LOCK_MOTIF(31), MOVE_UP(32), MOVE_DOWN(33), RESIZE(
			34), UNLOCK_MOTIF(35), CUT(36), COPY(37), PASTE(38), COPY_GROUP(39), REMOVE_GROUP(40), COMPILE_DESIGN(41), FLIP_VERT_MOTIF(
			42), FLIP_HORZ_MOTIF(43), PREVIEW_DESIGN(44), PREVIEW_MODE(45), HIDE_PROP(46), MOVE(47), PICK_COLOR(48), RESIZE_DESIGN(
			49), BACK_COLOR(50), ABOUT(51), DESIGN_BACKGROUND(52), UP(53), SELECT(54), COLOR_SELECT(55), COLOR_CURRENT(
			56), ARRANGE_RIGHT(57), ARRANGE_DOWN(58), OPTIONS(59), ADD_BLOCK_FROM_LIB(60), SHOW_BROWSER(61);

	public int value;

	private TmDesignEnum(int value) {
		this.value = value;
	}

	public int getValue() {
		return value;
	}

	@Override
	public String toString() {
		return super.toString();
	}

	public static TmDesignEnum fromString(String val) {
		return fromInt(Integer.parseInt(val));
	}

	public static TmDesignEnum fromInt(int val) {
		switch (val) {
		case 0:
			return FILE;
		case 1:
			return OPEN;
		case 2:
			return SAVE;
		case 3:
			return SAVE_AS_IMAGE;
		case 4:
			return EXIT;
		case 5:
			return SAVE_AS;
		case 6:
			return NEW;
		case 7:
			return CREATE_GROUP;
		case 8:
			return ADD_BLOCK;
		case 9:
			return EDIT_GRP;
		case 10:
			return SHOW_PROP;
		case 11:
			return EDIT_BLOCK;
		case 12:
			return ADD_BORDER;
		case 13:
			return ROTATE;
		case 14:
			return FLIP_VERT;
		case 15:
			return FLIP_HORZ;
		case 16:
			return MIRROR_VERT;
		case 17:
			return MIRROR_HORZ;
		case 18:
			return FILL;
		case 19:
			return REPLACE_COLOR;
		case 20:
			return OK;
		case 21:
			return CANCEL;
		case 22:
			return BORDER;
		case 23:
			return MOTIF;
		case 24:
			return ZOOM_IN;
		case 25:
			return ZOOM_OUT;
		case 26:
			return SELECT_COLOR;
		case 27:
			return UNDO;
		case 28:
			return REDO;
		case 29:
			return UPDATE_PROP;
		case 30:
			return REMOVE_MOTIF;
		case 31:
			return LOCK_MOTIF;
		case 32:
			return MOVE_UP;
		case 33:
			return MOVE_DOWN;
		case 34:
			return RESIZE;
		case 35:
			return UNLOCK_MOTIF;
		case 36:
			return CUT;
		case 37:
			return COPY;
		case 38:
			return PASTE;
		case 39:
			return COPY_GROUP;
		case 40:
			return REMOVE_GROUP;
		case 41:
			return COMPILE_DESIGN;
		case 42:
			return FLIP_VERT_MOTIF;
		case 43:
			return FLIP_HORZ_MOTIF;
		case 44:
			return PREVIEW_DESIGN;
		case 45:
			return PREVIEW_MODE;
		case 46:
			return HIDE_PROP;
		case 47:
			return MOVE;
		case 48:
			return PICK_COLOR;
		case 49:
			return RESIZE_DESIGN;
		case 50:
			return BACK_COLOR;
		case 51:
			return ABOUT;
		case 52:
			return DESIGN_BACKGROUND;
		case 53:
			return UP;
		case 54:
			return SELECT;
		case 55:
			return COLOR_CURRENT;
		case 56:
			return COLOR_CURRENT;
		case 57:
			return ARRANGE_RIGHT;
		case 58:
			return ARRANGE_DOWN;
		case 59:
			return OPTIONS;
		case 60:
			return ADD_BLOCK_FROM_LIB;
		case 61:
			return SHOW_BROWSER;
		default:
			return FILE;
		}
	}
}
