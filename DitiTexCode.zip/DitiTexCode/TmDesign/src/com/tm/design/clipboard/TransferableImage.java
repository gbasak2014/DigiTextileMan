package com.tm.design.clipboard;

import java.awt.Image;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;

/**
 * The class is used to transfer image from and to system clipboard for
 * Transferring image between different application.
 * 
 * @author Gouranga Basak
 * 
 */
public class TransferableImage implements Transferable
{
	private Image image;

	/**
	 * Create transferable object with specified image.
	 * 
	 * @param image
	 */
	public TransferableImage(Image image)
	{
		this.image = image;
	}

	/**
	 * Get transfered data from clipboard.
	 */
	@Override
	public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException
	{
		if (isDataFlavorSupported(flavor))
		{
			return image;
		} else
		{
			throw new UnsupportedFlavorException(flavor);
		}

	}

	/**
	 * Get supported data flavors.
	 */
	@Override
	public DataFlavor[] getTransferDataFlavors()
	{
		return new DataFlavor[] { DataFlavor.imageFlavor };
	}

	/**
	 * Verify if data flavor is image.
	 */
	@Override
	public boolean isDataFlavorSupported(DataFlavor flavor)
	{
		return flavor == DataFlavor.imageFlavor;
	}
}
