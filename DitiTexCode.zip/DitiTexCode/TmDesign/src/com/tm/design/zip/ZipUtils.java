package com.tm.design.zip;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class ZipUtils
{
	static void createFiles(String path) throws Exception
	{
		PrintWriter pw = new PrintWriter(path + "/file1.txt");
		pw.println("file1.txt -- I am in line 1");
		pw.println("file1.txt -- I am in line 2");
		pw.println("file1.txt -- I am in line 3");
		pw.println("file1.txt -- I am in line 4");
		pw.close();

		pw = new PrintWriter(path + "/file2.txt");
		pw.println("file2.txt -- I am in line 1");
		pw.println("file2.txt -- I am in line 2");
		pw.println("file2.txt -- I am in line 3");
		pw.println("file2.txt -- I am in line 4");
		pw.close();
	}

	public static void createZip(String srcDir, File zipFile) throws Exception
	{
		FileOutputStream fout = new FileOutputStream(zipFile);
		ZipOutputStream zout = new ZipOutputStream(fout);

		byte[] buff = new byte[1024];
		int len;

		File dir = new File(srcDir);
		for (File file : dir.listFiles())
		{
			FileInputStream fin = new FileInputStream(file);
			zout.putNextEntry(new ZipEntry(file.getName()));
			while ((len = fin.read(buff)) > 0)
			{
				zout.write(buff, 0, len);
			}
			zout.closeEntry();
			fin.close();
		}
		zout.close();
		fout.close();
	}

	static void readZip(String path) throws Exception
	{
		ZipInputStream zin = new ZipInputStream(new FileInputStream(path));
		ZipEntry zipEntry;
		byte[] buff = new byte[128];
		while ((zipEntry = zin.getNextEntry()) != null)
		{
			System.out.println(zipEntry.getName());
			int len = 0;
			while ((len = zin.read(buff)) > 0)
			{
				System.out.println(new String(buff, 0, len));
			}
			System.out.println("");
		}
	}

	public static void unZip(File src, String target) throws Exception
	{
		ZipInputStream zin = new ZipInputStream(new FileInputStream(src));
		ZipEntry zipEntry;
		byte[] buff = new byte[128];
		while ((zipEntry = zin.getNextEntry()) != null)
		{
			String name = zipEntry.getName();
			FileOutputStream fout = new FileOutputStream(target + File.separator + name);
			int len = 0;
			while ((len = zin.read(buff)) > 0)
			{
				fout.write(buff, 0, len);
			}
			fout.close();
		}

		zin.close();
	}

	public static void main(String[] args) throws Exception
	{
		System.out.println("Started.....");
		// createFiles("I:/Design/zip");
		// System.out.println("Creating Zip");

		// createZip("I:/Design/zip/files.zip", "I:/Design/zip");

		// readZip("I:/Design/zip/files.zip");

		System.out.println(System.getProperty("user.home"));
		String dst = System.getProperty("user.home") + File.separator + "tm" + File.separator + System.currentTimeMillis();
		File file = new File(dst);
		if (!file.exists())
		{
			file.mkdirs();
		}
		unZip(new File("I:/Design/zip/files.zip"), dst);
		System.out.println("Done....");
	}
}
