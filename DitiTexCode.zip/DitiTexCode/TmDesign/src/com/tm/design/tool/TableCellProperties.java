package com.tm.design.tool;

public class TableCellProperties
{
	String property;
	String tooltip;
	boolean editable;

	public TableCellProperties(String property, String tooltip, boolean editable)
	{
		this.property = property;
		this.tooltip = tooltip;
		this.editable = editable;
	}

	public String getProperty()
	{
		return property;
	}

	public String getTooltip()
	{
		return tooltip;
	}

	public boolean isEditable()
	{
		return editable;
	}

	public void setProperty(String property)
	{
		this.property = property;
	}

	public void setTooltip(String tooltip)
	{
		this.tooltip = tooltip;
	}

	public void setEditable(boolean editable)
	{
		this.editable = editable;
	}
}
