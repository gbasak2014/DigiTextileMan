package com.tm.design.tool;

import java.awt.Component;
import java.util.EventObject;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.event.CellEditorListener;
import javax.swing.table.TableCellEditor;

public class ComboBoxTableCellEditor extends JComboBox<String> implements TableCellEditor
{

	//DefaultComboBoxModel model;
	public ComboBoxTableCellEditor(List values)
	{
		super();
		for (Object item : values)
		{
			this.addItem((String)item);
		}
		
	}
	
	@Override
	public void addCellEditorListener(CellEditorListener arg0)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void cancelCellEditing()
	{
		// TODO Auto-generated method stub

	}

	@Override
	public Object getCellEditorValue()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean isCellEditable(EventObject arg0)
	{
		return true;
	}

	@Override
	public void removeCellEditorListener(CellEditorListener arg0)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public boolean shouldSelectCell(EventObject arg0)
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean stopCellEditing()
	{
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Component getTableCellEditorComponent(JTable arg0, Object arg1, boolean arg2, int arg3, int arg4)
	{
		// TODO Auto-generated method stub
		return this;
	}

}
