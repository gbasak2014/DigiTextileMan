package com.tm.design.tool;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.Vector;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

import com.tm.design.motif.Motif;
import com.tm.design.pane.MotifPane;

public class DesignPropertyTool extends JPanel {
	PropertiesTable table;

	// JButton btn;

	public DesignPropertyTool() {
		this.setLayout(new BorderLayout());
		DefaultTableModel model = new DefaultTableModel();

		this.table = new PropertiesTable(model);

		model.addColumn("Properties");
		model.addColumn("Value");

		JScrollPane scrollPane = new JScrollPane(table, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setPreferredSize(new Dimension(200, 500));
		this.add(scrollPane, BorderLayout.CENTER);

		for (int i = 0; i < 30; i++) {
			Vector v = new Vector();
			model.addRow(v);
		}

		this.setVisible(true);

	}

	public void addTableModelListener(TableModelListener listener) {
		this.table.getModel().addTableModelListener(listener);
	}

	public void setProperties(MotifPane motifPane) {
		if (motifPane == null) {
			return;
		}

		this.setRow("Group Properties", null, 0);
		this.setRow("Horizontal Align", motifPane.isHorizontalAlign(), 1);
		// this.setRow("Repeate", motifPane.isRepeate(), 2);
		this.setRow("Left", motifPane.getLeft(), 2);
		this.setRow("Top", motifPane.getTop(), 3);

		this.setRow("Width", motifPane.getSize().width, 4);
		this.setRow("Height", motifPane.getSize().height, 5);

		this.setRow("Horizontal Repeate", motifPane.getHorizontalRepeate(), 6);
		this.setRow("Vertican Repeate", motifPane.getVerticalRepeate(), 7);

		Motif motif = motifPane.getSelectedMotif();
		this.setRow("Motif Properties", null, 8);
		if (motif != null && motif.getImage() != null) {
			this.setRow("Left space", motif.getLeftSpace(), 9);
			this.setRow("Right space", motif.getRightSpace(), 10);
			this.setRow("Top space", motif.getTopSpace(), 11);
			this.setRow("Bottom space", motif.getBottomSpace(), 12);
			this.setRow("Repeate", motif.isRepeate(), 13);

			this.setRow("Width", motif.getWidth(), 14);
			this.setRow("Height", motif.getHeight(), 15);
		}

	}

	void removeRows() {
		DefaultTableModel model = (DefaultTableModel) this.table.getModel();
		for (int i = 0; i < model.getRowCount(); i++) {
			model.setValueAt("", i, 0);
			model.setValueAt("", i, 1);
		}
	}

	void setRow(String col, Object val, int row) {
		((DefaultTableModel) this.table.getModel()).setValueAt(col, row, 0);
		((DefaultTableModel) this.table.getModel()).setValueAt(val, row, 1);
	}

	public JTable getTable() {
		return table;
	}
}
