package com.tm.design.tool;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.BorderFactory;
import javax.swing.JSeparator;
import javax.swing.JToolBar;

import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.theme.DigiTmTheme;
import com.tm.design.TmDesignEnum;
import com.tm.design.dlg.MotifEditDlg;

public class EditMotifToolBar extends JToolBar
{
	//JButton btnColor;
	//JButton btnCurColor;
	//JButton bgColor;

	private static final long serialVersionUID = 2776824318215624138L;
	ToolColor toolColor;
	
	public EditMotifToolBar(MotifEditDlg parent, Color designBackgroung, ToolColor toolColor)
	{
		this.setBackground(DigiTmTheme.getBgColor());
		this.toolColor = toolColor;
		this.setLayout(new FlowLayout(FlowLayout.LEFT, 1, 1));
		this.setBorder(BorderFactory.createLineBorder(Color.WHITE));

		this.add(new ButtonMenuItem(TmDesignEnum.ROTATE.value, parent, "/img/rotate.jpg", "Rotate"));
		this.add(new ButtonMenuItem(TmDesignEnum.FLIP_VERT.value, parent, "/img/flip-v.jpg", "Flip Vertical"));
		this.add(new ButtonMenuItem(TmDesignEnum.FLIP_HORZ.value, parent, "/img/flip-h.jpg", "Flip Vertical"));
		this.add(new ButtonMenuItem(TmDesignEnum.MIRROR_VERT.value, parent, "/img/mirror-v.jpg", "Flip Vertical"));
		this.add(new ButtonMenuItem(TmDesignEnum.MIRROR_HORZ.value, parent, "/img/mirror-h.jpg", "Flip Vertical"));

		JSeparator sep = new JSeparator(JSeparator.VERTICAL);
		sep.setPreferredSize(new Dimension(2, 16));
		this.add(sep);
		this.add(new ButtonMenuItem(TmDesignEnum.ARRANGE_RIGHT.value, parent, "/img/arrangeright.jpg", "Arrange to right"));
		this.add(new ButtonMenuItem(TmDesignEnum.ARRANGE_DOWN.value, parent, "/img/arrangedown.jpg", "Arrange to down"));

		sep = new JSeparator(JSeparator.VERTICAL);
		sep.setPreferredSize(new Dimension(2, 16));
		this.add(sep);
		this.add(new ButtonMenuItem(TmDesignEnum.PICK_COLOR.value, parent, "/img/pickcolor.jpg", "Pick Color"));
		this.add(new ButtonMenuItem(TmDesignEnum.FILL.value, parent, "/img/fill.jpg", "Fill Color"));
		this.add(new ButtonMenuItem(TmDesignEnum.REPLACE_COLOR.value, parent, "/img/replcolor.jpg", "Replace Color"));

		sep = new JSeparator(JSeparator.VERTICAL);
		sep.setPreferredSize(new Dimension(2, 16));
		this.add(sep);
		this.add(new ButtonMenuItem(TmDesignEnum.ZOOM_IN.value, parent, "/img/z2.jpg", "Zoom in"));
		this.add(new ButtonMenuItem(TmDesignEnum.ZOOM_OUT.value, parent, "/img/z1.jpg", "Zoom out"));

		sep = new JSeparator(JSeparator.VERTICAL);
		sep.setPreferredSize(new Dimension(2, 16));
		this.add(sep);
		this.add(new ButtonMenuItem(TmDesignEnum.MOVE.value, parent, "/img/move-pane.jpg", "Move Image pane"));

		sep = new JSeparator(JSeparator.VERTICAL);
		sep.setPreferredSize(new Dimension(2, 16));
		this.add(sep);
		this.add(new ButtonMenuItem(TmDesignEnum.UNDO.value, parent, "/img/undo.jpg", "Undo"));
		this.add(new ButtonMenuItem(TmDesignEnum.REDO.value, parent, "/img/redo.jpg", "Redo"));

		this.add(this.toolColor);

	}

	public Color getSelectedColor()
	{
		return this.toolColor.getSelectedColor();
	}

	public void selectColor(int rgb)
	{
		this.toolColor.setSelectedColor(new Color(rgb));
	}

	public void setCurrentColor(int rgb)
	{
		this.toolColor.pickColor(new Color(rgb));
	}
}
