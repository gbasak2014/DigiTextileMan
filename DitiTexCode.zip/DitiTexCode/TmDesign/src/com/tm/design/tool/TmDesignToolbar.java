package com.tm.design.tool;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JPanel;

import com.tm.commons.action.FileMenuActionEnum;
import com.tm.commons.components.button.ButtonMenuItem;
import com.tm.commons.theme.DigiTmTheme;
import com.tm.design.TmDesignEnum;
import com.tm.design.action.ColorChangeListener;
import com.tm.design.win.TmDesignWin;

public class TmDesignToolbar extends JPanel implements ColorChangeListener {
	private static final long serialVersionUID = -210935007103043467L;
	ToolColor toolColor;
	TmDesignWin parent;

	public TmDesignToolbar(TmDesignWin parent, ToolColor toolColor) {
		this.parent = parent;
		this.toolColor = toolColor;
		this.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
		this.setBackground(DigiTmTheme.getBgColor());
		this.setBorder(DigiTmTheme.getLineBorder());
		addFileMenuItem(parent);
		this.add(new JLabel("    "));
		addEditMenuItem(parent);
		this.add(new JLabel("    "));
		addSettingMenuItem(parent);
	}

	void addFileMenuItem(ActionListener action) {
		this.add(new ButtonMenuItem(TmDesignEnum.NEW.value, action, "/img/new.jpg", "New Design"));
		this.add(new ButtonMenuItem(TmDesignEnum.OPEN.value, action, "/img/open.jpg", "Open Design"));
		this.add(new ButtonMenuItem(TmDesignEnum.ADD_BLOCK.value, action, "/img/add-motif.jpg", "Add Motif"));
		this.add(new ButtonMenuItem(TmDesignEnum.ADD_BLOCK_FROM_LIB.value, action, "/img/get-motif-lib.jpg",
				"Get motif from library"));
		this.add(new ButtonMenuItem(TmDesignEnum.ADD_BORDER.value, action, "/img/add-border.jpg", "Add Border"));
		this.add(new ButtonMenuItem(TmDesignEnum.SAVE.value, action, "/img/save.jpg", "Save Design"));
	}

	void addEditMenuItem(ActionListener action) {
		this.add(new ButtonMenuItem(TmDesignEnum.RESIZE_DESIGN.value, action, "/img/resize.jpg", "Resize Design"));
		this.add(new JLabel("    "));
		this.add(this.toolColor);
		this.add(new JLabel("    "));
		this.add(new ButtonMenuItem(TmDesignEnum.CUT.value, action, "/img/cut.jpg", "Cut Motif/Border"));
		this.add(new ButtonMenuItem(TmDesignEnum.COPY.value, action, "/img/copy.jpg", "Copy Motif/Border"));
		this.add(new ButtonMenuItem(TmDesignEnum.PASTE.value, action, "/img/paste.jpg", "Paste Motif/Border"));
		this.add(new ButtonMenuItem(TmDesignEnum.REMOVE_MOTIF.value, action, "/img/rm-motif.jpg", "Remove Motif/Border"));
		this.add(new ButtonMenuItem(TmDesignEnum.EDIT_GRP.value, action, "/img/edit-motif.jpg", "Edit Motif/Border"));
		this.add(new JLabel("    "));
		this.add(new ButtonMenuItem(TmDesignEnum.MOVE_UP.value, action, "/img/mv-up.jpg", "Move Motif Up / Left"));
		this.add(new ButtonMenuItem(TmDesignEnum.MOVE_DOWN.value, action, "/img/mv-down.jpg", "Move Motif Down / Right"));
		this.add(new ButtonMenuItem(TmDesignEnum.FLIP_VERT_MOTIF.value, action, "/img/fv-motif.jpg",
				"Flip Vertical Motif"));
		this.add(new ButtonMenuItem(TmDesignEnum.FLIP_HORZ_MOTIF.value, action, "/img/fh-motif.jpg",
				"Flip Horizontal Motif"));
		this.add(new JLabel("    "));
		this.add(new ButtonMenuItem(TmDesignEnum.COPY_GROUP.value, action, "/img/copy-group.jpg",
				"create Copy of Group"));
		this.add(new ButtonMenuItem(TmDesignEnum.FLIP_VERT.value, action, "/img/fv-group.jpg",
				"Flip Vertical Motif Group"));
		this.add(new ButtonMenuItem(TmDesignEnum.FLIP_HORZ.value, action, "/img/fh-group.jpg",
				"Flip Horizontal Motif Group"));
		this.add(new ButtonMenuItem(TmDesignEnum.REMOVE_GROUP.value, action, "/img/rm-group.jpg", "Remove Motif Group"));
	}

	void addSettingMenuItem(ActionListener action) {
		this.add(new ButtonMenuItem(TmDesignEnum.OPTIONS.value, action, "/img/options.jpg", "New Design"));
	}

	@Override
	public void colorChanged(Color color) {
		this.parent.setBackgroungColor(color);
	}
}
