package com.tm.design.tool;

import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.JTable;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;

import com.tm.commons.theme.DigiTmTheme;

public class PropertiesTable extends JTable
{
	TableCellProperties[] cellProperties;;

	public PropertiesTable(TableModel model)
	{
		super(model);
		this.setBackground(DigiTmTheme.getBgColor());
		this.cellProperties = this.getTableCellProperties();
		this.getTableHeader().setBackground(DigiTmTheme.getBgColor());
	}

	@Override
	public boolean isCellEditable(int row, int col)
	{
		if (col == 0)
		{
			return false;
		}

		if (row < this.cellProperties.length && this.cellProperties[row] != null)
		{
			return this.cellProperties[row].isEditable();
		}

		return false;
	}

	@Override
	public TableCellEditor getCellEditor(int row, int column)
	{

		Object val = this.getValueAt(row, column);

		if (val instanceof List)
		{
			return new ComboBoxTableCellEditor((List) val);
		}

		if (val instanceof Boolean)
		{
			return this.getDefaultEditor(Boolean.class);
		}

		return super.getCellEditor(row, column);
	}

	@Override
	public TableCellRenderer getCellRenderer(int row, int column)
	{
		Object val = this.getValueAt(row, column);
		if (val instanceof List)
		{
			return new ComboboxTableCellRenderer();
		}

		if (val instanceof Boolean)
		{
			return this.getDefaultRenderer(Boolean.class);
		}
		return super.getCellRenderer(row, column);
	}

	@Override
	public String getToolTipText(MouseEvent event)
	{
		try
		{
			int row = this.rowAtPoint(event.getPoint());
			System.out.println(row + " <<<<<< " + this.cellProperties.length);
			if (row < this.cellProperties.length && this.cellProperties[row] != null)
			{
				return this.cellProperties[row].getTooltip();
			}

			return null;
		} catch (Exception e)
		{
			e.printStackTrace();
		}

		return null;
	}

	public TableCellProperties[] getTableCellProperties()
	{
		TableCellProperties[] cellProperties = new TableCellProperties[17];
		cellProperties[0] = new TableCellProperties("Group Properties", "Group Properties", false);
		cellProperties[1] = new TableCellProperties("Horizontal Align", "Align Motif in group", true);
		//cellProperties[2] = new TableCellProperties("Repeat", "Is group repeatable", true);
		cellProperties[2] = new TableCellProperties("Left", "Group Left", true);
		cellProperties[3] = new TableCellProperties("Top", "Group Top", true);
		cellProperties[4] = new TableCellProperties("Group Width", "Group Width", false);
		cellProperties[5] = new TableCellProperties("Group Height", "Group Height", false);

		cellProperties[6] = new TableCellProperties("Horizontal Repeat", "Horizontal Repeat, value less than 1 will repeat till end", true);
		cellProperties[7] = new TableCellProperties("Vertical Repeat", "Vertical Repeat, value less than 1 will repeat till end", true);
		cellProperties[8] = new TableCellProperties("Motif Properties", "Motif Properties", false);
		cellProperties[9] = new TableCellProperties("Left space", "Left space of motif", true);
		cellProperties[10] = new TableCellProperties("Right space", "Right space of motif", true);
		cellProperties[11] = new TableCellProperties("Top space", "Top space of motif", true);
		cellProperties[12] = new TableCellProperties("Bottom space", "Bottom space of motif", true);
		cellProperties[13] = new TableCellProperties("Repeat", "Is motif Repeatable within group", true);
		cellProperties[14] = new TableCellProperties("Width", "Motif within", false);
		cellProperties[15] = new TableCellProperties("Height", "Motif height", false);

		return cellProperties;
	}
}
