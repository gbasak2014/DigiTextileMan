package com.tm.design.pane;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

import com.tm.design.clipboard.TransferableImage;
import com.tm.design.menu.TmPopupMenu;
import com.tm.design.motif.Motif;
import com.tm.design.win.TmDesignWin;

public class DesignPane extends JPanel implements MouseMotionListener, MouseListener {
	private static final long serialVersionUID = -2053810380282971077L;
	int px;
	int py;

	MotifPane selectedPane;
	int selectedIndex;

	List<MotifPane> list = new ArrayList<MotifPane>();

	TmDesignWin tmDesignWin;

	TmPopupMenu popup;
	TmDesignWin parent;

	boolean preview = true;

	Color backMotifColor;
	int backMotifWidth;
	int backMotifHeight;

	public DesignPane(TmDesignWin parent) {
		this.parent = parent;
		this.tmDesignWin = parent;
		this.popup = new TmPopupMenu(parent);
		this.addMouseListener(this);
		this.setBackground(Color.WHITE);
		this.setBorder(BorderFactory.createLineBorder(Color.BLACK));

		Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
		this.setSize(size);
		this.setPreferredSize(size);

		this.addMouseListener(this);
		this.addMouseMotionListener(this);
	}

	public void addMotif(BufferedImage motif) {
		if (this.selectedPane == null) {
			createMotifPane(motif);
		} else {
			this.selectedPane.addMotif(motif);
		}

		this.repaint();
	}

	public void addMotif(int width) {
		if (this.selectedPane == null) {
			createMotifPane(width);
		} else {
			this.selectedPane.addMotif(width);
		}

		this.repaint();
	}

	public void addMotif(int width, int height, Color color) {
		if (this.selectedPane == null) {
			createMotifPane(width, height, color);
		} else {
			this.selectedPane.addMotif(width, height, color);
		}
		this.repaint();
	}

	public MotifPane getSelectedMotifPane() {
		return this.selectedPane;
	}

	public int getSelectedMotifPaneIndex() {
		return this.selectedIndex;
	}

	public void createMotifPane(BufferedImage motif) {
		MotifPane pane = new MotifPane(motif, false);
		list.add(pane);
		this.selectedPane = pane;
		this.selectedIndex = list.size() - 1;
	}

	public void createMotifPane(int width) {
		MotifPane pane = new MotifPane(width, false);
		list.add(pane);
		this.selectedPane = pane;
		this.selectedIndex = list.size() - 1;
	}

	public void createMotifPane(int width, int height, Color color) {
		MotifPane pane = new MotifPane(width, height, color, false);
		list.add(pane);
		this.selectedPane = pane;
	}

	public void createGroupCopy(MotifPane pane) {
		if (pane != null) {
			MotifPane newGroup = pane.createClone();
			list.add(newGroup);
			this.selectedPane = newGroup;
			this.selectedIndex = list.size() - 1;
			this.repaint();
		}
	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		g.setColor(this.getBackground());
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		for (MotifPane motifPane : list) {
			motifPane.paint(g);
			if (this.preview) {
				paintMotifPane(g, motifPane);
			}
			//motifPane.paintBorder(g);
		}

		if (this.selectedPane != null && this.selectedPane.getSelectedMotif() != null) {
			this.selectedPane.getSelectedMotif().select(g);
		}
	}

	public void setPreviw(boolean mode) {
		this.preview = mode;
		this.repaint();
	}

	private void paintMotifPane(Graphics g, MotifPane motifPane) {
		if (motifPane.getHorizontalRepeate() != 1 || motifPane.getVerticalRepeate() != 1) {
			BufferedImage bi = new BufferedImage(motifPane.getSize().width, motifPane.getSize().height,
					BufferedImage.TYPE_INT_ARGB);
			Graphics2D g2 = bi.createGraphics();
			g2.setColor(new Color(0.1f, 0.1f, 0.1f, 0.0f));
			g2.fillRect(0, 0, bi.getWidth(), bi.getHeight());
			motifPane.paint(g2, this.getBackground());
			g2.dispose();
			
			int hCount = 1;
			for (int x = motifPane.getLeft() + bi.getWidth(); x < this.getWidth() + bi.getWidth(); x = x
					+ bi.getWidth()) {
				int vCount = 1;

				for (int y = motifPane.getTop() + bi.getHeight(); y < this.getHeight(); y = y + bi.getHeight()) {
					vCount++;
					if (motifPane.getVerticalRepeate() > 0 && vCount > motifPane.getVerticalRepeate()) {
						break;
					}
					g.drawImage(bi, x - bi.getWidth(), y, this);
				}

				hCount++;
				if (motifPane.getHorizontalRepeate() > 0 && hCount > motifPane.getHorizontalRepeate()) {
					break;
				}
				g.drawImage(bi, x, motifPane.getTop(), this);
			}
		}
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		if (this.selectedPane != null) {
			int curX = e.getX();
			int curY = e.getY();

			this.selectedPane.setLocation(this.selectedPane.getLeft() - px + curX, this.selectedPane.getTop() - py
					+ curY);

			px = curX;
			py = curY;
		}
		this.repaint();
	}

	@Override
	public void mouseMoved(MouseEvent e) {

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		this.px = e.getX();
		this.py = e.getY();
		if (this.selectedPane != null) {
			this.selectedPane.setSelected(false);
			this.selectedPane = null;
		}

		for (int i = this.list.size() - 1; i >= 0; i--) {
			MotifPane mp = this.list.get(i);
			if (mp.isIntersect(px, py)) {
				this.selectedIndex = i;
				this.selectedPane = mp;
				this.selectedPane.selecteMotif(px, py);
				break;
			}
		}

		if (this.selectedPane != null && this.selectedPane.getSelectedMotif() != null) {
			this.tmDesignWin.getStatusPane().setMotifProperties(
					"Motif L:" + this.selectedPane.getSelectedMotif().getLeft() + ", T:"
							+ this.selectedPane.getSelectedMotif().getTop());
		} else {
			this.tmDesignWin.getStatusPane().setMotifProperties("");
		}

		if (this.selectedPane != null && e.isPopupTrigger()) {
			popup.showPopup(e.getComponent(), e.getX(), e.getY(), this);
		}

		this.repaint();
	}

	public void selectMotif(int groupIndex, int motifIndex) {
		if (list.size() > groupIndex) {
			this.selectedPane = list.get(groupIndex);
			this.selectedPane.selectMotif(motifIndex);
		}
		this.repaint();
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		if (this.selectedPane != null && e.isPopupTrigger()) {
			popup.showPopup(e.getComponent(), e.getX(), e.getY(), this);
		} else {
			this.parent.getPropertiesTool().setProperties(this.selectedPane);
		}
	}

	public void cut() {
		copy();
		if (this.selectedPane != null && this.selectedPane.getSelectedMotif() != null) {
			this.selectedPane.removeSelectedMotif(this.getGraphics());
			if (this.selectedPane.getList().size() <= 0) {
				this.removeSelectedGroup();
			}
			this.repaint();
		}
	}

	public void copy() {
		if (this.selectedPane != null && this.selectedPane.getSelectedMotif() != null) {
			BufferedImage img = this.selectedPane.getSelectedMotif().getImage();
			copyToClipboard(img);
			if (img != null) {
				backMotifColor = null;
			} else {
				backMotifColor = this.selectedPane.getSelectedMotif().getColor();
				backMotifWidth = this.selectedPane.getSelectedMotif().getWidth();
				backMotifHeight = this.selectedPane.getSelectedMotif().getHeight();
			}
		}
	}

	public void removeMotif() {
		if (this.selectedPane != null && this.selectedPane.getSelectedMotif() != null) {
			this.selectedPane.removeSelectedMotif(this.getGraphics());
			this.repaint();
		}
	}

	public boolean paste() {
		Transferable transfer = Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null);

		if (transfer != null && transfer.isDataFlavorSupported(DataFlavor.imageFlavor)) {
			try {
				BufferedImage motif = (BufferedImage) transfer.getTransferData(DataFlavor.imageFlavor);
				this.addMotif(motif);
				return true;
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else if (this.backMotifColor != null) {
			this.addMotif(this.backMotifWidth, this.backMotifHeight, this.backMotifColor);
			return true;
		}

		return false;
	}

	public void removeSelectedGroup() {
		if (this.selectedPane != null) {
			this.list.remove(this.selectedPane);
			this.selectedPane = null;
		}

		this.repaint();
	}

	private void copyToClipboard(BufferedImage img) {
		Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		if (img != null) {
			TransferableImage transfer = new TransferableImage(img);
			clipboard.setContents(transfer, null);
		} else {
			StringSelection ss = new StringSelection("");
			clipboard.setContents(ss, null);
		}
	}

	public List<MotifPane> getMotifPaneList() {
		return this.list;
	}

	public void writeProperties(OutputStream out) throws Exception {
		Properties props = new Properties();
		props.put("design.width", "" + this.getWidth());
		props.put("design.height", "" + this.getHeight());
		props.put("design.bgcolor", "" + this.getBackground().getRGB());

		props.put("design.motif.list.size", "" + this.list.size());
		for (int i = 0; i < this.list.size(); i++) {
			MotifPane motifPane = this.list.get(i);
			props.put("design.motifPane" + i + ".left", "" + motifPane.getLeft());
			props.put("design.motifPane" + i + ".top", "" + motifPane.getTop());
			props.put("design.motifPane" + i + ".width", "" + motifPane.getSize().width);
			props.put("design.motifPane" + i + ".height", "" + motifPane.getSize().height);
			props.put("design.motifPane" + i + ".horizontalAlign", motifPane.isHorizontalAlign() ? "true" : "false");
			props.put("design.motifPane" + i + ".horizontalRepeat", "" + motifPane.getHorizontalRepeate());
			props.put("design.motifPane" + i + ".verticalRepeate", "" + motifPane.getVerticalRepeate());

			props.put("design.motifPane" + i + ".motif.list.zize", "" + motifPane.getList().size());
			List<Motif> motifList = motifPane.getList();
			for (int idx = 0; idx < motifList.size(); idx++) {
				Motif motif = motifList.get(idx);
				String type;
				if (motif.getImage() == null) {
					type = "border";
				} else {
					type = "motif";
				}
				props.put("design.motifPane" + i + ".motif" + idx + ".type", type);

				props.put("design.motifPane" + i + ".motif" + idx + ".left", "" + motif.getLeft());
				props.put("design.motifPane" + i + ".motif" + idx + ".top", "" + motif.getTop());
				props.put("design.motifPane" + i + ".motif" + idx + ".width", "" + motif.getWidth());
				props.put("design.motifPane" + i + ".motif" + idx + ".height", "" + motif.getHeight());
				props.put("design.motifPane" + i + ".motif" + idx + ".leftStace", "" + motif.getLeftSpace());
				props.put("design.motifPane" + i + ".motif" + idx + ".rightStace", "" + motif.getRightSpace());
				props.put("design.motifPane" + i + ".motif" + idx + ".topStace", "" + motif.getTopSpace());
				props.put("design.motifPane" + i + ".motif" + idx + ".bottomStace", "" + motif.getBottomSpace());
				props.put("design.motifPane" + i + ".motif" + idx + ".color", "" + motif.getColor().getRGB());
				props.put("design.motifPane" + i + ".motif" + idx + ".repeat", motif.isRepeate() ? "true" : "false");
			}
		}

		String comments = "# System generated file for Textile Master Design";
		props.store(out, comments);
	}

	public boolean isBorderCopied() {
		return this.backMotifColor != null;
	}
}
