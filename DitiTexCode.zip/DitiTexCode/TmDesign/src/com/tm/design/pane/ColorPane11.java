package com.tm.design.pane;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class ColorPane11
{
	BufferedImage img = new BufferedImage(67, 20, BufferedImage.TYPE_INT_RGB);

	public void createColors()
	{
		int x = 0;
		int y = 0;
		int cnt = 0;
		for (int r = 255; r >= 0; r = r - 50)
		{
			for (int g = 255; g >= 0; g = g - 50)
			{
				for (int b = 255; b >= 0; b = b - 50)
				{
					cnt++;
					if (y >= 20)
					{
						y = 0;
						x++;
						if (x >= 67)
						{
							return;
						}
					}
					img.setRGB(x, y, (new Color(r, g, b)).getRGB());
					y++;
				}
			}
		}

		System.out.println("CNT:" + cnt);
	}

	public static void main(String[] args)
	{
		final ColorPane11 cp = new ColorPane11();
		cp.createColors();

		final JPanel pnl = new JPanel();

		JFrame frame = new JFrame() {
			@Override
			public void paint(Graphics g)
			{
				super.paint(g);
				pnl.getGraphics().drawImage(cp.img, 0, 0, cp.img.getWidth() * 20, cp.img.getHeight() * 20, pnl);
			}
		};

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new BorderLayout());

		pnl.setPreferredSize(new Dimension(cp.img.getWidth() * 20, cp.img.getHeight() * 20));
		frame.getContentPane().add(pnl, BorderLayout.CENTER);
		frame.setPreferredSize(new Dimension(600, 400));
		frame.pack();
		frame.setVisible(true);
	}
}
