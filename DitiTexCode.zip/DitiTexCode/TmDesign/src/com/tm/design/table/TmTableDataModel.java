package com.tm.design.table;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class TmTableDataModel extends JFrame
{

	public TmTableDataModel()
	{
		this.setPreferredSize(new Dimension(300, 400));
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.getContentPane().setLayout(new BorderLayout());

		DefaultTableModel model = new DefaultTableModel();
		model.addColumn("Property");
		model.addColumn("Value");
		
		Vector row = new Vector();
		row.add("Prop1");
		row.add("val1");
		model.addRow(row);

		row = new Vector();
		row.add("Prop2");
		row.add(Boolean.TRUE);
		model.addRow(row);

/*		row = new Vector();
		row.add("Prop3");
		Vector val = new Vector();
		val.add("ABC");
		val.add("XYZ");
		val.add("AAA");
		row.add(val);
		model.addRow(row);
*/
		row = new Vector();
		row.add("Prop4");
		row.add("val4");
		model.addRow(row);

		JTable table = new JTable(model);

		JScrollPane pane = new JScrollPane(table);
		pane.add(table);

		this.getContentPane().add(new JLabel("XXXXXX"), BorderLayout.CENTER);
		this.getContentPane().add(pane, BorderLayout.NORTH);
		this.pack();
		this.setVisible(true);
	}

	public static void main(String[] args)
	{
		new TmTableDataModel();
	}
}
