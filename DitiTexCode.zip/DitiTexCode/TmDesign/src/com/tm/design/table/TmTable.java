package com.tm.design.table;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;

public class TmTable extends JTable
{
	Map<String, DefaultCellEditor> cells;

	public TmTable()
	{
		super();
		cells = new Hashtable<String, DefaultCellEditor>();
	}

	@Override
	public TableCellEditor getCellEditor(int row, int column)
	{
		Object val = this.getValueAt(row, column);
		if (val instanceof Vector)
		{
			DefaultCellEditor dce = cells.get(row + ":" + column);
			JComboBox<String> combo = new JComboBox<String>();
			if (dce == null)
			{
				Vector v = (Vector) val;
				for (Iterator itr = v.iterator(); itr.hasNext();)
				{
					combo.addItem(itr.next().toString());
				}
				dce = new DefaultCellEditor(combo);

			}

			return dce;
		}

		return super.getCellEditor(row, column);
	}

}
