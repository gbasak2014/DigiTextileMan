package com.tm.design.action;

import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

public interface MotifPaneAction extends MouseListener, MouseMotionListener
{

}
