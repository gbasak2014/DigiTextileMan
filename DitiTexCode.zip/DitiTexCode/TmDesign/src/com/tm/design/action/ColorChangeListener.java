package com.tm.design.action;

import java.awt.Color;

public interface ColorChangeListener
{
	void colorChanged(Color color);
}
