package com.tm.design.dlg;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.WindowEvent;
import java.awt.event.WindowFocusListener;

import javax.swing.JPanel;
import javax.swing.event.TableModelListener;

import com.tm.design.tool.DesignPropertyTool;
import com.tm.design.win.TmDesignWin;

public class ToolWin extends TmDlg implements WindowFocusListener
{
	DesignPropertyTool propertyTool;

	boolean active;

	public ToolWin(TmDesignWin parent)
	{
		super(parent);
		// this.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 200, 500);

		JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 0));

		// JButton btn = new JButton("Update");
		// btn.setPreferredSize(new Dimension(80, 20));
		// btn.addActionListener(action);
		// btn.setActionCommand(String.valueOf(TmDesignEnum.UPDATE_PROP.value));
		// btnPanel.add(btn);

		this.propertyTool = new DesignPropertyTool();
		this.propertyTool.getTable().setPreferredSize(new Dimension(50, 800));
		this.propertyTool.getTable().getColumnModel().getColumn(1).setWidth(50);

		this.getContentPane().setLayout(new BorderLayout());

		this.getContentPane().add(this.propertyTool, BorderLayout.CENTER);
		this.getContentPane().add(btnPanel, BorderLayout.NORTH);

		// this.addFocusListener(this);
		this.addWindowFocusListener(this);
	}

	public void addTableModelListener(TableModelListener listener)
	{
		this.propertyTool.addTableModelListener(listener);
	}
	
	@Override
	public void windowGainedFocus(WindowEvent arg0)
	{
		this.active = true;
	}

	@Override
	public void windowLostFocus(WindowEvent e)
	{
		this.active = false;
	}

	public boolean isActive()
	{
		return active;
	}

	public void setActive(boolean active)
	{
		this.active = active;
	}

	public DesignPropertyTool getPropertyTool()
	{
		return propertyTool;
	}
}
