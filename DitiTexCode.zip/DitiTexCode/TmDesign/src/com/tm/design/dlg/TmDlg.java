package com.tm.design.dlg;

import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.JDialog;
import javax.swing.JFrame;

public class TmDlg extends JDialog
{
	public TmDlg(JFrame frame)
	{
		super(frame);
		setTitle("Computer Aided Textile Design System : TextileMan : By Gouranga Basak : gb.textileman@gmail.com");
		try
		{
			URL url = this.getClass().getResource("/img/logogm.jpg");
			this.setIconImage(ImageIO.read(url));
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
