package com.tm.design.dlg;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;

import com.tm.design.TmDesignEnum;
import com.tm.design.TmUtil;
import com.tm.design.action.ColorChangeListener;
import com.tm.design.motif.Motif;
import com.tm.design.pane.ColorPane;
import com.tm.design.pane.DesignPane;
import com.tm.design.tool.EditMotifToolBar;
import com.tm.design.tool.ToolColor;
import com.tm.design.win.TmDesignWin;

public class MotifEditDlg extends JDialog implements ActionListener, MouseMotionListener, MouseListener,
		ColorChangeListener {

	private static final long serialVersionUID = 514843186746827478L;
	static final int FILL = 0;
	static final int REPLACE = 1;
	static final int MOVE = 2;
	static final int PICK = 3;

	ImgPane imgPane;
	boolean ok;
	BufferedImage motifBak;
	BufferedImage motifRedo;

	TmDesignEnum motifType;

	EditMotifToolBar toolBar;

	ToolColor toolColor;
	Motif motif;
	TmDesignWin parent;

	/**
	 * Create the dialog.
	 */
	public MotifEditDlg(TmDesignWin parent, BufferedImage motifImg, TmDesignEnum motifType, Color designBackground,
			Motif motif, ColorPane colorPane) {
		super(parent);
		this.parent = parent;
		this.motifType = motifType;
		this.motif = motif;
		this.toolColor = new ToolColor(this);
		toolColor.addColorPane(colorPane);
		this.toolBar = new EditMotifToolBar(this, designBackground, toolColor);
		this.imgPane = new ImgPane(motifImg);

		this.setBackground(designBackground);
		// this.scrollPane = new JScrollPane(this.imgPane);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(this.imgPane, BorderLayout.CENTER);
		getContentPane().add(getButtonPane(), BorderLayout.SOUTH);
		getContentPane().add(this.toolBar, BorderLayout.NORTH);

		setBounds(100, 100, 850, 650);

		this.imgPane.addMouseMotionListener(this);
		this.imgPane.addMouseListener(this);
	}

	JPanel getButtonPane() {
		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));

		JButton okButton = new JButton("OK");
		okButton.setActionCommand(String.valueOf(TmDesignEnum.OK.value));
		buttonPane.add(okButton);
		getRootPane().setDefaultButton(okButton);

		JButton cancelButton = new JButton("Cancel");
		cancelButton.setActionCommand(String.valueOf(TmDesignEnum.CANCEL.value));
		buttonPane.add(cancelButton);

		okButton.addActionListener(this);
		cancelButton.addActionListener(this);

		return buttonPane;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		TmDesignEnum action = TmDesignEnum.fromString(e.getActionCommand());
		this.imgPane.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));

		switch (action) {
		case OK:
			ok = true;
			performChange();
			this.setVisible(false);
			break;
		case CANCEL:
			ok = false;
			this.setVisible(false);
			break;
		case ROTATE:
		case FLIP_VERT:
		case FLIP_HORZ:
		case MIRROR_VERT:
		case MIRROR_HORZ:
		case ARRANGE_DOWN:
		case ARRANGE_RIGHT:
			performAction(action);
			break;
		case REPLACE_COLOR:
			this.imgPane.pen = REPLACE;
			break;
		case PICK_COLOR:
			this.imgPane.pen = PICK;
			break;
		case FILL:
			this.imgPane.pen = FILL;
			break;
		case MOVE:
			this.imgPane.pen = MOVE;
			this.imgPane.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
			break;
		case ZOOM_IN:
			this.zoom(1);
			break;
		case ZOOM_OUT:
			this.zoom(-1);
			break;
		case UNDO:
			this.undo();
			break;
		case REDO:
			this.redo();
			break;
		default:
			break;
		}
	}

	void performChange() {

		if (motifType == TmDesignEnum.MOTIF) {
			BufferedImage newImg = this.getMotifImage();
			motif.setImage(newImg);
		} else {
			motif.setColor(getSelectedColor());
		}

		DesignPane dp = this.parent.getDesignPane();
		dp.repaint();
	}

	public boolean isOk() {
		return ok;
	}

	public void setOk(boolean ok) {
		this.ok = ok;
	}

	private void performAction(TmDesignEnum action) {
		BufferedImage tmpImg = null;
		PointDlg dlg;

		switch (action) {
		case ROTATE:
			tmpImg = TmUtil.rotate90(this.imgPane.motifImg);
			break;
		case FLIP_VERT:
			tmpImg = TmUtil.flipVertical(this.imgPane.motifImg);
			break;
		case FLIP_HORZ:
			tmpImg = TmUtil.flipHorizontal(this.imgPane.motifImg);
			break;
		case MIRROR_VERT:
			dlg = new PointDlg("Skip from top:", "Skip from bottom:");
			dlg.setModal(true);
			dlg.setVisible(true);
			int ts = 0;
			int bs = 0;
			if (dlg.isOk()) {
				try {
					ts = Integer.parseInt(dlg.getValue1());
				} catch (Exception e) {
				}
				try {
					bs = Integer.parseInt(dlg.getValue2());
				} catch (Exception e) {
				}
			}
			tmpImg = TmUtil.mirrorVertical(this.imgPane.motifImg, ts, bs);
			break;
		case MIRROR_HORZ:
			dlg = new PointDlg("Skip from left:", "Skip from right:");
			dlg.setModal(true);
			dlg.setVisible(true);
			int ls = 0;
			int rs = 0;
			if (dlg.isOk()) {
				try {
					ls = Integer.parseInt(dlg.getValue1());
				} catch (Exception e) {
				}
				try {
					rs = Integer.parseInt(dlg.getValue2());
				} catch (Exception e) {
				}
			}
			tmpImg = TmUtil.mirrorHorizontal(this.imgPane.motifImg, ls, rs);
			break;
		case ARRANGE_DOWN:
			tmpImg = TmUtil.arrangeDown(this.imgPane.motifImg);
			break;
		case ARRANGE_RIGHT:
			tmpImg = TmUtil.arrangeRight(this.imgPane.motifImg);
			break;
		}

		if (tmpImg != null) {
			this.motifBak = this.imgPane.motifImg;
			this.imgPane.motifImg = tmpImg;
			imgPane.refreshPaneSize();
			imgPane.repaint();
		}

	}

	public void zoom(int val) {
		this.imgPane.zoom(val);
	}

	public void undo() {
		if (this.motifBak != null) {
			this.motifRedo = this.imgPane.motifImg;
			this.imgPane.motifImg = this.motifBak;
			this.imgPane.refreshPaneSize();
			this.imgPane.repaint();
			this.motifBak = null;
		}
	}

	public void redo() {
		if (this.motifRedo != null) {
			this.motifBak = this.imgPane.motifImg;
			this.imgPane.motifImg = this.motifRedo;
			this.imgPane.refreshPaneSize();
			this.imgPane.repaint();
			this.motifRedo = null;
		}
	}

	public BufferedImage getMotifImage() {
		return this.imgPane.motifImg;
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		if (this.imgPane.pen == MOVE) {
			this.imgPane.curX = e.getX();
			this.imgPane.curY = e.getY();

			this.repaint();
		}
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		int x = ((e.getX() - this.imgPane.left) / this.imgPane.zoom);
		int y = ((e.getY() - this.imgPane.top) / this.imgPane.zoom);

		if ((x >= 0 && x < this.imgPane.motifImg.getWidth()) && (y >= 0 && y < this.imgPane.motifImg.getHeight())) {
			this.toolBar.setCurrentColor(this.imgPane.motifImg.getRGB(x, y));
		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		this.imgPane.px = e.getX();
		this.imgPane.py = e.getY();
		int x = ((this.imgPane.px - this.imgPane.left) / this.imgPane.zoom);
		int y = ((this.imgPane.py - this.imgPane.top) / this.imgPane.zoom);

		if (this.imgPane.pen == FILL) {
			BufferedImage newImg = TmUtil.fill(this.imgPane.motifImg, x, y, this.toolBar.getSelectedColor().getRGB());
			if (newImg != null) {
				this.motifBak = this.imgPane.motifImg;
				this.motifRedo = null;
				this.imgPane.motifImg = newImg;
				this.repaint();
			}
		} else if (this.imgPane.pen == REPLACE) {
			BufferedImage newImg = TmUtil.replaceColor(this.imgPane.motifImg, x, y, this.toolBar.getSelectedColor()
					.getRGB());
			if (newImg != null) {
				this.motifBak = this.imgPane.motifImg;
				this.motifRedo = null;
				this.imgPane.motifImg = newImg;
				this.repaint();
			}
		} else if (this.imgPane.pen == PICK) {
			if (TmUtil.isValidPoint(this.imgPane.motifImg, x, y)) {
				this.toolBar.selectColor(this.imgPane.motifImg.getRGB(x, y));
			}
		}
	}

	public Color getSelectedColor() {
		return this.toolBar.getSelectedColor();
	}

	@Override
	public void colorChanged(Color color) {
		// TODO Auto-generated method stub

	}

	static class ImgPane extends JPanel {
		private static final long serialVersionUID = 8057867336505210776L;
		int zoom = 1;
		int px = 0;
		int py = 0;
		int curX = 0;
		int curY = 0;
		int left = 1;
		int top = 1;

		int pen = -1;

		BufferedImage motifImg;

		public ImgPane(BufferedImage motifImg) {
			this.motifImg = motifImg;
		}

		public void setImage(BufferedImage motifImg) {
			this.motifImg = motifImg;
		}

		@Override
		public void paint(Graphics g) {
			super.paint(g);
			int w = this.getWidth();
			int h = this.getHeight();

			g.setColor(this.getBackground());
			g.fillRect(0, 0, w, h);

			w = this.motifImg.getWidth() * this.zoom;

			h = this.motifImg.getHeight() * this.zoom;

			if (this.pen == MOVE) {
				this.left = this.left - (px - curX);
				this.top = this.top - (py - curY);
				px = curX;
				py = curY;
			}

			g.drawImage(this.motifImg, left, top, w, h, this);
			g.setColor(Color.GRAY);
			g.drawRect(left - 1, top - 1, w + 2, h + 2);
		}

		public void zoom(int val) {
			this.zoom = this.zoom + val;
			if (this.zoom < 1) {
				this.zoom = 1;
			} else if (this.zoom > 10) {
				this.zoom = 10;
			}

			this.refreshPaneSize();
			this.repaint();
		}

		void refreshPaneSize() {
			int w = this.getWidth();
			int h = this.getHeight();

			if (w < (this.motifImg.getWidth() * this.zoom + 2)) {
				w = this.motifImg.getWidth() * this.zoom + 2;
			}

			if (h < (this.motifImg.getHeight() * this.zoom + 2)) {
				h = this.motifImg.getHeight() * this.zoom + 2;
			}

			this.setPreferredSize(new Dimension(w, h));
		}
	}

}
