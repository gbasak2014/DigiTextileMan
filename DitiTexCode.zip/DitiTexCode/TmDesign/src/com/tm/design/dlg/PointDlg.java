package com.tm.design.dlg;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

public class PointDlg extends TmDlg implements ActionListener
{

	private final JPanel contentPanel = new JPanel();

	boolean ok;
	private JTextField txt1;
	private JTextField txt2;
	JLabel lbl1;
	JLabel lbl2;

	public PointDlg(String msg1, String msg2)
	{
		this();
		this.lbl1.setText(msg1);
		this.lbl2.setText(msg2);
	}

	public PointDlg()
	{
		super(null);
		setBounds(100, 100, 400, 220);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);

		lbl1 = new JLabel("Skip From Left:");
		lbl1.setHorizontalAlignment(SwingConstants.RIGHT);
		lbl1.setBounds(28, 47, 120, 14);
		contentPanel.add(lbl1);

		txt1 = new JTextField();
		txt1.setBounds(153, 44, 86, 20);
		contentPanel.add(txt1);
		txt1.setColumns(10);

		lbl2 = new JLabel("Skip From Left:");
		lbl2.setHorizontalAlignment(SwingConstants.RIGHT);
		lbl2.setBounds(28, 75, 120, 14);
		contentPanel.add(lbl2);

		txt2 = new JTextField();
		txt2.setColumns(10);
		txt2.setBounds(153, 72, 86, 20);
		contentPanel.add(txt2);
		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
		getContentPane().add(buttonPane, BorderLayout.SOUTH);
		JButton okButton = new JButton("OK");
		okButton.setActionCommand("OK");
		buttonPane.add(okButton);
		getRootPane().setDefaultButton(okButton);
		JButton cancelButton = new JButton("Cancel");
		cancelButton.setActionCommand("Cancel");
		buttonPane.add(cancelButton);
		
		okButton.addActionListener(this);
		cancelButton.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		String cmd = e.getActionCommand();
		if ("OK".equals(cmd))
		{
			this.ok = true;
		} else
		{
			this.ok = false;
		}
		this.setVisible(false);
	}

	public boolean isOk()
	{
		return this.ok;
	}

	public String getValue1()
	{
		return this.txt1.getText();
	}

	public String getValue2()
	{
		return this.txt2.getText();
	}
}
