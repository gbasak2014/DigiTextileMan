package com.tm.design.dlg;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import com.tm.commons.win.DigiTmWin;
import com.tm.design.motif.PreviewImage;
import com.tm.design.pane.MotifPane;

public class PreviewDesignDlg extends DigiTmWin implements ActionListener {
	private static final long serialVersionUID = -8047620284167934904L;
	PreviewPane pane;
	JScrollPane scrollPane;

	@Override
	public void saveProperties() {
		// TODO Auto-generated method stub

	}

	public PreviewDesignDlg(List<MotifPane> list, int width, int height, Color background) {
		super();
		this.pane = new PreviewPane(list, width, height, background);

		this.getContentPane().setLayout(new BorderLayout());
		this.scrollPane = new JScrollPane(this.pane);

		JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
		JButton btnClose = new JButton("Close");
		btnClose.addActionListener(this);
		btnClose.setActionCommand("CLOSE");

		btnPanel.add(btnClose);

		this.getContentPane().add(this.scrollPane, BorderLayout.CENTER);
		this.getContentPane().add(btnPanel, BorderLayout.SOUTH);

		this.setPreferredSize(new Dimension(600, 500));
		this.pack();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		if ("CLOSE".equals(cmd)) {
			this.setVisible(false);
		}

	}

	static class PreviewPane extends JPanel {
		List<PreviewImage> list;

		public PreviewPane(List<MotifPane> list, int w, int h, Color background) {
			this.setBackground(background);
			this.setPreferredSize(new Dimension(w, h));

			this.list = new ArrayList<PreviewImage>(list.size());
			for (MotifPane mp : list) {
				this.list.add(new PreviewImage(mp.createPaneImage(), mp.getLeft(), mp.getTop(),
						!mp.isHorizontalAlign(), mp.getHorizontalRepeate(), mp.getVerticalRepeate(), this));
			}

		}

		@Override
		public void paint(Graphics g) {
			int w = this.getWidth();
			int h = this.getHeight();
			g.setColor(this.getBackground());
			g.fillRect(0, 0, w, h);

			for (PreviewImage img : this.list) {
				img.paint(g);
			}
		}
	}
}
