package com.tm.design.dlg;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileFilter;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import com.tm.design.TmDesignEnum;


public class ImageOpenDlg extends TmDlg implements ActionListener
{

	// private final JPanel contentPanel = new JPanel();
	JComboBox<String> jcDrive = new JComboBox<String>();
	DefaultListModel<String> listDir = new DefaultListModel<String>();
	DefaultListModel<String> listFile = new DefaultListModel<String>();

	JList<String> jlDir = new JList<String>(listDir);
	JList<String> jlFile = new JList<String>(listFile);

	JLabel jlPath = new JLabel();

	boolean okPresses = false;

	ImgPage imgPane = new ImgPage();

	File selectedFile;

	JCheckBox checkImgPreview = new JCheckBox("No Image Preview");

	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		try
		{
			ImageOpenDlg dialog = new ImageOpenDlg(null, "I:/Design/PERSONAL .2");
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public ImageOpenDlg(JFrame parent, String lastPath)
	{
		super(parent);

		setBounds(100, 100, 800, 500);
		getContentPane().setLayout(new BorderLayout());
		imgPane.setBorder(BorderFactory.createLoweredBevelBorder());
		getContentPane().add(imgPane, BorderLayout.CENTER);

		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));

		JButton btnOk = new JButton("OK");
		btnOk.setActionCommand(String.valueOf(TmDesignEnum.OK.value));

		getRootPane().setDefaultButton(btnOk);

		JButton btnCancel = new JButton("Cancel");
		btnCancel.setActionCommand(String.valueOf(TmDesignEnum.CANCEL.value));

		JButton btnUp = new JButton("UP");
		btnUp.setActionCommand(String.valueOf(TmDesignEnum.UP.value));

		buttonPane.add(checkImgPreview);
		JLabel lbl = new JLabel();
		lbl.setPreferredSize(new Dimension(500, 10));
		buttonPane.add(lbl);
		buttonPane.add(btnOk);
		buttonPane.add(btnCancel);

		JPanel fsPane = new JPanel(new BorderLayout());
		jcDrive.setPreferredSize(new Dimension(100, 20));

		jlPath.setBorder(BorderFactory.createLoweredBevelBorder());
		jlPath.setPreferredSize(new Dimension(150, 20));

		JPanel jpNorth = new JPanel(new GridLayout(2, 1, 2, 5));

		JPanel jpPath = new JPanel();
		jpPath.add(jlPath);
		jpPath.add(btnUp);

		jpNorth.add(jcDrive);
		jpNorth.add(jpPath);

		fsPane.add(jpNorth, BorderLayout.NORTH);

		JPanel dirFilePane = new JPanel(new GridLayout(2, 1, 2, 2));

		jlDir.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		jlFile.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		dirFilePane.add(new JScrollPane(jlDir));
		dirFilePane.add(new JScrollPane(jlFile));

		fsPane.add(dirFilePane, BorderLayout.CENTER);
		getContentPane().add(buttonPane, BorderLayout.SOUTH);
		getContentPane().add(fsPane, BorderLayout.WEST);

		jcDrive.addActionListener(this);
		jcDrive.setActionCommand(String.valueOf(TmDesignEnum.SELECT.value));
		btnCancel.addActionListener(this);
		btnOk.addActionListener(this);
		btnUp.addActionListener(this);

		jlDir.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e)
			{
				if (e.getClickCount() >= 2 && ImageOpenDlg.this.jlDir.getSelectedValue() != null)
				{
					addPath(ImageOpenDlg.this.jlDir.getSelectedValue());
				}
			}
		});

		jlFile.addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent e)
			{
				previewImage(ImageOpenDlg.this.jlFile.getSelectedValue());
			}
		});

		char drive;
		if (lastPath != null)
		{
			drive = lastPath.charAt(0);
		} else
		{
			drive = 'A';
		}

		initDirCombo(drive);

		if (lastPath != null)
		{
			this.initDirAndFileList(lastPath);
			this.jlPath.setText(lastPath);
		}
	}

	void previewImage(String fileName)
	{
		selectedFile = new File(jlPath.getText() + File.separator + fileName);

		if (!checkImgPreview.isSelected())
		{
			try
			{
				BufferedImage img = ImageIO.read(selectedFile);
				imgPane.setImage(img);
			} catch (Exception e)
			{
			}
		} else
		{
			imgPane.setImage(null);
		}
	}

	void addPath(String dir)
	{
		jlPath.setText(jlPath.getText() + "/" + dir);
		jlPath.setToolTipText(jlPath.getText());
		initDirAndFileList(jlPath.getText());
	}

	public File getSelectedFile()
	{
		return selectedFile;
	}

	void upDir()
	{
		String str = jlPath.getText();
		int idx = str.lastIndexOf("/");
		if (idx > 0 && idx + 1 < str.length())
		{
			String path = str.substring(0, idx);
			jlPath.setText(path);
			initDirAndFileList(path);
		}
	}

	void initDirCombo(char selDrive)
	{
		File[] roots = File.listRoots();
		for (File file : roots)
		{
			if (file.getAbsolutePath().startsWith("/")) {
				jcDrive.addItem(file.getAbsolutePath());
			} else {
				jcDrive.addItem(file.getAbsolutePath().substring(0, 2));
			}
		}

		for (int i = 0; i < jcDrive.getItemCount(); i++)
		{
			if (selDrive == jcDrive.getItemAt(i).charAt(0))
			{
				jcDrive.setSelectedIndex(i);
				return;
			}
		}

		jcDrive.setSelectedIndex(0);
	}

	void initDirAndFileList(String path)
	{
		File dir = new File(path);
		if (dir.isDirectory())
		{
			File[] files = dir.listFiles(new FileFilter() {

				@Override
				public boolean accept(File pathname)
				{
					return pathname.isDirectory();
				}
			});

			listDir.clear();
			for (File file : files)
			{
				listDir.addElement(file.getName());
			}
		}

		initFileList(path);
	}

	void initFileList(String path)
	{
		File dir = new File(path);
		if (dir.isDirectory())
		{
			File[] files = dir.listFiles(new FileFilter() {

				@Override
				public boolean accept(File pathname)
				{
					return !pathname.isDirectory()
							&& (pathname.getName().toUpperCase().endsWith(".BMP") || pathname.getName().toUpperCase().endsWith(".JPG"));
				}
			});

			listFile.clear();
			for (File file : files)
			{
				listFile.addElement(file.getName());
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		TmDesignEnum action = TmDesignEnum.fromString(e.getActionCommand());

		switch (action)
		{
		case OK:
			okPresses = true;
			this.setVisible(false);
			break;
		case CANCEL:
			this.setVisible(false);
			break;
		case UP:
			upDir();
			break;
		case SELECT:
			String drive = (String) jcDrive.getSelectedItem();
			jlPath.setText(drive);
			initDirAndFileList(drive);
			break;
		default:
			break;
		}
	}

	public BufferedImage getSelectedImage()
	{
		if (selectedFile != null && imgPane.img == null)
		{
			try
			{
				return ImageIO.read(selectedFile);
			} catch (Exception e)
			{
			}
		}

		return imgPane.img;
	}

	public boolean isOk()
	{
		return okPresses;
	}

	class ImgPage extends JPanel
	{
		int left, top, x1, y1, x2, y2;
		BufferedImage img;

		void draggMe(int x, int y)
		{
			x2 = x;
			y2 = y;
			repaint();
		}

		public ImgPage()
		{
			this.setCursor(new Cursor(Cursor.HAND_CURSOR));
			this.addMouseMotionListener(new MouseMotionAdapter() {
				@Override
				public void mouseDragged(MouseEvent e)
				{
					draggMe(e.getX(), e.getY());
				}
			});

			this.addMouseListener(new MouseAdapter() {
				@Override
				public void mousePressed(MouseEvent e)
				{
					x1 = x2 = e.getX();
					y1 = y2 = e.getY();
				}

				@Override
				public void mouseReleased(MouseEvent e)
				{
					left = left + x2 - x1;
					top = top + y2 - y1;
				}
			});
		}

		public void setImage(BufferedImage img)
		{
			this.img = img;
			if (img != null)
			{
				left = (getWidth() - img.getWidth()) / 2;
				top = (getHeight() - img.getHeight()) / 2;
				x1 = y1 = x2 = y2 = 0;
			}
			repaint();
		}

		@Override
		public void paint(Graphics g)
		{
			super.paint(g);
			g.setColor(Color.BLACK);
			g.fillRect(0, 0, getWidth(), getHeight());
			if (img != null)
			{
				int x = left + x2 - x1;
				int y = top + y2 - y1;
				g.setColor(Color.WHITE);
				g.drawRect(x - 2, y - 2, img.getWidth() + 4, img.getHeight() + 4);
				g.drawImage(img, x, y, ImageOpenDlg.this);
			}
		}
	}
}
