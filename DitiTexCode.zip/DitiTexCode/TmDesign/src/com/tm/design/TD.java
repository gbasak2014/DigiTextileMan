package com.tm.design;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextPane;
import javax.swing.JWindow;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import com.tm.design.win.TmDesignWin;

public class TD extends JWindow implements ActionListener
{
	// com.textile.tm.X
	JRadioButton rdTm;
	JRadioButton rdTd;
	JRadioButton rdPc;
	JRadioButton rdIp;

	private JPanel contentPane;

	BufferedImage img1;
	BufferedImage img2;

	JTextPane jtDetails;
	String dtlPattern;
	String dtlTrace;
	String dtlMain;
	String dtlTd;
	private JPanel jpImg1;
	private JPanel jpImg2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args)
	{
		EventQueue.invokeLater(new Runnable() {
			public void run()
			{
				try
				{
					TD frame = new TD();
					frame.setVisible(true);
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TD()
	{
		Color color = new Color(50, 50, 100);
		setBounds(100, 100, 700, 460);
		contentPane = new JPanel();
		contentPane.setBackground(color);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblWelcomeToComputer = new JLabel("Welcome to Computer Aided Textile Design System - TextileMan");
		lblWelcomeToComputer.setForeground(new Color(211, 211, 211));
		lblWelcomeToComputer.setFont(new Font("Bookman Old Style", Font.BOLD, 20));
		lblWelcomeToComputer.setBounds(10, 44, 677, 36);
		contentPane.add(lblWelcomeToComputer);

		JLabel lblByGouranga = new JLabel("By - Gouranga Basak");
		lblByGouranga.setHorizontalAlignment(SwingConstants.RIGHT);
		lblByGouranga.setForeground(new Color(211, 211, 211));
		lblByGouranga.setFont(new Font("Bookman Old Style", Font.PLAIN, 18));
		lblByGouranga.setBounds(472, 78, 215, 23);
		contentPane.add(lblByGouranga);

		JLabel lblSelectApplicationTo = new JLabel("Select application and click OK");
		lblSelectApplicationTo.setHorizontalAlignment(SwingConstants.LEFT);
		lblSelectApplicationTo.setForeground(new Color(255, 165, 0));
		lblSelectApplicationTo.setFont(new Font("Bookman Old Style", Font.PLAIN, 18));
		lblSelectApplicationTo.setBounds(10, 112, 677, 28);
		contentPane.add(lblSelectApplicationTo);

		rdTm = new JRadioButton("Motif Creator");
		rdTm.setFont(new Font("Tahoma", Font.PLAIN, 18));
		rdTm.setForeground(new Color(255, 165, 0));
		rdTm.setBackground(color);
		rdTm.setBounds(198, 154, 158, 23);
		rdTm.setBorder(BorderFactory.createEmptyBorder());
		contentPane.add(rdTm);

		rdTd = new JRadioButton("Textile Designer");
		rdTd.setFont(new Font("Tahoma", Font.PLAIN, 18));
		rdTd.setForeground(new Color(255, 165, 0));
		rdTd.setBackground(color);
		rdTd.setBounds(198, 180, 158, 23);
		rdTd.setBorder(BorderFactory.createEmptyBorder());
		rdTd.setSelected(true);
		contentPane.add(rdTd);

		rdPc = new JRadioButton("Pattern Creator");
		rdPc.setForeground(new Color(255, 165, 0));
		rdPc.setFont(new Font("Tahoma", Font.PLAIN, 18));
		rdPc.setBackground(color);
		rdPc.setBounds(198, 206, 158, 23);
		rdPc.setBorder(BorderFactory.createEmptyBorder());
		contentPane.add(rdPc);

		rdIp = new JRadioButton("Image Processor");
		rdIp.setForeground(new Color(255, 165, 0));
		rdIp.setFont(new Font("Tahoma", Font.PLAIN, 18));
		rdIp.setBackground(color);
		rdIp.setBounds(198, 232, 158, 23);
		rdIp.setBorder(BorderFactory.createEmptyBorder());
		contentPane.add(rdIp);

		rdTm.setActionCommand("TM");
		rdTd.setActionCommand("TD");
		rdIp.setActionCommand("IP");
		rdPc.setActionCommand("PC");

		rdTm.addActionListener(this);
		rdTd.addActionListener(this);
		rdIp.addActionListener(this);
		rdPc.addActionListener(this);

		ButtonGroup bg = new ButtonGroup();
		bg.add(rdTm);
		bg.add(rdTd);
		bg.add(rdIp);
		bg.add(rdPc);

		JButton btnOk = new JButton("OK");
		btnOk.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnOk.setBounds(166, 415, 89, 23);
		btnOk.setActionCommand("OK");
		contentPane.add(btnOk);

		JButton btnCancel = new JButton("Cancel");
		btnCancel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnCancel.setBounds(267, 415, 89, 23);
		btnCancel.setActionCommand("Cancel");
		contentPane.add(btnCancel);

		constructDetails();

		jtDetails = new JTextPane();
		jtDetails.setFont(new Font("Tahoma", Font.PLAIN, 14));
		jtDetails.setForeground(Color.WHITE);
		jtDetails.setBackground(color);
		jtDetails.setText(this.dtlMain);
		jtDetails.setToolTipText("");
		jtDetails.setBounds(411, 180, 264, 245);
		contentPane.add(jtDetails);
		setSampleDesign();
		jpImg1 = new JPanel();
		jpImg1.setBackground(color);
		jpImg1.setBounds(38, 151, 150, 241);
		contentPane.add(jpImg1);
		jpImg2 = new JPanel();
		jpImg2.setBackground(color);
		jpImg2.setBounds(0, 0, 700, 39);
		contentPane.add(jpImg2);

		btnOk.addActionListener(this);
		btnCancel.addActionListener(this);
		constructDetails();
	}

	private void constructDetails()
	{
		this.dtlPattern = "Create patterns in a convenient way and see the looks on the fly in weaving material."
				+ " Save the pattern in library and use it from TextileMan as a filling pattern.";

		this.dtlTd = "Design you Textile product using the motif created in Motif Creator.";

		this.dtlTrace = "Process multicolored image before use it in TextileMan to create your design.";

		this.dtlMain = "Create Motif or Figure for your Textile product using different drawing Tools."
				+ " Edit Motif using editing tools, save motif in Library for future reuse and open existing saved motif."
				+ " Convert your motif into readable code for punching board using Manual or Electronic board punching machine";
	}

	@Override
	public void paint(Graphics arg0)
	{
		super.paint(arg0);
		Graphics g = jpImg1.getGraphics();
		g.drawImage(this.img1, 0, 0, this);

		g = jpImg2.getGraphics();
		g.drawImage(this.img2, 0, 0, this);

	}

	private void setSampleDesign()
	{
		try
		{
			URL url = this.getClass().getResource("/img/sample1.jpg");
			this.img1 = ImageIO.read(url);

			url = this.getClass().getResource("/img/sample2.jpg");
			this.img2 = ImageIO.read(url);

		} catch (Exception e)
		{
			e.printStackTrace();
		}

	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		String cmd = e.getActionCommand();

		if ("TM".equals(cmd))
		{
			this.jtDetails.setText(this.dtlMain);
		} else if ("TD".equals(cmd))
		{
			this.jtDetails.setText(this.dtlMain);
		} else if ("IP".equals(cmd))
		{
			this.jtDetails.setText(this.dtlTrace);
		} else if ("PC".equals(cmd))
		{
			this.jtDetails.setText(this.dtlPattern);
		} else if ("OK".equals(cmd))
		{
			this.openApp();
			this.setVisible(false);
			this.dispose();
		} else
		{
			this.setVisible(false);
			this.dispose();
		}
	}

	private void openApp()
	{
		EventQueue.invokeLater(new Runnable() {
			public void run()
			{
				try
				{
					if (rdTd.isSelected())
					{
						new TmDesignWin("XXXXXXX");
					}
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		});
	}
}
