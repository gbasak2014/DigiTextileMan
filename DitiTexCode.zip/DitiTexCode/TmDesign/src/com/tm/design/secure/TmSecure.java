package com.tm.design.secure;

import java.io.File;
import java.io.PrintWriter;
import java.util.List;

public class TmSecure {
	public static void getLock() throws Exception {
		List<String> locks = KeyChecker.getLock();

		PrintWriter pw = new PrintWriter("tmLock-192837465");

		for (String lock : locks) {
			pw.println(lock);
		}
		pw.close();
	}

	private static String getKey(String k) {
		return k.replaceAll("-", "XXXXXXXXXXXX");
	}

	public static boolean isValidKey(File path) {
		return false;
	}
}
