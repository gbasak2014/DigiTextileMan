package com.tm.design.secure;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.NetworkInterface;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

public class KeyChecker
{
	public static List<String> getLock() throws Exception
	{
		List<String> list = new ArrayList<String>();

		for (Enumeration<NetworkInterface> network = NetworkInterface.getNetworkInterfaces(); network.hasMoreElements();)
		{
			NetworkInterface ni = network.nextElement();
			if (ni.getHardwareAddress() != null && ni.getName().startsWith("eth"))
			{
				list.add(getAddress(ni.getHardwareAddress()));
			}
		}

		return list;
	}

	public static String getAddress(byte[] mac) throws Exception
	{

		StringBuilder sb = new StringBuilder();
		for (int i = mac.length - 1; i >= 0; i--)
		{
			sb.append(String.format("%02X%s", mac[i], (i > 0 ? "-" : "")));
		}

		return sb.toString();
	}

	public static List<String> getKey(File file) throws Exception
	{
		BufferedReader br = new BufferedReader(new FileReader(file));
		List<String> keys = new ArrayList<String>();
		String line;
		try
		{
			while ((line = br.readLine()) != null)
			{
				keys.add(line);
			}
		} catch (Exception e)
		{
		}

		br.close();
		return keys;
	}

	public static String getMd5(String str) throws Exception
	{
		MessageDigest md = MessageDigest.getInstance("MD5");
		md.reset();
		byte[] d = md.digest(str.getBytes());
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < d.length; i++)
		{
			sb.append(Integer.toBinaryString(0xff & d[i]));
		}
		return sb.toString();
	}

	public static boolean check(File file) throws Exception
	{
		List<String> locks = getLock();
		List<String> keys = getKey(file);

		for (int i = 0; i < locks.size(); i++)
		{
			String lock = locks.get(i);

			for (int j = 0; j < keys.size(); j++)
			{
				if (lock.equals(keys.get(j)))
				{
					return true;
				}
			}
		}
		return false;
	}
}
