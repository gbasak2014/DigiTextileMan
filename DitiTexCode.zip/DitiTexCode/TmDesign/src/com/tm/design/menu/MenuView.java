package com.tm.design.menu;

import java.awt.event.KeyEvent;

import javax.swing.JCheckBoxMenuItem;

import com.tm.commons.menu.DigiTmMenu;
import com.tm.commons.menu.DigiTmMenuItem;
import com.tm.design.TmDesignEnum;
import com.tm.design.win.TmDesignWin;

public class MenuView extends DigiTmMenu {
	private static final long serialVersionUID = 965246491808692997L;

	public MenuView(TmDesignWin tmDesignWin) {
		super("View");
		this.add(new DigiTmMenuItem("Preview Design", TmDesignEnum.PREVIEW_DESIGN.value, tmDesignWin, KeyEvent.VK_E));
		JCheckBoxMenuItem chkItem = new JCheckBoxMenuItem("Preview Mode");
		chkItem.setSelected(true);
		chkItem.setActionCommand(String.valueOf(TmDesignEnum.PREVIEW_MODE.value));
		chkItem.addActionListener(tmDesignWin);
		this.add(chkItem);

		this.add(new DigiTmMenuItem("View Properties", TmDesignEnum.SHOW_PROP.value, tmDesignWin, KeyEvent.VK_P));
		//this.add(new DigiTmMenuItem("View Motif Browser", TmDesignEnum.SHOW_BROWSER.value, tmDesignWin));
	}
}
