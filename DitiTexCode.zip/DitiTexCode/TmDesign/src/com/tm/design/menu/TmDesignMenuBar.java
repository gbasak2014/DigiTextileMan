package com.tm.design.menu;

import javax.swing.JMenuBar;

public class TmDesignMenuBar extends JMenuBar
{
	
	public TmDesignMenuBar()
	{
		// TODO Auto-generated constructor stub
	}
	
	private void createFileMenu()
	{
		
	}
}
