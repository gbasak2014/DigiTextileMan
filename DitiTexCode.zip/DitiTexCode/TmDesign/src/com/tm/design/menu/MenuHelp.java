package com.tm.design.menu;

import java.awt.event.KeyEvent;

import com.tm.commons.menu.DigiTmMenu;
import com.tm.commons.menu.DigiTmMenuItem;
import com.tm.design.TmDesignEnum;
import com.tm.design.win.TmDesignWin;

public class MenuHelp extends DigiTmMenu
{
	private static final long serialVersionUID = -1166181447774835885L;

	public MenuHelp(TmDesignWin tmDesignWin)
	{
		super("Help");
		this.add(new DigiTmMenuItem("About", TmDesignEnum.ABOUT.value, tmDesignWin, KeyEvent.VK_B));
	}
}
