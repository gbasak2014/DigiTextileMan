package com.tm.design.menu;

import java.awt.event.KeyEvent;

import com.tm.commons.menu.DigiTmMenu;
import com.tm.commons.menu.DigiTmMenuItem;
import com.tm.design.TmDesignEnum;
import com.tm.design.win.TmDesignWin;

public class MenuSetting extends DigiTmMenu
{
	private static final long serialVersionUID = -1166181447774835885L;

	public MenuSetting(TmDesignWin tmDesignWin)
	{
		super("Setting");
		this.add(new DigiTmMenuItem("Options", TmDesignEnum.OPTIONS.value, tmDesignWin, KeyEvent.VK_B));
	}
}
