package com.tm.design.menu;

import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

import javax.swing.JSeparator;

import com.tm.commons.menu.DigiTmMenu;
import com.tm.commons.menu.DigiTmMenuItem;
import com.tm.design.TmDesignEnum;
import com.tm.design.win.TmDesignWin;

public class MenuFile extends DigiTmMenu {
	private static final long serialVersionUID = -8030005196785947401L;

	public MenuFile(TmDesignWin tmDesignWin) {

		super("File");
		this.add(new DigiTmMenuItem("New", TmDesignEnum.NEW.value, tmDesignWin, KeyEvent.VK_N));
		this.add(new DigiTmMenuItem("Open", TmDesignEnum.OPEN.value, tmDesignWin, KeyEvent.VK_O));
		this.add(new DigiTmMenuItem("Add Motif", TmDesignEnum.ADD_BLOCK.value, tmDesignWin, KeyEvent.VK_I));
		this.add(new DigiTmMenuItem("Add Motif from Library", TmDesignEnum.ADD_BLOCK_FROM_LIB.value, tmDesignWin,
				KeyEvent.VK_I, InputEvent.CTRL_MASK + InputEvent.SHIFT_MASK));
		this.add(new DigiTmMenuItem("Add Border", TmDesignEnum.ADD_BORDER.value, tmDesignWin));

		this.add(new DigiTmMenuItem("Save", TmDesignEnum.SAVE.value, tmDesignWin, KeyEvent.VK_S));
		this.add(new DigiTmMenuItem("Save As", TmDesignEnum.SAVE_AS.value, tmDesignWin));

		this.add(new DigiTmMenuItem("Save As Image", TmDesignEnum.SAVE_AS_IMAGE.value, tmDesignWin, KeyEvent.VK_S,
				InputEvent.CTRL_MASK + InputEvent.SHIFT_MASK));

		this.add(new JSeparator());

		this.add(new DigiTmMenuItem("Exit", TmDesignEnum.EXIT.value, tmDesignWin));
	}
}
