package com.tm.design.menu;

import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

import javax.swing.JSeparator;

import com.tm.commons.menu.DigiTmMenu;
import com.tm.commons.menu.DigiTmMenuItem;
import com.tm.design.TmDesignEnum;
import com.tm.design.win.TmDesignWin;

public class MenuEdit extends DigiTmMenu
{
	private static final long serialVersionUID = 8704377828208837194L;

	public MenuEdit(TmDesignWin tmDesignWin)
	{
		super("Edit");
		this.add(new DigiTmMenuItem("Resize Design", TmDesignEnum.RESIZE_DESIGN.value, tmDesignWin));
		this.add(new DigiTmMenuItem("Background Color", TmDesignEnum.BACK_COLOR.value, tmDesignWin));
		this.add(new JSeparator());

		this.add(new DigiTmMenuItem("Cut", TmDesignEnum.CUT.value, tmDesignWin, KeyEvent.VK_X));
		this.add(new DigiTmMenuItem("Copy", TmDesignEnum.COPY.value, tmDesignWin, KeyEvent.VK_C));
		
		this.add(new DigiTmMenuItem("Paste", TmDesignEnum.PASTE.value, tmDesignWin, KeyEvent.VK_V));
		this.add(new DigiTmMenuItem("Remove Motif", TmDesignEnum.REMOVE_MOTIF.value, tmDesignWin, KeyEvent.VK_R));
		this.add(new JSeparator());
		
		this.add(new DigiTmMenuItem("Edit Motif", TmDesignEnum.EDIT_GRP.value, tmDesignWin, KeyEvent.VK_E));
		this.add(new DigiTmMenuItem("Move Motif Up / Left", TmDesignEnum.MOVE_UP.value, tmDesignWin, KeyEvent.VK_UP));
		this.add(new DigiTmMenuItem("Move Motif Down / Right", TmDesignEnum.MOVE_DOWN.value, tmDesignWin, KeyEvent.VK_DOWN));

		this.add(new DigiTmMenuItem("Flip Vertical Motif", TmDesignEnum.FLIP_VERT_MOTIF.value, tmDesignWin, KeyEvent.VK_T));
		this.add(new DigiTmMenuItem("Flip Horizontal Motif", TmDesignEnum.FLIP_HORZ_MOTIF.value, tmDesignWin, KeyEvent.VK_H));
		this.add(new JSeparator());
		
		this.add(new DigiTmMenuItem("create Copy of Group", TmDesignEnum.COPY_GROUP.value, tmDesignWin, KeyEvent.VK_C, InputEvent.CTRL_MASK
				+ InputEvent.SHIFT_MASK));
		
		this.add(new DigiTmMenuItem("Flip Vertical Motif Group", TmDesignEnum.FLIP_VERT.value, tmDesignWin, KeyEvent.VK_T, InputEvent.CTRL_MASK
				+ InputEvent.SHIFT_MASK));
		this.add(new DigiTmMenuItem("Flip Horizontal Motif Group", TmDesignEnum.FLIP_HORZ.value, tmDesignWin, KeyEvent.VK_H,
				InputEvent.CTRL_MASK + InputEvent.SHIFT_MASK));

		
		this.add(new DigiTmMenuItem("Remove Motif Group", TmDesignEnum.REMOVE_GROUP.value, tmDesignWin, KeyEvent.VK_R, InputEvent.CTRL_MASK
				+ InputEvent.SHIFT_MASK));

		this.add(new DigiTmMenuItem("Lock Motif Group", TmDesignEnum.LOCK_MOTIF.value, tmDesignWin, KeyEvent.VK_L));
		this.add(new DigiTmMenuItem("unlock Motif Group", TmDesignEnum.UNLOCK_MOTIF.value, tmDesignWin, KeyEvent.VK_U));
	}
}
