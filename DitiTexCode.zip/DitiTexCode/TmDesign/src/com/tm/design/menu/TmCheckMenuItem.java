package com.tm.design.menu;

import java.awt.Font;

import javax.swing.JCheckBoxMenuItem;

public class TmCheckMenuItem extends JCheckBoxMenuItem
{
	public TmCheckMenuItem(String name)
	{
		super(name);
		this.setFont(new Font("Serif", 0, 12));
	}
}
