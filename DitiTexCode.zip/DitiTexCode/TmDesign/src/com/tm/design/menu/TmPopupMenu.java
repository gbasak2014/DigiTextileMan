package com.tm.design.menu;

import java.awt.Component;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.util.Hashtable;
import java.util.Map;

import javax.swing.JPopupMenu;
import javax.swing.JSeparator;

import com.tm.commons.menu.DigiTmMenuItem;
import com.tm.design.TmDesignEnum;
import com.tm.design.motif.Motif;
import com.tm.design.pane.DesignPane;
import com.tm.design.pane.MotifPane;
import com.tm.design.win.TmDesignWin;

public class TmPopupMenu extends JPopupMenu
{
	TmDesignWin tmDesignWin;
	Map<TmDesignEnum, DigiTmMenuItem> items = new Hashtable<TmDesignEnum, DigiTmMenuItem>();

	public TmPopupMenu(TmDesignWin tmDesignWin)
	{
		this.tmDesignWin = tmDesignWin;
		this.createMenuItems();
	}

	private void createMenuItems()
	{
		DigiTmMenuItem item = new DigiTmMenuItem("Show Properties", TmDesignEnum.SHOW_PROP.value, this.tmDesignWin);
		items.put(TmDesignEnum.SHOW_PROP, item);
		this.add(item);

		item = new DigiTmMenuItem("Hide Properties", TmDesignEnum.HIDE_PROP.value, this.tmDesignWin);
		items.put(TmDesignEnum.HIDE_PROP, item);
		this.add(item);
		this.add(new JSeparator());

		item = new DigiTmMenuItem("Edit Motif", TmDesignEnum.EDIT_BLOCK.value, this.tmDesignWin);
		items.put(TmDesignEnum.EDIT_BLOCK, item);
		this.add(item);

		item = new DigiTmMenuItem("Cut", TmDesignEnum.CUT.value, this.tmDesignWin);
		items.put(TmDesignEnum.CUT, item);
		this.add(item);

		item = new DigiTmMenuItem("Copy", TmDesignEnum.COPY.value, this.tmDesignWin);
		items.put(TmDesignEnum.COPY, item);
		this.add(item);

		item = new DigiTmMenuItem("Paste", TmDesignEnum.PASTE.value, this.tmDesignWin);
		items.put(TmDesignEnum.PASTE, item);
		this.add(item);
		this.add(new JSeparator());

		item = new DigiTmMenuItem("Remove motif", TmDesignEnum.REMOVE_MOTIF.value, this.tmDesignWin);
		items.put(TmDesignEnum.REMOVE_MOTIF, item);
		this.add(item);
		this.add(new JSeparator());

		item = new DigiTmMenuItem("Move up", TmDesignEnum.MOVE_UP.value, this.tmDesignWin);
		items.put(TmDesignEnum.MOVE_UP, item);
		this.add(item);

		item = new DigiTmMenuItem("Move down", TmDesignEnum.MOVE_DOWN.value, this.tmDesignWin);
		items.put(TmDesignEnum.MOVE_DOWN, item);
		this.add(item);

		item = new DigiTmMenuItem("Flip Vertical (Motif)", TmDesignEnum.FLIP_VERT_MOTIF.value, this.tmDesignWin);
		items.put(TmDesignEnum.FLIP_VERT_MOTIF, item);
		this.add(item);

		item = new DigiTmMenuItem("Flip Horizontal (Motif)", TmDesignEnum.FLIP_HORZ_MOTIF.value, this.tmDesignWin);
		items.put(TmDesignEnum.FLIP_HORZ_MOTIF, item);
		this.add(item);
		this.add(new JSeparator());

		item = new DigiTmMenuItem("Create group copy", TmDesignEnum.COPY_GROUP.value, this.tmDesignWin);
		items.put(TmDesignEnum.COPY_GROUP, item);
		this.add(item);

		item = new DigiTmMenuItem("Remove group", TmDesignEnum.REMOVE_GROUP.value, this.tmDesignWin);
		items.put(TmDesignEnum.REMOVE_GROUP, item);
		this.add(item);

		item = new DigiTmMenuItem("Flip Vertical (Group)", TmDesignEnum.FLIP_VERT.value, this.tmDesignWin);
		items.put(TmDesignEnum.FLIP_VERT, item);
		this.add(item);

		item = new DigiTmMenuItem("Flip Horizontal (Group)", TmDesignEnum.FLIP_HORZ.value, this.tmDesignWin);
		items.put(TmDesignEnum.FLIP_HORZ, item);
		this.add(item);
		this.add(new JSeparator());

		item = new DigiTmMenuItem("Lock", TmDesignEnum.LOCK_MOTIF.value, this.tmDesignWin);
		items.put(TmDesignEnum.LOCK_MOTIF, item);
		this.add(item);

		item = new DigiTmMenuItem("Unlock", TmDesignEnum.UNLOCK_MOTIF.value, this.tmDesignWin);
		items.put(TmDesignEnum.UNLOCK_MOTIF, item);
		this.add(item);

	}

	public void showPopup(Component component, int x, int y, DesignPane designPane)
	{
		MotifPane mPane = designPane.getSelectedMotifPane();
		if (mPane.isHorizontalAlign())
		{
			this.items.get(TmDesignEnum.MOVE_UP).setText("Move left");
			this.items.get(TmDesignEnum.MOVE_DOWN).setText("Move right");
		} else
		{
			this.items.get(TmDesignEnum.MOVE_UP).setText("Move up");
			this.items.get(TmDesignEnum.MOVE_DOWN).setText("Move down");
		}

		if (mPane.isLocked())
		{
			this.items.get(TmDesignEnum.LOCK_MOTIF).setEnabled(false);
			this.items.get(TmDesignEnum.EDIT_BLOCK).setEnabled(false);
			this.items.get(TmDesignEnum.REMOVE_MOTIF).setEnabled(false);
			this.items.get(TmDesignEnum.UNLOCK_MOTIF).setEnabled(true);
		} else
		{
			this.items.get(TmDesignEnum.LOCK_MOTIF).setEnabled(true);
			this.items.get(TmDesignEnum.EDIT_BLOCK).setEnabled(true);
			this.items.get(TmDesignEnum.REMOVE_MOTIF).setEnabled(true);
			this.items.get(TmDesignEnum.UNLOCK_MOTIF).setEnabled(false);
		}

		this.items.get(TmDesignEnum.PASTE).setEnabled(this.isEnablePaste());

		this.items.get(TmDesignEnum.CUT).setEnabled(true);
		this.items.get(TmDesignEnum.COPY).setEnabled(true);

		if (mPane.getList().size() <= 1)
		{
			this.items.get(TmDesignEnum.REMOVE_MOTIF).setEnabled(false);
		} else
		{
			this.items.get(TmDesignEnum.REMOVE_MOTIF).setEnabled(true);
		}

		this.show(component, x, y);
	}

	public boolean isEnablePaste()
	{
		Transferable transfer = Toolkit.getDefaultToolkit().getSystemClipboard().getContents(null);

		if (transfer != null && transfer.isDataFlavorSupported(DataFlavor.imageFlavor))
		{
			return true;
		}

		return this.tmDesignWin.getDesignPane().isBorderCopied();
	}
}
